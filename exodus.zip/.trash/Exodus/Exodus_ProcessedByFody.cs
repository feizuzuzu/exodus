﻿using System;

// Token: 0x02000091 RID: 145
internal class Exodus_ProcessedByFody
{
	// Token: 0x04000228 RID: 552
	internal const string FodyVersion = "6.6.3.0";

	// Token: 0x04000229 RID: 553
	internal const string ReactiveUI = "18.3.1.49589";
}
