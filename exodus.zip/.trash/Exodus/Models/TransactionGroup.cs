﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Runtime.CompilerServices;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.Models
{
	// Token: 0x0200008B RID: 139
	[NullableContext(2)]
	[Nullable(0)]
	public class TransactionGroup : ReactiveObject
	{
		// Token: 0x060003E4 RID: 996 RVA: 0x00035954 File Offset: 0x00033B54
		public TransactionGroup(DateTime date)
		{
			this.Date = date;
			if (date == DateTime.Today)
			{
				this.DateTitle = "Today";
			}
			else if (date == DateTime.Today.AddDays(-1.0))
			{
				this.DateTitle = "Yesterday";
			}
			else
			{
				this.DateTitle = date.ToString("MMM dd, yyyy");
			}
			this.Transactions.CollectionChanged += delegate([Nullable(2)] object sender, NotifyCollectionChangedEventArgs args)
			{
				this.IsThereTransaction = (this.Transactions.Count > 0);
			};
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x060003E5 RID: 997 RVA: 0x000359E7 File Offset: 0x00033BE7
		// (set) Token: 0x060003E6 RID: 998 RVA: 0x000359EF File Offset: 0x00033BEF
		[Reactive]
		public DateTime Date
		{
			[CompilerGenerated]
			get
			{
				return this.$Date;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Date, value, "Date");
			}
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x060003E7 RID: 999 RVA: 0x00035A04 File Offset: 0x00033C04
		// (set) Token: 0x060003E8 RID: 1000 RVA: 0x00035A0C File Offset: 0x00033C0C
		[Reactive]
		public string DateTitle
		{
			[CompilerGenerated]
			get
			{
				return this.$DateTitle;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$DateTitle, value, "DateTitle");
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x060003E9 RID: 1001 RVA: 0x00035A21 File Offset: 0x00033C21
		// (set) Token: 0x060003EA RID: 1002 RVA: 0x00035A29 File Offset: 0x00033C29
		[Reactive]
		public bool IsThereTransaction
		{
			[CompilerGenerated]
			get
			{
				return this.$IsThereTransaction;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsThereTransaction, value, "IsThereTransaction");
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x060003EB RID: 1003 RVA: 0x00035A3E File Offset: 0x00033C3E
		// (set) Token: 0x060003EC RID: 1004 RVA: 0x00035A46 File Offset: 0x00033C46
		[Nullable(new byte[]
		{
			2,
			1
		})]
		[Reactive]
		public ObservableCollection<Transaction> Transactions
		{
			[CompilerGenerated]
			[return: Nullable(new byte[]
			{
				2,
				1
			})]
			get
			{
				return this.$Transactions;
			}
			[CompilerGenerated]
			[param: Nullable(new byte[]
			{
				2,
				1
			})]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Transactions, value, "Transactions");
			}
		} = new ObservableCollection<Transaction>();

		// Token: 0x04000222 RID: 546
		private DateTime $Date;

		// Token: 0x04000223 RID: 547
		private string $DateTitle;

		// Token: 0x04000224 RID: 548
		private bool $IsThereTransaction;

		// Token: 0x04000225 RID: 549
		private ObservableCollection<Transaction> $Transactions;
	}
}
