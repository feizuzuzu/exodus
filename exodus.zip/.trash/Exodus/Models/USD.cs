﻿using System;

namespace Exodus.Models
{
	// Token: 0x0200007D RID: 125
	public class USD
	{
		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000321 RID: 801 RVA: 0x00033971 File Offset: 0x00031B71
		// (set) Token: 0x06000322 RID: 802 RVA: 0x00033979 File Offset: 0x00031B79
		public double price { get; set; }
	}
}
