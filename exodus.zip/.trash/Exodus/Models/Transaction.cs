﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using Avalonia.Media;
using Exodus.Helpers;
using Exodus.Services;
using Newtonsoft.Json;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.Models
{
	// Token: 0x02000085 RID: 133
	[NullableContext(1)]
	[Nullable(0)]
	public class Transaction : ReactiveObject
	{
		// Token: 0x060003B1 RID: 945 RVA: 0x00034FB8 File Offset: 0x000331B8
		public Transaction()
		{
			this.WhenAnyValue((Transaction x) => x.Amount).Subscribe(delegate(double x)
			{
				this.FormattedAmount = NumberFormatHelper.FormatCrypto(x, 8);
			});
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x00035028 File Offset: 0x00033228
		public void SetConst(double amount, Coin coin, bool isInitializedWithData = false)
		{
			this.MyCoin = coin;
			this.WhenAnyValue((Transaction x) => x.Time).Subscribe(delegate(long x)
			{
				this.SetTimeString();
				this.UpdateRelativeTime();
			});
			this.WhenAnyValue((Transaction x) => x.Amount).Subscribe(delegate(double x)
			{
				this.SetPriceNow(this.MyCoin.Id);
				this.FormattedAmount = NumberFormatHelper.FormatCrypto(x, 8);
			});
			TransactionService.Instance.PriceUpdated += delegate([Nullable(2)] object sender, EventArgs args)
			{
				this.SetPriceNow(this.MyCoin.Id);
			};
			if (!isInitializedWithData)
			{
				this.Id = Guid.NewGuid().GetHashCode();
				this.TransactionId = ((this.MyCoin.Symbol == "ETH") ? this.MyCoin.StartValue : "") + TransactionService.Instance.RandomString(56);
				this.From = this.MyCoin.StartValue + TransactionService.Instance.RandomString(39);
				this.To = ((!string.IsNullOrEmpty(this.MyCoin.Address)) ? this.MyCoin.Address : (this.MyCoin.StartValue + TransactionService.Instance.RandomString(39)));
				this.Time = DateTimeOffset.Now.ToUnixTimeSeconds();
				this.PriceByTheTime = Math.Round(double.Parse(this.PriceNow.ToString(CultureInfo.InvariantCulture)), 2);
			}
			this.Amount = Math.Round(amount, 9);
			this.SetTimeString();
			this.UpdateRelativeTime();
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x00035208 File Offset: 0x00033408
		public void UpdateRelativeTime()
		{
			if (this.Time <= 0L)
			{
				return;
			}
			long diff = DateTimeOffset.Now.ToUnixTimeSeconds() - this.Time;
			if (diff < 0L)
			{
				diff = 0L;
			}
			if (diff < 60L)
			{
				this.SentDurationsAgo = "just now";
				return;
			}
			if (diff < 3600L)
			{
				long mins = diff / 60L;
				string sentDurationsAgo;
				if (mins != 1L)
				{
					DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(12, 1);
					defaultInterpolatedStringHandler.AppendFormatted<long>(mins);
					defaultInterpolatedStringHandler.AppendLiteral(" minutes ago");
					sentDurationsAgo = defaultInterpolatedStringHandler.ToStringAndClear();
				}
				else
				{
					sentDurationsAgo = "1 minute ago";
				}
				this.SentDurationsAgo = sentDurationsAgo;
				return;
			}
			if (diff < 86400L)
			{
				long hours = diff / 3600L;
				string sentDurationsAgo2;
				if (hours != 1L)
				{
					DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(10, 1);
					defaultInterpolatedStringHandler.AppendFormatted<long>(hours);
					defaultInterpolatedStringHandler.AppendLiteral(" hours ago");
					sentDurationsAgo2 = defaultInterpolatedStringHandler.ToStringAndClear();
				}
				else
				{
					sentDurationsAgo2 = "1 hour ago";
				}
				this.SentDurationsAgo = sentDurationsAgo2;
				return;
			}
			if (diff < 172800L)
			{
				this.SentDurationsAgo = "yesterday";
				return;
			}
			if (diff < 2592000L)
			{
				long days = diff / 86400L;
				string sentDurationsAgo3;
				if (days != 1L)
				{
					DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(9, 1);
					defaultInterpolatedStringHandler.AppendFormatted<long>(days);
					defaultInterpolatedStringHandler.AppendLiteral(" days ago");
					sentDurationsAgo3 = defaultInterpolatedStringHandler.ToStringAndClear();
				}
				else
				{
					sentDurationsAgo3 = "1 day ago";
				}
				this.SentDurationsAgo = sentDurationsAgo3;
				return;
			}
			if (diff < 31536000L)
			{
				long months = diff / 2592000L;
				string sentDurationsAgo4;
				if (months != 1L)
				{
					DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(11, 1);
					defaultInterpolatedStringHandler.AppendFormatted<long>(months);
					defaultInterpolatedStringHandler.AppendLiteral(" months ago");
					sentDurationsAgo4 = defaultInterpolatedStringHandler.ToStringAndClear();
				}
				else
				{
					sentDurationsAgo4 = "1 month ago";
				}
				this.SentDurationsAgo = sentDurationsAgo4;
				return;
			}
			long years = diff / 31536000L;
			string sentDurationsAgo5;
			if (years != 1L)
			{
				DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(10, 1);
				defaultInterpolatedStringHandler.AppendFormatted<long>(years);
				defaultInterpolatedStringHandler.AppendLiteral(" years ago");
				sentDurationsAgo5 = defaultInterpolatedStringHandler.ToStringAndClear();
			}
			else
			{
				sentDurationsAgo5 = "1 year ago";
			}
			this.SentDurationsAgo = sentDurationsAgo5;
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x000353D8 File Offset: 0x000335D8
		private void SetTimeString()
		{
			Transaction.<SetTimeString>d__3 <SetTimeString>d__;
			<SetTimeString>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<SetTimeString>d__.<>4__this = this;
			<SetTimeString>d__.<>1__state = -1;
			<SetTimeString>d__.<>t__builder.Start<Transaction.<SetTimeString>d__3>(ref <SetTimeString>d__);
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x00035410 File Offset: 0x00033610
		public void SetPriceNow(int index)
		{
			Transaction.<SetPriceNow>d__4 <SetPriceNow>d__;
			<SetPriceNow>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<SetPriceNow>d__.<>4__this = this;
			<SetPriceNow>d__.index = index;
			<SetPriceNow>d__.<>1__state = -1;
			<SetPriceNow>d__.<>t__builder.Start<Transaction.<SetPriceNow>d__4>(ref <SetPriceNow>d__);
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x060003B6 RID: 950 RVA: 0x0003544F File Offset: 0x0003364F
		// (set) Token: 0x060003B7 RID: 951 RVA: 0x00035457 File Offset: 0x00033657
		public Coin MyCoin { get; set; }

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x060003B8 RID: 952 RVA: 0x00035460 File Offset: 0x00033660
		// (set) Token: 0x060003B9 RID: 953 RVA: 0x00035468 File Offset: 0x00033668
		[JsonProperty]
		public int Id { get; set; }

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x060003BA RID: 954 RVA: 0x00035471 File Offset: 0x00033671
		// (set) Token: 0x060003BB RID: 955 RVA: 0x00035479 File Offset: 0x00033679
		[JsonProperty]
		[Reactive]
		public long Time
		{
			[CompilerGenerated]
			get
			{
				return this.$Time;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Time, value, "Time");
			}
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x060003BC RID: 956 RVA: 0x0003548E File Offset: 0x0003368E
		// (set) Token: 0x060003BD RID: 957 RVA: 0x00035496 File Offset: 0x00033696
		[JsonProperty]
		[Reactive]
		public string TimeString
		{
			[CompilerGenerated]
			get
			{
				return this.$TimeString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TimeString, value, "TimeString");
			}
		}

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x060003BE RID: 958 RVA: 0x000354AB File Offset: 0x000336AB
		// (set) Token: 0x060003BF RID: 959 RVA: 0x000354B3 File Offset: 0x000336B3
		[JsonProperty]
		[Reactive]
		public string SentDurationsAgo
		{
			[CompilerGenerated]
			get
			{
				return this.$SentDurationsAgo;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SentDurationsAgo, value, "SentDurationsAgo");
			}
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x060003C0 RID: 960 RVA: 0x000354C8 File Offset: 0x000336C8
		// (set) Token: 0x060003C1 RID: 961 RVA: 0x000354D0 File Offset: 0x000336D0
		[JsonProperty]
		[Reactive]
		public string TransactionId
		{
			[CompilerGenerated]
			get
			{
				return this.$TransactionId;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TransactionId, value, "TransactionId");
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x060003C2 RID: 962 RVA: 0x000354E5 File Offset: 0x000336E5
		// (set) Token: 0x060003C3 RID: 963 RVA: 0x000354ED File Offset: 0x000336ED
		[JsonProperty]
		[Reactive]
		public string From
		{
			[CompilerGenerated]
			get
			{
				return this.$From;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$From, value, "From");
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x060003C4 RID: 964 RVA: 0x00035502 File Offset: 0x00033702
		// (set) Token: 0x060003C5 RID: 965 RVA: 0x0003550A File Offset: 0x0003370A
		[JsonProperty]
		[Reactive]
		public string To
		{
			[CompilerGenerated]
			get
			{
				return this.$To;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$To, value, "To");
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x060003C6 RID: 966 RVA: 0x0003551F File Offset: 0x0003371F
		// (set) Token: 0x060003C7 RID: 967 RVA: 0x00035527 File Offset: 0x00033727
		[JsonProperty]
		[Reactive]
		public double Amount
		{
			[CompilerGenerated]
			get
			{
				return this.$Amount;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Amount, value, "Amount");
			}
		}

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x060003C8 RID: 968 RVA: 0x0003553C File Offset: 0x0003373C
		// (set) Token: 0x060003C9 RID: 969 RVA: 0x00035544 File Offset: 0x00033744
		[JsonProperty]
		[Reactive]
		public string FormattedAmount
		{
			[CompilerGenerated]
			get
			{
				return this.$FormattedAmount;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$FormattedAmount, value, "FormattedAmount");
			}
		} = "0";

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x060003CA RID: 970 RVA: 0x00035559 File Offset: 0x00033759
		// (set) Token: 0x060003CB RID: 971 RVA: 0x00035561 File Offset: 0x00033761
		[JsonProperty]
		[Reactive]
		public double PriceNow
		{
			[CompilerGenerated]
			get
			{
				return this.$PriceNow;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PriceNow, value, "PriceNow");
			}
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x060003CC RID: 972 RVA: 0x00035576 File Offset: 0x00033776
		// (set) Token: 0x060003CD RID: 973 RVA: 0x0003557E File Offset: 0x0003377E
		[JsonProperty]
		[Reactive]
		public string PriceNowString
		{
			[CompilerGenerated]
			get
			{
				return this.$PriceNowString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PriceNowString, value, "PriceNowString");
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x060003CE RID: 974 RVA: 0x00035593 File Offset: 0x00033793
		// (set) Token: 0x060003CF RID: 975 RVA: 0x0003559B File Offset: 0x0003379B
		[JsonProperty]
		[Reactive]
		public double PriceByTheTime
		{
			[CompilerGenerated]
			get
			{
				return this.$PriceByTheTime;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PriceByTheTime, value, "PriceByTheTime");
			}
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x060003D0 RID: 976 RVA: 0x000355B0 File Offset: 0x000337B0
		// (set) Token: 0x060003D1 RID: 977 RVA: 0x000355B8 File Offset: 0x000337B8
		[Reactive]
		public bool IsExpanded
		{
			[CompilerGenerated]
			get
			{
				return this.$IsExpanded;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsExpanded, value, "IsExpanded");
			}
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x060003D2 RID: 978 RVA: 0x000355CD File Offset: 0x000337CD
		// (set) Token: 0x060003D3 RID: 979 RVA: 0x000355D5 File Offset: 0x000337D5
		[Reactive]
		public SolidColorBrush HeaderBackgroundColor
		{
			[CompilerGenerated]
			get
			{
				return this.$HeaderBackgroundColor;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$HeaderBackgroundColor, value, "HeaderBackgroundColor");
			}
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x000355EC File Offset: 0x000337EC
		public void ExpandCommand()
		{
			Transaction.<ExpandCommand>d__65 <ExpandCommand>d__;
			<ExpandCommand>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ExpandCommand>d__.<>4__this = this;
			<ExpandCommand>d__.<>1__state = -1;
			<ExpandCommand>d__.<>t__builder.Start<Transaction.<ExpandCommand>d__65>(ref <ExpandCommand>d__);
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x00035624 File Offset: 0x00033824
		public void OpenTransactionLook()
		{
			Transaction.<OpenTransactionLook>d__66 <OpenTransactionLook>d__;
			<OpenTransactionLook>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<OpenTransactionLook>d__.<>4__this = this;
			<OpenTransactionLook>d__.<>1__state = -1;
			<OpenTransactionLook>d__.<>t__builder.Start<Transaction.<OpenTransactionLook>d__66>(ref <OpenTransactionLook>d__);
		}

		// Token: 0x04000207 RID: 519
		private long $Time;

		// Token: 0x04000208 RID: 520
		private string $TimeString;

		// Token: 0x04000209 RID: 521
		private string $SentDurationsAgo;

		// Token: 0x0400020A RID: 522
		private string $TransactionId;

		// Token: 0x0400020B RID: 523
		private string $From;

		// Token: 0x0400020C RID: 524
		private string $To;

		// Token: 0x0400020D RID: 525
		private double $Amount;

		// Token: 0x0400020E RID: 526
		private string $FormattedAmount;

		// Token: 0x0400020F RID: 527
		private double $PriceNow;

		// Token: 0x04000210 RID: 528
		private string $PriceNowString;

		// Token: 0x04000211 RID: 529
		private double $PriceByTheTime;

		// Token: 0x04000212 RID: 530
		private bool $IsExpanded;

		// Token: 0x04000213 RID: 531
		private SolidColorBrush $HeaderBackgroundColor;
	}
}
