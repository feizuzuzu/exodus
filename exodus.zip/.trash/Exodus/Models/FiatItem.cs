﻿using System;
using System.Runtime.CompilerServices;

namespace Exodus.Models
{
	// Token: 0x02000080 RID: 128
	[NullableContext(1)]
	[Nullable(0)]
	public class FiatItem
	{
		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x06000346 RID: 838 RVA: 0x00033C39 File Offset: 0x00031E39
		// (set) Token: 0x06000347 RID: 839 RVA: 0x00033C41 File Offset: 0x00031E41
		public string Code { get; set; } = "USD";

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x06000348 RID: 840 RVA: 0x00033C4A File Offset: 0x00031E4A
		// (set) Token: 0x06000349 RID: 841 RVA: 0x00033C52 File Offset: 0x00031E52
		public string Name { get; set; } = "United States Dollar";

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x0600034A RID: 842 RVA: 0x00033C5B File Offset: 0x00031E5B
		// (set) Token: 0x0600034B RID: 843 RVA: 0x00033C63 File Offset: 0x00031E63
		public string Symbol { get; set; } = "$";

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x0600034C RID: 844 RVA: 0x00033C6C File Offset: 0x00031E6C
		// (set) Token: 0x0600034D RID: 845 RVA: 0x00033C74 File Offset: 0x00031E74
		public string FlagEmoji { get; set; } = "\ud83c\uddfa\ud83c\uddf8";

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x0600034E RID: 846 RVA: 0x00033C7D File Offset: 0x00031E7D
		// (set) Token: 0x0600034F RID: 847 RVA: 0x00033C85 File Offset: 0x00031E85
		public double RateToUsd { get; set; } = 1.0;

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x06000350 RID: 848 RVA: 0x00033C8E File Offset: 0x00031E8E
		public string DisplayText
		{
			get
			{
				return this.Code + " - " + this.Name;
			}
		}
	}
}
