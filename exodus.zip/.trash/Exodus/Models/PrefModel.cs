﻿using System;
using System.Collections.ObjectModel;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;

namespace Exodus.Models
{
	// Token: 0x02000083 RID: 131
	public class PrefModel
	{
		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000394 RID: 916 RVA: 0x00034A18 File Offset: 0x00032C18
		// (set) Token: 0x06000395 RID: 917 RVA: 0x00034A20 File Offset: 0x00032C20
		[Nullable(new byte[]
		{
			2,
			1
		})]
		[JsonProperty]
		public ObservableCollection<Coin> Coins { [return: Nullable(new byte[]
		{
			2,
			1
		})] get; [param: Nullable(new byte[]
		{
			2,
			1
		})] set; }
	}
}
