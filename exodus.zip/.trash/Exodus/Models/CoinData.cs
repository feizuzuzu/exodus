﻿using System;
using System.Runtime.CompilerServices;

namespace Exodus.Models
{
	// Token: 0x0200007B RID: 123
	[NullableContext(1)]
	[Nullable(0)]
	public class CoinData
	{
		// Token: 0x170000AF RID: 175
		// (get) Token: 0x0600031B RID: 795 RVA: 0x0003394F File Offset: 0x00031B4F
		// (set) Token: 0x0600031C RID: 796 RVA: 0x00033957 File Offset: 0x00031B57
		public Quote quote { get; set; }
	}
}
