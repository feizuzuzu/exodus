﻿using System;
using System.Runtime.CompilerServices;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using Exodus.Helpers;
using Exodus.Services;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.Models
{
	// Token: 0x02000084 RID: 132
	[NullableContext(1)]
	[Nullable(0)]
	public class SwapCoinItem : ReactiveObject
	{
		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x06000397 RID: 919 RVA: 0x00034A29 File Offset: 0x00032C29
		public Coin OriginalCoin { get; }

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x06000398 RID: 920 RVA: 0x00034A31 File Offset: 0x00032C31
		// (set) Token: 0x06000399 RID: 921 RVA: 0x00034A39 File Offset: 0x00032C39
		[Reactive]
		public int Id
		{
			[CompilerGenerated]
			get
			{
				return this.$Id;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Id, value, "Id");
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x0600039A RID: 922 RVA: 0x00034A4E File Offset: 0x00032C4E
		// (set) Token: 0x0600039B RID: 923 RVA: 0x00034A56 File Offset: 0x00032C56
		[Reactive]
		public string Name
		{
			[CompilerGenerated]
			get
			{
				return this.$Name;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Name, value, "Name");
			}
		} = "";

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x0600039C RID: 924 RVA: 0x00034A6B File Offset: 0x00032C6B
		// (set) Token: 0x0600039D RID: 925 RVA: 0x00034A73 File Offset: 0x00032C73
		[Reactive]
		public string Symbol
		{
			[CompilerGenerated]
			get
			{
				return this.$Symbol;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Symbol, value, "Symbol");
			}
		} = "";

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x0600039E RID: 926 RVA: 0x00034A88 File Offset: 0x00032C88
		// (set) Token: 0x0600039F RID: 927 RVA: 0x00034A90 File Offset: 0x00032C90
		[Reactive]
		public string SubNetwork
		{
			[CompilerGenerated]
			get
			{
				return this.$SubNetwork;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SubNetwork, value, "SubNetwork");
			}
		} = "";

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x060003A0 RID: 928 RVA: 0x00034AA5 File Offset: 0x00032CA5
		// (set) Token: 0x060003A1 RID: 929 RVA: 0x00034AAD File Offset: 0x00032CAD
		[Nullable(2)]
		[Reactive]
		public Bitmap Icon
		{
			[NullableContext(2)]
			[CompilerGenerated]
			get
			{
				return this.$Icon;
			}
			[NullableContext(2)]
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Icon, value, "Icon");
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x060003A2 RID: 930 RVA: 0x00034AC2 File Offset: 0x00032CC2
		// (set) Token: 0x060003A3 RID: 931 RVA: 0x00034ACA File Offset: 0x00032CCA
		[Reactive]
		public double Balance
		{
			[CompilerGenerated]
			get
			{
				return this.$Balance;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Balance, value, "Balance");
			}
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x060003A4 RID: 932 RVA: 0x00034ADF File Offset: 0x00032CDF
		// (set) Token: 0x060003A5 RID: 933 RVA: 0x00034AE7 File Offset: 0x00032CE7
		[Reactive]
		public string FormattedBalance
		{
			[CompilerGenerated]
			get
			{
				return this.$FormattedBalance;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$FormattedBalance, value, "FormattedBalance");
			}
		} = "0";

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x060003A6 RID: 934 RVA: 0x00034AFC File Offset: 0x00032CFC
		// (set) Token: 0x060003A7 RID: 935 RVA: 0x00034B04 File Offset: 0x00032D04
		[Reactive]
		public double PriceUsd
		{
			[CompilerGenerated]
			get
			{
				return this.$PriceUsd;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PriceUsd, value, "PriceUsd");
			}
		}

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x060003A8 RID: 936 RVA: 0x00034B19 File Offset: 0x00032D19
		// (set) Token: 0x060003A9 RID: 937 RVA: 0x00034B21 File Offset: 0x00032D21
		[Reactive]
		public double ValueInUsd
		{
			[CompilerGenerated]
			get
			{
				return this.$ValueInUsd;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ValueInUsd, value, "ValueInUsd");
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x060003AA RID: 938 RVA: 0x00034B36 File Offset: 0x00032D36
		// (set) Token: 0x060003AB RID: 939 RVA: 0x00034B3E File Offset: 0x00032D3E
		[Reactive]
		public string ValueInUsdString
		{
			[CompilerGenerated]
			get
			{
				return this.$ValueInUsdString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ValueInUsdString, value, "ValueInUsdString");
			}
		} = "$0.00";

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x060003AC RID: 940 RVA: 0x00034B53 File Offset: 0x00032D53
		// (set) Token: 0x060003AD RID: 941 RVA: 0x00034B5B File Offset: 0x00032D5B
		[Reactive]
		public string DisplaySubtitle
		{
			[CompilerGenerated]
			get
			{
				return this.$DisplaySubtitle;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$DisplaySubtitle, value, "DisplaySubtitle");
			}
		} = "";

		// Token: 0x060003AE RID: 942 RVA: 0x00034B70 File Offset: 0x00032D70
		public SwapCoinItem(Coin coin)
		{
			this.OriginalCoin = coin;
			this.Id = coin.Id;
			this.Name = coin.Name;
			this.Symbol = coin.Symbol;
			string symbol = coin.Symbol;
			string subNetwork;
			if (!(symbol == "USDT"))
			{
				if (!(symbol == "BNB"))
				{
					subNetwork = coin.Symbol;
				}
				else
				{
					subNetwork = "BSC";
				}
			}
			else
			{
				subNetwork = "TRX";
			}
			this.SubNetwork = subNetwork;
			this.RefreshBalance();
			this.LoadIcon(this.Symbol);
		}

		// Token: 0x060003AF RID: 943 RVA: 0x00034C44 File Offset: 0x00032E44
		public void RefreshBalance()
		{
			this.Balance = this.OriginalCoin.Balance;
			this.FormattedBalance = NumberFormatHelper.FormatCrypto(this.Balance, 8);
			this.PriceUsd = TransactionService.Instance.GetPrice(this.Symbol);
			this.ValueInUsd = this.Balance * this.PriceUsd;
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
			defaultInterpolatedStringHandler.AppendLiteral("$");
			defaultInterpolatedStringHandler.AppendFormatted<double>(this.ValueInUsd, "N2");
			this.ValueInUsdString = defaultInterpolatedStringHandler.ToStringAndClear();
			this.DisplaySubtitle = this.FormattedBalance + " " + this.Symbol;
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x00034CF0 File Offset: 0x00032EF0
		private void LoadIcon(string symbol)
		{
			string text = symbol.ToUpper();
			string text2;
			if (text != null)
			{
				int length = text.Length;
				if (length != 3)
				{
					if (length == 4)
					{
						char c = text[3];
						if (c <= 'E')
						{
							if (c != 'C')
							{
								if (c == 'E')
								{
									if (text == "DOGE")
									{
										text2 = "avares://Exodus/Assets/Resources/Icons/doge.png";
										goto IL_28D;
									}
								}
							}
							else if (text == "USDC")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/usdc.png";
								goto IL_28D;
							}
						}
						else if (c != 'K')
						{
							if (c == 'T')
							{
								if (text == "USDT")
								{
									text2 = "avares://Exodus/Assets/Resources/Icons/tether.png";
									goto IL_28D;
								}
							}
						}
						else if (text == "LINK")
						{
							text2 = "avares://Exodus/Assets/Resources/Icons/link.png";
							goto IL_28D;
						}
					}
				}
				else
				{
					char c = text[2];
					if (c <= 'H')
					{
						switch (c)
						{
						case 'A':
							if (text == "ADA")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/ada.png";
								goto IL_28D;
							}
							break;
						case 'B':
							if (text == "BNB")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/bnb.png";
								goto IL_28D;
							}
							break;
						case 'C':
							if (text == "BTC")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/bitcoin.png";
								goto IL_28D;
							}
							if (text == "LTC")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/ltc.png";
								goto IL_28D;
							}
							break;
						default:
							if (c == 'H')
							{
								if (text == "ETH")
								{
									text2 = "avares://Exodus/Assets/Resources/Icons/ethereum_1.png";
									goto IL_28D;
								}
								if (text == "BCH")
								{
									text2 = "avares://Exodus/Assets/Resources/Icons/bch.png";
									goto IL_28D;
								}
							}
							break;
						}
					}
					else
					{
						switch (c)
						{
						case 'L':
							if (text == "SOL")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/solana.png";
								goto IL_28D;
							}
							break;
						case 'M':
							if (text == "XLM")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/xlm.png";
								goto IL_28D;
							}
							break;
						case 'N':
						case 'O':
						case 'Q':
						case 'S':
							break;
						case 'P':
							if (text == "XRP")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/xrp.png";
								goto IL_28D;
							}
							break;
						case 'R':
							if (text == "XMR")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/xmr.png";
								goto IL_28D;
							}
							break;
						case 'T':
							if (text == "DOT")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/dot.png";
								goto IL_28D;
							}
							break;
						default:
							if (c == 'X')
							{
								if (text == "TRX")
								{
									text2 = "avares://Exodus/Assets/Resources/Icons/tron.png";
									goto IL_28D;
								}
							}
							break;
						}
					}
				}
			}
			text2 = "avares://Exodus/Assets/Resources/Icons/bitcoin.png";
			IL_28D:
			string path = text2;
			try
			{
				this.Icon = new Bitmap(AssetLoader.Open(new Uri(path), null));
			}
			catch
			{
			}
		}

		// Token: 0x040001FA RID: 506
		private int $Id;

		// Token: 0x040001FB RID: 507
		private string $Name;

		// Token: 0x040001FC RID: 508
		private string $Symbol;

		// Token: 0x040001FD RID: 509
		private string $SubNetwork;

		// Token: 0x040001FE RID: 510
		private Bitmap $Icon;

		// Token: 0x040001FF RID: 511
		private double $Balance;

		// Token: 0x04000200 RID: 512
		private string $FormattedBalance;

		// Token: 0x04000201 RID: 513
		private double $PriceUsd;

		// Token: 0x04000202 RID: 514
		private double $ValueInUsd;

		// Token: 0x04000203 RID: 515
		private string $ValueInUsdString;

		// Token: 0x04000204 RID: 516
		private string $DisplaySubtitle;
	}
}
