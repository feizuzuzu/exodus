﻿using System;
using System.Runtime.CompilerServices;
using Avalonia.Media;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.Models
{
	// Token: 0x02000081 RID: 129
	[NullableContext(1)]
	[Nullable(0)]
	public class DonutSegment : ReactiveObject
	{
		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06000352 RID: 850 RVA: 0x00033CF6 File Offset: 0x00031EF6
		// (set) Token: 0x06000353 RID: 851 RVA: 0x00033CFE File Offset: 0x00031EFE
		[Reactive]
		public string Name
		{
			[CompilerGenerated]
			get
			{
				return this.$Name;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Name, value, "Name");
			}
		} = "";

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06000354 RID: 852 RVA: 0x00033D13 File Offset: 0x00031F13
		// (set) Token: 0x06000355 RID: 853 RVA: 0x00033D1B File Offset: 0x00031F1B
		[Reactive]
		public string Symbol
		{
			[CompilerGenerated]
			get
			{
				return this.$Symbol;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Symbol, value, "Symbol");
			}
		} = "";

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06000356 RID: 854 RVA: 0x00033D30 File Offset: 0x00031F30
		// (set) Token: 0x06000357 RID: 855 RVA: 0x00033D38 File Offset: 0x00031F38
		[Reactive]
		public double Percentage
		{
			[CompilerGenerated]
			get
			{
				return this.$Percentage;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Percentage, value, "Percentage");
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x06000358 RID: 856 RVA: 0x00033D4D File Offset: 0x00031F4D
		// (set) Token: 0x06000359 RID: 857 RVA: 0x00033D55 File Offset: 0x00031F55
		[Reactive]
		public IBrush Brush
		{
			[CompilerGenerated]
			get
			{
				return this.$Brush;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Brush, value, "Brush");
			}
		} = Brushes.White;

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x0600035A RID: 858 RVA: 0x00033D6A File Offset: 0x00031F6A
		// (set) Token: 0x0600035B RID: 859 RVA: 0x00033D72 File Offset: 0x00031F72
		[Reactive]
		public string PathData
		{
			[CompilerGenerated]
			get
			{
				return this.$PathData;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PathData, value, "PathData");
			}
		} = "";

		// Token: 0x040001D9 RID: 473
		private string $Name;

		// Token: 0x040001DA RID: 474
		private string $Symbol;

		// Token: 0x040001DB RID: 475
		private double $Percentage;

		// Token: 0x040001DC RID: 476
		private IBrush $Brush;

		// Token: 0x040001DD RID: 477
		private string $PathData;
	}
}
