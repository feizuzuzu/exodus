﻿using System;
using System.Runtime.CompilerServices;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.Models
{
	// Token: 0x02000082 RID: 130
	[NullableContext(1)]
	[Nullable(0)]
	public class PortfolioCoinItem : ReactiveObject
	{
		// Token: 0x170000CC RID: 204
		// (get) Token: 0x0600035D RID: 861 RVA: 0x00033DBB File Offset: 0x00031FBB
		// (set) Token: 0x0600035E RID: 862 RVA: 0x00033DC3 File Offset: 0x00031FC3
		public Coin OriginalCoin { get; set; }

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x0600035F RID: 863 RVA: 0x00033DCC File Offset: 0x00031FCC
		// (set) Token: 0x06000360 RID: 864 RVA: 0x00033DD4 File Offset: 0x00031FD4
		[Reactive]
		public int Id
		{
			[CompilerGenerated]
			get
			{
				return this.$Id;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Id, value, "Id");
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x06000361 RID: 865 RVA: 0x00033DE9 File Offset: 0x00031FE9
		// (set) Token: 0x06000362 RID: 866 RVA: 0x00033DF1 File Offset: 0x00031FF1
		[Reactive]
		public string Name
		{
			[CompilerGenerated]
			get
			{
				return this.$Name;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Name, value, "Name");
			}
		} = "";

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x06000363 RID: 867 RVA: 0x00033E06 File Offset: 0x00032006
		// (set) Token: 0x06000364 RID: 868 RVA: 0x00033E0E File Offset: 0x0003200E
		[Reactive]
		public string Symbol
		{
			[CompilerGenerated]
			get
			{
				return this.$Symbol;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Symbol, value, "Symbol");
			}
		} = "";

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x06000365 RID: 869 RVA: 0x00033E23 File Offset: 0x00032023
		// (set) Token: 0x06000366 RID: 870 RVA: 0x00033E2B File Offset: 0x0003202B
		[Nullable(2)]
		[Reactive]
		public Bitmap Icon
		{
			[NullableContext(2)]
			[CompilerGenerated]
			get
			{
				return this.$Icon;
			}
			[NullableContext(2)]
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Icon, value, "Icon");
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x06000367 RID: 871 RVA: 0x00033E40 File Offset: 0x00032040
		// (set) Token: 0x06000368 RID: 872 RVA: 0x00033E48 File Offset: 0x00032048
		[Reactive]
		public bool IsBsc
		{
			[CompilerGenerated]
			get
			{
				return this.$IsBsc;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsBsc, value, "IsBsc");
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x06000369 RID: 873 RVA: 0x00033E5D File Offset: 0x0003205D
		// (set) Token: 0x0600036A RID: 874 RVA: 0x00033E65 File Offset: 0x00032065
		[Reactive]
		public bool HasDropdown
		{
			[CompilerGenerated]
			get
			{
				return this.$HasDropdown;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$HasDropdown, value, "HasDropdown");
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x0600036B RID: 875 RVA: 0x00033E7A File Offset: 0x0003207A
		// (set) Token: 0x0600036C RID: 876 RVA: 0x00033E82 File Offset: 0x00032082
		[Reactive]
		public string ApyText
		{
			[CompilerGenerated]
			get
			{
				return this.$ApyText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ApyText, value, "ApyText");
			}
		} = "";

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x0600036D RID: 877 RVA: 0x00033E97 File Offset: 0x00032097
		// (set) Token: 0x0600036E RID: 878 RVA: 0x00033E9F File Offset: 0x0003209F
		[Reactive]
		public bool HasApy
		{
			[CompilerGenerated]
			get
			{
				return this.$HasApy;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$HasApy, value, "HasApy");
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x0600036F RID: 879 RVA: 0x00033EB4 File Offset: 0x000320B4
		// (set) Token: 0x06000370 RID: 880 RVA: 0x00033EBC File Offset: 0x000320BC
		[Reactive]
		public double Price
		{
			[CompilerGenerated]
			get
			{
				return this.$Price;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Price, value, "Price");
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x06000371 RID: 881 RVA: 0x00033ED1 File Offset: 0x000320D1
		// (set) Token: 0x06000372 RID: 882 RVA: 0x00033ED9 File Offset: 0x000320D9
		[Reactive]
		public string PriceString
		{
			[CompilerGenerated]
			get
			{
				return this.$PriceString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PriceString, value, "PriceString");
			}
		} = "$0.00";

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x06000373 RID: 883 RVA: 0x00033EEE File Offset: 0x000320EE
		// (set) Token: 0x06000374 RID: 884 RVA: 0x00033EF6 File Offset: 0x000320F6
		[Reactive]
		public double Change24H
		{
			[CompilerGenerated]
			get
			{
				return this.$Change24H;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Change24H, value, "Change24H");
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x06000375 RID: 885 RVA: 0x00033F0B File Offset: 0x0003210B
		// (set) Token: 0x06000376 RID: 886 RVA: 0x00033F13 File Offset: 0x00032113
		[Reactive]
		public string Change24HString
		{
			[CompilerGenerated]
			get
			{
				return this.$Change24HString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Change24HString, value, "Change24HString");
			}
		} = "+0.00%";

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x06000377 RID: 887 RVA: 0x00033F28 File Offset: 0x00032128
		// (set) Token: 0x06000378 RID: 888 RVA: 0x00033F30 File Offset: 0x00032130
		[Reactive]
		public bool IsPositiveChange
		{
			[CompilerGenerated]
			get
			{
				return this.$IsPositiveChange;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsPositiveChange, value, "IsPositiveChange");
			}
		} = true;

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x06000379 RID: 889 RVA: 0x00033F45 File Offset: 0x00032145
		// (set) Token: 0x0600037A RID: 890 RVA: 0x00033F4D File Offset: 0x0003214D
		[Reactive]
		public IBrush ChangeBrush
		{
			[CompilerGenerated]
			get
			{
				return this.$ChangeBrush;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ChangeBrush, value, "ChangeBrush");
			}
		} = Brushes.LimeGreen;

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x0600037B RID: 891 RVA: 0x00033F62 File Offset: 0x00032162
		// (set) Token: 0x0600037C RID: 892 RVA: 0x00033F6A File Offset: 0x0003216A
		[Reactive]
		public string MarketCap
		{
			[CompilerGenerated]
			get
			{
				return this.$MarketCap;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$MarketCap, value, "MarketCap");
			}
		} = "$0.00";

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x0600037D RID: 893 RVA: 0x00033F7F File Offset: 0x0003217F
		// (set) Token: 0x0600037E RID: 894 RVA: 0x00033F87 File Offset: 0x00032187
		[Reactive]
		public string Volume24H
		{
			[CompilerGenerated]
			get
			{
				return this.$Volume24H;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Volume24H, value, "Volume24H");
			}
		} = "$0.00";

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x0600037F RID: 895 RVA: 0x00033F9C File Offset: 0x0003219C
		// (set) Token: 0x06000380 RID: 896 RVA: 0x00033FA4 File Offset: 0x000321A4
		[Reactive]
		public string TrendPath
		{
			[CompilerGenerated]
			get
			{
				return this.$TrendPath;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TrendPath, value, "TrendPath");
			}
		} = "";

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x06000381 RID: 897 RVA: 0x00033FB9 File Offset: 0x000321B9
		// (set) Token: 0x06000382 RID: 898 RVA: 0x00033FC1 File Offset: 0x000321C1
		[Reactive]
		public IBrush TrendBrush
		{
			[CompilerGenerated]
			get
			{
				return this.$TrendBrush;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TrendBrush, value, "TrendBrush");
			}
		} = Brushes.White;

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x06000383 RID: 899 RVA: 0x00033FD6 File Offset: 0x000321D6
		// (set) Token: 0x06000384 RID: 900 RVA: 0x00033FDE File Offset: 0x000321DE
		[Reactive]
		public double Balance
		{
			[CompilerGenerated]
			get
			{
				return this.$Balance;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Balance, value, "Balance");
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x06000385 RID: 901 RVA: 0x00033FF3 File Offset: 0x000321F3
		// (set) Token: 0x06000386 RID: 902 RVA: 0x00033FFB File Offset: 0x000321FB
		[Reactive]
		public string BalanceString
		{
			[CompilerGenerated]
			get
			{
				return this.$BalanceString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$BalanceString, value, "BalanceString");
			}
		} = "0.00";

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x06000387 RID: 903 RVA: 0x00034010 File Offset: 0x00032210
		// (set) Token: 0x06000388 RID: 904 RVA: 0x00034018 File Offset: 0x00032218
		[Reactive]
		public double ValueInUsd
		{
			[CompilerGenerated]
			get
			{
				return this.$ValueInUsd;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ValueInUsd, value, "ValueInUsd");
			}
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x06000389 RID: 905 RVA: 0x0003402D File Offset: 0x0003222D
		// (set) Token: 0x0600038A RID: 906 RVA: 0x00034035 File Offset: 0x00032235
		[Reactive]
		public string ValueInUsdString
		{
			[CompilerGenerated]
			get
			{
				return this.$ValueInUsdString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ValueInUsdString, value, "ValueInUsdString");
			}
		} = "$0.00";

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x0600038B RID: 907 RVA: 0x0003404A File Offset: 0x0003224A
		// (set) Token: 0x0600038C RID: 908 RVA: 0x00034052 File Offset: 0x00032252
		[Reactive]
		public double PortfolioPercentage
		{
			[CompilerGenerated]
			get
			{
				return this.$PortfolioPercentage;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PortfolioPercentage, value, "PortfolioPercentage");
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x0600038D RID: 909 RVA: 0x00034067 File Offset: 0x00032267
		// (set) Token: 0x0600038E RID: 910 RVA: 0x0003406F File Offset: 0x0003226F
		[Reactive]
		public string PortfolioPercentageString
		{
			[CompilerGenerated]
			get
			{
				return this.$PortfolioPercentageString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PortfolioPercentageString, value, "PortfolioPercentageString");
			}
		} = "0%";

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x0600038F RID: 911 RVA: 0x00034084 File Offset: 0x00032284
		// (set) Token: 0x06000390 RID: 912 RVA: 0x0003408C File Offset: 0x0003228C
		[Reactive]
		public string BrandHex
		{
			[CompilerGenerated]
			get
			{
				return this.$BrandHex;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$BrandHex, value, "BrandHex");
			}
		} = "#FFFFFF";

		// Token: 0x06000391 RID: 913 RVA: 0x000340A4 File Offset: 0x000322A4
		public PortfolioCoinItem(Coin coin)
		{
			this.OriginalCoin = coin;
			this.Id = coin.Id;
			this.Name = coin.Name;
			this.Symbol = coin.Symbol;
			this.Balance = coin.Balance;
			this.IsBsc = (coin.Symbol == "BNB");
			this.HasDropdown = (coin.Symbol == "ETH" || coin.Symbol == "USDT");
			if (coin.Symbol == "SOL")
			{
				this.ApyText = "5.21% APY";
				this.HasApy = true;
			}
			else if (coin.Symbol == "ADA")
			{
				this.ApyText = "2.98% APY";
				this.HasApy = true;
			}
			this.LoadIcon(coin.Symbol);
			this.SetupMarketMetadata(coin.Symbol);
		}

		// Token: 0x06000392 RID: 914 RVA: 0x00034234 File Offset: 0x00032434
		private void LoadIcon(string symbol)
		{
			string text = symbol.ToUpper();
			string text2;
			if (text != null)
			{
				int length = text.Length;
				if (length != 3)
				{
					if (length == 4)
					{
						char c = text[3];
						if (c <= 'E')
						{
							if (c != 'C')
							{
								if (c == 'E')
								{
									if (text == "DOGE")
									{
										text2 = "avares://Exodus/Assets/Resources/Icons/doge.png";
										goto IL_28D;
									}
								}
							}
							else if (text == "USDC")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/usdc.png";
								goto IL_28D;
							}
						}
						else if (c != 'K')
						{
							if (c == 'T')
							{
								if (text == "USDT")
								{
									text2 = "avares://Exodus/Assets/Resources/Icons/tether.png";
									goto IL_28D;
								}
							}
						}
						else if (text == "LINK")
						{
							text2 = "avares://Exodus/Assets/Resources/Icons/link.png";
							goto IL_28D;
						}
					}
				}
				else
				{
					char c = text[2];
					if (c <= 'H')
					{
						switch (c)
						{
						case 'A':
							if (text == "ADA")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/ada.png";
								goto IL_28D;
							}
							break;
						case 'B':
							if (text == "BNB")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/bnb.png";
								goto IL_28D;
							}
							break;
						case 'C':
							if (text == "BTC")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/bitcoin.png";
								goto IL_28D;
							}
							if (text == "LTC")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/ltc.png";
								goto IL_28D;
							}
							break;
						default:
							if (c == 'H')
							{
								if (text == "ETH")
								{
									text2 = "avares://Exodus/Assets/Resources/Icons/ethereum-icon.png";
									goto IL_28D;
								}
								if (text == "BCH")
								{
									text2 = "avares://Exodus/Assets/Resources/Icons/bch.png";
									goto IL_28D;
								}
							}
							break;
						}
					}
					else
					{
						switch (c)
						{
						case 'L':
							if (text == "SOL")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/solana.png";
								goto IL_28D;
							}
							break;
						case 'M':
							if (text == "XLM")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/xlm.png";
								goto IL_28D;
							}
							break;
						case 'N':
						case 'O':
						case 'Q':
						case 'S':
							break;
						case 'P':
							if (text == "XRP")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/xrp.png";
								goto IL_28D;
							}
							break;
						case 'R':
							if (text == "XMR")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/xmr.png";
								goto IL_28D;
							}
							break;
						case 'T':
							if (text == "DOT")
							{
								text2 = "avares://Exodus/Assets/Resources/Icons/dot.png";
								goto IL_28D;
							}
							break;
						default:
							if (c == 'X')
							{
								if (text == "TRX")
								{
									text2 = "avares://Exodus/Assets/Resources/Icons/tron.png";
									goto IL_28D;
								}
							}
							break;
						}
					}
				}
			}
			text2 = "avares://Exodus/Assets/Resources/Icons/bitcoin.png";
			IL_28D:
			string path = text2;
			try
			{
				this.Icon = new Bitmap(AssetLoader.Open(new Uri(path), null));
			}
			catch
			{
			}
		}

		// Token: 0x06000393 RID: 915 RVA: 0x000344FC File Offset: 0x000326FC
		private void SetupMarketMetadata(string symbol)
		{
			string text = symbol.ToUpper();
			if (text != null)
			{
				int length = text.Length;
				if (length != 3)
				{
					if (length == 4)
					{
						char c = text[3];
						if (c != 'C')
						{
							if (c != 'E')
							{
								if (c == 'T')
								{
									if (text == "USDT")
									{
										this.BrandHex = "#26A17B";
										this.Change24H = -0.05;
										this.MarketCap = "$183B";
										this.Volume24H = "$74.8B";
										this.TrendPath = "M 0,14 C 15,10 30,18 45,12 C 60,16 75,11 90,15 L 115,13";
										goto IL_46E;
									}
								}
							}
							else if (text == "DOGE")
							{
								this.BrandHex = "#C3A634";
								this.Change24H = 5.39;
								this.MarketCap = "$13.7B";
								this.Volume24H = "$1.06B";
								this.TrendPath = "M 0,24 C 20,24 40,22 60,16 C 80,18 95,8 115,4";
								goto IL_46E;
							}
						}
						else if (text == "USDC")
						{
							this.BrandHex = "#2775CA";
							this.Change24H = 0.02;
							this.MarketCap = "$74.2B";
							this.Volume24H = "$20.6B";
							this.TrendPath = "M 0,14 C 15,11 30,17 45,13 C 60,16 75,12 90,15 L 115,14";
							goto IL_46E;
						}
					}
				}
				else
				{
					char c = text[0];
					if (c <= 'L')
					{
						switch (c)
						{
						case 'A':
							if (text == "ADA")
							{
								this.BrandHex = "#0033AD";
								this.Change24H = 7.16;
								this.MarketCap = "$8.3B";
								this.Volume24H = "$709M";
								this.TrendPath = "M 0,25 C 25,25 50,22 75,12 C 90,8 105,10 115,5";
								goto IL_46E;
							}
							break;
						case 'B':
							if (text == "BTC")
							{
								this.BrandHex = "#F7931A";
								this.Change24H = 4.39;
								this.MarketCap = "$1.63T";
								this.Volume24H = "$42.3B";
								this.TrendPath = "M 0,22 C 20,22 30,18 45,19 C 55,20 65,15 75,10 C 85,5 95,8 105,4 L 115,2";
								goto IL_46E;
							}
							if (text == "BNB")
							{
								this.BrandHex = "#F3BA2F";
								this.Change24H = 2.78;
								this.MarketCap = "$95.7B";
								this.Volume24H = "$1.27B";
								this.TrendPath = "M 0,20 C 15,20 25,18 40,20 C 55,22 65,14 75,10 C 85,12 95,6 115,4";
								goto IL_46E;
							}
							break;
						case 'C':
						case 'D':
							break;
						case 'E':
							if (text == "ETH")
							{
								this.BrandHex = "#627EEA";
								this.Change24H = 5.39;
								this.MarketCap = "$308B";
								this.Volume24H = "$18.4B";
								this.TrendPath = "M 0,24 C 20,24 35,23 50,16 C 60,10 70,12 80,6 C 90,8 100,5 115,3";
								goto IL_46E;
							}
							break;
						default:
							if (c == 'L')
							{
								if (text == "LTC")
								{
									this.BrandHex = "#B8B8B8";
									this.Change24H = 1.28;
									this.MarketCap = "$3.97B";
									this.Volume24H = "$247M";
									this.TrendPath = "M 0,22 C 20,22 35,16 50,6 C 65,12 80,11 95,7 L 115,8";
									goto IL_46E;
								}
							}
							break;
						}
					}
					else if (c != 'S')
					{
						if (c != 'T')
						{
							if (c == 'X')
							{
								if (text == "XRP")
								{
									this.BrandHex = "#23292F";
									this.Change24H = 6.67;
									this.MarketCap = "$91.1B";
									this.Volume24H = "$4.15B";
									this.TrendPath = "M 0,24 C 20,23 40,21 60,11 C 80,14 100,6 115,4";
									goto IL_46E;
								}
							}
						}
						else if (text == "TRX")
						{
							this.BrandHex = "#EF0027";
							this.Change24H = 0.19;
							this.MarketCap = "$31.1B";
							this.Volume24H = "$438M";
							this.TrendPath = "M 0,21 C 20,20 40,16 60,22 C 75,25 90,14 100,18 L 115,12";
							goto IL_46E;
						}
					}
					else if (text == "SOL")
					{
						this.BrandHex = "#00FFA3";
						this.Change24H = 3.82;
						this.MarketCap = "$61B";
						this.Volume24H = "$4.23B";
						this.TrendPath = "M 0,23 C 20,22 35,23 50,18 C 65,12 80,15 95,8 L 115,5";
						goto IL_46E;
					}
				}
			}
			this.BrandHex = "#888888";
			this.Change24H = 1.5;
			this.MarketCap = "$5.0B";
			this.Volume24H = "$100M";
			this.TrendPath = "M 0,20 C 30,20 60,15 90,10 L 115,8";
			IL_46E:
			this.IsPositiveChange = (this.Change24H >= 0.0);
			string str = this.IsPositiveChange ? "+ " : "- ";
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
			defaultInterpolatedStringHandler.AppendFormatted<double>(Math.Abs(this.Change24H), "0.00");
			defaultInterpolatedStringHandler.AppendLiteral("%");
			this.Change24HString = str + defaultInterpolatedStringHandler.ToStringAndClear();
			this.ChangeBrush = (this.IsPositiveChange ? Brush.Parse("#00E676") : Brush.Parse("#FF5252"));
			this.TrendBrush = Brush.Parse(this.BrandHex);
		}

		// Token: 0x040001DF RID: 479
		private int $Id;

		// Token: 0x040001E0 RID: 480
		private string $Name;

		// Token: 0x040001E1 RID: 481
		private string $Symbol;

		// Token: 0x040001E2 RID: 482
		private Bitmap $Icon;

		// Token: 0x040001E3 RID: 483
		private bool $IsBsc;

		// Token: 0x040001E4 RID: 484
		private bool $HasDropdown;

		// Token: 0x040001E5 RID: 485
		private string $ApyText;

		// Token: 0x040001E6 RID: 486
		private bool $HasApy;

		// Token: 0x040001E7 RID: 487
		private double $Price;

		// Token: 0x040001E8 RID: 488
		private string $PriceString;

		// Token: 0x040001E9 RID: 489
		private double $Change24H;

		// Token: 0x040001EA RID: 490
		private string $Change24HString;

		// Token: 0x040001EB RID: 491
		private bool $IsPositiveChange;

		// Token: 0x040001EC RID: 492
		private IBrush $ChangeBrush;

		// Token: 0x040001ED RID: 493
		private string $MarketCap;

		// Token: 0x040001EE RID: 494
		private string $Volume24H;

		// Token: 0x040001EF RID: 495
		private string $TrendPath;

		// Token: 0x040001F0 RID: 496
		private IBrush $TrendBrush;

		// Token: 0x040001F1 RID: 497
		private double $Balance;

		// Token: 0x040001F2 RID: 498
		private string $BalanceString;

		// Token: 0x040001F3 RID: 499
		private double $ValueInUsd;

		// Token: 0x040001F4 RID: 500
		private string $ValueInUsdString;

		// Token: 0x040001F5 RID: 501
		private double $PortfolioPercentage;

		// Token: 0x040001F6 RID: 502
		private string $PortfolioPercentageString;

		// Token: 0x040001F7 RID: 503
		private string $BrandHex;
	}
}
