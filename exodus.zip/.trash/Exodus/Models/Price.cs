﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace Exodus.Models
{
	// Token: 0x0200007A RID: 122
	[NullableContext(1)]
	[Nullable(0)]
	public class Price
	{
		// Token: 0x170000AE RID: 174
		// (get) Token: 0x06000318 RID: 792 RVA: 0x0003393E File Offset: 0x00031B3E
		// (set) Token: 0x06000319 RID: 793 RVA: 0x00033946 File Offset: 0x00031B46
		public Dictionary<string, CoinData> data { get; set; }
	}
}
