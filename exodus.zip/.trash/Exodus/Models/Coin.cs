﻿using System;
using System.Collections.ObjectModel;
using System.Runtime.CompilerServices;
using Exodus.Helpers;
using Exodus.Services;
using Exodus.ViewModels;
using Newtonsoft.Json;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.Models
{
	// Token: 0x0200007E RID: 126
	[NullableContext(1)]
	[Nullable(0)]
	public class Coin : ReactiveObject
	{
		// Token: 0x06000324 RID: 804 RVA: 0x00033984 File Offset: 0x00031B84
		public Coin()
		{
			this.WhenAnyValue((Coin x) => x.Balance).Subscribe(delegate(double b)
			{
				this.FormattedBalance = NumberFormatHelper.FormatCrypto(b, 8);
			});
		}

		// Token: 0x06000325 RID: 805 RVA: 0x00033A00 File Offset: 0x00031C00
		public void Initialize()
		{
			this.IsShowPercentageIcon = (this.Id == 4);
			this.IsLocked = (this.Id != 0 && this.Id != 1 && this.Id != 4 && this.Id != 10 && this.Id != 11 && this.Id != 13);
			this.FormattedBalance = NumberFormatHelper.FormatCrypto(this.Balance, 8);
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x06000326 RID: 806 RVA: 0x00033A72 File Offset: 0x00031C72
		// (set) Token: 0x06000327 RID: 807 RVA: 0x00033A7A File Offset: 0x00031C7A
		[JsonProperty]
		[Reactive]
		public int Id
		{
			[CompilerGenerated]
			get
			{
				return this.$Id;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Id, value, "Id");
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x06000328 RID: 808 RVA: 0x00033A8F File Offset: 0x00031C8F
		// (set) Token: 0x06000329 RID: 809 RVA: 0x00033A97 File Offset: 0x00031C97
		[JsonProperty]
		[Reactive]
		public string Name
		{
			[CompilerGenerated]
			get
			{
				return this.$Name;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Name, value, "Name");
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x0600032A RID: 810 RVA: 0x00033AAC File Offset: 0x00031CAC
		// (set) Token: 0x0600032B RID: 811 RVA: 0x00033AB4 File Offset: 0x00031CB4
		[JsonProperty]
		[Reactive]
		public string Symbol
		{
			[CompilerGenerated]
			get
			{
				return this.$Symbol;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Symbol, value, "Symbol");
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x0600032C RID: 812 RVA: 0x00033AC9 File Offset: 0x00031CC9
		// (set) Token: 0x0600032D RID: 813 RVA: 0x00033AD1 File Offset: 0x00031CD1
		[JsonProperty]
		[Reactive]
		public string Address
		{
			[CompilerGenerated]
			get
			{
				return this.$Address;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Address, value, "Address");
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x0600032E RID: 814 RVA: 0x00033AE6 File Offset: 0x00031CE6
		// (set) Token: 0x0600032F RID: 815 RVA: 0x00033AEE File Offset: 0x00031CEE
		[JsonProperty]
		[Reactive]
		public string StartValue
		{
			[CompilerGenerated]
			get
			{
				return this.$StartValue;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$StartValue, value, "StartValue");
			}
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x06000330 RID: 816 RVA: 0x00033B03 File Offset: 0x00031D03
		// (set) Token: 0x06000331 RID: 817 RVA: 0x00033B0B File Offset: 0x00031D0B
		[JsonProperty]
		[Reactive]
		public double Balance
		{
			[CompilerGenerated]
			get
			{
				return this.$Balance;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Balance, value, "Balance");
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000332 RID: 818 RVA: 0x00033B20 File Offset: 0x00031D20
		// (set) Token: 0x06000333 RID: 819 RVA: 0x00033B28 File Offset: 0x00031D28
		[JsonProperty]
		[Reactive]
		public string FormattedBalance
		{
			[CompilerGenerated]
			get
			{
				return this.$FormattedBalance;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$FormattedBalance, value, "FormattedBalance");
			}
		} = "0";

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x06000334 RID: 820 RVA: 0x00033B3D File Offset: 0x00031D3D
		// (set) Token: 0x06000335 RID: 821 RVA: 0x00033B45 File Offset: 0x00031D45
		[JsonProperty]
		[Reactive]
		public ObservableCollection<Transaction> Transactions
		{
			[CompilerGenerated]
			get
			{
				return this.$Transactions;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Transactions, value, "Transactions");
			}
		} = new ObservableCollection<Transaction>();

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x06000336 RID: 822 RVA: 0x00033B5A File Offset: 0x00031D5A
		// (set) Token: 0x06000337 RID: 823 RVA: 0x00033B62 File Offset: 0x00031D62
		[JsonProperty]
		[Reactive]
		public bool IsEmpty
		{
			[CompilerGenerated]
			get
			{
				return this.$IsEmpty;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsEmpty, value, "IsEmpty");
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x06000338 RID: 824 RVA: 0x00033B77 File Offset: 0x00031D77
		// (set) Token: 0x06000339 RID: 825 RVA: 0x00033B7F File Offset: 0x00031D7F
		[Reactive]
		public bool IsSelected
		{
			[CompilerGenerated]
			get
			{
				return this.$IsSelected;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsSelected, value, "IsSelected");
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x0600033A RID: 826 RVA: 0x00033B94 File Offset: 0x00031D94
		// (set) Token: 0x0600033B RID: 827 RVA: 0x00033B9C File Offset: 0x00031D9C
		[Reactive]
		public bool IsLocked
		{
			[CompilerGenerated]
			get
			{
				return this.$IsLocked;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsLocked, value, "IsLocked");
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x0600033C RID: 828 RVA: 0x00033BB1 File Offset: 0x00031DB1
		public double TabOpacity
		{
			get
			{
				return 1.0;
			}
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x0600033D RID: 829 RVA: 0x00033BBC File Offset: 0x00031DBC
		// (set) Token: 0x0600033E RID: 830 RVA: 0x00033BC4 File Offset: 0x00031DC4
		[Reactive]
		public bool IsShowPercentageIcon
		{
			[CompilerGenerated]
			get
			{
				return this.$IsShowPercentageIcon;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsShowPercentageIcon, value, "IsShowPercentageIcon");
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x0600033F RID: 831 RVA: 0x00033BD9 File Offset: 0x00031DD9
		public bool IsBscNetwork
		{
			get
			{
				return this.Symbol == "BNB";
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000340 RID: 832 RVA: 0x00033BEB File Offset: 0x00031DEB
		// (set) Token: 0x06000341 RID: 833 RVA: 0x00033BF3 File Offset: 0x00031DF3
		[Nullable(2)]
		[Reactive]
		public CoinSpecificPartViewModel ViewPart
		{
			[NullableContext(2)]
			[CompilerGenerated]
			get
			{
				return this.$ViewPart;
			}
			[NullableContext(2)]
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ViewPart, value, "ViewPart");
			}
		}

		// Token: 0x06000342 RID: 834 RVA: 0x00033C08 File Offset: 0x00031E08
		public void SelectedCommand()
		{
			if (this.IsLocked)
			{
				return;
			}
			CoinManagementService.Instance.CoinSelected(this);
		}

		// Token: 0x040001C6 RID: 454
		private int $Id;

		// Token: 0x040001C7 RID: 455
		private string $Name;

		// Token: 0x040001C8 RID: 456
		private string $Symbol;

		// Token: 0x040001C9 RID: 457
		private string $Address;

		// Token: 0x040001CA RID: 458
		private string $StartValue;

		// Token: 0x040001CB RID: 459
		private double $Balance;

		// Token: 0x040001CC RID: 460
		private string $FormattedBalance;

		// Token: 0x040001CD RID: 461
		private ObservableCollection<Transaction> $Transactions;

		// Token: 0x040001CE RID: 462
		private bool $IsEmpty;

		// Token: 0x040001CF RID: 463
		private bool $IsSelected;

		// Token: 0x040001D0 RID: 464
		private bool $IsLocked;

		// Token: 0x040001D1 RID: 465
		private bool $IsShowPercentageIcon;

		// Token: 0x040001D2 RID: 466
		private CoinSpecificPartViewModel $ViewPart;
	}
}
