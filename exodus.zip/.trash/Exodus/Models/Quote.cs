﻿using System;
using System.Runtime.CompilerServices;

namespace Exodus.Models
{
	// Token: 0x0200007C RID: 124
	[NullableContext(1)]
	[Nullable(0)]
	public class Quote
	{
		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x0600031E RID: 798 RVA: 0x00033960 File Offset: 0x00031B60
		// (set) Token: 0x0600031F RID: 799 RVA: 0x00033968 File Offset: 0x00031B68
		public USD USD { get; set; }
	}
}
