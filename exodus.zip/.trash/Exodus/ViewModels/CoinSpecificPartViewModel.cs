﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using DynamicData;
using DynamicData.Binding;
using Exodus.Helpers;
using Exodus.Models;
using Exodus.Services;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.ViewModels
{
	// Token: 0x0200003D RID: 61
	[NullableContext(1)]
	[Nullable(0)]
	public class CoinSpecificPartViewModel : ViewModelBase
	{
		// Token: 0x060000E0 RID: 224 RVA: 0x00029C7C File Offset: 0x00027E7C
		public CoinSpecificPartViewModel()
		{
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x060000E1 RID: 225 RVA: 0x00029CD1 File Offset: 0x00027ED1
		// (set) Token: 0x060000E2 RID: 226 RVA: 0x00029CD9 File Offset: 0x00027ED9
		public MainWindowViewModel MainVm { get; set; }

		// Token: 0x060000E3 RID: 227 RVA: 0x00029CE4 File Offset: 0x00027EE4
		public CoinSpecificPartViewModel(MainWindowViewModel mainVm, Coin myCoin)
		{
			this.MainVm = mainVm;
			this.MyCoin = myCoin;
			this.IsBitcoin = (myCoin.Id == 0);
			this.IsEthereum = (myCoin.Id == 1);
			this.NoTransactionText = "No " + myCoin.Name + " Transactions";
			if (myCoin.Symbol == "ETH")
			{
				this.IsShowNetworkPill = true;
				this.NetworkPillText = "Total ETH balance";
				try
				{
					this.NetworkPillIcon = new Bitmap(AssetLoader.Open(new Uri("avares://Exodus/Assets/Resources/Icons/eth_pill.png"), null));
				}
				catch
				{
				}
				this.HasNetworkPillIcon = true;
				this.NetworkPillHasDropdown = true;
				this.IsShowGasWarning = true;
				this.GasWarningText = "Your ETH balance is low. Swap for or buy ETH to transact with ETH tokens.";
				this.YourAddressTitle = "Your Ethereum Address on ETH Network";
			}
			else if (myCoin.Symbol == "USDT")
			{
				this.IsShowNetworkPill = true;
				this.NetworkPillText = "Total USDT balance";
				try
				{
					this.NetworkPillIcon = new Bitmap(AssetLoader.Open(new Uri("avares://Exodus/Assets/Resources/Icons/usdt_pill.png"), null));
				}
				catch
				{
				}
				this.HasNetworkPillIcon = true;
				this.NetworkPillHasDropdown = true;
				this.IsShowGasWarning = false;
				this.YourAddressTitle = "Your Tether Address on Tron Network";
			}
			else if (myCoin.Symbol == "BNB")
			{
				this.IsShowNetworkPill = true;
				this.NetworkPillText = "BSC NETWORK";
				this.NetworkPillIcon = null;
				this.HasNetworkPillIcon = false;
				this.NetworkPillHasDropdown = false;
				this.IsShowGasWarning = true;
				this.GasWarningText = "Your BNB balance is low. Swap for or buy BNB on the BNB Smart Chain network to transact with BSC tokens.";
				this.YourAddressTitle = "Your BNB Address on BSC Network";
			}
			else if (myCoin.Symbol == "TRX")
			{
				this.IsShowNetworkPill = false;
				this.IsShowGasWarning = true;
				this.GasWarningText = "Your TRX balance is low. Swap for or buy TRX on the Tron network to transact with TRX tokens.";
				this.YourAddressTitle = "Your Tron Address";
			}
			else if (myCoin.Symbol == "SOL")
			{
				this.IsShowNetworkPill = false;
				this.IsShowGasWarning = true;
				this.GasWarningText = "Your SOL balance is low. Swap for or buy SOL on the Solana network to transact with SOL tokens.";
				this.YourAddressTitle = "Your Solana Address";
			}
			else
			{
				this.IsShowNetworkPill = false;
				this.IsShowGasWarning = false;
				this.YourAddressTitle = "Your " + myCoin.Name + " Address";
			}
			Application application = Application.Current;
			bool flag;
			object resource;
			if (application == null)
			{
				flag = false;
			}
			else
			{
				DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(6, 1);
				defaultInterpolatedStringHandler.AppendLiteral("Banner");
				defaultInterpolatedStringHandler.AppendFormatted<int>(myCoin.Id);
				flag = application.TryFindResource(defaultInterpolatedStringHandler.ToStringAndClear(), out resource);
			}
			if (flag)
			{
				DataTemplate dt = resource as DataTemplate;
				if (dt != null)
				{
					this.BannerControl = dt;
					goto IL_2FB;
				}
			}
			Application application2 = Application.Current;
			object def;
			if (application2 != null && application2.TryFindResource("DefaultBanner", out def))
			{
				DataTemplate defDt = def as DataTemplate;
				if (defDt != null)
				{
					this.BannerControl = defDt;
					goto IL_2FB;
				}
			}
			this.BannerControl = (DataTemplate)Application.Current.FindResource("Banner0");
			IL_2FB:
			Control control = this.BannerControl.Build(null);
			this.BannerControlHeight = ((control != null) ? control.Height : 84.0);
			this.WhenAnyValue((CoinSpecificPartViewModel x) => x.BalanceInUsd).Subscribe(delegate(double btcBalanceInUsd)
			{
				this.BalanceInUsdString = btcBalanceInUsd.ToString("N");
			});
			this.WhenAnyValue((CoinSpecificPartViewModel x) => x.IsThereTransaction, (CoinSpecificPartViewModel x) => x.IsTherePendingTransaction).Subscribe(delegate(ValueTuple<bool, bool> x)
			{
				this.IsThereAnyTransaction = (this.IsThereTransaction || this.IsTherePendingTransaction);
			});
			this.Transactions.ToObservableChangeSet((Transaction x) => x).ToCollection<Transaction, Transaction>().Subscribe(delegate(IReadOnlyCollection<Transaction> x)
			{
				this.CalculateBalance(true);
				this.IsThereTransaction = (this.Transactions.Count > 0);
			});
			this.PendingTransactions.ToObservableChangeSet((Transaction x) => x).ToCollection<Transaction, Transaction>().Subscribe(delegate(IReadOnlyCollection<Transaction> x)
			{
				this.CalculateBalance(true);
				this.IsTherePendingTransaction = (this.PendingTransactions.Count > 0);
			});
			this.IsThereAnyTransaction = false;
			this.IsThereTransaction = false;
			this.IsTherePendingTransaction = false;
			TransactionService.Instance.ChangeAddressEvent += delegate([Nullable(2)] object sender, EventArgs args)
			{
				if (this.MainVm.SelectedCoin.Id != this.MyCoin.Id)
				{
					return;
				}
				this.ChangeAddress();
			};
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x0002A1C0 File Offset: 0x000283C0
		public void TransactionsChanged()
		{
			this.CalculateBalance(true);
			this.IsThereTransaction = (this.Transactions.Count > 0);
			this.IsTherePendingTransaction = (this.PendingTransactions.Count > 0);
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x0002A1F4 File Offset: 0x000283F4
		public void AdjustTransactionsGroup()
		{
			List<TransactionGroup> temp = new List<TransactionGroup>();
			foreach (IGrouping<DateTime, Transaction> grouping in from t in this.Transactions
			group t by DateTimeOffset.FromUnixTimeSeconds(t.Time).LocalDateTime.Date)
			{
				TransactionGroup transactionGroup = new TransactionGroup(grouping.Key);
				foreach (Transaction transaction in grouping.OrderBy((Transaction t) => t.Time).Reverse<Transaction>())
				{
					transactionGroup.Transactions.Add(transaction);
				}
				temp.Add(transactionGroup);
			}
			if (temp.Count == 0)
			{
				temp.Add(new TransactionGroup(DateTime.Today));
			}
			temp = (from t in temp
			orderby t.Date
			select t).Reverse<TransactionGroup>().ToList<TransactionGroup>();
			this.TransactionsGroups = new ObservableCollection<TransactionGroup>(temp);
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x0002A330 File Offset: 0x00028530
		public void AddTransactionToToday(Transaction transaction)
		{
			this.TransactionsGroups[0].Transactions.Insert(0, transaction);
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x0002A34C File Offset: 0x0002854C
		public void ReceiveCommand()
		{
			CoinSpecificPartViewModel.<ReceiveCommand>d__9 <ReceiveCommand>d__;
			<ReceiveCommand>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ReceiveCommand>d__.<>4__this = this;
			<ReceiveCommand>d__.<>1__state = -1;
			<ReceiveCommand>d__.<>t__builder.Start<CoinSpecificPartViewModel.<ReceiveCommand>d__9>(ref <ReceiveCommand>d__);
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x0002A384 File Offset: 0x00028584
		public void RefreshCommand()
		{
			CoinSpecificPartViewModel.<RefreshCommand>d__10 <RefreshCommand>d__;
			<RefreshCommand>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<RefreshCommand>d__.<>4__this = this;
			<RefreshCommand>d__.<>1__state = -1;
			<RefreshCommand>d__.<>t__builder.Start<CoinSpecificPartViewModel.<RefreshCommand>d__10>(ref <RefreshCommand>d__);
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x0002A3BB File Offset: 0x000285BB
		public void DoRefreshCommand()
		{
			if (this.IsShowRefresh)
			{
				return;
			}
			Task.Run(delegate()
			{
				CoinSpecificPartViewModel.<<DoRefreshCommand>b__11_0>d <<DoRefreshCommand>b__11_0>d;
				<<DoRefreshCommand>b__11_0>d.<>t__builder = AsyncTaskMethodBuilder.Create();
				<<DoRefreshCommand>b__11_0>d.<>4__this = this;
				<<DoRefreshCommand>b__11_0>d.<>1__state = -1;
				<<DoRefreshCommand>b__11_0>d.<>t__builder.Start<CoinSpecificPartViewModel.<<DoRefreshCommand>b__11_0>d>(ref <<DoRefreshCommand>b__11_0>d);
				return <<DoRefreshCommand>b__11_0>d.<>t__builder.Task;
			});
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x060000EA RID: 234 RVA: 0x0002A3D8 File Offset: 0x000285D8
		// (set) Token: 0x060000EB RID: 235 RVA: 0x0002A3E0 File Offset: 0x000285E0
		[Reactive]
		public bool IsShowRefresh
		{
			[CompilerGenerated]
			get
			{
				return this.$IsShowRefresh;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsShowRefresh, value, "IsShowRefresh");
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060000EC RID: 236 RVA: 0x0002A3F5 File Offset: 0x000285F5
		// (set) Token: 0x060000ED RID: 237 RVA: 0x0002A3FD File Offset: 0x000285FD
		[Reactive]
		public bool IsPlayRefresh
		{
			[CompilerGenerated]
			get
			{
				return this.$IsPlayRefresh;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsPlayRefresh, value, "IsPlayRefresh");
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060000EE RID: 238 RVA: 0x0002A412 File Offset: 0x00028612
		// (set) Token: 0x060000EF RID: 239 RVA: 0x0002A41A File Offset: 0x0002861A
		[Reactive]
		public bool IsBitcoin
		{
			[CompilerGenerated]
			get
			{
				return this.$IsBitcoin;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsBitcoin, value, "IsBitcoin");
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060000F0 RID: 240 RVA: 0x0002A42F File Offset: 0x0002862F
		// (set) Token: 0x060000F1 RID: 241 RVA: 0x0002A437 File Offset: 0x00028637
		[Reactive]
		public bool IsEthereum
		{
			[CompilerGenerated]
			get
			{
				return this.$IsEthereum;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsEthereum, value, "IsEthereum");
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000F2 RID: 242 RVA: 0x0002A44C File Offset: 0x0002864C
		// (set) Token: 0x060000F3 RID: 243 RVA: 0x0002A454 File Offset: 0x00028654
		[Reactive]
		public Coin MyCoin
		{
			[CompilerGenerated]
			get
			{
				return this.$MyCoin;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$MyCoin, value, "MyCoin");
			}
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060000F4 RID: 244 RVA: 0x0002A469 File Offset: 0x00028669
		// (set) Token: 0x060000F5 RID: 245 RVA: 0x0002A471 File Offset: 0x00028671
		[Reactive]
		public Uri LogoUri
		{
			[CompilerGenerated]
			get
			{
				return this.$LogoUri;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$LogoUri, value, "LogoUri");
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060000F6 RID: 246 RVA: 0x0002A486 File Offset: 0x00028686
		// (set) Token: 0x060000F7 RID: 247 RVA: 0x0002A48E File Offset: 0x0002868E
		[Reactive]
		public string TransactionLookUrl
		{
			[CompilerGenerated]
			get
			{
				return this.$TransactionLookUrl;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TransactionLookUrl, value, "TransactionLookUrl");
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060000F8 RID: 248 RVA: 0x0002A4A3 File Offset: 0x000286A3
		// (set) Token: 0x060000F9 RID: 249 RVA: 0x0002A4AB File Offset: 0x000286AB
		[Reactive]
		public string AddressLookUrl
		{
			[CompilerGenerated]
			get
			{
				return this.$AddressLookUrl;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$AddressLookUrl, value, "AddressLookUrl");
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060000FA RID: 250 RVA: 0x0002A4C0 File Offset: 0x000286C0
		// (set) Token: 0x060000FB RID: 251 RVA: 0x0002A4C8 File Offset: 0x000286C8
		[Nullable(2)]
		[Reactive]
		public DataTemplate BannerControl
		{
			[NullableContext(2)]
			[CompilerGenerated]
			get
			{
				return this.$BannerControl;
			}
			[NullableContext(2)]
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$BannerControl, value, "BannerControl");
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060000FC RID: 252 RVA: 0x0002A4DD File Offset: 0x000286DD
		// (set) Token: 0x060000FD RID: 253 RVA: 0x0002A4E5 File Offset: 0x000286E5
		[Reactive]
		public double BannerControlHeight
		{
			[CompilerGenerated]
			get
			{
				return this.$BannerControlHeight;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$BannerControlHeight, value, "BannerControlHeight");
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060000FE RID: 254 RVA: 0x0002A4FA File Offset: 0x000286FA
		// (set) Token: 0x060000FF RID: 255 RVA: 0x0002A502 File Offset: 0x00028702
		[Reactive]
		public bool IsCurrentlyPending
		{
			[CompilerGenerated]
			get
			{
				return this.$IsCurrentlyPending;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsCurrentlyPending, value, "IsCurrentlyPending");
			}
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x06000100 RID: 256 RVA: 0x0002A517 File Offset: 0x00028717
		// (set) Token: 0x06000101 RID: 257 RVA: 0x0002A51F File Offset: 0x0002871F
		[Reactive]
		public double Balance
		{
			[CompilerGenerated]
			get
			{
				return this.$Balance;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Balance, value, "Balance");
			}
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x06000102 RID: 258 RVA: 0x0002A534 File Offset: 0x00028734
		// (set) Token: 0x06000103 RID: 259 RVA: 0x0002A53C File Offset: 0x0002873C
		[Reactive]
		public string FormattedBalance
		{
			[CompilerGenerated]
			get
			{
				return this.$FormattedBalance;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$FormattedBalance, value, "FormattedBalance");
			}
		} = "0";

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x06000104 RID: 260 RVA: 0x0002A551 File Offset: 0x00028751
		// (set) Token: 0x06000105 RID: 261 RVA: 0x0002A559 File Offset: 0x00028759
		[Reactive]
		public double BalanceInUsd
		{
			[CompilerGenerated]
			get
			{
				return this.$BalanceInUsd;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$BalanceInUsd, value, "BalanceInUsd");
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x06000106 RID: 262 RVA: 0x0002A56E File Offset: 0x0002876E
		// (set) Token: 0x06000107 RID: 263 RVA: 0x0002A576 File Offset: 0x00028776
		[Reactive]
		public string BalanceInUsdString
		{
			[CompilerGenerated]
			get
			{
				return this.$BalanceInUsdString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$BalanceInUsdString, value, "BalanceInUsdString");
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x06000108 RID: 264 RVA: 0x0002A58B File Offset: 0x0002878B
		// (set) Token: 0x06000109 RID: 265 RVA: 0x0002A593 File Offset: 0x00028793
		[Reactive]
		public bool IsTherePendingTransaction
		{
			[CompilerGenerated]
			get
			{
				return this.$IsTherePendingTransaction;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsTherePendingTransaction, value, "IsTherePendingTransaction");
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x0600010A RID: 266 RVA: 0x0002A5A8 File Offset: 0x000287A8
		// (set) Token: 0x0600010B RID: 267 RVA: 0x0002A5B0 File Offset: 0x000287B0
		[Reactive]
		public string NoTransactionText
		{
			[CompilerGenerated]
			get
			{
				return this.$NoTransactionText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$NoTransactionText, value, "NoTransactionText");
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x0600010C RID: 268 RVA: 0x0002A5C5 File Offset: 0x000287C5
		// (set) Token: 0x0600010D RID: 269 RVA: 0x0002A5CD File Offset: 0x000287CD
		[Reactive]
		public string YourAddressTitle
		{
			[CompilerGenerated]
			get
			{
				return this.$YourAddressTitle;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$YourAddressTitle, value, "YourAddressTitle");
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x0600010E RID: 270 RVA: 0x0002A5E2 File Offset: 0x000287E2
		// (set) Token: 0x0600010F RID: 271 RVA: 0x0002A5EA File Offset: 0x000287EA
		[Reactive]
		public bool IsShowNetworkPill
		{
			[CompilerGenerated]
			get
			{
				return this.$IsShowNetworkPill;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsShowNetworkPill, value, "IsShowNetworkPill");
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x06000110 RID: 272 RVA: 0x0002A5FF File Offset: 0x000287FF
		// (set) Token: 0x06000111 RID: 273 RVA: 0x0002A607 File Offset: 0x00028807
		[Reactive]
		public string NetworkPillText
		{
			[CompilerGenerated]
			get
			{
				return this.$NetworkPillText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$NetworkPillText, value, "NetworkPillText");
			}
		} = "";

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000112 RID: 274 RVA: 0x0002A61C File Offset: 0x0002881C
		// (set) Token: 0x06000113 RID: 275 RVA: 0x0002A624 File Offset: 0x00028824
		[Nullable(2)]
		[Reactive]
		public Bitmap NetworkPillIcon
		{
			[NullableContext(2)]
			[CompilerGenerated]
			get
			{
				return this.$NetworkPillIcon;
			}
			[NullableContext(2)]
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$NetworkPillIcon, value, "NetworkPillIcon");
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000114 RID: 276 RVA: 0x0002A639 File Offset: 0x00028839
		// (set) Token: 0x06000115 RID: 277 RVA: 0x0002A641 File Offset: 0x00028841
		[Reactive]
		public bool HasNetworkPillIcon
		{
			[CompilerGenerated]
			get
			{
				return this.$HasNetworkPillIcon;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$HasNetworkPillIcon, value, "HasNetworkPillIcon");
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000116 RID: 278 RVA: 0x0002A656 File Offset: 0x00028856
		// (set) Token: 0x06000117 RID: 279 RVA: 0x0002A65E File Offset: 0x0002885E
		[Reactive]
		public bool NetworkPillHasDropdown
		{
			[CompilerGenerated]
			get
			{
				return this.$NetworkPillHasDropdown;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$NetworkPillHasDropdown, value, "NetworkPillHasDropdown");
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000118 RID: 280 RVA: 0x0002A673 File Offset: 0x00028873
		// (set) Token: 0x06000119 RID: 281 RVA: 0x0002A67B File Offset: 0x0002887B
		[Reactive]
		public bool IsShowGasWarning
		{
			[CompilerGenerated]
			get
			{
				return this.$IsShowGasWarning;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsShowGasWarning, value, "IsShowGasWarning");
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x0600011A RID: 282 RVA: 0x0002A690 File Offset: 0x00028890
		// (set) Token: 0x0600011B RID: 283 RVA: 0x0002A698 File Offset: 0x00028898
		[Reactive]
		public string GasWarningText
		{
			[CompilerGenerated]
			get
			{
				return this.$GasWarningText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$GasWarningText, value, "GasWarningText");
			}
		} = "";

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x0600011C RID: 284 RVA: 0x0002A6AD File Offset: 0x000288AD
		// (set) Token: 0x0600011D RID: 285 RVA: 0x0002A6B5 File Offset: 0x000288B5
		[Reactive]
		public string TotalInPending
		{
			[CompilerGenerated]
			get
			{
				return this.$TotalInPending;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TotalInPending, value, "TotalInPending");
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x0600011E RID: 286 RVA: 0x0002A6CA File Offset: 0x000288CA
		// (set) Token: 0x0600011F RID: 287 RVA: 0x0002A6D2 File Offset: 0x000288D2
		[Reactive]
		public bool IsThereAnyTransaction
		{
			[CompilerGenerated]
			get
			{
				return this.$IsThereAnyTransaction;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsThereAnyTransaction, value, "IsThereAnyTransaction");
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06000120 RID: 288 RVA: 0x0002A6E7 File Offset: 0x000288E7
		// (set) Token: 0x06000121 RID: 289 RVA: 0x0002A6EF File Offset: 0x000288EF
		[Reactive]
		public bool ForceStopPending
		{
			[CompilerGenerated]
			get
			{
				return this.$ForceStopPending;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ForceStopPending, value, "ForceStopPending");
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000122 RID: 290 RVA: 0x0002A704 File Offset: 0x00028904
		// (set) Token: 0x06000123 RID: 291 RVA: 0x0002A70C File Offset: 0x0002890C
		[Reactive]
		public Transaction OnWaitTransaction
		{
			[CompilerGenerated]
			get
			{
				return this.$OnWaitTransaction;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$OnWaitTransaction, value, "OnWaitTransaction");
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000124 RID: 292 RVA: 0x0002A721 File Offset: 0x00028921
		// (set) Token: 0x06000125 RID: 293 RVA: 0x0002A729 File Offset: 0x00028929
		[Reactive]
		public bool IsAddedToOnWaitTransaction
		{
			[CompilerGenerated]
			get
			{
				return this.$IsAddedToOnWaitTransaction;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsAddedToOnWaitTransaction, value, "IsAddedToOnWaitTransaction");
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06000126 RID: 294 RVA: 0x0002A73E File Offset: 0x0002893E
		// (set) Token: 0x06000127 RID: 295 RVA: 0x0002A746 File Offset: 0x00028946
		[Reactive]
		public ObservableCollection<Transaction> Transactions
		{
			[CompilerGenerated]
			get
			{
				return this.$Transactions;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Transactions, value, "Transactions");
			}
		} = new ObservableCollection<Transaction>();

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000128 RID: 296 RVA: 0x0002A75B File Offset: 0x0002895B
		// (set) Token: 0x06000129 RID: 297 RVA: 0x0002A763 File Offset: 0x00028963
		[Reactive]
		public ObservableCollection<TransactionGroup> TransactionsGroups
		{
			[CompilerGenerated]
			get
			{
				return this.$TransactionsGroups;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TransactionsGroups, value, "TransactionsGroups");
			}
		} = new ObservableCollection<TransactionGroup>();

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x0600012A RID: 298 RVA: 0x0002A778 File Offset: 0x00028978
		// (set) Token: 0x0600012B RID: 299 RVA: 0x0002A780 File Offset: 0x00028980
		[Reactive]
		public ObservableCollection<Transaction> PendingTransactions
		{
			[CompilerGenerated]
			get
			{
				return this.$PendingTransactions;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PendingTransactions, value, "PendingTransactions");
			}
		} = new ObservableCollection<Transaction>();

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x0600012C RID: 300 RVA: 0x0002A795 File Offset: 0x00028995
		// (set) Token: 0x0600012D RID: 301 RVA: 0x0002A79D File Offset: 0x0002899D
		[Reactive]
		public bool IsThereTransaction
		{
			[CompilerGenerated]
			get
			{
				return this.$IsThereTransaction;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsThereTransaction, value, "IsThereTransaction");
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x0600012E RID: 302 RVA: 0x0002A7B2 File Offset: 0x000289B2
		// (set) Token: 0x0600012F RID: 303 RVA: 0x0002A7BA File Offset: 0x000289BA
		[Reactive]
		public SolidColorBrush Foreground1
		{
			[CompilerGenerated]
			get
			{
				return this.$Foreground1;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Foreground1, value, "Foreground1");
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000130 RID: 304 RVA: 0x0002A7CF File Offset: 0x000289CF
		// (set) Token: 0x06000131 RID: 305 RVA: 0x0002A7D7 File Offset: 0x000289D7
		[Reactive]
		public LinearGradientBrush Foreground2
		{
			[CompilerGenerated]
			get
			{
				return this.$Foreground2;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Foreground2, value, "Foreground2");
			}
		}

		// Token: 0x06000132 RID: 306 RVA: 0x0002A7EC File Offset: 0x000289EC
		public void CalculateBalance(bool isDoAnimation = true)
		{
			List<Transaction> total = new List<Transaction>();
			using (IEnumerator<Transaction> enumerator = this.Transactions.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					Transaction transaction = enumerator.Current;
					if (total.FirstOrDefault((Transaction t) => t.Id == transaction.Id) == null)
					{
						total.Add(transaction);
					}
				}
			}
			double totalInPending = 0.0;
			using (IEnumerator<Transaction> enumerator = this.PendingTransactions.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					Transaction transaction = enumerator.Current;
					totalInPending += transaction.Amount;
					if (total.FirstOrDefault((Transaction t) => t.Id == transaction.Id) == null)
					{
						total.Add(transaction);
					}
				}
			}
			this.TotalInPending = NumberFormatHelper.FormatCrypto(totalInPending, 8) + " " + this.MyCoin.Symbol;
			double balance = total.Sum((Transaction b) => b.Amount);
			this.Balance = Math.Round(balance, 8);
			this.FormattedBalance = NumberFormatHelper.FormatCrypto(this.Balance, 8);
			double price = TransactionService.Instance.GetPrice(this.MyCoin.Symbol);
			this.BalanceInUsd = Math.Round(this.Balance * price, 2);
			this.MyCoin.Balance = this.Balance;
			this.MyCoin.IsEmpty = (this.Balance == 0.0);
			Task.Run(delegate()
			{
				this.MainVm.BalanceAdder(isDoAnimation);
			});
		}

		// Token: 0x06000133 RID: 307 RVA: 0x0002A9D4 File Offset: 0x00028BD4
		private void ChangeAddress()
		{
			CoinSpecificPartViewModel.<ChangeAddress>d__157 <ChangeAddress>d__;
			<ChangeAddress>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ChangeAddress>d__.<>4__this = this;
			<ChangeAddress>d__.<>1__state = -1;
			<ChangeAddress>d__.<>t__builder.Start<CoinSpecificPartViewModel.<ChangeAddress>d__157>(ref <ChangeAddress>d__);
		}

		// Token: 0x04000040 RID: 64
		private bool $IsShowRefresh;

		// Token: 0x04000041 RID: 65
		private bool $IsPlayRefresh;

		// Token: 0x04000042 RID: 66
		private bool $IsBitcoin;

		// Token: 0x04000043 RID: 67
		private bool $IsEthereum;

		// Token: 0x04000044 RID: 68
		private Coin $MyCoin;

		// Token: 0x04000045 RID: 69
		private Uri $LogoUri;

		// Token: 0x04000046 RID: 70
		private string $TransactionLookUrl;

		// Token: 0x04000047 RID: 71
		private string $AddressLookUrl;

		// Token: 0x04000048 RID: 72
		private DataTemplate $BannerControl;

		// Token: 0x04000049 RID: 73
		private double $BannerControlHeight;

		// Token: 0x0400004A RID: 74
		private bool $IsCurrentlyPending;

		// Token: 0x0400004B RID: 75
		private double $Balance;

		// Token: 0x0400004C RID: 76
		private string $FormattedBalance;

		// Token: 0x0400004D RID: 77
		private double $BalanceInUsd;

		// Token: 0x0400004E RID: 78
		private string $BalanceInUsdString;

		// Token: 0x0400004F RID: 79
		private bool $IsTherePendingTransaction;

		// Token: 0x04000050 RID: 80
		private string $NoTransactionText;

		// Token: 0x04000051 RID: 81
		private string $YourAddressTitle;

		// Token: 0x04000052 RID: 82
		private bool $IsShowNetworkPill;

		// Token: 0x04000053 RID: 83
		private string $NetworkPillText;

		// Token: 0x04000054 RID: 84
		private Bitmap $NetworkPillIcon;

		// Token: 0x04000055 RID: 85
		private bool $HasNetworkPillIcon;

		// Token: 0x04000056 RID: 86
		private bool $NetworkPillHasDropdown;

		// Token: 0x04000057 RID: 87
		private bool $IsShowGasWarning;

		// Token: 0x04000058 RID: 88
		private string $GasWarningText;

		// Token: 0x04000059 RID: 89
		private string $TotalInPending;

		// Token: 0x0400005A RID: 90
		private bool $IsThereAnyTransaction;

		// Token: 0x0400005B RID: 91
		private bool $ForceStopPending;

		// Token: 0x0400005C RID: 92
		private Transaction $OnWaitTransaction;

		// Token: 0x0400005D RID: 93
		private bool $IsAddedToOnWaitTransaction;

		// Token: 0x0400005E RID: 94
		private ObservableCollection<Transaction> $Transactions;

		// Token: 0x0400005F RID: 95
		private ObservableCollection<TransactionGroup> $TransactionsGroups;

		// Token: 0x04000060 RID: 96
		private ObservableCollection<Transaction> $PendingTransactions;

		// Token: 0x04000061 RID: 97
		private bool $IsThereTransaction;

		// Token: 0x04000062 RID: 98
		private SolidColorBrush $Foreground1;

		// Token: 0x04000063 RID: 99
		private LinearGradientBrush $Foreground2;
	}
}
