﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Avalonia.Threading;
using Exodus.Helpers;
using Exodus.Models;
using Exodus.Services;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.ViewModels
{
	// Token: 0x02000063 RID: 99
	[NullableContext(1)]
	[Nullable(0)]
	public class SwapViewModel : ViewModelBase
	{
		// Token: 0x17000087 RID: 135
		// (get) Token: 0x06000264 RID: 612 RVA: 0x0002F46E File Offset: 0x0002D66E
		public MainWindowViewModel MainVm { get; }

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x06000265 RID: 613 RVA: 0x0002F476 File Offset: 0x0002D676
		public ObservableCollection<SwapCoinItem> AllCoins { get; } = new ObservableCollection<SwapCoinItem>();

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x06000266 RID: 614 RVA: 0x0002F47E File Offset: 0x0002D67E
		public ObservableCollection<SwapCoinItem> FilteredCoins { get; } = new ObservableCollection<SwapCoinItem>();

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06000267 RID: 615 RVA: 0x0002F486 File Offset: 0x0002D686
		// (set) Token: 0x06000268 RID: 616 RVA: 0x0002F48E File Offset: 0x0002D68E
		[Nullable(2)]
		[Reactive]
		public SwapCoinItem SelectedHaveCoin
		{
			[NullableContext(2)]
			[CompilerGenerated]
			get
			{
				return this.$SelectedHaveCoin;
			}
			[NullableContext(2)]
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SelectedHaveCoin, value, "SelectedHaveCoin");
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000269 RID: 617 RVA: 0x0002F4A3 File Offset: 0x0002D6A3
		// (set) Token: 0x0600026A RID: 618 RVA: 0x0002F4AB File Offset: 0x0002D6AB
		[Nullable(2)]
		[Reactive]
		public SwapCoinItem SelectedWantCoin
		{
			[NullableContext(2)]
			[CompilerGenerated]
			get
			{
				return this.$SelectedWantCoin;
			}
			[NullableContext(2)]
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SelectedWantCoin, value, "SelectedWantCoin");
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x0600026B RID: 619 RVA: 0x0002F4C0 File Offset: 0x0002D6C0
		// (set) Token: 0x0600026C RID: 620 RVA: 0x0002F4C8 File Offset: 0x0002D6C8
		[Reactive]
		public string HaveAmountString
		{
			[CompilerGenerated]
			get
			{
				return this.$HaveAmountString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$HaveAmountString, value, "HaveAmountString");
			}
		} = "0.00";

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x0600026D RID: 621 RVA: 0x0002F4DD File Offset: 0x0002D6DD
		// (set) Token: 0x0600026E RID: 622 RVA: 0x0002F4E5 File Offset: 0x0002D6E5
		[Reactive]
		public string WantAmountString
		{
			[CompilerGenerated]
			get
			{
				return this.$WantAmountString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$WantAmountString, value, "WantAmountString");
			}
		} = "0.00";

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x0600026F RID: 623 RVA: 0x0002F4FA File Offset: 0x0002D6FA
		// (set) Token: 0x06000270 RID: 624 RVA: 0x0002F502 File Offset: 0x0002D702
		[Reactive]
		public string HaveUsdString
		{
			[CompilerGenerated]
			get
			{
				return this.$HaveUsdString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$HaveUsdString, value, "HaveUsdString");
			}
		} = "$0.00";

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000271 RID: 625 RVA: 0x0002F517 File Offset: 0x0002D717
		// (set) Token: 0x06000272 RID: 626 RVA: 0x0002F51F File Offset: 0x0002D71F
		[Reactive]
		public string WantUsdString
		{
			[CompilerGenerated]
			get
			{
				return this.$WantUsdString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$WantUsdString, value, "WantUsdString");
			}
		} = "$0.00";

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06000273 RID: 627 RVA: 0x0002F534 File Offset: 0x0002D734
		// (set) Token: 0x06000274 RID: 628 RVA: 0x0002F53C File Offset: 0x0002D73C
		[Reactive]
		public string ExchangeRateText
		{
			[CompilerGenerated]
			get
			{
				return this.$ExchangeRateText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ExchangeRateText, value, "ExchangeRateText");
			}
		} = "";

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000275 RID: 629 RVA: 0x0002F551 File Offset: 0x0002D751
		// (set) Token: 0x06000276 RID: 630 RVA: 0x0002F559 File Offset: 0x0002D759
		[Reactive]
		public string ActionButtonText
		{
			[CompilerGenerated]
			get
			{
				return this.$ActionButtonText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ActionButtonText, value, "ActionButtonText");
			}
		} = "ENTER AMOUNT";

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000277 RID: 631 RVA: 0x0002F56E File Offset: 0x0002D76E
		// (set) Token: 0x06000278 RID: 632 RVA: 0x0002F576 File Offset: 0x0002D776
		[Reactive]
		public bool IsSwapButtonActive
		{
			[CompilerGenerated]
			get
			{
				return this.$IsSwapButtonActive;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsSwapButtonActive, value, "IsSwapButtonActive");
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000279 RID: 633 RVA: 0x0002F58B File Offset: 0x0002D78B
		// (set) Token: 0x0600027A RID: 634 RVA: 0x0002F593 File Offset: 0x0002D793
		[Reactive]
		public bool IsAssetPickerOpen
		{
			[CompilerGenerated]
			get
			{
				return this.$IsAssetPickerOpen;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsAssetPickerOpen, value, "IsAssetPickerOpen");
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x0600027B RID: 635 RVA: 0x0002F5A8 File Offset: 0x0002D7A8
		// (set) Token: 0x0600027C RID: 636 RVA: 0x0002F5B0 File Offset: 0x0002D7B0
		[Reactive]
		public string PickerTarget
		{
			[CompilerGenerated]
			get
			{
				return this.$PickerTarget;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PickerTarget, value, "PickerTarget");
			}
		} = "HAVE";

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x0600027D RID: 637 RVA: 0x0002F5C5 File Offset: 0x0002D7C5
		// (set) Token: 0x0600027E RID: 638 RVA: 0x0002F5CD File Offset: 0x0002D7CD
		[Reactive]
		public string PickerTitle
		{
			[CompilerGenerated]
			get
			{
				return this.$PickerTitle;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PickerTitle, value, "PickerTitle");
			}
		} = "Select Asset to Swap";

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x0600027F RID: 639 RVA: 0x0002F5E2 File Offset: 0x0002D7E2
		// (set) Token: 0x06000280 RID: 640 RVA: 0x0002F5EA File Offset: 0x0002D7EA
		[Reactive]
		public string SearchQuery
		{
			[CompilerGenerated]
			get
			{
				return this.$SearchQuery;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SearchQuery, value, "SearchQuery");
			}
		} = "";

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x06000281 RID: 641 RVA: 0x0002F5FF File Offset: 0x0002D7FF
		// (set) Token: 0x06000282 RID: 642 RVA: 0x0002F607 File Offset: 0x0002D807
		[Reactive]
		public bool IsToastVisible
		{
			[CompilerGenerated]
			get
			{
				return this.$IsToastVisible;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsToastVisible, value, "IsToastVisible");
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x06000283 RID: 643 RVA: 0x0002F61C File Offset: 0x0002D81C
		// (set) Token: 0x06000284 RID: 644 RVA: 0x0002F624 File Offset: 0x0002D824
		[Reactive]
		public string ToastMessage
		{
			[CompilerGenerated]
			get
			{
				return this.$ToastMessage;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ToastMessage, value, "ToastMessage");
			}
		} = "";

		// Token: 0x06000285 RID: 645 RVA: 0x0002F63C File Offset: 0x0002D83C
		public SwapViewModel(MainWindowViewModel mainVm)
		{
			this.MainVm = mainVm;
			this.InitializeCoins();
			this.WhenAnyValue((SwapViewModel x) => x.HaveAmountString).Subscribe(delegate(string _)
			{
				this.CalculateExchange();
			});
			this.WhenAnyValue((SwapViewModel x) => x.SearchQuery).Subscribe(delegate(string _)
			{
				this.ApplyFilter();
			});
			TransactionService.Instance.PriceUpdated += delegate([Nullable(2)] object s, EventArgs e)
			{
				Dispatcher.UIThread.InvokeAsync(delegate()
				{
					this.RefreshCoins();
				});
			};
		}

		// Token: 0x06000286 RID: 646 RVA: 0x0002F798 File Offset: 0x0002D998
		public void InitializeCoins()
		{
			this.AllCoins.Clear();
			if (this.MainVm.Coins == null)
			{
				return;
			}
			foreach (SwapCoinItem item in (from i in (from c in this.MainVm.Coins
			select new SwapCoinItem(c)).ToList<SwapCoinItem>()
			orderby i.ValueInUsd descending, i.Balance descending
			select i).ToList<SwapCoinItem>())
			{
				this.AllCoins.Add(item);
			}
			this.SelectedHaveCoin = (this.AllCoins.FirstOrDefault((SwapCoinItem c) => c.Symbol == "BTC" || c.Balance > 0.0) ?? this.AllCoins.FirstOrDefault<SwapCoinItem>());
			SwapCoinItem selectedWantCoin;
			if ((selectedWantCoin = this.AllCoins.FirstOrDefault((SwapCoinItem c) => c.Symbol == "USDT" && c != this.SelectedHaveCoin)) == null)
			{
				selectedWantCoin = (this.AllCoins.FirstOrDefault((SwapCoinItem c) => c.Symbol == "ETH" && c != this.SelectedHaveCoin) ?? this.AllCoins.LastOrDefault<SwapCoinItem>());
			}
			this.SelectedWantCoin = selectedWantCoin;
			this.ApplyFilter();
			this.CalculateExchange();
		}

		// Token: 0x06000287 RID: 647 RVA: 0x0002F918 File Offset: 0x0002DB18
		public void RefreshCoins()
		{
			foreach (SwapCoinItem swapCoinItem in this.AllCoins)
			{
				swapCoinItem.RefreshBalance();
			}
			this.CalculateExchange();
		}

		// Token: 0x06000288 RID: 648 RVA: 0x0002F968 File Offset: 0x0002DB68
		private void CalculateExchange()
		{
			if (this.SelectedHaveCoin == null || this.SelectedWantCoin == null)
			{
				return;
			}
			double haveAmount = this.ParseInputAmount(this.HaveAmountString);
			double havePrice = (this.SelectedHaveCoin.PriceUsd > 0.0) ? this.SelectedHaveCoin.PriceUsd : 1.0;
			double wantPrice = (this.SelectedWantCoin.PriceUsd > 0.0) ? this.SelectedWantCoin.PriceUsd : 1.0;
			double rate = havePrice / wantPrice;
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(6, 3);
			defaultInterpolatedStringHandler.AppendLiteral("1 ");
			defaultInterpolatedStringHandler.AppendFormatted(this.SelectedHaveCoin.Symbol);
			defaultInterpolatedStringHandler.AppendLiteral(" ≈ ");
			defaultInterpolatedStringHandler.AppendFormatted(NumberFormatHelper.FormatCrypto(rate, 8));
			defaultInterpolatedStringHandler.AppendLiteral(" ");
			defaultInterpolatedStringHandler.AppendFormatted(this.SelectedWantCoin.Symbol);
			this.ExchangeRateText = defaultInterpolatedStringHandler.ToStringAndClear();
			if (haveAmount > 0.0)
			{
				double haveUsd = haveAmount * havePrice;
				double wantAmount = haveUsd / wantPrice;
				defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(3, 1);
				defaultInterpolatedStringHandler.AppendLiteral("≈ $");
				defaultInterpolatedStringHandler.AppendFormatted<double>(haveUsd, "N2");
				this.HaveUsdString = defaultInterpolatedStringHandler.ToStringAndClear();
				this.WantAmountString = NumberFormatHelper.FormatCrypto(wantAmount, 8);
				defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(3, 1);
				defaultInterpolatedStringHandler.AppendLiteral("≈ $");
				defaultInterpolatedStringHandler.AppendFormatted<double>(haveUsd, "N2");
				this.WantUsdString = defaultInterpolatedStringHandler.ToStringAndClear();
				this.ActionButtonText = "SWAP";
				this.IsSwapButtonActive = true;
				return;
			}
			this.HaveUsdString = "$0.00";
			this.WantAmountString = "0.00";
			this.WantUsdString = "$0.00";
			this.ActionButtonText = "ENTER AMOUNT";
			this.IsSwapButtonActive = false;
		}

		// Token: 0x06000289 RID: 649 RVA: 0x0002FB2C File Offset: 0x0002DD2C
		private double ParseInputAmount(string input)
		{
			if (string.IsNullOrWhiteSpace(input))
			{
				return 0.0;
			}
			string clean = input.Replace(" ", "").Replace(",", "");
			double val;
			if (double.TryParse(clean, NumberStyles.Any, CultureInfo.InvariantCulture, out val))
			{
				return val;
			}
			double val2;
			if (double.TryParse(clean, NumberStyles.Any, CultureInfo.CurrentCulture, out val2))
			{
				return val2;
			}
			return 0.0;
		}

		// Token: 0x0600028A RID: 650 RVA: 0x0002FBA0 File Offset: 0x0002DDA0
		public void FlipCoins()
		{
			SwapCoinItem temp = this.SelectedHaveCoin;
			this.SelectedHaveCoin = this.SelectedWantCoin;
			this.SelectedWantCoin = temp;
			this.CalculateExchange();
		}

		// Token: 0x0600028B RID: 651 RVA: 0x0002FBD0 File Offset: 0x0002DDD0
		public void ApplyMin()
		{
			if (this.SelectedHaveCoin == null)
			{
				return;
			}
			double min = (this.SelectedHaveCoin.Balance > 0.0) ? Math.Max(0.001, this.SelectedHaveCoin.Balance * 0.05) : 0.01;
			this.HaveAmountString = NumberFormatHelper.FormatCrypto(min, 8);
		}

		// Token: 0x0600028C RID: 652 RVA: 0x0002FC38 File Offset: 0x0002DE38
		public void ApplyHalf()
		{
			if (this.SelectedHaveCoin == null)
			{
				return;
			}
			double half = this.SelectedHaveCoin.Balance / 2.0;
			this.HaveAmountString = NumberFormatHelper.FormatCrypto(half, 8);
		}

		// Token: 0x0600028D RID: 653 RVA: 0x0002FC71 File Offset: 0x0002DE71
		public void ApplyMax()
		{
			if (this.SelectedHaveCoin == null)
			{
				return;
			}
			this.HaveAmountString = NumberFormatHelper.FormatCrypto(this.SelectedHaveCoin.Balance, 8);
		}

		// Token: 0x0600028E RID: 654 RVA: 0x0002FC93 File Offset: 0x0002DE93
		public void OpenHavePicker()
		{
			this.PickerTarget = "HAVE";
			this.PickerTitle = "Select Asset to Swap (From)";
			this.SearchQuery = "";
			this.ApplyFilter();
			this.IsAssetPickerOpen = true;
		}

		// Token: 0x0600028F RID: 655 RVA: 0x0002FCC3 File Offset: 0x0002DEC3
		public void OpenWantPicker()
		{
			this.PickerTarget = "WANT";
			this.PickerTitle = "Select Asset to Swap (To)";
			this.SearchQuery = "";
			this.ApplyFilter();
			this.IsAssetPickerOpen = true;
		}

		// Token: 0x06000290 RID: 656 RVA: 0x0002FCF3 File Offset: 0x0002DEF3
		public void ClosePicker()
		{
			this.IsAssetPickerOpen = false;
		}

		// Token: 0x06000291 RID: 657 RVA: 0x0002FCFC File Offset: 0x0002DEFC
		[NullableContext(2)]
		public void SelectCoin(SwapCoinItem coin)
		{
			if (coin == null)
			{
				return;
			}
			if (this.PickerTarget == "HAVE")
			{
				if (coin == this.SelectedWantCoin)
				{
					this.SelectedWantCoin = this.SelectedHaveCoin;
				}
				this.SelectedHaveCoin = coin;
			}
			else
			{
				if (coin == this.SelectedHaveCoin)
				{
					this.SelectedHaveCoin = this.SelectedWantCoin;
				}
				this.SelectedWantCoin = coin;
			}
			this.IsAssetPickerOpen = false;
			this.CalculateExchange();
		}

		// Token: 0x06000292 RID: 658 RVA: 0x0002FD68 File Offset: 0x0002DF68
		private void ApplyFilter()
		{
			this.FilteredCoins.Clear();
			string q = (this.SearchQuery ?? "").Trim().ToLower();
			foreach (SwapCoinItem c2 in (string.IsNullOrEmpty(q) ? this.AllCoins.AsEnumerable<SwapCoinItem>() : (from c in this.AllCoins
			where c.Symbol.ToLower().Contains(q) || c.Name.ToLower().Contains(q)
			select c)))
			{
				this.FilteredCoins.Add(c2);
			}
		}

		// Token: 0x06000293 RID: 659 RVA: 0x0002FE18 File Offset: 0x0002E018
		public void ExecuteSwap()
		{
			this.ShowToast("Simulated Swap: Preview mode (Balances preserved for LARP security)");
		}

		// Token: 0x06000294 RID: 660 RVA: 0x0002FE25 File Offset: 0x0002E025
		public void ShowToast(string msg)
		{
			this.ToastMessage = msg;
			this.IsToastVisible = true;
			Task.Run(delegate()
			{
				SwapViewModel.<<ShowToast>b__84_0>d <<ShowToast>b__84_0>d;
				<<ShowToast>b__84_0>d.<>t__builder = AsyncTaskMethodBuilder.Create();
				<<ShowToast>b__84_0>d.<>4__this = this;
				<<ShowToast>b__84_0>d.<>1__state = -1;
				<<ShowToast>b__84_0>d.<>t__builder.Start<SwapViewModel.<<ShowToast>b__84_0>d>(ref <<ShowToast>b__84_0>d);
				return <<ShowToast>b__84_0>d.<>t__builder.Task;
			});
		}

		// Token: 0x0400011D RID: 285
		private SwapCoinItem $SelectedHaveCoin;

		// Token: 0x0400011E RID: 286
		private SwapCoinItem $SelectedWantCoin;

		// Token: 0x0400011F RID: 287
		private string $HaveAmountString;

		// Token: 0x04000120 RID: 288
		private string $WantAmountString;

		// Token: 0x04000121 RID: 289
		private string $HaveUsdString;

		// Token: 0x04000122 RID: 290
		private string $WantUsdString;

		// Token: 0x04000123 RID: 291
		private string $ExchangeRateText;

		// Token: 0x04000124 RID: 292
		private string $ActionButtonText;

		// Token: 0x04000125 RID: 293
		private bool $IsSwapButtonActive;

		// Token: 0x04000126 RID: 294
		private bool $IsAssetPickerOpen;

		// Token: 0x04000127 RID: 295
		private string $PickerTarget;

		// Token: 0x04000128 RID: 296
		private string $PickerTitle;

		// Token: 0x04000129 RID: 297
		private string $SearchQuery;

		// Token: 0x0400012A RID: 298
		private bool $IsToastVisible;

		// Token: 0x0400012B RID: 299
		private string $ToastMessage;
	}
}
