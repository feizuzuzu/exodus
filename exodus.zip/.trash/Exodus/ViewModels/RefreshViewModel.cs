﻿using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.ViewModels
{
	// Token: 0x0200005A RID: 90
	[NullableContext(1)]
	[Nullable(0)]
	public class RefreshViewModel : ViewModelBase
	{
		// Token: 0x0600021D RID: 541 RVA: 0x0002E958 File Offset: 0x0002CB58
		public RefreshViewModel(MainWindowViewModel mainWindowViewModel)
		{
			this.MainWindowVm = mainWindowViewModel;
			this.RefreshText = "Are you sure you want to rescan the " + mainWindowViewModel.SelectedCoin.Name + " blockchain?";
			this.IsShow = false;
			this.IsShowButtons = false;
			this.Opacity = 0.0;
			this.SolidOpacity = 0.0;
			this.WhenAnyValue((RefreshViewModel x) => x.IsShow).Subscribe(delegate(bool _)
			{
				if (this.IsShow)
				{
					this.IsVisible = true;
				}
				this.Opacity = (this.IsShow ? 0.974 : 0.0);
				this.SolidOpacity = (this.IsShow > false);
				if (this.IsShow)
				{
					Task.Run(delegate()
					{
						RefreshViewModel.<<-ctor>b__0_2>d <<-ctor>b__0_2>d;
						<<-ctor>b__0_2>d.<>t__builder = AsyncTaskMethodBuilder.Create();
						<<-ctor>b__0_2>d.<>4__this = this;
						<<-ctor>b__0_2>d.<>1__state = -1;
						<<-ctor>b__0_2>d.<>t__builder.Start<RefreshViewModel.<<-ctor>b__0_2>d>(ref <<-ctor>b__0_2>d);
						return <<-ctor>b__0_2>d.<>t__builder.Task;
					});
					return;
				}
				this.IsShowButtons = false;
				this.ButtonsOpacity = 0.0;
				Task.Run(delegate()
				{
					RefreshViewModel.<<-ctor>b__0_3>d <<-ctor>b__0_3>d;
					<<-ctor>b__0_3>d.<>t__builder = AsyncTaskMethodBuilder.Create();
					<<-ctor>b__0_3>d.<>4__this = this;
					<<-ctor>b__0_3>d.<>1__state = -1;
					<<-ctor>b__0_3>d.<>t__builder.Start<RefreshViewModel.<<-ctor>b__0_3>d>(ref <<-ctor>b__0_3>d);
					return <<-ctor>b__0_3>d.<>t__builder.Task;
				});
			});
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x0600021E RID: 542 RVA: 0x0002EA0F File Offset: 0x0002CC0F
		// (set) Token: 0x0600021F RID: 543 RVA: 0x0002EA17 File Offset: 0x0002CC17
		[Nullable(2)]
		[Reactive]
		public MainWindowViewModel MainWindowVm
		{
			[NullableContext(2)]
			[CompilerGenerated]
			get
			{
				return this.$MainWindowVm;
			}
			[NullableContext(2)]
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$MainWindowVm, value, "MainWindowVm");
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x06000220 RID: 544 RVA: 0x0002EA2C File Offset: 0x0002CC2C
		// (set) Token: 0x06000221 RID: 545 RVA: 0x0002EA34 File Offset: 0x0002CC34
		[Reactive]
		public string RefreshText
		{
			[CompilerGenerated]
			get
			{
				return this.$RefreshText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$RefreshText, value, "RefreshText");
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06000222 RID: 546 RVA: 0x0002EA49 File Offset: 0x0002CC49
		// (set) Token: 0x06000223 RID: 547 RVA: 0x0002EA51 File Offset: 0x0002CC51
		[Reactive]
		public double SolidOpacity
		{
			[CompilerGenerated]
			get
			{
				return this.$SolidOpacity;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SolidOpacity, value, "SolidOpacity");
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x06000224 RID: 548 RVA: 0x0002EA66 File Offset: 0x0002CC66
		// (set) Token: 0x06000225 RID: 549 RVA: 0x0002EA6E File Offset: 0x0002CC6E
		[Reactive]
		public double Opacity
		{
			[CompilerGenerated]
			get
			{
				return this.$Opacity;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Opacity, value, "Opacity");
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06000226 RID: 550 RVA: 0x0002EA83 File Offset: 0x0002CC83
		// (set) Token: 0x06000227 RID: 551 RVA: 0x0002EA8B File Offset: 0x0002CC8B
		[Reactive]
		public bool IsShow
		{
			[CompilerGenerated]
			get
			{
				return this.$IsShow;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsShow, value, "IsShow");
			}
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06000228 RID: 552 RVA: 0x0002EAA0 File Offset: 0x0002CCA0
		// (set) Token: 0x06000229 RID: 553 RVA: 0x0002EAA8 File Offset: 0x0002CCA8
		[Reactive]
		public bool IsShowButtons
		{
			[CompilerGenerated]
			get
			{
				return this.$IsShowButtons;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsShowButtons, value, "IsShowButtons");
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x0600022A RID: 554 RVA: 0x0002EABD File Offset: 0x0002CCBD
		// (set) Token: 0x0600022B RID: 555 RVA: 0x0002EAC5 File Offset: 0x0002CCC5
		[Reactive]
		public double ButtonsOpacity
		{
			[CompilerGenerated]
			get
			{
				return this.$ButtonsOpacity;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ButtonsOpacity, value, "ButtonsOpacity");
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x0600022C RID: 556 RVA: 0x0002EADA File Offset: 0x0002CCDA
		// (set) Token: 0x0600022D RID: 557 RVA: 0x0002EAE2 File Offset: 0x0002CCE2
		[Reactive]
		public bool IsVisible
		{
			[CompilerGenerated]
			get
			{
				return this.$IsVisible;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsVisible, value, "IsVisible");
			}
		}

		// Token: 0x0600022E RID: 558 RVA: 0x0002EAF8 File Offset: 0x0002CCF8
		public void YesRefreshCommand()
		{
			RefreshViewModel.<YesRefreshCommand>d__33 <YesRefreshCommand>d__;
			<YesRefreshCommand>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<YesRefreshCommand>d__.<>4__this = this;
			<YesRefreshCommand>d__.<>1__state = -1;
			<YesRefreshCommand>d__.<>t__builder.Start<RefreshViewModel.<YesRefreshCommand>d__33>(ref <YesRefreshCommand>d__);
		}

		// Token: 0x0600022F RID: 559 RVA: 0x0002EB2F File Offset: 0x0002CD2F
		public void CloseCommand()
		{
			this.IsShow = false;
		}

		// Token: 0x040000F1 RID: 241
		private MainWindowViewModel $MainWindowVm;

		// Token: 0x040000F2 RID: 242
		private string $RefreshText;

		// Token: 0x040000F3 RID: 243
		private double $SolidOpacity;

		// Token: 0x040000F4 RID: 244
		private double $Opacity;

		// Token: 0x040000F5 RID: 245
		private bool $IsShow;

		// Token: 0x040000F6 RID: 246
		private bool $IsShowButtons;

		// Token: 0x040000F7 RID: 247
		private double $ButtonsOpacity;

		// Token: 0x040000F8 RID: 248
		private bool $IsVisible;
	}
}
