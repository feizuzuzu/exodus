﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Avalonia.Threading;
using Exodus.Helpers;
using Exodus.Models;
using Exodus.Services;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.ViewModels
{
	// Token: 0x02000039 RID: 57
	[NullableContext(1)]
	[Nullable(0)]
	public class BuySellViewModel : ViewModelBase
	{
		// Token: 0x1700000B RID: 11
		// (get) Token: 0x060000A5 RID: 165 RVA: 0x00029141 File Offset: 0x00027341
		public MainWindowViewModel MainVm { get; }

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x060000A6 RID: 166 RVA: 0x00029149 File Offset: 0x00027349
		public ObservableCollection<SwapCoinItem> AllCryptoCoins { get; } = new ObservableCollection<SwapCoinItem>();

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x060000A7 RID: 167 RVA: 0x00029151 File Offset: 0x00027351
		public ObservableCollection<SwapCoinItem> FilteredCryptoCoins { get; } = new ObservableCollection<SwapCoinItem>();

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x060000A8 RID: 168 RVA: 0x00029159 File Offset: 0x00027359
		public List<FiatItem> FiatCurrencies { get; } = new List<FiatItem>
		{
			new FiatItem
			{
				Code = "USD",
				Name = "United States Dollar",
				Symbol = "$",
				FlagEmoji = "\ud83c\uddfa\ud83c\uddf8",
				RateToUsd = 1.0
			},
			new FiatItem
			{
				Code = "EUR",
				Name = "Euro",
				Symbol = "€",
				FlagEmoji = "\ud83c\uddea\ud83c\uddfa",
				RateToUsd = 1.08
			},
			new FiatItem
			{
				Code = "GBP",
				Name = "British Pound",
				Symbol = "£",
				FlagEmoji = "\ud83c\uddec\ud83c\udde7",
				RateToUsd = 1.28
			},
			new FiatItem
			{
				Code = "AUD",
				Name = "Australian Dollar",
				Symbol = "A$",
				FlagEmoji = "\ud83c\udde6\ud83c\uddfa",
				RateToUsd = 0.65
			},
			new FiatItem
			{
				Code = "CAD",
				Name = "Canadian Dollar",
				Symbol = "C$",
				FlagEmoji = "\ud83c\udde8\ud83c\udde6",
				RateToUsd = 0.73
			},
			new FiatItem
			{
				Code = "BRL",
				Name = "Brazilian Real",
				Symbol = "R$",
				FlagEmoji = "\ud83c\udde7\ud83c\uddf7",
				RateToUsd = 0.18
			},
			new FiatItem
			{
				Code = "CHF",
				Name = "Swiss Franc",
				Symbol = "CHF",
				FlagEmoji = "\ud83c\udde8\ud83c\udded",
				RateToUsd = 1.12
			},
			new FiatItem
			{
				Code = "COP",
				Name = "Colombian Peso",
				Symbol = "Col$",
				FlagEmoji = "\ud83c\udde8\ud83c\uddf4",
				RateToUsd = 0.00025
			}
		};

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x060000A9 RID: 169 RVA: 0x00029161 File Offset: 0x00027361
		// (set) Token: 0x060000AA RID: 170 RVA: 0x00029169 File Offset: 0x00027369
		[Reactive]
		public FiatItem SelectedFiat
		{
			[CompilerGenerated]
			get
			{
				return this.$SelectedFiat;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SelectedFiat, value, "SelectedFiat");
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x060000AB RID: 171 RVA: 0x0002917E File Offset: 0x0002737E
		// (set) Token: 0x060000AC RID: 172 RVA: 0x00029186 File Offset: 0x00027386
		[Nullable(2)]
		[Reactive]
		public SwapCoinItem SelectedCrypto
		{
			[NullableContext(2)]
			[CompilerGenerated]
			get
			{
				return this.$SelectedCrypto;
			}
			[NullableContext(2)]
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SelectedCrypto, value, "SelectedCrypto");
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x060000AD RID: 173 RVA: 0x0002919B File Offset: 0x0002739B
		// (set) Token: 0x060000AE RID: 174 RVA: 0x000291A3 File Offset: 0x000273A3
		[Reactive]
		public string PayAmountString
		{
			[CompilerGenerated]
			get
			{
				return this.$PayAmountString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PayAmountString, value, "PayAmountString");
			}
		} = "100";

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x060000AF RID: 175 RVA: 0x000291B8 File Offset: 0x000273B8
		// (set) Token: 0x060000B0 RID: 176 RVA: 0x000291C0 File Offset: 0x000273C0
		[Reactive]
		public string ReceiveCryptoString
		{
			[CompilerGenerated]
			get
			{
				return this.$ReceiveCryptoString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ReceiveCryptoString, value, "ReceiveCryptoString");
			}
		} = "0.00";

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x060000B1 RID: 177 RVA: 0x000291D5 File Offset: 0x000273D5
		// (set) Token: 0x060000B2 RID: 178 RVA: 0x000291DD File Offset: 0x000273DD
		[Reactive]
		public string RateInfoText
		{
			[CompilerGenerated]
			get
			{
				return this.$RateInfoText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$RateInfoText, value, "RateInfoText");
			}
		} = "";

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x060000B3 RID: 179 RVA: 0x000291F2 File Offset: 0x000273F2
		// (set) Token: 0x060000B4 RID: 180 RVA: 0x000291FA File Offset: 0x000273FA
		[Reactive]
		public string ActiveSubTab
		{
			[CompilerGenerated]
			get
			{
				return this.$ActiveSubTab;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ActiveSubTab, value, "ActiveSubTab");
			}
		} = "BUY";

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x060000B5 RID: 181 RVA: 0x0002920F File Offset: 0x0002740F
		// (set) Token: 0x060000B6 RID: 182 RVA: 0x00029217 File Offset: 0x00027417
		[Reactive]
		public bool IsCryptoPickerOpen
		{
			[CompilerGenerated]
			get
			{
				return this.$IsCryptoPickerOpen;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsCryptoPickerOpen, value, "IsCryptoPickerOpen");
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x060000B7 RID: 183 RVA: 0x0002922C File Offset: 0x0002742C
		// (set) Token: 0x060000B8 RID: 184 RVA: 0x00029234 File Offset: 0x00027434
		[Reactive]
		public bool IsFiatPickerOpen
		{
			[CompilerGenerated]
			get
			{
				return this.$IsFiatPickerOpen;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsFiatPickerOpen, value, "IsFiatPickerOpen");
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x060000B9 RID: 185 RVA: 0x00029249 File Offset: 0x00027449
		// (set) Token: 0x060000BA RID: 186 RVA: 0x00029251 File Offset: 0x00027451
		[Reactive]
		public string SearchQuery
		{
			[CompilerGenerated]
			get
			{
				return this.$SearchQuery;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SearchQuery, value, "SearchQuery");
			}
		} = "";

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x060000BB RID: 187 RVA: 0x00029266 File Offset: 0x00027466
		// (set) Token: 0x060000BC RID: 188 RVA: 0x0002926E File Offset: 0x0002746E
		[Reactive]
		public bool IsToastVisible
		{
			[CompilerGenerated]
			get
			{
				return this.$IsToastVisible;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsToastVisible, value, "IsToastVisible");
			}
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x060000BD RID: 189 RVA: 0x00029283 File Offset: 0x00027483
		// (set) Token: 0x060000BE RID: 190 RVA: 0x0002928B File Offset: 0x0002748B
		[Reactive]
		public string ToastMessage
		{
			[CompilerGenerated]
			get
			{
				return this.$ToastMessage;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ToastMessage, value, "ToastMessage");
			}
		} = "";

		// Token: 0x060000BF RID: 191 RVA: 0x000292A0 File Offset: 0x000274A0
		public BuySellViewModel(MainWindowViewModel mainVm)
		{
			this.MainVm = mainVm;
			this.SelectedFiat = this.FiatCurrencies[0];
			this.InitializeCoins();
			this.WhenAnyValue((BuySellViewModel x) => x.PayAmountString).Subscribe(delegate(string _)
			{
				this.CalculateReceive();
			});
			this.WhenAnyValue((BuySellViewModel x) => x.SearchQuery).Subscribe(delegate(string _)
			{
				this.ApplyCryptoFilter();
			});
			TransactionService.Instance.PriceUpdated += delegate([Nullable(2)] object s, EventArgs e)
			{
				Dispatcher.UIThread.InvokeAsync(delegate()
				{
					this.RefreshCoins();
				});
			};
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x00029620 File Offset: 0x00027820
		public void InitializeCoins()
		{
			this.AllCryptoCoins.Clear();
			if (this.MainVm.Coins == null)
			{
				return;
			}
			foreach (SwapCoinItem item in (from i in (from c in this.MainVm.Coins
			select new SwapCoinItem(c)).ToList<SwapCoinItem>()
			orderby i.ValueInUsd descending, i.Balance descending
			select i).ToList<SwapCoinItem>())
			{
				this.AllCryptoCoins.Add(item);
			}
			this.SelectedCrypto = (this.AllCryptoCoins.FirstOrDefault((SwapCoinItem c) => c.Symbol == "BTC") ?? this.AllCryptoCoins.FirstOrDefault<SwapCoinItem>());
			this.ApplyCryptoFilter();
			this.CalculateReceive();
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x00029758 File Offset: 0x00027958
		public void RefreshCoins()
		{
			foreach (SwapCoinItem swapCoinItem in this.AllCryptoCoins)
			{
				swapCoinItem.RefreshBalance();
			}
			this.CalculateReceive();
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x000297A8 File Offset: 0x000279A8
		private void CalculateReceive()
		{
			if (this.SelectedCrypto == null || this.SelectedFiat == null)
			{
				return;
			}
			double pay = this.ParseInputAmount(this.PayAmountString);
			double num = (this.SelectedCrypto.PriceUsd > 0.0) ? this.SelectedCrypto.PriceUsd : 1.0;
			double fiatRate = (this.SelectedFiat.RateToUsd > 0.0) ? this.SelectedFiat.RateToUsd : 1.0;
			double priceInFiat = num / fiatRate;
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(22, 3);
			defaultInterpolatedStringHandler.AppendLiteral("1 ");
			defaultInterpolatedStringHandler.AppendFormatted(this.SelectedCrypto.Symbol);
			defaultInterpolatedStringHandler.AppendLiteral(" ≈ $");
			defaultInterpolatedStringHandler.AppendFormatted<double>(priceInFiat, "N2");
			defaultInterpolatedStringHandler.AppendLiteral(" ");
			defaultInterpolatedStringHandler.AppendFormatted(this.SelectedFiat.Code);
			defaultInterpolatedStringHandler.AppendLiteral(" (Includes fee)");
			this.RateInfoText = defaultInterpolatedStringHandler.ToStringAndClear();
			if (pay > 0.0 && priceInFiat > 0.0)
			{
				double cryptoAmount = pay / priceInFiat;
				this.ReceiveCryptoString = NumberFormatHelper.FormatCrypto(cryptoAmount, 8);
				return;
			}
			this.ReceiveCryptoString = "0.00";
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x000298E0 File Offset: 0x00027AE0
		private double ParseInputAmount(string input)
		{
			if (string.IsNullOrWhiteSpace(input))
			{
				return 0.0;
			}
			double val;
			if (double.TryParse(input.Replace(" ", "").Replace(",", "").Replace("$", ""), NumberStyles.Any, CultureInfo.InvariantCulture, out val))
			{
				return val;
			}
			return 0.0;
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x0002994B File Offset: 0x00027B4B
		public void SetPresetAmount(string amount)
		{
			this.PayAmountString = amount;
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x00029954 File Offset: 0x00027B54
		public void SelectSubTab(string tab)
		{
			this.ActiveSubTab = tab;
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x0002995D File Offset: 0x00027B5D
		public void OpenCryptoPicker()
		{
			this.SearchQuery = "";
			this.ApplyCryptoFilter();
			this.IsCryptoPickerOpen = true;
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x00029977 File Offset: 0x00027B77
		public void CloseCryptoPicker()
		{
			this.IsCryptoPickerOpen = false;
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x00029980 File Offset: 0x00027B80
		[NullableContext(2)]
		public void SelectCrypto(SwapCoinItem coin)
		{
			if (coin == null)
			{
				return;
			}
			this.SelectedCrypto = coin;
			this.IsCryptoPickerOpen = false;
			this.CalculateReceive();
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x0002999A File Offset: 0x00027B9A
		public void OpenFiatPicker()
		{
			this.IsFiatPickerOpen = true;
		}

		// Token: 0x060000CA RID: 202 RVA: 0x000299A3 File Offset: 0x00027BA3
		public void CloseFiatPicker()
		{
			this.IsFiatPickerOpen = false;
		}

		// Token: 0x060000CB RID: 203 RVA: 0x000299AC File Offset: 0x00027BAC
		[NullableContext(2)]
		public void SelectFiat(FiatItem fiat)
		{
			if (fiat == null)
			{
				return;
			}
			this.SelectedFiat = fiat;
			this.IsFiatPickerOpen = false;
			this.CalculateReceive();
		}

		// Token: 0x060000CC RID: 204 RVA: 0x000299C8 File Offset: 0x00027BC8
		private void ApplyCryptoFilter()
		{
			this.FilteredCryptoCoins.Clear();
			string q = (this.SearchQuery ?? "").Trim().ToLower();
			foreach (SwapCoinItem c2 in (string.IsNullOrEmpty(q) ? this.AllCryptoCoins.AsEnumerable<SwapCoinItem>() : (from c in this.AllCryptoCoins
			where c.Symbol.ToLower().Contains(q) || c.Name.ToLower().Contains(q)
			select c)))
			{
				this.FilteredCryptoCoins.Add(c2);
			}
		}

		// Token: 0x060000CD RID: 205 RVA: 0x00029A78 File Offset: 0x00027C78
		public void ExecuteContinue()
		{
			this.ShowToast("Simulated Checkout: Preview mode (Balances preserved for LARP security)");
		}

		// Token: 0x060000CE RID: 206 RVA: 0x00029A85 File Offset: 0x00027C85
		public void BackToWallet()
		{
			this.MainVm.NavigateToWallet();
		}

		// Token: 0x060000CF RID: 207 RVA: 0x00029A92 File Offset: 0x00027C92
		public void ShowToast(string msg)
		{
			this.ToastMessage = msg;
			this.IsToastVisible = true;
			Task.Run(delegate()
			{
				BuySellViewModel.<<ShowToast>b__72_0>d <<ShowToast>b__72_0>d;
				<<ShowToast>b__72_0>d.<>t__builder = AsyncTaskMethodBuilder.Create();
				<<ShowToast>b__72_0>d.<>4__this = this;
				<<ShowToast>b__72_0>d.<>1__state = -1;
				<<ShowToast>b__72_0>d.<>t__builder.Start<BuySellViewModel.<<ShowToast>b__72_0>d>(ref <<ShowToast>b__72_0>d);
				return <<ShowToast>b__72_0>d.<>t__builder.Task;
			});
		}

		// Token: 0x0400002A RID: 42
		private FiatItem $SelectedFiat;

		// Token: 0x0400002B RID: 43
		private SwapCoinItem $SelectedCrypto;

		// Token: 0x0400002C RID: 44
		private string $PayAmountString;

		// Token: 0x0400002D RID: 45
		private string $ReceiveCryptoString;

		// Token: 0x0400002E RID: 46
		private string $RateInfoText;

		// Token: 0x0400002F RID: 47
		private string $ActiveSubTab;

		// Token: 0x04000030 RID: 48
		private bool $IsCryptoPickerOpen;

		// Token: 0x04000031 RID: 49
		private bool $IsFiatPickerOpen;

		// Token: 0x04000032 RID: 50
		private string $SearchQuery;

		// Token: 0x04000033 RID: 51
		private bool $IsToastVisible;

		// Token: 0x04000034 RID: 52
		private string $ToastMessage;
	}
}
