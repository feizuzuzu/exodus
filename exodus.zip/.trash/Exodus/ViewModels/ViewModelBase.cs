﻿using System;
using ReactiveUI;

namespace Exodus.ViewModels
{
	// Token: 0x02000068 RID: 104
	public class ViewModelBase : ReactiveObject
	{
	}
}
