﻿using System;
using System.Reactive;
using System.Runtime.CompilerServices;
using Avalonia.Media.Imaging;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.ViewModels
{
	// Token: 0x02000051 RID: 81
	[NullableContext(1)]
	[Nullable(0)]
	public class NotificationViewModel : ViewModelBase
	{
		// Token: 0x060001B8 RID: 440 RVA: 0x0002CE86 File Offset: 0x0002B086
		public NotificationViewModel()
		{
			this.CloseNotification = ReactiveCommand.Create(new Action(this._closeNotification), null, null);
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x060001B9 RID: 441 RVA: 0x0002CEA7 File Offset: 0x0002B0A7
		// (set) Token: 0x060001BA RID: 442 RVA: 0x0002CEAF File Offset: 0x0002B0AF
		[Reactive]
		public Bitmap Logo
		{
			[CompilerGenerated]
			get
			{
				return this.$Logo;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Logo, value, "Logo");
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x060001BB RID: 443 RVA: 0x0002CEC4 File Offset: 0x0002B0C4
		// (set) Token: 0x060001BC RID: 444 RVA: 0x0002CECC File Offset: 0x0002B0CC
		[Reactive]
		public bool IsNotification
		{
			[CompilerGenerated]
			get
			{
				return this.$IsNotification;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsNotification, value, "IsNotification");
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x060001BD RID: 445 RVA: 0x0002CEE1 File Offset: 0x0002B0E1
		// (set) Token: 0x060001BE RID: 446 RVA: 0x0002CEE9 File Offset: 0x0002B0E9
		[Reactive]
		public bool IsShow
		{
			[CompilerGenerated]
			get
			{
				return this.$IsShow;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsShow, value, "IsShow");
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x060001BF RID: 447 RVA: 0x0002CEFE File Offset: 0x0002B0FE
		// (set) Token: 0x060001C0 RID: 448 RVA: 0x0002CF06 File Offset: 0x0002B106
		[Nullable(2)]
		[Reactive]
		public CoinSpecificPartViewModel ViewPart
		{
			[NullableContext(2)]
			[CompilerGenerated]
			get
			{
				return this.$ViewPart;
			}
			[NullableContext(2)]
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ViewPart, value, "ViewPart");
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x060001C1 RID: 449 RVA: 0x0002CF1B File Offset: 0x0002B11B
		// (set) Token: 0x060001C2 RID: 450 RVA: 0x0002CF23 File Offset: 0x0002B123
		[Reactive]
		public double CurrentlyAdded
		{
			[CompilerGenerated]
			get
			{
				return this.$CurrentlyAdded;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$CurrentlyAdded, value, "CurrentlyAdded");
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x060001C3 RID: 451 RVA: 0x0002CF38 File Offset: 0x0002B138
		// (set) Token: 0x060001C4 RID: 452 RVA: 0x0002CF40 File Offset: 0x0002B140
		[Reactive]
		public double NotificationStripeWidth
		{
			[CompilerGenerated]
			get
			{
				return this.$NotificationStripeWidth;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$NotificationStripeWidth, value, "NotificationStripeWidth");
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x060001C5 RID: 453 RVA: 0x0002CF55 File Offset: 0x0002B155
		// (set) Token: 0x060001C6 RID: 454 RVA: 0x0002CF5D File Offset: 0x0002B15D
		[Reactive]
		public ReactiveCommand<Unit, Unit> CloseNotification
		{
			[CompilerGenerated]
			get
			{
				return this.$CloseNotification;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$CloseNotification, value, "CloseNotification");
			}
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x0002CF74 File Offset: 0x0002B174
		public void _closeNotification()
		{
			NotificationViewModel.<_closeNotification>d__29 <_closeNotification>d__;
			<_closeNotification>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<_closeNotification>d__.<>4__this = this;
			<_closeNotification>d__.<>1__state = -1;
			<_closeNotification>d__.<>t__builder.Start<NotificationViewModel.<_closeNotification>d__29>(ref <_closeNotification>d__);
		}

		// Token: 0x040000B4 RID: 180
		private Bitmap $Logo;

		// Token: 0x040000B5 RID: 181
		private bool $IsNotification;

		// Token: 0x040000B6 RID: 182
		private bool $IsShow;

		// Token: 0x040000B7 RID: 183
		private CoinSpecificPartViewModel $ViewPart;

		// Token: 0x040000B8 RID: 184
		private double $CurrentlyAdded;

		// Token: 0x040000B9 RID: 185
		private double $NotificationStripeWidth;

		// Token: 0x040000BA RID: 186
		private ReactiveCommand<Unit, Unit> $CloseNotification;
	}
}
