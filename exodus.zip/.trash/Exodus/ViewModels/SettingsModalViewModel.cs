﻿using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Exodus.Helpers;
using Exodus.Services;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.ViewModels
{
	// Token: 0x0200005F RID: 95
	[NullableContext(1)]
	[Nullable(0)]
	public class SettingsModalViewModel : ViewModelBase
	{
		// Token: 0x1700007C RID: 124
		// (get) Token: 0x0600023D RID: 573 RVA: 0x0002EEC6 File Offset: 0x0002D0C6
		public MainWindowViewModel MainVm { get; }

		// Token: 0x0600023E RID: 574 RVA: 0x0002EED0 File Offset: 0x0002D0D0
		public SettingsModalViewModel()
		{
		}

		// Token: 0x0600023F RID: 575 RVA: 0x0002EF30 File Offset: 0x0002D130
		public SettingsModalViewModel(MainWindowViewModel mainVm)
		{
			this.MainVm = mainVm;
			this.IsShow = false;
			this.IsVisible = false;
			this.Opacity = 0.0;
			this.SolidOpacity = 0.0;
			this.WhenAnyValue((SettingsModalViewModel x) => x.IsShow).Subscribe(delegate(bool isShow)
			{
				SettingsModalViewModel.<<-ctor>b__4_1>d <<-ctor>b__4_1>d;
				<<-ctor>b__4_1>d.<>t__builder = AsyncVoidMethodBuilder.Create();
				<<-ctor>b__4_1>d.<>4__this = this;
				<<-ctor>b__4_1>d.isShow = isShow;
				<<-ctor>b__4_1>d.<>1__state = -1;
				<<-ctor>b__4_1>d.<>t__builder.Start<SettingsModalViewModel.<<-ctor>b__4_1>d>(ref <<-ctor>b__4_1>d);
			});
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x06000240 RID: 576 RVA: 0x0002F012 File Offset: 0x0002D212
		// (set) Token: 0x06000241 RID: 577 RVA: 0x0002F01A File Offset: 0x0002D21A
		[Reactive]
		public bool IsShow
		{
			[CompilerGenerated]
			get
			{
				return this.$IsShow;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsShow, value, "IsShow");
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x06000242 RID: 578 RVA: 0x0002F02F File Offset: 0x0002D22F
		// (set) Token: 0x06000243 RID: 579 RVA: 0x0002F037 File Offset: 0x0002D237
		[Reactive]
		public bool IsVisible
		{
			[CompilerGenerated]
			get
			{
				return this.$IsVisible;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsVisible, value, "IsVisible");
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x06000244 RID: 580 RVA: 0x0002F04C File Offset: 0x0002D24C
		// (set) Token: 0x06000245 RID: 581 RVA: 0x0002F054 File Offset: 0x0002D254
		[Reactive]
		public double Opacity
		{
			[CompilerGenerated]
			get
			{
				return this.$Opacity;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Opacity, value, "Opacity");
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06000246 RID: 582 RVA: 0x0002F069 File Offset: 0x0002D269
		// (set) Token: 0x06000247 RID: 583 RVA: 0x0002F071 File Offset: 0x0002D271
		[Reactive]
		public double SolidOpacity
		{
			[CompilerGenerated]
			get
			{
				return this.$SolidOpacity;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SolidOpacity, value, "SolidOpacity");
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06000248 RID: 584 RVA: 0x0002F086 File Offset: 0x0002D286
		// (set) Token: 0x06000249 RID: 585 RVA: 0x0002F08E File Offset: 0x0002D28E
		[Reactive]
		public string TelegramUrl
		{
			[CompilerGenerated]
			get
			{
				return this.$TelegramUrl;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TelegramUrl, value, "TelegramUrl");
			}
		} = "https://t.me/exodus_larp";

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x0600024A RID: 586 RVA: 0x0002F0A3 File Offset: 0x0002D2A3
		// (set) Token: 0x0600024B RID: 587 RVA: 0x0002F0AB File Offset: 0x0002D2AB
		[Reactive]
		public string WebsiteUrl
		{
			[CompilerGenerated]
			get
			{
				return this.$WebsiteUrl;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$WebsiteUrl, value, "WebsiteUrl");
			}
		} = "https://exoduslarp.com";

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x0600024C RID: 588 RVA: 0x0002F0C0 File Offset: 0x0002D2C0
		// (set) Token: 0x0600024D RID: 589 RVA: 0x0002F0C8 File Offset: 0x0002D2C8
		[Reactive]
		public string AppVersion
		{
			[CompilerGenerated]
			get
			{
				return this.$AppVersion;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$AppVersion, value, "AppVersion");
			}
		} = VersionService.Instance.CurrentVersion;

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x0600024E RID: 590 RVA: 0x0002F0DD File Offset: 0x0002D2DD
		// (set) Token: 0x0600024F RID: 591 RVA: 0x0002F0E5 File Offset: 0x0002D2E5
		[Reactive]
		public string VersionBadge
		{
			[CompilerGenerated]
			get
			{
				return this.$VersionBadge;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$VersionBadge, value, "VersionBadge");
			}
		} = "v" + VersionService.Instance.CurrentVersion;

		// Token: 0x06000250 RID: 592 RVA: 0x0002F0FA File Offset: 0x0002D2FA
		public void UpdateVersion(string version)
		{
			this.AppVersion = version;
			this.VersionBadge = "v" + version;
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x06000251 RID: 593 RVA: 0x0002F114 File Offset: 0x0002D314
		// (set) Token: 0x06000252 RID: 594 RVA: 0x0002F11C File Offset: 0x0002D31C
		[Reactive]
		public string CopyFeedbackMessage
		{
			[CompilerGenerated]
			get
			{
				return this.$CopyFeedbackMessage;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$CopyFeedbackMessage, value, "CopyFeedbackMessage");
			}
		} = "";

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x06000253 RID: 595 RVA: 0x0002F131 File Offset: 0x0002D331
		// (set) Token: 0x06000254 RID: 596 RVA: 0x0002F139 File Offset: 0x0002D339
		[Reactive]
		public bool IsFeedbackVisible
		{
			[CompilerGenerated]
			get
			{
				return this.$IsFeedbackVisible;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsFeedbackVisible, value, "IsFeedbackVisible");
			}
		}

		// Token: 0x06000255 RID: 597 RVA: 0x0002F14E File Offset: 0x0002D34E
		public void OpenTelegram()
		{
			UrlUtils.OpenUrl(this.TelegramUrl);
		}

		// Token: 0x06000256 RID: 598 RVA: 0x0002F15B File Offset: 0x0002D35B
		public void OpenWebsite()
		{
			UrlUtils.OpenUrl(this.WebsiteUrl);
		}

		// Token: 0x06000257 RID: 599 RVA: 0x0002F168 File Offset: 0x0002D368
		public void CopyTelegram()
		{
			GeneralServices.Instance.CopyTextToClipBoard(this.TelegramUrl);
			this.ShowFeedback("Telegram link copied to clipboard!");
		}

		// Token: 0x06000258 RID: 600 RVA: 0x0002F185 File Offset: 0x0002D385
		public void CopyWebsite()
		{
			GeneralServices.Instance.CopyTextToClipBoard(this.WebsiteUrl);
			this.ShowFeedback("Website URL copied to clipboard!");
		}

		// Token: 0x06000259 RID: 601 RVA: 0x0002F1A2 File Offset: 0x0002D3A2
		private void ShowFeedback(string message)
		{
			this.CopyFeedbackMessage = message;
			this.IsFeedbackVisible = true;
			Task.Run(delegate()
			{
				SettingsModalViewModel.<<ShowFeedback>b__50_0>d <<ShowFeedback>b__50_0>d;
				<<ShowFeedback>b__50_0>d.<>t__builder = AsyncTaskMethodBuilder.Create();
				<<ShowFeedback>b__50_0>d.<>4__this = this;
				<<ShowFeedback>b__50_0>d.<>1__state = -1;
				<<ShowFeedback>b__50_0>d.<>t__builder.Start<SettingsModalViewModel.<<ShowFeedback>b__50_0>d>(ref <<ShowFeedback>b__50_0>d);
				return <<ShowFeedback>b__50_0>d.<>t__builder.Task;
			});
		}

		// Token: 0x0600025A RID: 602 RVA: 0x0002F1C4 File Offset: 0x0002D3C4
		public void CloseCommand()
		{
			this.IsShow = false;
		}

		// Token: 0x04000106 RID: 262
		private bool $IsShow;

		// Token: 0x04000107 RID: 263
		private bool $IsVisible;

		// Token: 0x04000108 RID: 264
		private double $Opacity;

		// Token: 0x04000109 RID: 265
		private double $SolidOpacity;

		// Token: 0x0400010A RID: 266
		private string $TelegramUrl;

		// Token: 0x0400010B RID: 267
		private string $WebsiteUrl;

		// Token: 0x0400010C RID: 268
		private string $AppVersion;

		// Token: 0x0400010D RID: 269
		private string $VersionBadge;

		// Token: 0x0400010E RID: 270
		private string $CopyFeedbackMessage;

		// Token: 0x0400010F RID: 271
		private bool $IsFeedbackVisible;
	}
}
