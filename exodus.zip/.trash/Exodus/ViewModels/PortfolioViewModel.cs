﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using Avalonia.Media;
using Avalonia.Threading;
using Exodus.Helpers;
using Exodus.Models;
using Exodus.Services;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.ViewModels
{
	// Token: 0x02000053 RID: 83
	[NullableContext(1)]
	[Nullable(0)]
	public class PortfolioViewModel : ViewModelBase
	{
		// Token: 0x1700005B RID: 91
		// (get) Token: 0x060001CA RID: 458 RVA: 0x0002D096 File Offset: 0x0002B296
		public MainWindowViewModel MainVm { get; }

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x060001CB RID: 459 RVA: 0x0002D09E File Offset: 0x0002B29E
		// (set) Token: 0x060001CC RID: 460 RVA: 0x0002D0A6 File Offset: 0x0002B2A6
		[Reactive]
		public string TotalBalanceString
		{
			[CompilerGenerated]
			get
			{
				return this.$TotalBalanceString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TotalBalanceString, value, "TotalBalanceString");
			}
		} = "$0.00";

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x060001CD RID: 461 RVA: 0x0002D0BB File Offset: 0x0002B2BB
		// (set) Token: 0x060001CE RID: 462 RVA: 0x0002D0C3 File Offset: 0x0002B2C3
		[Reactive]
		public string AssetCountText
		{
			[CompilerGenerated]
			get
			{
				return this.$AssetCountText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$AssetCountText, value, "AssetCountText");
			}
		} = "0 Assets";

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x060001CF RID: 463 RVA: 0x0002D0D8 File Offset: 0x0002B2D8
		// (set) Token: 0x060001D0 RID: 464 RVA: 0x0002D0E0 File Offset: 0x0002B2E0
		[Reactive]
		public string Change24HString
		{
			[CompilerGenerated]
			get
			{
				return this.$Change24HString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Change24HString, value, "Change24HString");
			}
		} = "+$0.00 (+0.00%)";

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x060001D1 RID: 465 RVA: 0x0002D0F5 File Offset: 0x0002B2F5
		// (set) Token: 0x060001D2 RID: 466 RVA: 0x0002D0FD File Offset: 0x0002B2FD
		[Reactive]
		public bool IsChange24HPositive
		{
			[CompilerGenerated]
			get
			{
				return this.$IsChange24HPositive;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsChange24HPositive, value, "IsChange24HPositive");
			}
		} = true;

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x060001D3 RID: 467 RVA: 0x0002D112 File Offset: 0x0002B312
		// (set) Token: 0x060001D4 RID: 468 RVA: 0x0002D11A File Offset: 0x0002B31A
		[Reactive]
		public IBrush Change24HBrush
		{
			[CompilerGenerated]
			get
			{
				return this.$Change24HBrush;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Change24HBrush, value, "Change24HBrush");
			}
		} = Brushes.LimeGreen;

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x060001D5 RID: 469 RVA: 0x0002D12F File Offset: 0x0002B32F
		// (set) Token: 0x060001D6 RID: 470 RVA: 0x0002D137 File Offset: 0x0002B337
		[Reactive]
		public string HighestBalanceText
		{
			[CompilerGenerated]
			get
			{
				return this.$HighestBalanceText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$HighestBalanceText, value, "HighestBalanceText");
			}
		} = "$0.00";

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x060001D7 RID: 471 RVA: 0x0002D14C File Offset: 0x0002B34C
		// (set) Token: 0x060001D8 RID: 472 RVA: 0x0002D154 File Offset: 0x0002B354
		[Reactive]
		public string PortfolioAgeText
		{
			[CompilerGenerated]
			get
			{
				return this.$PortfolioAgeText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PortfolioAgeText, value, "PortfolioAgeText");
			}
		} = "11 Months, 2 Days";

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x060001D9 RID: 473 RVA: 0x0002D169 File Offset: 0x0002B369
		// (set) Token: 0x060001DA RID: 474 RVA: 0x0002D171 File Offset: 0x0002B371
		[Reactive]
		public string Best24HAsset
		{
			[CompilerGenerated]
			get
			{
				return this.$Best24HAsset;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Best24HAsset, value, "Best24HAsset");
			}
		} = "-";

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x060001DB RID: 475 RVA: 0x0002D186 File Offset: 0x0002B386
		// (set) Token: 0x060001DC RID: 476 RVA: 0x0002D18E File Offset: 0x0002B38E
		[Reactive]
		public string Worst24HAsset
		{
			[CompilerGenerated]
			get
			{
				return this.$Worst24HAsset;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Worst24HAsset, value, "Worst24HAsset");
			}
		} = "-";

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x060001DD RID: 477 RVA: 0x0002D1A3 File Offset: 0x0002B3A3
		// (set) Token: 0x060001DE RID: 478 RVA: 0x0002D1AB File Offset: 0x0002B3AB
		[Reactive]
		public string SelectedTimeRange
		{
			[CompilerGenerated]
			get
			{
				return this.$SelectedTimeRange;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SelectedTimeRange, value, "SelectedTimeRange");
			}
		} = "NOW";

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x060001DF RID: 479 RVA: 0x0002D1C0 File Offset: 0x0002B3C0
		// (set) Token: 0x060001E0 RID: 480 RVA: 0x0002D1C8 File Offset: 0x0002B3C8
		[Reactive]
		public bool FilterWithBalance
		{
			[CompilerGenerated]
			get
			{
				return this.$FilterWithBalance;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$FilterWithBalance, value, "FilterWithBalance");
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x060001E1 RID: 481 RVA: 0x0002D1DD File Offset: 0x0002B3DD
		// (set) Token: 0x060001E2 RID: 482 RVA: 0x0002D1E5 File Offset: 0x0002B3E5
		[Reactive]
		public bool FilterFavorite
		{
			[CompilerGenerated]
			get
			{
				return this.$FilterFavorite;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$FilterFavorite, value, "FilterFavorite");
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x060001E3 RID: 483 RVA: 0x0002D1FA File Offset: 0x0002B3FA
		// (set) Token: 0x060001E4 RID: 484 RVA: 0x0002D202 File Offset: 0x0002B402
		[Reactive]
		public string ActiveSubTab
		{
			[CompilerGenerated]
			get
			{
				return this.$ActiveSubTab;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ActiveSubTab, value, "ActiveSubTab");
			}
		} = "OVERVIEW";

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x060001E5 RID: 485 RVA: 0x0002D217 File Offset: 0x0002B417
		public ObservableCollection<PortfolioCoinItem> AllItems { get; } = new ObservableCollection<PortfolioCoinItem>();

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x060001E6 RID: 486 RVA: 0x0002D21F File Offset: 0x0002B41F
		public ObservableCollection<PortfolioCoinItem> DisplayItems { get; } = new ObservableCollection<PortfolioCoinItem>();

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x060001E7 RID: 487 RVA: 0x0002D227 File Offset: 0x0002B427
		public ObservableCollection<DonutSegment> DonutSegments { get; } = new ObservableCollection<DonutSegment>();

		// Token: 0x060001E8 RID: 488 RVA: 0x0002D230 File Offset: 0x0002B430
		public PortfolioViewModel(MainWindowViewModel mainVm)
		{
			this.MainVm = mainVm;
			this.WhenAnyValue((PortfolioViewModel x) => x.FilterWithBalance, (PortfolioViewModel x) => x.FilterFavorite).Subscribe(delegate(ValueTuple<bool, bool> _)
			{
				this.ApplyFilters();
			});
			this.InitializeItems();
			this.UpdatePortfolio(true);
			TransactionService.Instance.PriceUpdated += delegate([Nullable(2)] object sender, EventArgs args)
			{
				Dispatcher.UIThread.InvokeAsync(delegate()
				{
					this.UpdatePortfolio(false);
				});
			};
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x0002D398 File Offset: 0x0002B598
		private void InitializeItems()
		{
			this.AllItems.Clear();
			if (this.MainVm.Coins == null)
			{
				return;
			}
			foreach (Coin coin in this.MainVm.Coins)
			{
				PortfolioCoinItem item = new PortfolioCoinItem(coin);
				this.AllItems.Add(item);
			}
			this.ApplyFilters();
		}

		// Token: 0x060001EA RID: 490 RVA: 0x0002D414 File Offset: 0x0002B614
		public void SelectTimeRange(string range)
		{
			this.SelectedTimeRange = range;
		}

		// Token: 0x060001EB RID: 491 RVA: 0x0002D41D File Offset: 0x0002B61D
		public void SelectSubTab(string tab)
		{
			this.ActiveSubTab = tab;
		}

		// Token: 0x060001EC RID: 492 RVA: 0x0002D426 File Offset: 0x0002B626
		[NullableContext(2)]
		public void SelectCoin(PortfolioCoinItem item)
		{
			if (item == null || item.OriginalCoin == null)
			{
				return;
			}
			this.MainVm.SelectCoinAndOpenWallet(item.OriginalCoin);
		}

		// Token: 0x060001ED RID: 493 RVA: 0x0002D448 File Offset: 0x0002B648
		private void ApplyFilters()
		{
			this.DisplayItems.Clear();
			IEnumerable<PortfolioCoinItem> query = this.AllItems.AsEnumerable<PortfolioCoinItem>();
			if (this.FilterWithBalance)
			{
				query = from i in query
				where i.Balance > 0.0
				select i;
			}
			foreach (PortfolioCoinItem item in (from i in query
			orderby i.ValueInUsd descending
			select i).ToList<PortfolioCoinItem>())
			{
				this.DisplayItems.Add(item);
			}
		}

		// Token: 0x060001EE RID: 494 RVA: 0x0002D50C File Offset: 0x0002B70C
		public void UpdatePortfolio(bool playAnimation = false)
		{
			if (this.MainVm.Coins == null || this.AllItems.Count == 0)
			{
				return;
			}
			double totalBalance = 0.0;
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler;
			foreach (PortfolioCoinItem item in this.AllItems)
			{
				item.Balance = item.OriginalCoin.Balance;
				item.Price = TransactionService.Instance.GetPrice(item.Symbol);
				item.ValueInUsd = Math.Round(item.Balance * item.Price, 2);
				PortfolioCoinItem portfolioCoinItem = item;
				string priceString;
				if (item.Price < 1.0)
				{
					defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
					defaultInterpolatedStringHandler.AppendLiteral("$");
					defaultInterpolatedStringHandler.AppendFormatted<double>(item.Price, "0.000000");
					priceString = defaultInterpolatedStringHandler.ToStringAndClear();
				}
				else
				{
					defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
					defaultInterpolatedStringHandler.AppendLiteral("$");
					defaultInterpolatedStringHandler.AppendFormatted<double>(item.Price, "N2");
					priceString = defaultInterpolatedStringHandler.ToStringAndClear();
				}
				portfolioCoinItem.PriceString = priceString;
				item.BalanceString = ((item.Balance > 0.0) ? (NumberFormatHelper.FormatCrypto(item.Balance, 8) + " " + item.Symbol) : ("0.00 " + item.Symbol));
				PortfolioCoinItem portfolioCoinItem2 = item;
				defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
				defaultInterpolatedStringHandler.AppendLiteral("$");
				defaultInterpolatedStringHandler.AppendFormatted<double>(item.ValueInUsd, "N2");
				portfolioCoinItem2.ValueInUsdString = defaultInterpolatedStringHandler.ToStringAndClear();
				totalBalance += item.ValueInUsd;
			}
			this._finalTotalBalance = totalBalance;
			int assetCount = 0;
			double weightedChange = 0.0;
			foreach (PortfolioCoinItem item2 in this.AllItems)
			{
				if (totalBalance > 0.0)
				{
					item2.PortfolioPercentage = Math.Round(item2.ValueInUsd / totalBalance * 100.0, 2);
					PortfolioCoinItem portfolioCoinItem3 = item2;
					string portfolioPercentageString;
					if (item2.PortfolioPercentage < 1.0)
					{
						if (item2.PortfolioPercentage <= 0.0)
						{
							portfolioPercentageString = "0%";
						}
						else
						{
							defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
							defaultInterpolatedStringHandler.AppendFormatted<double>(item2.PortfolioPercentage, "0.00");
							defaultInterpolatedStringHandler.AppendLiteral("%");
							portfolioPercentageString = defaultInterpolatedStringHandler.ToStringAndClear();
						}
					}
					else
					{
						defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
						defaultInterpolatedStringHandler.AppendFormatted<double>(Math.Round(item2.PortfolioPercentage), "0");
						defaultInterpolatedStringHandler.AppendLiteral("%");
						portfolioPercentageString = defaultInterpolatedStringHandler.ToStringAndClear();
					}
					portfolioCoinItem3.PortfolioPercentageString = portfolioPercentageString;
				}
				else
				{
					item2.PortfolioPercentage = 0.0;
					item2.PortfolioPercentageString = "0%";
				}
				if (item2.Balance > 0.0)
				{
					assetCount++;
					weightedChange += item2.PortfolioPercentage / 100.0 * item2.Change24H;
				}
			}
			string assetCountText;
			if (assetCount != 1)
			{
				defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(7, 1);
				defaultInterpolatedStringHandler.AppendFormatted<int>(assetCount);
				defaultInterpolatedStringHandler.AppendLiteral(" Assets");
				assetCountText = defaultInterpolatedStringHandler.ToStringAndClear();
			}
			else
			{
				assetCountText = "1 Asset";
			}
			this.AssetCountText = assetCountText;
			this.IsChange24HPositive = (weightedChange >= 0.0);
			double changeUsd = totalBalance * (weightedChange / 100.0);
			string str = this.IsChange24HPositive ? "+$" : "-$";
			defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(4, 3);
			defaultInterpolatedStringHandler.AppendFormatted<double>(Math.Abs(changeUsd), "N2");
			defaultInterpolatedStringHandler.AppendLiteral(" (");
			defaultInterpolatedStringHandler.AppendFormatted(this.IsChange24HPositive ? "+" : "-");
			defaultInterpolatedStringHandler.AppendFormatted<double>(Math.Abs(weightedChange), "0.00");
			defaultInterpolatedStringHandler.AppendLiteral("%)");
			this.Change24HString = str + defaultInterpolatedStringHandler.ToStringAndClear();
			this.Change24HBrush = (this.IsChange24HPositive ? Brush.Parse("#00E676") : Brush.Parse("#FF5252"));
			defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
			defaultInterpolatedStringHandler.AppendLiteral("$");
			defaultInterpolatedStringHandler.AppendFormatted<double>(totalBalance * 1.004, "N2");
			this.HighestBalanceText = defaultInterpolatedStringHandler.ToStringAndClear();
			List<PortfolioCoinItem> withBalance = (from i in this.AllItems
			where i.Balance > 0.0
			select i).ToList<PortfolioCoinItem>();
			List<PortfolioCoinItem> pool = (withBalance.Count > 0) ? withBalance : this.AllItems.ToList<PortfolioCoinItem>();
			if (pool.Count > 0)
			{
				PortfolioCoinItem best = (from i in pool
				orderby i.Change24H descending
				select i).First<PortfolioCoinItem>();
				PortfolioCoinItem worst = (from i in pool
				orderby i.Change24H
				select i).First<PortfolioCoinItem>();
				this.Best24HAsset = best.Name + " " + best.Change24HString;
				this.Worst24HAsset = worst.Name + " " + worst.Change24HString;
			}
			this._cachedPositiveItems = (from i in pool
			where i.PortfolioPercentage > 0.0
			orderby i.PortfolioPercentage descending
			select i).ToList<PortfolioCoinItem>();
			this.ApplyFilters();
			if (playAnimation)
			{
				this.PlayEntranceAnimation();
				return;
			}
			defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
			defaultInterpolatedStringHandler.AppendLiteral("$");
			defaultInterpolatedStringHandler.AppendFormatted<double>(this._finalTotalBalance, "N2");
			this.TotalBalanceString = defaultInterpolatedStringHandler.ToStringAndClear();
			this.RenderDonutWithProgress(1.0);
		}

		// Token: 0x060001EF RID: 495 RVA: 0x0002DB24 File Offset: 0x0002BD24
		public void PlayEntranceAnimation()
		{
			DispatcherTimer animTimer = this._animTimer;
			if (animTimer != null)
			{
				animTimer.Stop();
			}
			this._animStartTime = DateTime.UtcNow;
			this.RenderDonutWithProgress(0.0);
			this._animTimer = new DispatcherTimer
			{
				Interval = TimeSpan.FromMilliseconds(16.0)
			};
			this._animTimer.Tick += delegate([Nullable(2)] object s, EventArgs e)
			{
				double t = Math.Clamp((DateTime.UtcNow - this._animStartTime).TotalMilliseconds / 800.0, 0.0, 1.0);
				double progress = 1.0 - Math.Pow(1.0 - t, 3.0);
				this.RenderDonutWithProgress(progress);
				if (t >= 1.0)
				{
					this._animTimer.Stop();
					this.RenderDonutWithProgress(1.0);
				}
			};
			this._animTimer.Start();
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x0002DBA0 File Offset: 0x0002BDA0
		private void RenderDonutWithProgress(double progress)
		{
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
			defaultInterpolatedStringHandler.AppendLiteral("$");
			defaultInterpolatedStringHandler.AppendFormatted<double>(this._finalTotalBalance * progress, "N2");
			this.TotalBalanceString = defaultInterpolatedStringHandler.ToStringAndClear();
			this.DonutSegments.Clear();
			if (this._cachedPositiveItems.Count == 0)
			{
				Collection<DonutSegment> donutSegments = this.DonutSegments;
				DonutSegment donutSegment = new DonutSegment();
				donutSegment.Name = "None";
				donutSegment.Symbol = "";
				donutSegment.Percentage = 100.0;
				donutSegment.Brush = Brush.Parse("#2A3038");
				defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(27, 10);
				defaultInterpolatedStringHandler.AppendLiteral("M ");
				defaultInterpolatedStringHandler.AppendFormatted<double>(210.0);
				defaultInterpolatedStringHandler.AppendLiteral(",");
				defaultInterpolatedStringHandler.AppendFormatted<double>(30.0);
				defaultInterpolatedStringHandler.AppendLiteral(" A ");
				defaultInterpolatedStringHandler.AppendFormatted<double>(180.0);
				defaultInterpolatedStringHandler.AppendLiteral(",");
				defaultInterpolatedStringHandler.AppendFormatted<double>(180.0);
				defaultInterpolatedStringHandler.AppendLiteral(" 0 1,1 ");
				defaultInterpolatedStringHandler.AppendFormatted<double>(210.0);
				defaultInterpolatedStringHandler.AppendLiteral(",");
				defaultInterpolatedStringHandler.AppendFormatted<double>(390.0);
				defaultInterpolatedStringHandler.AppendLiteral(" A ");
				defaultInterpolatedStringHandler.AppendFormatted<double>(180.0);
				defaultInterpolatedStringHandler.AppendLiteral(",");
				defaultInterpolatedStringHandler.AppendFormatted<double>(180.0);
				defaultInterpolatedStringHandler.AppendLiteral(" 0 1,1 ");
				defaultInterpolatedStringHandler.AppendFormatted<double>(210.0);
				defaultInterpolatedStringHandler.AppendLiteral(",");
				defaultInterpolatedStringHandler.AppendFormatted<double>(30.0);
				donutSegment.PathData = defaultInterpolatedStringHandler.ToStringAndClear();
				donutSegments.Add(donutSegment);
				return;
			}
			if (progress <= 0.001)
			{
				return;
			}
			if (this._cachedPositiveItems.Count != 1)
			{
				double currentAngle = 0.0;
				double gap = 2.2 * Math.Min(1.0, progress * 1.5);
				foreach (PortfolioCoinItem item in this._cachedPositiveItems)
				{
					double targetSweep = item.PortfolioPercentage / 100.0 * 360.0;
					double currentSweep = targetSweep * progress;
					if (currentSweep >= 0.5)
					{
						double actualSweep = (currentSweep > gap) ? (currentSweep - gap) : currentSweep;
						double num = currentAngle + gap / 2.0;
						double endDeg = num + actualSweep;
						double rad = (num - 90.0) * 3.141592653589793 / 180.0;
						double rad2 = (endDeg - 90.0) * 3.141592653589793 / 180.0;
						double x = 210.0 + 180.0 * Math.Cos(rad);
						double y = 210.0 + 180.0 * Math.Sin(rad);
						double x2 = 210.0 + 180.0 * Math.Cos(rad2);
						double y2 = 210.0 + 180.0 * Math.Sin(rad2);
						int isLargeArc = (actualSweep > 180.0) ? 1 : 0;
						string path = string.Format(CultureInfo.InvariantCulture, "M {0:F2},{1:F2} A {2:F2},{2:F2} 0 {3},1 {4:F2},{5:F2}", new object[]
						{
							x,
							y,
							180.0,
							isLargeArc,
							x2,
							y2
						});
						this.DonutSegments.Add(new DonutSegment
						{
							Name = item.Name,
							Symbol = item.Symbol,
							Percentage = item.PortfolioPercentage,
							Brush = Brush.Parse(item.BrandHex),
							PathData = path
						});
						currentAngle += targetSweep * progress;
					}
				}
				return;
			}
			PortfolioCoinItem item2 = this._cachedPositiveItems[0];
			double sweep = 360.0 * progress;
			if (sweep < 0.5)
			{
				return;
			}
			if (sweep >= 359.5)
			{
				Collection<DonutSegment> donutSegments2 = this.DonutSegments;
				DonutSegment donutSegment2 = new DonutSegment();
				donutSegment2.Name = item2.Name;
				donutSegment2.Symbol = item2.Symbol;
				donutSegment2.Percentage = 100.0;
				donutSegment2.Brush = Brush.Parse(item2.BrandHex);
				defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(27, 10);
				defaultInterpolatedStringHandler.AppendLiteral("M ");
				defaultInterpolatedStringHandler.AppendFormatted<double>(210.0);
				defaultInterpolatedStringHandler.AppendLiteral(",");
				defaultInterpolatedStringHandler.AppendFormatted<double>(30.0);
				defaultInterpolatedStringHandler.AppendLiteral(" A ");
				defaultInterpolatedStringHandler.AppendFormatted<double>(180.0);
				defaultInterpolatedStringHandler.AppendLiteral(",");
				defaultInterpolatedStringHandler.AppendFormatted<double>(180.0);
				defaultInterpolatedStringHandler.AppendLiteral(" 0 1,1 ");
				defaultInterpolatedStringHandler.AppendFormatted<double>(210.0);
				defaultInterpolatedStringHandler.AppendLiteral(",");
				defaultInterpolatedStringHandler.AppendFormatted<double>(390.0);
				defaultInterpolatedStringHandler.AppendLiteral(" A ");
				defaultInterpolatedStringHandler.AppendFormatted<double>(180.0);
				defaultInterpolatedStringHandler.AppendLiteral(",");
				defaultInterpolatedStringHandler.AppendFormatted<double>(180.0);
				defaultInterpolatedStringHandler.AppendLiteral(" 0 1,1 ");
				defaultInterpolatedStringHandler.AppendFormatted<double>(210.0);
				defaultInterpolatedStringHandler.AppendLiteral(",");
				defaultInterpolatedStringHandler.AppendFormatted<double>(30.0);
				donutSegment2.PathData = defaultInterpolatedStringHandler.ToStringAndClear();
				donutSegments2.Add(donutSegment2);
				return;
			}
			double rad3 = (sweep - 90.0) * 3.141592653589793 / 180.0;
			double x3 = 210.0 + 180.0 * Math.Cos(rad3);
			double y3 = 210.0 + 180.0 * Math.Sin(rad3);
			int isLargeArc2 = (sweep > 180.0) ? 1 : 0;
			string path2 = string.Format(CultureInfo.InvariantCulture, "M {0:F2},{1:F2} A {2:F2},{2:F2} 0 {3},1 {4:F2},{5:F2}", new object[]
			{
				210.0,
				30.0,
				180.0,
				isLargeArc2,
				x3,
				y3
			});
			this.DonutSegments.Add(new DonutSegment
			{
				Name = item2.Name,
				Symbol = item2.Symbol,
				Percentage = 100.0,
				Brush = Brush.Parse(item2.BrandHex),
				PathData = path2
			});
		}

		// Token: 0x040000C3 RID: 195
		[Nullable(2)]
		private DispatcherTimer _animTimer;

		// Token: 0x040000C4 RID: 196
		private DateTime _animStartTime;

		// Token: 0x040000C5 RID: 197
		private const double AnimDurationMs = 800.0;

		// Token: 0x040000C6 RID: 198
		private double _finalTotalBalance;

		// Token: 0x040000C7 RID: 199
		private List<PortfolioCoinItem> _cachedPositiveItems = new List<PortfolioCoinItem>();

		// Token: 0x040000C8 RID: 200
		private string $TotalBalanceString;

		// Token: 0x040000C9 RID: 201
		private string $AssetCountText;

		// Token: 0x040000CA RID: 202
		private string $Change24HString;

		// Token: 0x040000CB RID: 203
		private bool $IsChange24HPositive;

		// Token: 0x040000CC RID: 204
		private IBrush $Change24HBrush;

		// Token: 0x040000CD RID: 205
		private string $HighestBalanceText;

		// Token: 0x040000CE RID: 206
		private string $PortfolioAgeText;

		// Token: 0x040000CF RID: 207
		private string $Best24HAsset;

		// Token: 0x040000D0 RID: 208
		private string $Worst24HAsset;

		// Token: 0x040000D1 RID: 209
		private string $SelectedTimeRange;

		// Token: 0x040000D2 RID: 210
		private bool $FilterWithBalance;

		// Token: 0x040000D3 RID: 211
		private bool $FilterFavorite;

		// Token: 0x040000D4 RID: 212
		private string $ActiveSubTab;
	}
}
