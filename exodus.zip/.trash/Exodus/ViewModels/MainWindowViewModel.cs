﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Media;
using System.Reactive.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using Avalonia.Threading;
using Exodus.Models;
using Exodus.Services;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.ViewModels
{
	// Token: 0x02000046 RID: 70
	[NullableContext(1)]
	[Nullable(0)]
	public class MainWindowViewModel : ViewModelBase
	{
		// Token: 0x06000154 RID: 340 RVA: 0x0002AF3C File Offset: 0x0002913C
		public MainWindowViewModel()
		{
			this.WhenAnyValue((MainWindowViewModel x) => x.TotalBalanceInUsdPlayer).Subscribe(delegate(double btcBalanceInUsd)
			{
				this.TotalBalanceInUsdPlayerString = btcBalanceInUsd.ToString("N");
			});
			TransactionService.Instance.AddTransactionEvent += delegate([Nullable(2)] object sender, EventArgs args)
			{
				this.AddTransaction();
			};
			TransactionService.Instance.StopPendingEvent += delegate([Nullable(2)] object sender, EventArgs args)
			{
				this.SelectedCoin.ViewPart.ForceStopPending = true;
			};
			TransactionService.Instance.DeleteLastTransactionEvent += delegate([Nullable(2)] object sender, EventArgs args)
			{
				this.DeleteLastTransaction();
			};
			TransactionService.Instance.ResetEvent += delegate([Nullable(2)] object sender, EventArgs args)
			{
				this.Reset();
			};
			TransactionService.Instance.TransactionAddedEvent += delegate([Nullable(2)] object sender, EventArgs args)
			{
				new Thread(new ThreadStart(this.PlayNotification)).Start();
			};
			this.Coins = DataBaseService.Instance.Preferences.Coins;
			this.InitializeCoins();
			this.SetupViewPart();
			this.ReorderCoins();
			this.SelectedCoinIndex = 0;
			CoinManagementService.Instance.CoinSelectedEvent += delegate([Nullable(2)] object sender, EventArgs args)
			{
				this.SelectedCoinIndex = this.Coins.IndexOf((Coin)sender);
			};
			TransactionService.Instance.PriceUpdated += delegate([Nullable(2)] object sender, EventArgs args)
			{
				if (this.Coins != null)
				{
					foreach (Coin coin in this.Coins)
					{
						CoinSpecificPartViewModel viewPart = coin.ViewPart;
						if (viewPart != null)
						{
							viewPart.CalculateBalance(false);
						}
					}
				}
			};
			Observable.Interval(TimeSpan.FromSeconds(30.0)).Subscribe(delegate(long _)
			{
				Dispatcher.UIThread.InvokeAsync(new Action(this.UpdateAllTransactionsRelativeTime));
			});
			this.WhenAnyValue((MainWindowViewModel x) => x.SelectedCoinIndex).Subscribe(delegate(int btcBalanceInUsd)
			{
				if (this.SelectedCoin != null)
				{
					this.SelectedCoin.IsSelected = false;
				}
				if (this.Coins != null && this.SelectedCoinIndex >= 0 && this.SelectedCoinIndex < this.Coins.Count)
				{
					this.SelectedCoin = this.Coins[this.SelectedCoinIndex];
					this.SelectedCoinViewPart = this.SelectedCoin.ViewPart;
					this.SelectedCoin.IsSelected = true;
				}
			});
			this.NotificationViewModel = new NotificationViewModel
			{
				NotificationStripeWidth = 360.0,
				IsNotification = false,
				IsShow = false
			};
			this.ReceiveAddressViewModel = new ReceiveAddressViewModel(this)
			{
				IsShow = false
			};
			this.RefreshViewModel = new RefreshViewModel(this)
			{
				IsShow = false
			};
			this.SettingsModalViewModel = new SettingsModalViewModel(this)
			{
				IsShow = false
			};
			this.PortfolioViewModel = new PortfolioViewModel(this);
			this.SwapViewModel = new SwapViewModel(this);
			this.BuySellViewModel = new BuySellViewModel(this);
			this.WhenAnyValue((MainWindowViewModel x) => x.TotalBalanceInUsdPlayer).Subscribe(delegate(double _)
			{
				PortfolioViewModel portfolioViewModel = this.PortfolioViewModel;
				if (portfolioViewModel == null)
				{
					return;
				}
				portfolioViewModel.UpdatePortfolio(false);
			});
			this.AppVersion = VersionService.Instance.CurrentVersion;
			this.WindowTitle = "EXODUS " + this.AppVersion;
			VersionService.Instance.VersionUpdated += delegate(string newVersion)
			{
				Dispatcher.UIThread.Post(delegate()
				{
					this.AppVersion = newVersion;
					this.WindowTitle = "EXODUS " + newVersion;
					SettingsModalViewModel settingsModalViewModel = this.SettingsModalViewModel;
					if (settingsModalViewModel == null)
					{
						return;
					}
					settingsModalViewModel.UpdateVersion(newVersion);
				}, default(DispatcherPriority));
			};
			Task.Run(delegate()
			{
				MainWindowViewModel.<>c.<<-ctor>b__0_15>d <<-ctor>b__0_15>d;
				<<-ctor>b__0_15>d.<>t__builder = AsyncTaskMethodBuilder.Create();
				<<-ctor>b__0_15>d.<>1__state = -1;
				<<-ctor>b__0_15>d.<>t__builder.Start<MainWindowViewModel.<>c.<<-ctor>b__0_15>d>(ref <<-ctor>b__0_15>d);
				return <<-ctor>b__0_15>d.<>t__builder.Task;
			});
			DataBaseService.Instance.IsInitialized = true;
		}

		// Token: 0x06000155 RID: 341 RVA: 0x0002B254 File Offset: 0x00029454
		private void InitializeCoins()
		{
			int i = 0;
			int j = this.Coins.Count;
			while (i < j)
			{
				this.Coins[i].Initialize();
				if (this.Coins[i].Transactions != null)
				{
					foreach (Transaction transaction in this.Coins[i].Transactions)
					{
						transaction.UpdateRelativeTime();
					}
				}
				i++;
			}
		}

		// Token: 0x06000156 RID: 342 RVA: 0x0002B2E8 File Offset: 0x000294E8
		public void UpdateAllTransactionsRelativeTime()
		{
			if (this.Coins == null)
			{
				return;
			}
			foreach (Coin coin in this.Coins)
			{
				if (coin.Transactions != null)
				{
					foreach (Transaction transaction in coin.Transactions)
					{
						transaction.UpdateRelativeTime();
					}
				}
			}
		}

		// Token: 0x06000157 RID: 343 RVA: 0x0002B378 File Offset: 0x00029578
		private void SetupViewPart()
		{
			foreach (Coin coin in this.Coins)
			{
				if (coin.Symbol == "BTC")
				{
					coin.ViewPart = new CoinSpecificPartViewModel(this, coin)
					{
						LogoUri = new Uri("avares://Exodus/Assets/Resources/Icons/bitcoin.png"),
						TransactionLookUrl = "https://mempool.space/tx/",
						AddressLookUrl = "https://mempool.space/address/",
						Foreground1 = SolidColorBrush.Parse("#FFC82D"),
						Foreground2 = new LinearGradientBrush
						{
							StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative),
							EndPoint = new RelativePoint(1.0, 1.0, RelativeUnit.Relative),
							GradientStops = new GradientStops
							{
								new GradientStop(Color.Parse("#E6FFC82D"), 0.0),
								new GradientStop(Color.Parse("#B3FFFC2D"), 1.0)
							}
						},
						Transactions = coin.Transactions,
						IsThereTransaction = (coin.Transactions.Count > 0),
						IsThereAnyTransaction = (coin.Transactions.Count > 0)
					};
				}
				else if (coin.Symbol == "ETH")
				{
					coin.ViewPart = new CoinSpecificPartViewModel(this, coin)
					{
						LogoUri = new Uri("avares://Exodus/Assets/Resources/Icons/ethereum_1.png"),
						TransactionLookUrl = "https://etherscan.io/tx/",
						AddressLookUrl = "https://etherscan.io/address/",
						Foreground1 = SolidColorBrush.Parse("#8C93AF"),
						Foreground2 = new LinearGradientBrush
						{
							StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative),
							EndPoint = new RelativePoint(1.0, 1.0, RelativeUnit.Relative),
							GradientStops = new GradientStops
							{
								new GradientStop(Color.Parse("#E68C93AF"), 0.0),
								new GradientStop(Color.Parse("#B38D8CAF"), 1.0)
							}
						},
						Transactions = coin.Transactions,
						IsThereTransaction = (coin.Transactions.Count > 0),
						IsThereAnyTransaction = (coin.Transactions.Count > 0)
					};
				}
				else if (coin.Symbol == "SOL")
				{
					coin.ViewPart = new CoinSpecificPartViewModel(this, coin)
					{
						LogoUri = new Uri("avares://Exodus/Assets/Resources/Icons/solana.png"),
						TransactionLookUrl = "https://solscan.io/tx/",
						AddressLookUrl = "https://solscan.io/account/",
						Foreground1 = SolidColorBrush.Parse("#14F195"),
						Foreground2 = new LinearGradientBrush
						{
							StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative),
							EndPoint = new RelativePoint(1.0, 1.0, RelativeUnit.Relative),
							GradientStops = new GradientStops
							{
								new GradientStop(Color.Parse("#E614F195"), 0.0),
								new GradientStop(Color.Parse("#B39945FF"), 1.0)
							}
						},
						Transactions = coin.Transactions,
						IsThereTransaction = (coin.Transactions.Count > 0),
						IsThereAnyTransaction = (coin.Transactions.Count > 0)
					};
				}
				else if (coin.Symbol == "USDT")
				{
					coin.ViewPart = new CoinSpecificPartViewModel(this, coin)
					{
						LogoUri = new Uri("avares://Exodus/Assets/Resources/Icons/tether.png"),
						TransactionLookUrl = "https://tronscan.org/#/transaction/",
						AddressLookUrl = "https://tronscan.org/#/address/",
						Foreground1 = SolidColorBrush.Parse("#26A17B"),
						Foreground2 = new LinearGradientBrush
						{
							StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative),
							EndPoint = new RelativePoint(1.0, 1.0, RelativeUnit.Relative),
							GradientStops = new GradientStops
							{
								new GradientStop(Color.Parse("#E626A17B"), 0.0),
								new GradientStop(Color.Parse("#B350AF95"), 1.0)
							}
						},
						Transactions = coin.Transactions,
						IsThereTransaction = (coin.Transactions.Count > 0),
						IsThereAnyTransaction = (coin.Transactions.Count > 0)
					};
				}
				else if (coin.Symbol == "BNB")
				{
					coin.ViewPart = new CoinSpecificPartViewModel(this, coin)
					{
						LogoUri = new Uri("avares://Exodus/Assets/Resources/Icons/bnb.png"),
						TransactionLookUrl = "https://bscscan.com/tx/",
						AddressLookUrl = "https://bscscan.com/address/",
						Foreground1 = SolidColorBrush.Parse("#F3BA2F"),
						Foreground2 = new LinearGradientBrush
						{
							StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative),
							EndPoint = new RelativePoint(1.0, 1.0, RelativeUnit.Relative),
							GradientStops = new GradientStops
							{
								new GradientStop(Color.Parse("#E6F3BA2F"), 0.0),
								new GradientStop(Color.Parse("#B3DCA022"), 1.0)
							}
						},
						Transactions = coin.Transactions,
						IsThereTransaction = (coin.Transactions.Count > 0),
						IsThereAnyTransaction = (coin.Transactions.Count > 0)
					};
				}
				else if (coin.Symbol == "TRX")
				{
					coin.ViewPart = new CoinSpecificPartViewModel(this, coin)
					{
						LogoUri = new Uri("avares://Exodus/Assets/Resources/Icons/tron.png"),
						TransactionLookUrl = "https://tronscan.org/#/transaction/",
						AddressLookUrl = "https://tronscan.org/#/address/",
						Foreground1 = SolidColorBrush.Parse("#FA2841"),
						Foreground2 = new LinearGradientBrush
						{
							StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative),
							EndPoint = new RelativePoint(1.0, 1.0, RelativeUnit.Relative),
							GradientStops = new GradientStops
							{
								new GradientStop(Color.Parse("#E6FA2841"), 0.0),
								new GradientStop(Color.Parse("#B3C9182E"), 1.0)
							}
						},
						Transactions = coin.Transactions,
						IsThereTransaction = (coin.Transactions.Count > 0),
						IsThereAnyTransaction = (coin.Transactions.Count > 0)
					};
				}
				else
				{
					coin.ViewPart = new CoinSpecificPartViewModel(this, coin)
					{
						LogoUri = new Uri("avares://Exodus/Assets/Resources/Icons/bitcoin.png"),
						TransactionLookUrl = "https://mempool.space/tx/",
						AddressLookUrl = "https://mempool.space/address/",
						Foreground1 = SolidColorBrush.Parse("#A0A3BD"),
						Foreground2 = new LinearGradientBrush
						{
							StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative),
							EndPoint = new RelativePoint(1.0, 1.0, RelativeUnit.Relative),
							GradientStops = new GradientStops
							{
								new GradientStop(Color.Parse("#E66B7280"), 0.0),
								new GradientStop(Color.Parse("#B3374151"), 1.0)
							}
						},
						Transactions = coin.Transactions,
						IsThereTransaction = (coin.Transactions.Count > 0),
						IsThereAnyTransaction = (coin.Transactions.Count > 0)
					};
				}
				coin.ViewPart.CalculateBalance(false);
				coin.ViewPart.AdjustTransactionsGroup();
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000158 RID: 344 RVA: 0x0002BBA8 File Offset: 0x00029DA8
		// (set) Token: 0x06000159 RID: 345 RVA: 0x0002BBB0 File Offset: 0x00029DB0
		[Reactive]
		public ObservableCollection<Coin> Coins
		{
			[CompilerGenerated]
			get
			{
				return this.$Coins;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Coins, value, "Coins");
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x0600015A RID: 346 RVA: 0x0002BBC5 File Offset: 0x00029DC5
		// (set) Token: 0x0600015B RID: 347 RVA: 0x0002BBCD File Offset: 0x00029DCD
		[Reactive]
		public int SelectedCoinIndex
		{
			[CompilerGenerated]
			get
			{
				return this.$SelectedCoinIndex;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SelectedCoinIndex, value, "SelectedCoinIndex");
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x0600015C RID: 348 RVA: 0x0002BBE2 File Offset: 0x00029DE2
		// (set) Token: 0x0600015D RID: 349 RVA: 0x0002BBEA File Offset: 0x00029DEA
		[Reactive]
		public Coin SelectedCoin
		{
			[CompilerGenerated]
			get
			{
				return this.$SelectedCoin;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SelectedCoin, value, "SelectedCoin");
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x0600015E RID: 350 RVA: 0x0002BBFF File Offset: 0x00029DFF
		// (set) Token: 0x0600015F RID: 351 RVA: 0x0002BC07 File Offset: 0x00029E07
		[Reactive]
		public CoinSpecificPartViewModel SelectedCoinViewPart
		{
			[CompilerGenerated]
			get
			{
				return this.$SelectedCoinViewPart;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SelectedCoinViewPart, value, "SelectedCoinViewPart");
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000160 RID: 352 RVA: 0x0002BC1C File Offset: 0x00029E1C
		// (set) Token: 0x06000161 RID: 353 RVA: 0x0002BC24 File Offset: 0x00029E24
		[Reactive]
		public NotificationViewModel NotificationViewModel
		{
			[CompilerGenerated]
			get
			{
				return this.$NotificationViewModel;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$NotificationViewModel, value, "NotificationViewModel");
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000162 RID: 354 RVA: 0x0002BC39 File Offset: 0x00029E39
		// (set) Token: 0x06000163 RID: 355 RVA: 0x0002BC41 File Offset: 0x00029E41
		[Reactive]
		public ReceiveAddressViewModel ReceiveAddressViewModel
		{
			[CompilerGenerated]
			get
			{
				return this.$ReceiveAddressViewModel;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$ReceiveAddressViewModel, value, "ReceiveAddressViewModel");
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000164 RID: 356 RVA: 0x0002BC56 File Offset: 0x00029E56
		// (set) Token: 0x06000165 RID: 357 RVA: 0x0002BC5E File Offset: 0x00029E5E
		[Reactive]
		public RefreshViewModel RefreshViewModel
		{
			[CompilerGenerated]
			get
			{
				return this.$RefreshViewModel;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$RefreshViewModel, value, "RefreshViewModel");
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000166 RID: 358 RVA: 0x0002BC73 File Offset: 0x00029E73
		// (set) Token: 0x06000167 RID: 359 RVA: 0x0002BC7B File Offset: 0x00029E7B
		[Reactive]
		public SettingsModalViewModel SettingsModalViewModel
		{
			[CompilerGenerated]
			get
			{
				return this.$SettingsModalViewModel;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SettingsModalViewModel, value, "SettingsModalViewModel");
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000168 RID: 360 RVA: 0x0002BC90 File Offset: 0x00029E90
		// (set) Token: 0x06000169 RID: 361 RVA: 0x0002BC98 File Offset: 0x00029E98
		[Reactive]
		public string AppVersion
		{
			[CompilerGenerated]
			get
			{
				return this.$AppVersion;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$AppVersion, value, "AppVersion");
			}
		} = VersionService.Instance.CurrentVersion;

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x0600016A RID: 362 RVA: 0x0002BCAD File Offset: 0x00029EAD
		// (set) Token: 0x0600016B RID: 363 RVA: 0x0002BCB5 File Offset: 0x00029EB5
		[Reactive]
		public string WindowTitle
		{
			[CompilerGenerated]
			get
			{
				return this.$WindowTitle;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$WindowTitle, value, "WindowTitle");
			}
		} = "EXODUS " + VersionService.Instance.CurrentVersion;

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x0600016C RID: 364 RVA: 0x0002BCCA File Offset: 0x00029ECA
		// (set) Token: 0x0600016D RID: 365 RVA: 0x0002BCD2 File Offset: 0x00029ED2
		[Reactive]
		public double TotalBalanceInUsd
		{
			[CompilerGenerated]
			get
			{
				return this.$TotalBalanceInUsd;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TotalBalanceInUsd, value, "TotalBalanceInUsd");
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x0600016E RID: 366 RVA: 0x0002BCE7 File Offset: 0x00029EE7
		// (set) Token: 0x0600016F RID: 367 RVA: 0x0002BCEF File Offset: 0x00029EEF
		[Reactive]
		public double TotalBalanceInUsdPlayer
		{
			[CompilerGenerated]
			get
			{
				return this.$TotalBalanceInUsdPlayer;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TotalBalanceInUsdPlayer, value, "TotalBalanceInUsdPlayer");
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06000170 RID: 368 RVA: 0x0002BD04 File Offset: 0x00029F04
		// (set) Token: 0x06000171 RID: 369 RVA: 0x0002BD0C File Offset: 0x00029F0C
		[Reactive]
		public string TotalBalanceInUsdPlayerString
		{
			[CompilerGenerated]
			get
			{
				return this.$TotalBalanceInUsdPlayerString;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$TotalBalanceInUsdPlayerString, value, "TotalBalanceInUsdPlayerString");
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06000172 RID: 370 RVA: 0x0002BD21 File Offset: 0x00029F21
		// (set) Token: 0x06000173 RID: 371 RVA: 0x0002BD29 File Offset: 0x00029F29
		[Reactive]
		public double CurrentlyAdded
		{
			[CompilerGenerated]
			get
			{
				return this.$CurrentlyAdded;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$CurrentlyAdded, value, "CurrentlyAdded");
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000174 RID: 372 RVA: 0x0002BD3E File Offset: 0x00029F3E
		// (set) Token: 0x06000175 RID: 373 RVA: 0x0002BD46 File Offset: 0x00029F46
		[Reactive]
		public bool IsWalletViewActive
		{
			[CompilerGenerated]
			get
			{
				return this.$IsWalletViewActive;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsWalletViewActive, value, "IsWalletViewActive");
			}
		} = true;

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000176 RID: 374 RVA: 0x0002BD5B File Offset: 0x00029F5B
		// (set) Token: 0x06000177 RID: 375 RVA: 0x0002BD63 File Offset: 0x00029F63
		[Reactive]
		public bool IsPortfolioViewActive
		{
			[CompilerGenerated]
			get
			{
				return this.$IsPortfolioViewActive;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsPortfolioViewActive, value, "IsPortfolioViewActive");
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06000178 RID: 376 RVA: 0x0002BD78 File Offset: 0x00029F78
		// (set) Token: 0x06000179 RID: 377 RVA: 0x0002BD80 File Offset: 0x00029F80
		[Reactive]
		public bool IsSwapViewActive
		{
			[CompilerGenerated]
			get
			{
				return this.$IsSwapViewActive;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsSwapViewActive, value, "IsSwapViewActive");
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x0600017A RID: 378 RVA: 0x0002BD95 File Offset: 0x00029F95
		// (set) Token: 0x0600017B RID: 379 RVA: 0x0002BD9D File Offset: 0x00029F9D
		[Reactive]
		public bool IsBuySellViewActive
		{
			[CompilerGenerated]
			get
			{
				return this.$IsBuySellViewActive;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsBuySellViewActive, value, "IsBuySellViewActive");
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x0600017C RID: 380 RVA: 0x0002BDB2 File Offset: 0x00029FB2
		// (set) Token: 0x0600017D RID: 381 RVA: 0x0002BDBA File Offset: 0x00029FBA
		[Reactive]
		public PortfolioViewModel PortfolioViewModel
		{
			[CompilerGenerated]
			get
			{
				return this.$PortfolioViewModel;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$PortfolioViewModel, value, "PortfolioViewModel");
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x0600017E RID: 382 RVA: 0x0002BDCF File Offset: 0x00029FCF
		// (set) Token: 0x0600017F RID: 383 RVA: 0x0002BDD7 File Offset: 0x00029FD7
		[Reactive]
		public SwapViewModel SwapViewModel
		{
			[CompilerGenerated]
			get
			{
				return this.$SwapViewModel;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SwapViewModel, value, "SwapViewModel");
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000180 RID: 384 RVA: 0x0002BDEC File Offset: 0x00029FEC
		// (set) Token: 0x06000181 RID: 385 RVA: 0x0002BDF4 File Offset: 0x00029FF4
		[Reactive]
		public BuySellViewModel BuySellViewModel
		{
			[CompilerGenerated]
			get
			{
				return this.$BuySellViewModel;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$BuySellViewModel, value, "BuySellViewModel");
			}
		}

		// Token: 0x06000182 RID: 386 RVA: 0x0002BE09 File Offset: 0x0002A009
		public void OpenSettingsCommand()
		{
			this.SettingsModalViewModel.IsShow = true;
		}

		// Token: 0x06000183 RID: 387 RVA: 0x0002BE17 File Offset: 0x0002A017
		public void NavigateToPortfolio()
		{
			this.IsPortfolioViewActive = true;
			this.IsWalletViewActive = false;
			this.IsSwapViewActive = false;
			this.IsBuySellViewActive = false;
			PortfolioViewModel portfolioViewModel = this.PortfolioViewModel;
			if (portfolioViewModel == null)
			{
				return;
			}
			portfolioViewModel.UpdatePortfolio(true);
		}

		// Token: 0x06000184 RID: 388 RVA: 0x0002BE46 File Offset: 0x0002A046
		public void NavigateToWallet()
		{
			this.IsPortfolioViewActive = false;
			this.IsWalletViewActive = true;
			this.IsSwapViewActive = false;
			this.IsBuySellViewActive = false;
		}

		// Token: 0x06000185 RID: 389 RVA: 0x0002BE64 File Offset: 0x0002A064
		public void NavigateToSwap()
		{
			this.IsPortfolioViewActive = false;
			this.IsWalletViewActive = false;
			this.IsSwapViewActive = true;
			this.IsBuySellViewActive = false;
			SwapViewModel swapViewModel = this.SwapViewModel;
			if (swapViewModel == null)
			{
				return;
			}
			swapViewModel.RefreshCoins();
		}

		// Token: 0x06000186 RID: 390 RVA: 0x0002BE92 File Offset: 0x0002A092
		public void NavigateToBuySell()
		{
			this.IsPortfolioViewActive = false;
			this.IsWalletViewActive = false;
			this.IsSwapViewActive = false;
			this.IsBuySellViewActive = true;
			BuySellViewModel buySellViewModel = this.BuySellViewModel;
			if (buySellViewModel == null)
			{
				return;
			}
			buySellViewModel.RefreshCoins();
		}

		// Token: 0x06000187 RID: 391 RVA: 0x0002BEC0 File Offset: 0x0002A0C0
		public void SelectCoinAndOpenWallet(Coin coin)
		{
			if (this.Coins != null && coin != null)
			{
				int idx = this.Coins.IndexOf(coin);
				if (idx >= 0)
				{
					this.SelectedCoinIndex = idx;
				}
			}
			this.IsPortfolioViewActive = false;
			this.IsWalletViewActive = true;
			this.IsSwapViewActive = false;
			this.IsBuySellViewActive = false;
		}

		// Token: 0x06000188 RID: 392 RVA: 0x0002BF0C File Offset: 0x0002A10C
		public void AddTransaction()
		{
			MainWindowViewModel.<AddTransaction>d__94 <AddTransaction>d__;
			<AddTransaction>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<AddTransaction>d__.<>4__this = this;
			<AddTransaction>d__.<>1__state = -1;
			<AddTransaction>d__.<>t__builder.Start<MainWindowViewModel.<AddTransaction>d__94>(ref <AddTransaction>d__);
		}

		// Token: 0x06000189 RID: 393 RVA: 0x0002BF44 File Offset: 0x0002A144
		public void DeleteLastTransaction()
		{
			MainWindowViewModel.<DeleteLastTransaction>d__95 <DeleteLastTransaction>d__;
			<DeleteLastTransaction>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<DeleteLastTransaction>d__.<>4__this = this;
			<DeleteLastTransaction>d__.<>1__state = -1;
			<DeleteLastTransaction>d__.<>t__builder.Start<MainWindowViewModel.<DeleteLastTransaction>d__95>(ref <DeleteLastTransaction>d__);
		}

		// Token: 0x0600018A RID: 394 RVA: 0x0002BF7C File Offset: 0x0002A17C
		public void Reset()
		{
			MainWindowViewModel.<Reset>d__96 <Reset>d__;
			<Reset>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Reset>d__.<>4__this = this;
			<Reset>d__.<>1__state = -1;
			<Reset>d__.<>t__builder.Start<MainWindowViewModel.<Reset>d__96>(ref <Reset>d__);
		}

		// Token: 0x0600018B RID: 395 RVA: 0x0002BFB4 File Offset: 0x0002A1B4
		private void ReorderCoins()
		{
			this.Coins = new ObservableCollection<Coin>((from c in this.Coins
			orderby (c.IsLocked > false) ? 1 : 0
			select c).ThenByDescending(delegate(Coin c)
			{
				CoinSpecificPartViewModel viewPart = c.ViewPart;
				if (viewPart == null)
				{
					return 0.0;
				}
				return viewPart.BalanceInUsd;
			}));
			this.SelectedCoinIndex = ((this.Coins.IndexOf(this.SelectedCoin) == -1) ? 0 : this.Coins.IndexOf(this.SelectedCoin));
		}

		// Token: 0x0600018C RID: 396 RVA: 0x0002C048 File Offset: 0x0002A248
		public void BalanceAdder(bool isDoAnimation = true)
		{
			MainWindowViewModel.<BalanceAdder>d__99 <BalanceAdder>d__;
			<BalanceAdder>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<BalanceAdder>d__.<>4__this = this;
			<BalanceAdder>d__.isDoAnimation = isDoAnimation;
			<BalanceAdder>d__.<>1__state = -1;
			<BalanceAdder>d__.<>t__builder.Start<MainWindowViewModel.<BalanceAdder>d__99>(ref <BalanceAdder>d__);
		}

		// Token: 0x0600018D RID: 397 RVA: 0x0002C088 File Offset: 0x0002A288
		private void PlayNotification()
		{
			new Thread(new ThreadStart(MainWindowViewModel.<PlayNotification>g__PlayThread|100_0)).Start();
			Dispatcher.UIThread.InvokeAsync(delegate()
			{
				this.NotificationViewModel = new NotificationViewModel
				{
					Logo = new Bitmap(AssetLoader.Open(this.SelectedCoinViewPart.LogoUri, null)),
					IsNotification = true,
					IsShow = true,
					ViewPart = this.SelectedCoinViewPart,
					CurrentlyAdded = this.CurrentlyAdded,
					NotificationStripeWidth = 360.0
				};
			});
			Dispatcher.UIThread.InvokeAsync(delegate()
			{
				MainWindowViewModel.<<PlayNotification>b__100_2>d <<PlayNotification>b__100_2>d;
				<<PlayNotification>b__100_2>d.<>t__builder = AsyncTaskMethodBuilder.Create();
				<<PlayNotification>b__100_2>d.<>4__this = this;
				<<PlayNotification>b__100_2>d.<>1__state = -1;
				<<PlayNotification>b__100_2>d.<>t__builder.Start<MainWindowViewModel.<<PlayNotification>b__100_2>d>(ref <<PlayNotification>b__100_2>d);
				return <<PlayNotification>b__100_2>d.<>t__builder.Task;
			});
		}

		// Token: 0x0600019E RID: 414 RVA: 0x0002C390 File Offset: 0x0002A590
		[CompilerGenerated]
		internal static void <PlayNotification>g__PlayThread|100_0()
		{
			Thread.Sleep(TimeSpan.FromMilliseconds(200.0));
			Stream stream = AssetLoader.Open(new Uri("avares://Exodus/Assets/Resources/Audios/receive.wav"), null);
			stream.Seek(0L, SeekOrigin.Begin);
			stream.Position = 0L;
			new SoundPlayer(stream).Play();
		}

		// Token: 0x0400007E RID: 126
		private bool _isBalanceAdderBusy;

		// Token: 0x0400007F RID: 127
		private ObservableCollection<Coin> $Coins;

		// Token: 0x04000080 RID: 128
		private int $SelectedCoinIndex;

		// Token: 0x04000081 RID: 129
		private Coin $SelectedCoin;

		// Token: 0x04000082 RID: 130
		private CoinSpecificPartViewModel $SelectedCoinViewPart;

		// Token: 0x04000083 RID: 131
		private NotificationViewModel $NotificationViewModel;

		// Token: 0x04000084 RID: 132
		private ReceiveAddressViewModel $ReceiveAddressViewModel;

		// Token: 0x04000085 RID: 133
		private RefreshViewModel $RefreshViewModel;

		// Token: 0x04000086 RID: 134
		private SettingsModalViewModel $SettingsModalViewModel;

		// Token: 0x04000087 RID: 135
		private string $AppVersion;

		// Token: 0x04000088 RID: 136
		private string $WindowTitle;

		// Token: 0x04000089 RID: 137
		private double $TotalBalanceInUsd;

		// Token: 0x0400008A RID: 138
		private double $TotalBalanceInUsdPlayer;

		// Token: 0x0400008B RID: 139
		private string $TotalBalanceInUsdPlayerString;

		// Token: 0x0400008C RID: 140
		private double $CurrentlyAdded;

		// Token: 0x0400008D RID: 141
		private bool $IsWalletViewActive;

		// Token: 0x0400008E RID: 142
		private bool $IsPortfolioViewActive;

		// Token: 0x0400008F RID: 143
		private bool $IsSwapViewActive;

		// Token: 0x04000090 RID: 144
		private bool $IsBuySellViewActive;

		// Token: 0x04000091 RID: 145
		private PortfolioViewModel $PortfolioViewModel;

		// Token: 0x04000092 RID: 146
		private SwapViewModel $SwapViewModel;

		// Token: 0x04000093 RID: 147
		private BuySellViewModel $BuySellViewModel;
	}
}
