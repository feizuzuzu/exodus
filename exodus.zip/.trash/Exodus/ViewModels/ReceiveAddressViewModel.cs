﻿using System;
using System.Reactive;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.ViewModels
{
	// Token: 0x02000055 RID: 85
	[NullableContext(1)]
	[Nullable(0)]
	public class ReceiveAddressViewModel : ViewModelBase
	{
		// Token: 0x060001FE RID: 510 RVA: 0x0002E3C4 File Offset: 0x0002C5C4
		public ReceiveAddressViewModel(MainWindowViewModel mainWindowViewModel)
		{
			this.CopyCommand = ReactiveCommand.Create(new Action(this._copyCommand), null, null);
			this.MainWindowVm = mainWindowViewModel;
			this.IsShow = false;
			this.Opacity = 0.0;
			this.SolidOpacity = 0.0;
			this.AddressOpacity = 1.0;
			this.CopyOpacity = 0.0;
			this.WhenAnyValue((ReceiveAddressViewModel x) => x.IsShow).Subscribe(delegate(bool _)
			{
				if (this.IsShow)
				{
					this.IsVisible = true;
				}
				this.Opacity = (this.IsShow ? 0.974 : 0.0);
				this.SolidOpacity = (this.IsShow > false);
				if (this.IsShow)
				{
					return;
				}
				Task.Run(delegate()
				{
					ReceiveAddressViewModel.<<-ctor>b__0_2>d <<-ctor>b__0_2>d;
					<<-ctor>b__0_2>d.<>t__builder = AsyncTaskMethodBuilder.Create();
					<<-ctor>b__0_2>d.<>4__this = this;
					<<-ctor>b__0_2>d.<>1__state = -1;
					<<-ctor>b__0_2>d.<>t__builder.Start<ReceiveAddressViewModel.<<-ctor>b__0_2>d>(ref <<-ctor>b__0_2>d);
					return <<-ctor>b__0_2>d.<>t__builder.Task;
				});
			});
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x060001FF RID: 511 RVA: 0x0002E48B File Offset: 0x0002C68B
		// (set) Token: 0x06000200 RID: 512 RVA: 0x0002E493 File Offset: 0x0002C693
		[Nullable(2)]
		[Reactive]
		public MainWindowViewModel MainWindowVm
		{
			[NullableContext(2)]
			[CompilerGenerated]
			get
			{
				return this.$MainWindowVm;
			}
			[NullableContext(2)]
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$MainWindowVm, value, "MainWindowVm");
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000201 RID: 513 RVA: 0x0002E4A8 File Offset: 0x0002C6A8
		// (set) Token: 0x06000202 RID: 514 RVA: 0x0002E4B0 File Offset: 0x0002C6B0
		[Reactive]
		public bool IsShow
		{
			[CompilerGenerated]
			get
			{
				return this.$IsShow;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsShow, value, "IsShow");
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000203 RID: 515 RVA: 0x0002E4C5 File Offset: 0x0002C6C5
		// (set) Token: 0x06000204 RID: 516 RVA: 0x0002E4CD File Offset: 0x0002C6CD
		[Reactive]
		public bool IsVisible
		{
			[CompilerGenerated]
			get
			{
				return this.$IsVisible;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$IsVisible, value, "IsVisible");
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000205 RID: 517 RVA: 0x0002E4E2 File Offset: 0x0002C6E2
		// (set) Token: 0x06000206 RID: 518 RVA: 0x0002E4EA File Offset: 0x0002C6EA
		[Reactive]
		public double Opacity
		{
			[CompilerGenerated]
			get
			{
				return this.$Opacity;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Opacity, value, "Opacity");
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000207 RID: 519 RVA: 0x0002E4FF File Offset: 0x0002C6FF
		// (set) Token: 0x06000208 RID: 520 RVA: 0x0002E507 File Offset: 0x0002C707
		[Reactive]
		public double SolidOpacity
		{
			[CompilerGenerated]
			get
			{
				return this.$SolidOpacity;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$SolidOpacity, value, "SolidOpacity");
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000209 RID: 521 RVA: 0x0002E51C File Offset: 0x0002C71C
		// (set) Token: 0x0600020A RID: 522 RVA: 0x0002E524 File Offset: 0x0002C724
		[Reactive]
		public ReactiveCommand<Unit, Unit> CopyCommand
		{
			[CompilerGenerated]
			get
			{
				return this.$CopyCommand;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$CopyCommand, value, "CopyCommand");
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x0600020B RID: 523 RVA: 0x0002E539 File Offset: 0x0002C739
		// (set) Token: 0x0600020C RID: 524 RVA: 0x0002E541 File Offset: 0x0002C741
		[Reactive]
		public double CopyOpacity
		{
			[CompilerGenerated]
			get
			{
				return this.$CopyOpacity;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$CopyOpacity, value, "CopyOpacity");
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x0600020D RID: 525 RVA: 0x0002E556 File Offset: 0x0002C756
		// (set) Token: 0x0600020E RID: 526 RVA: 0x0002E55E File Offset: 0x0002C75E
		[Reactive]
		public double AddressOpacity
		{
			[CompilerGenerated]
			get
			{
				return this.$AddressOpacity;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$AddressOpacity, value, "AddressOpacity");
			}
		}

		// Token: 0x0600020F RID: 527 RVA: 0x0002E574 File Offset: 0x0002C774
		public void _copyCommand()
		{
			ReceiveAddressViewModel.<_copyCommand>d__33 <_copyCommand>d__;
			<_copyCommand>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<_copyCommand>d__.<>4__this = this;
			<_copyCommand>d__.<>1__state = -1;
			<_copyCommand>d__.<>t__builder.Start<ReceiveAddressViewModel.<_copyCommand>d__33>(ref <_copyCommand>d__);
		}

		// Token: 0x06000210 RID: 528 RVA: 0x0002E5AC File Offset: 0x0002C7AC
		public void ChainCommand()
		{
			ReceiveAddressViewModel.<ChainCommand>d__34 <ChainCommand>d__;
			<ChainCommand>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ChainCommand>d__.<>4__this = this;
			<ChainCommand>d__.<>1__state = -1;
			<ChainCommand>d__.<>t__builder.Start<ReceiveAddressViewModel.<ChainCommand>d__34>(ref <ChainCommand>d__);
		}

		// Token: 0x06000211 RID: 529 RVA: 0x0002E5E3 File Offset: 0x0002C7E3
		public void CloseCommand()
		{
			this.IsShow = false;
		}

		// Token: 0x040000DD RID: 221
		private MainWindowViewModel $MainWindowVm;

		// Token: 0x040000DE RID: 222
		private bool $IsShow;

		// Token: 0x040000DF RID: 223
		private bool $IsVisible;

		// Token: 0x040000E0 RID: 224
		private double $Opacity;

		// Token: 0x040000E1 RID: 225
		private double $SolidOpacity;

		// Token: 0x040000E2 RID: 226
		private ReactiveCommand<Unit, Unit> $CopyCommand;

		// Token: 0x040000E3 RID: 227
		private double $CopyOpacity;

		// Token: 0x040000E4 RID: 228
		private double $AddressOpacity;
	}
}
