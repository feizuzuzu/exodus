﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using Exodus.Helpers;
using Exodus.Models;
using Exodus.Services;
using Exodus.Views;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;

namespace Exodus.ViewModels
{
	// Token: 0x02000037 RID: 55
	[NullableContext(1)]
	[Nullable(0)]
	public class AddTransactionWindowViewModel : ViewModelBase
	{
		// Token: 0x06000081 RID: 129 RVA: 0x00028728 File Offset: 0x00026928
		public AddTransactionWindowViewModel()
		{
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000082 RID: 130 RVA: 0x00028788 File Offset: 0x00026988
		public Coin MyCoin { get; }

		// Token: 0x06000083 RID: 131 RVA: 0x00028790 File Offset: 0x00026990
		public AddTransactionWindowViewModel(AddTransactionWindow window, Coin myCoin, int myCoinIndex)
		{
			this._window = window;
			this.MyCoin = myCoin;
			double price = TransactionService.Instance.GetPrice(myCoin.Symbol);
			if (price <= 0.0)
			{
				price = 100.0;
			}
			double amount = Math.Round(10000.0 / price, 6);
			this.MyTransaction = new Transaction();
			this.MyTransaction.SetConst(amount, myCoin, false);
			this.SetupChips();
			this.AmountInput = NumberFormatHelper.FormatCrypto(amount, 8);
			this.WhenAnyValue((AddTransactionWindowViewModel x) => x.AmountInput).Subscribe(new Action<string>(this.OnAmountInputChanged));
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000084 RID: 132 RVA: 0x000288B4 File Offset: 0x00026AB4
		// (set) Token: 0x06000085 RID: 133 RVA: 0x000288BC File Offset: 0x00026ABC
		[Reactive]
		public Transaction MyTransaction
		{
			[CompilerGenerated]
			get
			{
				return this.$MyTransaction;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$MyTransaction, value, "MyTransaction");
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000086 RID: 134 RVA: 0x000288D1 File Offset: 0x00026AD1
		// (set) Token: 0x06000087 RID: 135 RVA: 0x000288D9 File Offset: 0x00026AD9
		[Reactive]
		public string AmountInput
		{
			[CompilerGenerated]
			get
			{
				return this.$AmountInput;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$AmountInput, value, "AmountInput");
			}
		} = "";

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000088 RID: 136 RVA: 0x000288EE File Offset: 0x00026AEE
		// (set) Token: 0x06000089 RID: 137 RVA: 0x000288F6 File Offset: 0x00026AF6
		[Reactive]
		public string LivePreviewText
		{
			[CompilerGenerated]
			get
			{
				return this.$LivePreviewText;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$LivePreviewText, value, "LivePreviewText");
			}
		} = "";

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x0600008A RID: 138 RVA: 0x0002890B File Offset: 0x00026B0B
		// (set) Token: 0x0600008B RID: 139 RVA: 0x00028913 File Offset: 0x00026B13
		[Reactive]
		public string Chip1Text
		{
			[CompilerGenerated]
			get
			{
				return this.$Chip1Text;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Chip1Text, value, "Chip1Text");
			}
		} = "";

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x0600008C RID: 140 RVA: 0x00028928 File Offset: 0x00026B28
		// (set) Token: 0x0600008D RID: 141 RVA: 0x00028930 File Offset: 0x00026B30
		[Reactive]
		public string Chip2Text
		{
			[CompilerGenerated]
			get
			{
				return this.$Chip2Text;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Chip2Text, value, "Chip2Text");
			}
		} = "";

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x0600008E RID: 142 RVA: 0x00028945 File Offset: 0x00026B45
		// (set) Token: 0x0600008F RID: 143 RVA: 0x0002894D File Offset: 0x00026B4D
		[Reactive]
		public string Chip3Text
		{
			[CompilerGenerated]
			get
			{
				return this.$Chip3Text;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Chip3Text, value, "Chip3Text");
			}
		} = "";

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000090 RID: 144 RVA: 0x00028962 File Offset: 0x00026B62
		// (set) Token: 0x06000091 RID: 145 RVA: 0x0002896A File Offset: 0x00026B6A
		[Reactive]
		public string Chip4Text
		{
			[CompilerGenerated]
			get
			{
				return this.$Chip4Text;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Chip4Text, value, "Chip4Text");
			}
		} = "";

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000092 RID: 146 RVA: 0x0002897F File Offset: 0x00026B7F
		// (set) Token: 0x06000093 RID: 147 RVA: 0x00028987 File Offset: 0x00026B87
		[Reactive]
		public string Chip5Text
		{
			[CompilerGenerated]
			get
			{
				return this.$Chip5Text;
			}
			[CompilerGenerated]
			set
			{
				this.RaiseAndSetIfChanged(ref this.$Chip5Text, value, "Chip5Text");
			}
		} = "";

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000094 RID: 148 RVA: 0x0002899C File Offset: 0x00026B9C
		// (set) Token: 0x06000095 RID: 149 RVA: 0x000289A4 File Offset: 0x00026BA4
		public bool SuccessfullyAdd { get; set; }

		// Token: 0x06000096 RID: 150 RVA: 0x000289B0 File Offset: 0x00026BB0
		private void SetupChips()
		{
			if (this.MyCoin == null)
			{
				return;
			}
			string a = this.MyCoin.Symbol.ToUpper();
			if (a == "USDT")
			{
				this.Chip1Text = "1,000";
				this.Chip2Text = "5,000";
				this.Chip3Text = "10,000";
				this.Chip4Text = "20,000";
				this.Chip5Text = "50,000";
				return;
			}
			if (a == "SOL")
			{
				this.Chip1Text = "10";
				this.Chip2Text = "50";
				this.Chip3Text = "250";
				this.Chip4Text = "500";
				this.Chip5Text = "1,250";
				return;
			}
			if (a == "TRX")
			{
				this.Chip1Text = "10,000";
				this.Chip2Text = "30,000";
				this.Chip3Text = "60,000";
				this.Chip4Text = "100,000";
				this.Chip5Text = "500,000";
				return;
			}
			if (a == "BTC")
			{
				this.Chip1Text = "0.1";
				this.Chip2Text = "0.5";
				this.Chip3Text = "1.0";
				this.Chip4Text = "5.0";
				this.Chip5Text = "15.54";
				return;
			}
			if (a == "ETH")
			{
				this.Chip1Text = "1";
				this.Chip2Text = "5";
				this.Chip3Text = "10";
				this.Chip4Text = "20";
				this.Chip5Text = "32.5";
				return;
			}
			if (!(a == "BNB"))
			{
				this.Chip1Text = "100";
				this.Chip2Text = "500";
				this.Chip3Text = "1,000";
				this.Chip4Text = "5,000";
				this.Chip5Text = "10,000";
				return;
			}
			this.Chip1Text = "5";
			this.Chip2Text = "20";
			this.Chip3Text = "50";
			this.Chip4Text = "100";
			this.Chip5Text = "350";
		}

		// Token: 0x06000097 RID: 151 RVA: 0x00028BBD File Offset: 0x00026DBD
		public void SelectChip(string chipValue)
		{
			if (!string.IsNullOrWhiteSpace(chipValue))
			{
				this.AmountInput = chipValue;
			}
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00028BCE File Offset: 0x00026DCE
		public void Chip1Command()
		{
			this.SelectChip(this.Chip1Text);
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00028BDC File Offset: 0x00026DDC
		public void Chip2Command()
		{
			this.SelectChip(this.Chip2Text);
		}

		// Token: 0x0600009A RID: 154 RVA: 0x00028BEA File Offset: 0x00026DEA
		public void Chip3Command()
		{
			this.SelectChip(this.Chip3Text);
		}

		// Token: 0x0600009B RID: 155 RVA: 0x00028BF8 File Offset: 0x00026DF8
		public void Chip4Command()
		{
			this.SelectChip(this.Chip4Text);
		}

		// Token: 0x0600009C RID: 156 RVA: 0x00028C06 File Offset: 0x00026E06
		public void Chip5Command()
		{
			this.SelectChip(this.Chip5Text);
		}

		// Token: 0x0600009D RID: 157 RVA: 0x00028C14 File Offset: 0x00026E14
		private void OnAmountInputChanged(string input)
		{
			if (this.MyCoin == null || this.MyTransaction == null)
			{
				return;
			}
			double parsed = AddTransactionWindowViewModel.ParseCryptoInput(input, this.MyCoin.Symbol);
			this.MyTransaction.Amount = parsed;
			double price = TransactionService.Instance.GetPrice(this.MyCoin.Symbol);
			double usd = parsed * price;
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(16, 3);
			defaultInterpolatedStringHandler.AppendLiteral("+ ");
			defaultInterpolatedStringHandler.AppendFormatted(NumberFormatHelper.FormatCrypto(parsed, 8));
			defaultInterpolatedStringHandler.AppendLiteral(" ");
			defaultInterpolatedStringHandler.AppendFormatted(this.MyCoin.Symbol);
			defaultInterpolatedStringHandler.AppendLiteral("  ( ≈ $");
			defaultInterpolatedStringHandler.AppendFormatted<double>(usd, "N2");
			defaultInterpolatedStringHandler.AppendLiteral(" USD )");
			this.LivePreviewText = defaultInterpolatedStringHandler.ToStringAndClear();
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00028CE0 File Offset: 0x00026EE0
		public static double ParseCryptoInput(string input, string symbol)
		{
			if (string.IsNullOrWhiteSpace(input))
			{
				return 0.0;
			}
			input = input.Trim();
			if (!string.IsNullOrEmpty(symbol))
			{
				input = Regex.Replace(input, symbol, "", RegexOptions.IgnoreCase).Trim();
			}
			if ((symbol == "USDT" || symbol == "TRX" || symbol == "DOGE" || symbol == "SOL") && Regex.IsMatch(input, "^\\d+\\.000$"))
			{
				input = input.Replace(".", "");
			}
			input = input.Replace(",", "");
			double val;
			if (double.TryParse(input, NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands | NumberStyles.AllowExponent, CultureInfo.InvariantCulture, out val))
			{
				return Math.Abs(val);
			}
			return 0.0;
		}

		// Token: 0x0600009F RID: 159 RVA: 0x00028DAC File Offset: 0x00026FAC
		public void Randomize()
		{
			if (this.MyTransaction != null && this.MyCoin != null)
			{
				if (this.MyCoin.Symbol == "SOL")
				{
					this.MyTransaction.TransactionId = TransactionService.Instance.RandomBase58String(88);
					this.MyTransaction.From = TransactionService.Instance.RandomBase58String(44);
					return;
				}
				if (this.MyCoin.Symbol == "USDT" || this.MyCoin.Symbol == "TRX")
				{
					this.MyTransaction.TransactionId = TransactionService.Instance.RandomHexString(64);
					this.MyTransaction.From = "T" + TransactionService.Instance.RandomBase58String(33);
					return;
				}
				if (this.MyCoin.Symbol == "ETH" || this.MyCoin.Symbol == "BNB" || this.MyCoin.Symbol == "LINK")
				{
					this.MyTransaction.TransactionId = "0x" + TransactionService.Instance.RandomHexString(64);
					this.MyTransaction.From = "0x" + TransactionService.Instance.RandomHexString(40);
					return;
				}
				this.MyTransaction.TransactionId = TransactionService.Instance.RandomHexString(64);
				this.MyTransaction.From = this.MyCoin.StartValue + TransactionService.Instance.RandomString(39);
			}
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x00028F44 File Offset: 0x00027144
		public void SetWhalePreset()
		{
			if (this.MyTransaction != null && this.MyCoin != null)
			{
				string symbol = this.MyCoin.Symbol;
				double num;
				if (symbol != null)
				{
					int length = symbol.Length;
					if (length != 3)
					{
						if (length == 4)
						{
							char c = symbol[0];
							if (c != 'D')
							{
								if (c == 'U')
								{
									if (symbol == "USDT")
									{
										num = 150000.0;
										goto IL_182;
									}
								}
							}
							else if (symbol == "DOGE")
							{
								num = 500000.0;
								goto IL_182;
							}
						}
					}
					else
					{
						char c = symbol[0];
						if (c <= 'E')
						{
							if (c != 'B')
							{
								if (c == 'E')
								{
									if (symbol == "ETH")
									{
										num = 32.5;
										goto IL_182;
									}
								}
							}
							else
							{
								if (symbol == "BTC")
								{
									num = 15.5410928;
									goto IL_182;
								}
								if (symbol == "BNB")
								{
									num = 350.0;
									goto IL_182;
								}
							}
						}
						else if (c != 'L')
						{
							if (c != 'S')
							{
								if (c == 'T')
								{
									if (symbol == "TRX")
									{
										num = 500000.0;
										goto IL_182;
									}
								}
							}
							else if (symbol == "SOL")
							{
								num = 1250.0;
								goto IL_182;
							}
						}
						else if (symbol == "LTC")
						{
							num = 250.0;
							goto IL_182;
						}
					}
				}
				num = 500.0;
				IL_182:
				double whaleAmount = num;
				this.AmountInput = NumberFormatHelper.FormatCrypto(whaleAmount, 8);
				this.Randomize();
			}
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x000290E8 File Offset: 0x000272E8
		public void Save()
		{
			if (this.MyCoin != null && this.MyTransaction != null)
			{
				this.MyTransaction.Amount = AddTransactionWindowViewModel.ParseCryptoInput(this.AmountInput, this.MyCoin.Symbol);
			}
			this.SuccessfullyAdd = true;
			this.Close();
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00029128 File Offset: 0x00027328
		public void Close()
		{
			this._window.Close();
		}

		// Token: 0x0400001A RID: 26
		private AddTransactionWindow _window;

		// Token: 0x0400001D RID: 29
		private Transaction $MyTransaction;

		// Token: 0x0400001E RID: 30
		private string $AmountInput;

		// Token: 0x0400001F RID: 31
		private string $LivePreviewText;

		// Token: 0x04000020 RID: 32
		private string $Chip1Text;

		// Token: 0x04000021 RID: 33
		private string $Chip2Text;

		// Token: 0x04000022 RID: 34
		private string $Chip3Text;

		// Token: 0x04000023 RID: 35
		private string $Chip4Text;

		// Token: 0x04000024 RID: 36
		private string $Chip5Text;
	}
}
