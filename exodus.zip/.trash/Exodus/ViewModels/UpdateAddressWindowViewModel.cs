﻿using System;
using System.Runtime.CompilerServices;
using Exodus.Views;
using ReactiveUI.Fody.Helpers;

namespace Exodus.ViewModels
{
	// Token: 0x02000067 RID: 103
	[NullableContext(1)]
	[Nullable(0)]
	public class UpdateAddressWindowViewModel
	{
		// Token: 0x060002A7 RID: 679 RVA: 0x0003004B File Offset: 0x0002E24B
		public UpdateAddressWindowViewModel(UpdateAddressWindow window, string address)
		{
			this._window = window;
			this.DraftAddress = address;
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x060002A8 RID: 680 RVA: 0x00030061 File Offset: 0x0002E261
		// (set) Token: 0x060002A9 RID: 681 RVA: 0x00030069 File Offset: 0x0002E269
		public bool SuccessfullyUpdated { get; set; }

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x060002AA RID: 682 RVA: 0x00030072 File Offset: 0x0002E272
		// (set) Token: 0x060002AB RID: 683 RVA: 0x0003007A File Offset: 0x0002E27A
		[Reactive]
		public string DraftAddress { get; set; }

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x060002AC RID: 684 RVA: 0x00030083 File Offset: 0x0002E283
		// (set) Token: 0x060002AD RID: 685 RVA: 0x0003008B File Offset: 0x0002E28B
		public string NewAddress { get; set; }

		// Token: 0x060002AE RID: 686 RVA: 0x00030094 File Offset: 0x0002E294
		public void Save()
		{
			this.NewAddress = this.DraftAddress;
			this.SuccessfullyUpdated = true;
			this.Close();
		}

		// Token: 0x060002AF RID: 687 RVA: 0x000300AF File Offset: 0x0002E2AF
		public void Close()
		{
			this._window.Close();
		}

		// Token: 0x04000136 RID: 310
		private UpdateAddressWindow _window;
	}
}
