﻿using System;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Logging;
using Avalonia.ReactiveUI;

namespace Exodus
{
	// Token: 0x02000008 RID: 8
	[NullableContext(1)]
	[Nullable(0)]
	internal class Program
	{
		// Token: 0x0600000C RID: 12 RVA: 0x000022F0 File Offset: 0x000004F0
		[STAThread]
		public static void Main(string[] args)
		{
			Program.BuildAvaloniaApp().StartWithClassicDesktopLifetime(args, null);
		}

		// Token: 0x0600000D RID: 13 RVA: 0x000022FF File Offset: 0x000004FF
		public static AppBuilder BuildAvaloniaApp()
		{
			return AppBuilder.Configure<App>().UsePlatformDetect().WithInterFont().LogToTrace(LogEventLevel.Warning, Array.Empty<string>()).UseSkia().UseReactiveUI();
		}
	}
}
