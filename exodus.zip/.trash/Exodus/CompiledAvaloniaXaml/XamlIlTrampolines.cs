﻿using System;
using System.Globalization;
using Avalonia.Utilities;
using Exodus.Models;
using Exodus.ViewModels;

namespace CompiledAvaloniaXaml
{
	// Token: 0x02000094 RID: 148
	internal class XamlIlTrampolines
	{
		// Token: 0x060005E7 RID: 1511 RVA: 0x0003C420 File Offset: 0x0003A620
		public static void AddTransactionWindowViewModel+SetWhalePreset_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).SetWhalePreset();
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x0003C438 File Offset: 0x0003A638
		public static void AddTransactionWindowViewModel+Randomize_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Randomize();
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x0003C450 File Offset: 0x0003A650
		public static void AddTransactionWindowViewModel+Chip1Command_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Chip1Command();
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x0003C468 File Offset: 0x0003A668
		public static void AddTransactionWindowViewModel+Chip2Command_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Chip2Command();
		}

		// Token: 0x060005EB RID: 1515 RVA: 0x0003C480 File Offset: 0x0003A680
		public static void AddTransactionWindowViewModel+Chip3Command_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Chip3Command();
		}

		// Token: 0x060005EC RID: 1516 RVA: 0x0003C498 File Offset: 0x0003A698
		public static void AddTransactionWindowViewModel+Chip4Command_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Chip4Command();
		}

		// Token: 0x060005ED RID: 1517 RVA: 0x0003C4B0 File Offset: 0x0003A6B0
		public static void AddTransactionWindowViewModel+Chip5Command_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Chip5Command();
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x0003C4C8 File Offset: 0x0003A6C8
		public static void AddTransactionWindowViewModel+Save_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Save();
		}

		// Token: 0x060005EF RID: 1519 RVA: 0x0003C4E0 File Offset: 0x0003A6E0
		public static void AddTransactionWindowViewModel+Close_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Close();
		}

		// Token: 0x060005F0 RID: 1520 RVA: 0x0003C4F8 File Offset: 0x0003A6F8
		public static void BuySellViewModel+BackToWallet_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).BackToWallet();
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x0003C510 File Offset: 0x0003A710
		public static void BuySellViewModel+OpenFiatPicker_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).OpenFiatPicker();
		}

		// Token: 0x060005F2 RID: 1522 RVA: 0x0003C528 File Offset: 0x0003A728
		public static void BuySellViewModel+OpenCryptoPicker_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).OpenCryptoPicker();
		}

		// Token: 0x060005F3 RID: 1523 RVA: 0x0003C540 File Offset: 0x0003A740
		public static void BuySellViewModel+SetPresetAmount_1!CommandExecuteTrampoline(object A_0, object A_1)
		{
			BuySellViewModel buySellViewModel = (BuySellViewModel)A_0;
			object obj;
			TypeUtilities.TryConvert(typeof(string), A_1, CultureInfo.CurrentCulture, out obj);
			buySellViewModel.SetPresetAmount((string)obj);
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x0003C578 File Offset: 0x0003A778
		public static void BuySellViewModel+ExecuteContinue_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).ExecuteContinue();
		}

		// Token: 0x060005F5 RID: 1525 RVA: 0x0003C590 File Offset: 0x0003A790
		public static void BuySellViewModel+CloseCryptoPicker_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).CloseCryptoPicker();
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x0003C5A8 File Offset: 0x0003A7A8
		public static void BuySellViewModel+SelectCrypto_1!CommandExecuteTrampoline(object A_0, object A_1)
		{
			BuySellViewModel buySellViewModel = (BuySellViewModel)A_0;
			object obj;
			TypeUtilities.TryConvert(typeof(SwapCoinItem), A_1, CultureInfo.CurrentCulture, out obj);
			buySellViewModel.SelectCrypto((SwapCoinItem)obj);
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x0003C5E0 File Offset: 0x0003A7E0
		public static void BuySellViewModel+CloseFiatPicker_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).CloseFiatPicker();
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x0003C5F8 File Offset: 0x0003A7F8
		public static void BuySellViewModel+SelectFiat_1!CommandExecuteTrampoline(object A_0, object A_1)
		{
			BuySellViewModel buySellViewModel = (BuySellViewModel)A_0;
			object obj;
			TypeUtilities.TryConvert(typeof(FiatItem), A_1, CultureInfo.CurrentCulture, out obj);
			buySellViewModel.SelectFiat((FiatItem)obj);
		}

		// Token: 0x060005F9 RID: 1529 RVA: 0x0003C630 File Offset: 0x0003A830
		public static void CoinSpecificPartViewModel+RefreshCommand_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).RefreshCommand();
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x0003C648 File Offset: 0x0003A848
		public static void CoinSpecificPartViewModel+ReceiveCommand_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).ReceiveCommand();
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x0003C660 File Offset: 0x0003A860
		public static void Transaction+ExpandCommand_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((Transaction)A_0).ExpandCommand();
		}

		// Token: 0x060005FC RID: 1532 RVA: 0x0003C678 File Offset: 0x0003A878
		public static void Transaction+OpenTransactionLook_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((Transaction)A_0).OpenTransactionLook();
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x0003C690 File Offset: 0x0003A890
		public static void MainWindowViewModel+NavigateToPortfolio_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).NavigateToPortfolio();
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x0003C6A8 File Offset: 0x0003A8A8
		public static void MainWindowViewModel+NavigateToWallet_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).NavigateToWallet();
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x0003C6C0 File Offset: 0x0003A8C0
		public static void MainWindowViewModel+NavigateToSwap_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).NavigateToSwap();
		}

		// Token: 0x06000600 RID: 1536 RVA: 0x0003C6D8 File Offset: 0x0003A8D8
		public static void MainWindowViewModel+NavigateToBuySell_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).NavigateToBuySell();
		}

		// Token: 0x06000601 RID: 1537 RVA: 0x0003C6F0 File Offset: 0x0003A8F0
		public static void MainWindowViewModel+OpenSettingsCommand_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).OpenSettingsCommand();
		}

		// Token: 0x06000602 RID: 1538 RVA: 0x0003C708 File Offset: 0x0003A908
		public static void Coin+SelectedCommand_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((Coin)A_0).SelectedCommand();
		}

		// Token: 0x06000603 RID: 1539 RVA: 0x0003C720 File Offset: 0x0003A920
		public static void PortfolioViewModel+SelectCoin_1!CommandExecuteTrampoline(object A_0, object A_1)
		{
			PortfolioViewModel portfolioViewModel = (PortfolioViewModel)A_0;
			object obj;
			TypeUtilities.TryConvert(typeof(PortfolioCoinItem), A_1, CultureInfo.CurrentCulture, out obj);
			portfolioViewModel.SelectCoin((PortfolioCoinItem)obj);
		}

		// Token: 0x06000604 RID: 1540 RVA: 0x0003C758 File Offset: 0x0003A958
		public static void ReceiveAddressViewModel+CloseCommand_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((ReceiveAddressViewModel)A_0).CloseCommand();
		}

		// Token: 0x06000605 RID: 1541 RVA: 0x0003C770 File Offset: 0x0003A970
		public static void ReceiveAddressViewModel+ChainCommand_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((ReceiveAddressViewModel)A_0).ChainCommand();
		}

		// Token: 0x06000606 RID: 1542 RVA: 0x0003C788 File Offset: 0x0003A988
		public static void RefreshViewModel+CloseCommand_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((RefreshViewModel)A_0).CloseCommand();
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x0003C7A0 File Offset: 0x0003A9A0
		public static void RefreshViewModel+YesRefreshCommand_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((RefreshViewModel)A_0).YesRefreshCommand();
		}

		// Token: 0x06000608 RID: 1544 RVA: 0x0003C7B8 File Offset: 0x0003A9B8
		public static void SettingsModalViewModel+CloseCommand_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SettingsModalViewModel)A_0).CloseCommand();
		}

		// Token: 0x06000609 RID: 1545 RVA: 0x0003C7D0 File Offset: 0x0003A9D0
		public static void SettingsModalViewModel+CopyTelegram_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SettingsModalViewModel)A_0).CopyTelegram();
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x0003C7E8 File Offset: 0x0003A9E8
		public static void SettingsModalViewModel+OpenTelegram_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SettingsModalViewModel)A_0).OpenTelegram();
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x0003C800 File Offset: 0x0003AA00
		public static void SettingsModalViewModel+CopyWebsite_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SettingsModalViewModel)A_0).CopyWebsite();
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x0003C818 File Offset: 0x0003AA18
		public static void SettingsModalViewModel+OpenWebsite_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SettingsModalViewModel)A_0).OpenWebsite();
		}

		// Token: 0x0600060D RID: 1549 RVA: 0x0003C830 File Offset: 0x0003AA30
		public static void SwapViewModel+OpenHavePicker_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SwapViewModel)A_0).OpenHavePicker();
		}

		// Token: 0x0600060E RID: 1550 RVA: 0x0003C848 File Offset: 0x0003AA48
		public static void SwapViewModel+FlipCoins_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SwapViewModel)A_0).FlipCoins();
		}

		// Token: 0x0600060F RID: 1551 RVA: 0x0003C860 File Offset: 0x0003AA60
		public static void SwapViewModel+OpenWantPicker_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SwapViewModel)A_0).OpenWantPicker();
		}

		// Token: 0x06000610 RID: 1552 RVA: 0x0003C878 File Offset: 0x0003AA78
		public static void SwapViewModel+ApplyMin_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SwapViewModel)A_0).ApplyMin();
		}

		// Token: 0x06000611 RID: 1553 RVA: 0x0003C890 File Offset: 0x0003AA90
		public static void SwapViewModel+ApplyHalf_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SwapViewModel)A_0).ApplyHalf();
		}

		// Token: 0x06000612 RID: 1554 RVA: 0x0003C8A8 File Offset: 0x0003AAA8
		public static void SwapViewModel+ApplyMax_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SwapViewModel)A_0).ApplyMax();
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x0003C8C0 File Offset: 0x0003AAC0
		public static void SwapViewModel+ExecuteSwap_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SwapViewModel)A_0).ExecuteSwap();
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x0003C8D8 File Offset: 0x0003AAD8
		public static void SwapViewModel+ClosePicker_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((SwapViewModel)A_0).ClosePicker();
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x0003C8F0 File Offset: 0x0003AAF0
		public static void SwapViewModel+SelectCoin_1!CommandExecuteTrampoline(object A_0, object A_1)
		{
			SwapViewModel swapViewModel = (SwapViewModel)A_0;
			object obj;
			TypeUtilities.TryConvert(typeof(SwapCoinItem), A_1, CultureInfo.CurrentCulture, out obj);
			swapViewModel.SelectCoin((SwapCoinItem)obj);
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x0003C928 File Offset: 0x0003AB28
		public static void UpdateAddressWindowViewModel+Save_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((UpdateAddressWindowViewModel)A_0).Save();
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x0003C940 File Offset: 0x0003AB40
		public static void UpdateAddressWindowViewModel+Close_0!CommandExecuteTrampoline(object A_0, object A_1)
		{
			((UpdateAddressWindowViewModel)A_0).Close();
		}
	}
}
