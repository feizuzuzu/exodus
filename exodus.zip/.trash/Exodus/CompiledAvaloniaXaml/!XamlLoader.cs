﻿using System;
using System.ComponentModel;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Exodus;
using Exodus.Controls;
using Exodus.Views;

namespace CompiledAvaloniaXaml
{
	// Token: 0x02000099 RID: 153
	[EditorBrowsable(EditorBrowsableState.Never)]
	public class !XamlLoader
	{
		// Token: 0x06000630 RID: 1584 RVA: 0x0003CE1C File Offset: 0x0003B01C
		public static object TryLoad(IServiceProvider A_0, string A_1)
		{
			if (string.Equals(A_1, "avares://Exodus/App.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new App();
			}
			if (string.Equals(A_1, "avares://Exodus/Assets/Resources/Icons/Icons.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return !AvaloniaResources.Build:/Assets/Resources/Icons/Icons.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(A_0));
			}
			if (string.Equals(A_1, "avares://Exodus/Controls/ThreeDotAnimation.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new ThreeDotAnimation();
			}
			if (string.Equals(A_1, "avares://Exodus/Resources/CoinBanners.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return !AvaloniaResources.Build:/Resources/CoinBanners.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(A_0));
			}
			if (string.Equals(A_1, "avares://Exodus/Resources/FontResources.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return !AvaloniaResources.Build:/Resources/FontResources.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(A_0));
			}
			if (string.Equals(A_1, "avares://Exodus/Resources/SmoothScrollThemeResources.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return !AvaloniaResources.Build:/Resources/SmoothScrollThemeResources.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(A_0));
			}
			if (string.Equals(A_1, "avares://Exodus/Styles/ButtonStyles.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return !AvaloniaResources.Build:/Styles/ButtonStyles.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(A_0));
			}
			if (string.Equals(A_1, "avares://Exodus/Styles/TextBoxStyles.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return !AvaloniaResources.Build:/Styles/TextBoxStyles.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(A_0));
			}
			if (string.Equals(A_1, "avares://Exodus/Styles/ToggleButtonStyles.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return !AvaloniaResources.Build:/Styles/ToggleButtonStyles.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(A_0));
			}
			if (string.Equals(A_1, "avares://Exodus/Views/AddTransactionWindow.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new AddTransactionWindow();
			}
			if (string.Equals(A_1, "avares://Exodus/Views/BuySellView.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new BuySellView();
			}
			if (string.Equals(A_1, "avares://Exodus/Views/CoinSpecificPartView.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new CoinSpecificPartView();
			}
			if (string.Equals(A_1, "avares://Exodus/Views/MainWindow.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new MainWindow();
			}
			if (string.Equals(A_1, "avares://Exodus/Views/NotificationView.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new NotificationView();
			}
			if (string.Equals(A_1, "avares://Exodus/Views/PortfolioView.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new PortfolioView();
			}
			if (string.Equals(A_1, "avares://Exodus/Views/ReceiveAddressView.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new ReceiveAddressView();
			}
			if (string.Equals(A_1, "avares://Exodus/Views/RefreshView.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new RefreshView();
			}
			if (string.Equals(A_1, "avares://Exodus/Views/SettingsModalView.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new SettingsModalView();
			}
			if (string.Equals(A_1, "avares://Exodus/Views/SwapView.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new SwapView();
			}
			if (string.Equals(A_1, "avares://Exodus/Views/UpdateAddressWindow.axaml", StringComparison.OrdinalIgnoreCase))
			{
				return new UpdateAddressWindow();
			}
			return null;
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x0003D084 File Offset: 0x0003B284
		public static object TryLoad(string A_0)
		{
			return !XamlLoader.TryLoad(null, A_0);
		}
	}
}
