﻿using System;

namespace CompiledAvaloniaXaml
{
	// Token: 0x02000093 RID: 147
	internal class !IndexerAccessorFactoryClosure
	{
	}
}
