﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.XamlIl.Runtime;

namespace CompiledAvaloniaXaml
{
	// Token: 0x02000095 RID: 149
	internal class XamlIlContext
	{
		// Token: 0x02000096 RID: 150
		public class Context<TTarget> : IRootObjectProvider, IAvaloniaXamlIlParentStackProvider, ITypeDescriptorContext, IProvideValueTarget, IUriContext, IServiceProvider
		{
			// Token: 0x17000106 RID: 262
			// (get) Token: 0x06000618 RID: 1560 RVA: 0x0003C958 File Offset: 0x0003AB58
			virtual object RootObject
			{
				get
				{
					if (this.RootObject != null)
					{
						return this.RootObject;
					}
					if (this._sp != null)
					{
						IRootObjectProvider rootObjectProvider = (IRootObjectProvider)this._sp.GetService(typeof(IRootObjectProvider));
						if (rootObjectProvider != null)
						{
							return rootObjectProvider.RootObject;
						}
					}
					return null;
				}
			}

			// Token: 0x17000107 RID: 263
			// (get) Token: 0x06000619 RID: 1561 RVA: 0x0003C9B8 File Offset: 0x0003ABB8
			virtual object IntermediateRootObject
			{
				get
				{
					return this.IntermediateRoot;
				}
			}

			// Token: 0x17000108 RID: 264
			// (get) Token: 0x0600061A RID: 1562 RVA: 0x0003C9CC File Offset: 0x0003ABCC
			virtual IEnumerable<object> Parents
			{
				get
				{
					return this._parentStackEnumerable;
				}
			}

			// Token: 0x17000109 RID: 265
			// (get) Token: 0x0600061B RID: 1563 RVA: 0x0003C9E0 File Offset: 0x0003ABE0
			virtual IContainer Container
			{
				get
				{
					return null;
				}
			}

			// Token: 0x1700010A RID: 266
			// (get) Token: 0x0600061C RID: 1564 RVA: 0x0003C9F0 File Offset: 0x0003ABF0
			virtual object Instance
			{
				get
				{
					return null;
				}
			}

			// Token: 0x1700010B RID: 267
			// (get) Token: 0x0600061D RID: 1565 RVA: 0x0003CA00 File Offset: 0x0003AC00
			virtual PropertyDescriptor PropertyDescriptor
			{
				get
				{
					return null;
				}
			}

			// Token: 0x0600061E RID: 1566 RVA: 0x0003CA10 File Offset: 0x0003AC10
			virtual bool OnComponentChanging()
			{
				throw new NotSupportedException();
			}

			// Token: 0x0600061F RID: 1567 RVA: 0x0003CA24 File Offset: 0x0003AC24
			virtual void OnComponentChanged()
			{
				throw new NotSupportedException();
			}

			// Token: 0x1700010C RID: 268
			// (get) Token: 0x06000620 RID: 1568 RVA: 0x0003CA38 File Offset: 0x0003AC38
			virtual object TargetObject
			{
				get
				{
					return this.ProvideTargetObject;
				}
			}

			// Token: 0x1700010D RID: 269
			// (get) Token: 0x06000621 RID: 1569 RVA: 0x0003CA4C File Offset: 0x0003AC4C
			virtual object TargetProperty
			{
				get
				{
					return this.ProvideTargetProperty;
				}
			}

			// Token: 0x1700010E RID: 270
			// (get) Token: 0x06000622 RID: 1570 RVA: 0x0003CA60 File Offset: 0x0003AC60
			// (set) Token: 0x06000623 RID: 1571 RVA: 0x0003CA74 File Offset: 0x0003AC74
			public virtual Uri BaseUri
			{
				get
				{
					return this._baseUri;
				}
				set
				{
					this._baseUri = value;
				}
			}

			// Token: 0x06000624 RID: 1572 RVA: 0x0003CA88 File Offset: 0x0003AC88
			public virtual object GetService(Type A_1)
			{
				if (this._innerSp != null)
				{
					object service = this._innerSp.GetService(A_1);
					if (service != null)
					{
						return service;
					}
				}
				if (typeof(IRootObjectProvider).Equals(A_1))
				{
					return this;
				}
				if (typeof(IAvaloniaXamlIlParentStackProvider).Equals(A_1))
				{
					return this;
				}
				if (typeof(ITypeDescriptorContext).Equals(A_1))
				{
					return this;
				}
				if (typeof(IProvideValueTarget).Equals(A_1))
				{
					return this;
				}
				if (typeof(IUriContext).Equals(A_1))
				{
					return this;
				}
				if (this._staticProviders != null)
				{
					for (int i = 0; i < this._staticProviders.Length; i++)
					{
						object obj = this._staticProviders[i];
						if (A_1.IsAssignableFrom(obj.GetType()))
						{
							return obj;
						}
					}
				}
				if (this._sp != null)
				{
					return this._sp.GetService(A_1);
				}
				return null;
			}

			// Token: 0x06000625 RID: 1573 RVA: 0x0003CB80 File Offset: 0x0003AD80
			public Context(IServiceProvider A_1, object[] A_2, string A_3)
			{
				this._sp = A_1;
				this._staticProviders = A_2;
				if (A_3 != null)
				{
					this._baseUri = new Uri(A_3);
				}
				this.ParentsStack = new List<object>();
				this._parentStackEnumerable = new XamlIlContext.ParentStackEnumerable(this.ParentsStack, this._sp);
				this.AvaloniaNameScope = A_1.GetService(typeof(INameScope));
				this._innerSp = XamlIlRuntimeHelpers.CreateInnerServiceProviderV1(this);
			}

			// Token: 0x06000626 RID: 1574 RVA: 0x0003CBF8 File Offset: 0x0003ADF8
			public void PushParent(object A_1)
			{
				this.ParentsStack.Add(A_1);
				this.ProvideTargetObject = A_1;
			}

			// Token: 0x06000627 RID: 1575 RVA: 0x0003CC18 File Offset: 0x0003AE18
			public void PopParent()
			{
				int index = this.ParentsStack.Count - 1;
				this.ProvideTargetObject = this.ParentsStack[index];
				this.ParentsStack.RemoveAt(index);
			}

			// Token: 0x040002D1 RID: 721
			public TTarget RootObject;

			// Token: 0x040002D2 RID: 722
			public object IntermediateRoot;

			// Token: 0x040002D3 RID: 723
			IServiceProvider _sp;

			// Token: 0x040002D4 RID: 724
			IServiceProvider _innerSp;

			// Token: 0x040002D5 RID: 725
			object[] _staticProviders;

			// Token: 0x040002D6 RID: 726
			public List<object> ParentsStack;

			// Token: 0x040002D7 RID: 727
			IEnumerable<object> _parentStackEnumerable;

			// Token: 0x040002D8 RID: 728
			public object ProvideTargetObject;

			// Token: 0x040002D9 RID: 729
			public object ProvideTargetProperty;

			// Token: 0x040002DA RID: 730
			Uri _baseUri;

			// Token: 0x040002DB RID: 731
			public INameScope AvaloniaNameScope;
		}

		// Token: 0x02000097 RID: 151
		private class ParentStackEnumerable : IEnumerable<object>
		{
			// Token: 0x06000628 RID: 1576 RVA: 0x0003CC54 File Offset: 0x0003AE54
			public ParentStackEnumerable(List<object> A_1, IServiceProvider A_2)
			{
				this._parentList = A_1;
				this._parentSP = A_2;
			}

			// Token: 0x06000629 RID: 1577 RVA: 0x0003CC78 File Offset: 0x0003AE78
			public virtual IEnumerator<object> GetEnumerator()
			{
				return new XamlIlContext.ParentStackEnumerable.Enumerator(this._parentList, this._parentSP);
			}

			// Token: 0x0600062A RID: 1578 RVA: 0x0003CC98 File Offset: 0x0003AE98
			virtual IEnumerator GetEnumerator()
			{
				return this.GetEnumerator();
			}

			// Token: 0x040002DC RID: 732
			List<object> _parentList;

			// Token: 0x040002DD RID: 733
			IServiceProvider _parentSP;

			// Token: 0x02000098 RID: 152
			public class Enumerator : IEnumerator<object>
			{
				// Token: 0x0600062B RID: 1579 RVA: 0x0003CCAC File Offset: 0x0003AEAC
				public Enumerator(List<object> A_1, IServiceProvider A_2)
				{
					this._parentList = A_1;
					this._parentSP = A_2;
				}

				// Token: 0x1700010F RID: 271
				// (get) Token: 0x0600062C RID: 1580 RVA: 0x0003CCD0 File Offset: 0x0003AED0
				public virtual object Current
				{
					get
					{
						return this._current;
					}
				}

				// Token: 0x0600062D RID: 1581 RVA: 0x0003CCE4 File Offset: 0x0003AEE4
				virtual void IEnumerator()
				{
					throw new NotSupportedException();
				}

				// Token: 0x0600062E RID: 1582 RVA: 0x0003CCF8 File Offset: 0x0003AEF8
				virtual void Dispose()
				{
					if (this._parentEnumerator != null)
					{
						this._parentEnumerator.Dispose();
					}
				}

				// Token: 0x0600062F RID: 1583 RVA: 0x0003CD1C File Offset: 0x0003AF1C
				virtual bool IEnumerator()
				{
					if (this._state != 0)
					{
						if (this._state != 1)
						{
							if (this._state != 2)
							{
								return false;
							}
							goto IL_C8;
						}
					}
					else
					{
						this._list = this._parentList;
						this._listIndex = this._list.Count - 1;
						this._state = 1;
					}
					if (this._listIndex >= 0)
					{
						this._current = this._list[this._listIndex];
						this._listIndex--;
						return true;
					}
					IAvaloniaXamlIlParentStackProvider avaloniaXamlIlParentStackProvider;
					if (this._parentSP == null || (avaloniaXamlIlParentStackProvider = (IAvaloniaXamlIlParentStackProvider)this._parentSP.GetService(typeof(IAvaloniaXamlIlParentStackProvider))) == null)
					{
						goto IL_EB;
					}
					this._parentEnumerator = avaloniaXamlIlParentStackProvider.Parents.GetEnumerator();
					this._state = 2;
					IL_C8:
					if (this._parentEnumerator.MoveNext())
					{
						this._current = this._parentEnumerator.Current;
						return true;
					}
					IL_EB:
					this._state = 3;
					return false;
				}

				// Token: 0x040002DE RID: 734
				int _state;

				// Token: 0x040002DF RID: 735
				List<object> _parentList;

				// Token: 0x040002E0 RID: 736
				IServiceProvider _parentSP;

				// Token: 0x040002E1 RID: 737
				List<object> _list;

				// Token: 0x040002E2 RID: 738
				int _listIndex;

				// Token: 0x040002E3 RID: 739
				object _current;

				// Token: 0x040002E4 RID: 740
				IEnumerator<object> _parentEnumerator;
			}
		}
	}
}
