﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Collections;
using Avalonia.Controls;
using Avalonia.Controls.Presenters;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompositionScroll;

namespace CompiledAvaloniaXaml
{
	// Token: 0x0200009A RID: 154
	[EditorBrowsable(EditorBrowsableState.Never)]
	public class !AvaloniaResources
	{
		// Token: 0x06000632 RID: 1586 RVA: 0x0003D090 File Offset: 0x0003B290
		public static void axaml(IServiceProvider A_0, Styles A_1)
		{
			XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
			{
				(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
			}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			A_1.Resources.AddDeferred("Settings", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_2.Build), context));
			A_1.Resources.AddDeferred("History", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_3.Build), context));
			A_1.Resources.AddDeferred("Support", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_4.Build), context));
			A_1.Resources.AddDeferred("ThreeDot", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_5.Build), context));
			A_1.Resources.AddDeferred("Star", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_6.Build), context));
			A_1.Resources.AddDeferred("Exchange", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_7.Build), context));
			A_1.Resources.AddDeferred("Received", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_8.Build), context));
			A_1.Resources.AddDeferred("Expand", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_9.Build), context));
			A_1.Resources.AddDeferred("Collapse", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_10.Build), context));
			A_1.Resources.AddDeferred("Copy", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_11.Build), context));
			A_1.Resources.AddDeferred("CopyLight", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_12.Build), context));
			A_1.Resources.AddDeferred("Close", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_13.Build), context));
			A_1.Resources.AddDeferred("ThreeDotLoading", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_14.Build), context));
			A_1.Resources.AddDeferred("CircleDot", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_15.Build), context));
			A_1.Resources.AddDeferred("PointDownFullArrow", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_16.Build), context));
			A_1.Resources.AddDeferred("IIcon", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_17.Build), context));
			A_1.Resources.AddDeferred("Chain", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_18.Build), context));
			A_1.Resources.AddDeferred("Refresh", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_19.Build), context));
			A_1.Resources.AddDeferred("TelegramIcon", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_20.Build), context));
			A_1.Resources.AddDeferred("GlobeIcon", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_21.Build), context));
			A_1.Resources.AddDeferred("ExternalLinkIcon", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_22.Build), context));
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x06000633 RID: 1587 RVA: 0x0003D3BC File Offset: 0x0003B5BC
		public static Styles axaml(IServiceProvider A_0)
		{
			Styles styles = new Styles();
			!AvaloniaResources.Populate:/Assets/Resources/Icons/Icons.axaml(A_0, styles);
			return styles;
		}

		// Token: 0x06000634 RID: 1588 RVA: 0x0003D3D8 File Offset: 0x0003B5D8
		public static void axaml(IServiceProvider A_0, Styles A_1)
		{
			XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
			{
				(object)!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.Singleton
			}, "avares://Exodus/Styles/ButtonStyles.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			context.PushParent(A_1);
			Style style = new Style();
			style.Selector = Selectors.OfType((Selector)null, typeof(Button));
			style.Add(new Setter
			{
				Property = TemplatedControl.BackgroundProperty,
				Value = new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue()
			});
			A_1.Add(style);
			Style style2 = new Style();
			style2.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pointerover").Template().OfType(typeof(ContentPresenter));
			style2.Add(new Setter
			{
				Property = ContentPresenter.BackgroundProperty,
				Value = new TemplateBinding(ContentPresenter.BackgroundProperty).ProvideValue()
			});
			A_1.Add(style2);
			Style style3 = new Style();
			style3.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pressed").Template().OfType(typeof(ContentPresenter));
			style3.Add(new Setter
			{
				Property = ContentPresenter.BackgroundProperty,
				Value = new TemplateBinding(ContentPresenter.BackgroundProperty).ProvideValue()
			});
			A_1.Add(style3);
			Style style4;
			IStyle item = style4 = new Style();
			context.PushParent(style4);
			Style style5 = style4;
			style5.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pointerover");
			style5.Add(new Setter
			{
				Property = TemplatedControl.BackgroundProperty,
				Value = new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue()
			});
			Setter setter2;
			SetterBase setter = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter3 = setter2;
			setter3.Property = Visual.RenderTransformProperty;
			setter3.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(0.99)");
			context.PopParent();
			style5.Add(setter);
			context.PopParent();
			A_1.Add(item);
			IStyle item2 = style4 = new Style();
			context.PushParent(style4);
			Style style6 = style4;
			style6.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pressed");
			style6.Add(new Setter
			{
				Property = TemplatedControl.BackgroundProperty,
				Value = new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue()
			});
			SetterBase setter4 = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter5 = setter2;
			setter5.Property = Visual.RenderTransformProperty;
			setter5.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(0.97)");
			context.PopParent();
			style6.Add(setter4);
			context.PopParent();
			A_1.Add(item2);
			context.PopParent();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x0003D6C8 File Offset: 0x0003B8C8
		public static Styles axaml(IServiceProvider A_0)
		{
			Styles styles = new Styles();
			!AvaloniaResources.Populate:/Styles/ButtonStyles.axaml(A_0, styles);
			return styles;
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x0003D6E4 File Offset: 0x0003B8E4
		public static void axaml(IServiceProvider A_0, Styles A_1)
		{
			XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
			{
				(object)!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.Singleton
			}, "avares://Exodus/Styles/ToggleButtonStyles.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			Style style = new Style();
			style.Selector = Selectors.OfType((Selector)null, typeof(ToggleButton)).Template().OfType(typeof(ContentPresenter));
			style.Add(new Setter
			{
				Property = ContentPresenter.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(16777215U)
			});
			Setter setter = new Setter();
			setter.Property = Visual.RenderTransformProperty;
			ScaleTransform scaleTransform = new ScaleTransform();
			scaleTransform.SetValue<double>(ScaleTransform.ScaleXProperty, 1.0, BindingPriority.Template);
			scaleTransform.SetValue<double>(ScaleTransform.ScaleYProperty, 1.0, BindingPriority.Template);
			setter.Value = scaleTransform;
			style.Add(setter);
			A_1.Add(style);
			Style style2 = new Style();
			style2.Selector = Selectors.OfType((Selector)null, typeof(ToggleButton)).Class(":unchecked").Template().OfType(typeof(ContentPresenter));
			style2.Add(new Setter
			{
				Property = ContentPresenter.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(16777215U)
			});
			Setter setter2 = new Setter();
			setter2.Property = Visual.RenderTransformProperty;
			ScaleTransform scaleTransform2 = new ScaleTransform();
			scaleTransform2.SetValue<double>(ScaleTransform.ScaleXProperty, 1.0, BindingPriority.Template);
			scaleTransform2.SetValue<double>(ScaleTransform.ScaleYProperty, 1.0, BindingPriority.Template);
			setter2.Value = scaleTransform2;
			style2.Add(setter2);
			A_1.Add(style2);
			Style style3 = new Style();
			style3.Selector = Selectors.OfType((Selector)null, typeof(ToggleButton)).Class(":checked").Template().OfType(typeof(ContentPresenter));
			style3.Add(new Setter
			{
				Property = ContentPresenter.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(16777215U)
			});
			Setter setter3 = new Setter();
			setter3.Property = Visual.RenderTransformProperty;
			ScaleTransform scaleTransform3 = new ScaleTransform();
			scaleTransform3.SetValue<double>(ScaleTransform.ScaleXProperty, 1.0, BindingPriority.Template);
			scaleTransform3.SetValue<double>(ScaleTransform.ScaleYProperty, 1.0, BindingPriority.Template);
			setter3.Value = scaleTransform3;
			style3.Add(setter3);
			A_1.Add(style3);
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x06000637 RID: 1591 RVA: 0x0003D954 File Offset: 0x0003BB54
		public static Styles axaml(IServiceProvider A_0)
		{
			Styles styles = new Styles();
			!AvaloniaResources.Populate:/Styles/ToggleButtonStyles.axaml(A_0, styles);
			return styles;
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x0003D970 File Offset: 0x0003BB70
		public static void axaml(IServiceProvider A_0, Styles A_1)
		{
			XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
			{
				(object)!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.Singleton
			}, "avares://Exodus/Styles/TextBoxStyles.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			Style style = new Style();
			style.Selector = Selectors.OfType((Selector)null, typeof(TextBox)).Template().OfType(typeof(Border)).Name("PART_BorderElement");
			style.Add(new Setter
			{
				Property = Border.BackgroundProperty,
				Value = new TemplateBinding(Border.BackgroundProperty).ProvideValue()
			});
			style.Add(new Setter
			{
				Property = Border.BorderBrushProperty,
				Value = new TemplateBinding(Border.BorderBrushProperty).ProvideValue()
			});
			style.Add(new Setter
			{
				Property = Border.CornerRadiusProperty,
				Value = new TemplateBinding(Border.CornerRadiusProperty).ProvideValue()
			});
			A_1.Add(style);
			Style style2 = new Style();
			style2.Selector = Selectors.OfType((Selector)null, typeof(TextBox)).Class(":pointerover").Template().OfType(typeof(Border)).Name("PART_BorderElement");
			style2.Add(new Setter
			{
				Property = Border.BackgroundProperty,
				Value = new TemplateBinding(Border.BackgroundProperty).ProvideValue()
			});
			style2.Add(new Setter
			{
				Property = Border.BorderBrushProperty,
				Value = new TemplateBinding(Border.BorderBrushProperty).ProvideValue()
			});
			style2.Add(new Setter
			{
				Property = Border.CornerRadiusProperty,
				Value = new TemplateBinding(Border.CornerRadiusProperty).ProvideValue()
			});
			A_1.Add(style2);
			Style style3 = new Style();
			style3.Selector = Selectors.OfType((Selector)null, typeof(TextBox)).Class(":focus").Template().OfType(typeof(Border)).Name("PART_BorderElement");
			style3.Add(new Setter
			{
				Property = Border.BackgroundProperty,
				Value = new TemplateBinding(Border.BackgroundProperty).ProvideValue()
			});
			style3.Add(new Setter
			{
				Property = Border.BorderBrushProperty,
				Value = new TemplateBinding(Border.BorderBrushProperty).ProvideValue()
			});
			style3.Add(new Setter
			{
				Property = Border.CornerRadiusProperty,
				Value = new TemplateBinding(Border.CornerRadiusProperty).ProvideValue()
			});
			A_1.Add(style3);
			Style style4 = new Style();
			style4.Selector = Selectors.Or(new List<Selector>
			{
				Selectors.OfType((Selector)null, typeof(TextBox)).Template().OfType(typeof(TextBlock)).Name("PART_Watermark"),
				Selectors.OfType((Selector)null, typeof(TextBox)).Template().OfType(typeof(TextBlock)).Name("PART_FloatingWatermark")
			});
			style4.Add(new Setter
			{
				Property = TextBlock.ForegroundProperty,
				Value = new TemplateBinding(TextBlock.ForegroundProperty).ProvideValue()
			});
			A_1.Add(style4);
			Style style5 = new Style();
			style5.Selector = Selectors.Or(new List<Selector>
			{
				Selectors.OfType((Selector)null, typeof(TextBox)).Class(":focus").Template().OfType(typeof(TextBlock)).Name("PART_Watermark"),
				Selectors.OfType((Selector)null, typeof(TextBox)).Class(":focus").Template().OfType(typeof(TextBlock)).Name("PART_FloatingWatermark"),
				Selectors.OfType((Selector)null, typeof(TextBox)).Class(":pointerover").Template().OfType(typeof(TextBlock)).Name("PART_Watermark"),
				Selectors.OfType((Selector)null, typeof(TextBox)).Class(":pointerover").Template().OfType(typeof(TextBlock)).Name("PART_FloatingWatermark")
			});
			style5.Add(new Setter
			{
				Property = TextBlock.ForegroundProperty,
				Value = new TemplateBinding(TextBlock.ForegroundProperty).ProvideValue()
			});
			A_1.Add(style5);
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x0003DE24 File Offset: 0x0003C024
		public static Styles axaml(IServiceProvider A_0)
		{
			Styles styles = new Styles();
			!AvaloniaResources.Populate:/Styles/TextBoxStyles.axaml(A_0, styles);
			return styles;
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x0003DE40 File Offset: 0x0003C040
		public static void axaml(IServiceProvider A_0, ResourceDictionary A_1)
		{
			XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
			{
				(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
			}, "avares://Exodus/Resources/FontResources.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			A_1.AddDeferred("RobotoRegular", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_38.Build), context));
			A_1.AddDeferred("RobotoMedium", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_39.Build), context));
			A_1.AddDeferred("RobotoThin", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_40.Build), context));
			A_1.AddDeferred("RobotoLight", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_41.Build), context));
			A_1.AddDeferred("RobotoLightItalic", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_42.Build), context));
			A_1.AddDeferred("RobotoBold", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_43.Build), context));
			A_1.AddDeferred("RobotoBlack", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_44.Build), context));
			A_1.AddDeferred("RobotoCondensedLight", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_45.Build), context));
			A_1.AddDeferred("RobotoCondensedRegular", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_46.Build), context));
			A_1.AddDeferred("RobotoCondensedBold", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_47.Build), context));
			A_1.AddDeferred("RobotoCondensedMedium", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_48.Build), context));
			A_1.AddDeferred("RobotoCondensedSemiBold", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_49.Build), context));
			A_1.AddDeferred("Nunito", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_50.Build), context));
			A_1.AddDeferred("NunitoItalic", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_51.Build), context));
			A_1.AddDeferred("Icomoon", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_52.Build), context));
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x0600063B RID: 1595 RVA: 0x0003E054 File Offset: 0x0003C254
		public static ResourceDictionary axaml(IServiceProvider A_0)
		{
			ResourceDictionary resourceDictionary = new ResourceDictionary();
			!AvaloniaResources.Populate:/Resources/FontResources.axaml(A_0, resourceDictionary);
			return resourceDictionary;
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x0003E070 File Offset: 0x0003C270
		public static void axaml(IServiceProvider A_0, ResourceDictionary A_1)
		{
			XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
			{
				(object)!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.Singleton
			}, "avares://Exodus/Resources/SmoothScrollThemeResources.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			context.PushParent(A_1);
			A_1.AddDeferred(typeof(ScrollViewer), XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_53.Build), context));
			A_1.AddDeferred("ScrollViewerWithMouse", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_55.Build), context));
			A_1.AddDeferred("ScrollViewerWithSwapDirection", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_56.Build), context));
			context.PopParent();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x0003E13C File Offset: 0x0003C33C
		public static ResourceDictionary axaml(IServiceProvider A_0)
		{
			ResourceDictionary resourceDictionary = new ResourceDictionary();
			!AvaloniaResources.Populate:/Resources/SmoothScrollThemeResources.axaml(A_0, resourceDictionary);
			return resourceDictionary;
		}

		// Token: 0x0600063E RID: 1598 RVA: 0x0003E158 File Offset: 0x0003C358
		public static void axaml(IServiceProvider A_0, ResourceDictionary A_1)
		{
			XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
			{
				(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
			}, "avares://Exodus/Resources/CoinBanners.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			context.PushParent(A_1);
			A_1.AddDeferred("Banner0", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_24.Build), context));
			A_1.AddDeferred("Banner1", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_26.Build), context));
			A_1.AddDeferred("Banner4", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_28.Build), context));
			A_1.AddDeferred("Banner10", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_30.Build), context));
			A_1.AddDeferred("Banner11", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_32.Build), context));
			A_1.AddDeferred("Banner13", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_34.Build), context));
			A_1.AddDeferred("DefaultBanner", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_36.Build), context));
			context.PopParent();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x0600063F RID: 1599 RVA: 0x0003E290 File Offset: 0x0003C490
		public static ResourceDictionary axaml(IServiceProvider A_0)
		{
			ResourceDictionary resourceDictionary = new ResourceDictionary();
			!AvaloniaResources.Populate:/Resources/CoinBanners.axaml(A_0, resourceDictionary);
			return resourceDictionary;
		}

		// Token: 0x0200009B RID: 155
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x06000640 RID: 1600 RVA: 0x0003E2AC File Offset: 0x0003C4AC
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x06000641 RID: 1601 RVA: 0x0003E2CC File Offset: 0x0003C4CC
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(5)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"local",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Exodus", null)
						}
					},
					{
						"scroll",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("CompositionScroll", null)
						}
					},
					{
						"converters",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaceInfo("Exodus.Helpers.Converters", "Exodus")
						}
					}
				};
			}

			// Token: 0x17000110 RID: 272
			// (get) Token: 0x06000642 RID: 1602 RVA: 0x0003E5D0 File Offset: 0x0003C7D0
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/App.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x06000644 RID: 1604 RVA: 0x0003E610 File Offset: 0x0003C810
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/App.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/App.axaml();
			}

			// Token: 0x040002E5 RID: 741
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002E6 RID: 742
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x0200009C RID: 156
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x06000645 RID: 1605 RVA: 0x0003E628 File Offset: 0x0003C828
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x06000646 RID: 1606 RVA: 0x0003E648 File Offset: 0x0003C848
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(2)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					}
				};
			}

			// Token: 0x17000111 RID: 273
			// (get) Token: 0x06000647 RID: 1607 RVA: 0x0003E8EC File Offset: 0x0003CAEC
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x06000649 RID: 1609 RVA: 0x0003E92C File Offset: 0x0003CB2C
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml();
			}

			// Token: 0x040002E7 RID: 743
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002E8 RID: 744
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x0200009D RID: 157
		private class XamlClosure_2
		{
			// Token: 0x0600064A RID: 1610 RVA: 0x0003E944 File Offset: 0x0003CB44
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M11.864 0a.5.5 0 01.474.343l.021.09.357 2.622.04.012c.243.074.483.16.719.258l.351.157.368.188 2.11-1.604a.5.5 0 01.508-.058l.078.044.071.06 1.926 1.927a.5.5 0 01.093.578l-.05.078-1.603 2.11.02.034c.12.224.229.454.327.69l.138.36.128.393 2.628.359a.5.5 0 01.4.317l.024.087.008.091v2.728a.5.5 0 01-.343.474l-.09.021-2.624.356-.01.038a7.68 7.68 0 01-.258.72l-.157.35-.189.369 1.605 2.11a.5.5 0 01.058.507l-.044.078-.059.071-1.928 1.928a.5.5 0 01-.578.094l-.078-.05-2.111-1.603-.033.02a7.68 7.68 0 01-.69.327l-.36.138-.394.128-.358 2.628a.5.5 0 01-.317.4l-.087.024-.091.008H9.136a.5.5 0 01-.474-.343l-.021-.09-.357-2.624-.037-.01a7.68 7.68 0 01-.72-.258l-.35-.157-.37-.189-2.109 1.605a.5.5 0 01-.507.058l-.078-.044-.071-.059-1.928-1.928a.5.5 0 01-.094-.578l.05-.078 1.602-2.111-.018-.033a7.68 7.68 0 01-.328-.69l-.138-.36-.129-.394-2.627-.358a.5.5 0 01-.4-.317l-.024-.087L0 11.864V9.136a.5.5 0 01.343-.474l.09-.021 2.622-.358.012-.039a7.68 7.68 0 01.258-.719l.157-.351.188-.369-1.604-2.11a.5.5 0 01-.058-.507l.044-.078.059-.07L4.039 2.11a.5.5 0 01.578-.093l.079.049 2.108 1.605.035-.018c.224-.12.454-.23.69-.328l.36-.138.393-.129.359-2.627a.5.5 0 01.317-.4l.087-.024L9.136 0h2.728zm-.437 1H9.572l-.343 2.52a.5.5 0 01-.21.344l-.073.041-.079.03-.332.091a6.706 6.706 0 00-1.511.673.5.5 0 01-.488.016l-.073-.046-2.026-1.542-1.311 1.311 1.54 2.025a.5.5 0 01.098.365l-.021.095-.04.09-.17.3a6.706 6.706 0 00-.598 1.542.5.5 0 01-.333.355l-.084.019L1 9.572v1.855l2.52.344a.5.5 0 01.344.21l.041.073.03.079.091.332c.161.53.387 1.037.673 1.511a.5.5 0 01.016.488l-.046.073-1.54 2.025 1.311 1.31 2.026-1.538a.5.5 0 01.365-.098l.094.021.09.04.3.17a6.706 6.706 0 001.543.598.5.5 0 01.355.333l.019.085.34 2.517h1.855l.344-2.52a.5.5 0 01.21-.344l.073-.041.079-.03.332-.091a6.706 6.706 0 001.511-.673.5.5 0 01.488-.016l.073.046 2.025 1.539 1.31-1.311-1.538-2.025a.5.5 0 01-.098-.365l.021-.094.04-.09.17-.3a6.706 6.706 0 00.598-1.543.5.5 0 01.333-.355l.085-.019L20 11.427V9.572l-2.52-.343a.5.5 0 01-.344-.21l-.041-.073-.03-.079-.091-.332a6.706 6.706 0 00-.673-1.511.5.5 0 01-.016-.488l.046-.073 1.539-2.026-1.308-1.311-2.025 1.54a.5.5 0 01-.365.098l-.095-.021-.09-.04-.3-.17a6.706 6.706 0 00-1.542-.598.5.5 0 01-.355-.333l-.019-.084L11.427 1zM10.5 7a3.5 3.5 0 110 7 3.5 3.5 0 010-7zm0 1a2.5 2.5 0 100 5 2.5 2.5 0 000-5z");
			}
		}

		// Token: 0x0200009E RID: 158
		private class XamlClosure_3
		{
			// Token: 0x0600064B RID: 1611 RVA: 0x0003E9B0 File Offset: 0x0003CBB0
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M11 1c5.523 0 10 4.477 10 10s-4.477 10-10 10c-4.072 0-7.69-2.456-9.232-6.15a.5.5 0 01.923-.385 9 9 0 10.037-7.016.5.5 0 11-.92-.395A10.001 10.001 0 0111 1z M10.5 6.5a.5.5 0 01.492.41L11 7v4.709l3.248 1.857a.5.5 0 01.224.6l-.038.082a.5.5 0 01-.6.224l-.082-.038-3.5-2a.5.5 0 01-.244-.346L10 12V7a.5.5 0 01.5-.5zM.287 3.263a.5.5 0 01.961-.261l.024.087.78 4.432 4.433-.782a.5.5 0 01.555.319l.024.087a.5.5 0 01-.319.555l-.087.024-4.924.868a.5.5 0 01-.555-.318l-.024-.087-.868-4.924z");
			}
		}

		// Token: 0x0200009F RID: 159
		private class XamlClosure_4
		{
			// Token: 0x0600064C RID: 1612 RVA: 0x0003EA1C File Offset: 0x0003CC1C
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M15.986 1.545a10.554 10.554 0 013.469 3.469.469.469 0 01-.058.113l-.058.07-3.606 3.606a5.524 5.524 0 010 3.394l3.606 3.606a.498.498 0 01.116.182 10.556 10.556 0 01-3.468 3.469.434.434 0 01-.114-.057l-.07-.058-3.605-3.606a5.524 5.524 0 01-3.395 0l-3.606 3.606a.498.498 0 01-.183.116 10.568 10.568 0 01-3.468-3.468.434.434 0 01.057-.114l.058-.07 3.606-3.605a5.524 5.524 0 010-3.396L1.661 5.197a.498.498 0 01-.116-.183 10.568 10.568 0 013.469-3.469c.04.014.078.034.113.058l.07.058 3.606 3.606a5.524 5.524 0 013.395 0l3.605-3.606a.499.499 0 01.146-.101zm-.683 11.637a5.504 5.504 0 01-2.12 2.121l2.974 2.975 2.121-2.121-2.975-2.975zm-9.606 0l-2.975 2.975 2.121 2.121 2.975-2.975a5.504 5.504 0 01-1.207-.914 5.504 5.504 0 01-.914-1.206zm1.621-5.864a4.5 4.5 0 106.364 6.364 4.5 4.5 0 00-6.364-6.364zm8.838-4.595l-2.973 2.974c.432.242.839.546 1.206.914.368.368.673.775.914 1.207l2.974-2.974-2.12-2.121zM4.843 2.722L2.722 4.843l2.975 2.974c.242-.432.546-.839.914-1.206a5.504 5.504 0 011.207-.914L4.843 2.722z");
			}
		}

		// Token: 0x020000A0 RID: 160
		private class XamlClosure_5
		{
			// Token: 0x0600064D RID: 1613 RVA: 0x0003EA88 File Offset: 0x0003CC88
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M3.692,14.15 A1.846,-1.846 0 1 1 0,14.15 A1.846,-1.846 0 0 1 3.692,14.15 z M3.692,8 A1.846,-1.846 0 1 1 0,8 A1.846,-1.846 0 0 1 3.692,8 z M3.692,1.846 A1.846,-1.846 0 1 1 0,1.846 A1.846,-1.846 0 0 1 3.692,1.846 z");
			}
		}

		// Token: 0x020000A1 RID: 161
		private class XamlClosure_6
		{
			// Token: 0x0600064E RID: 1614 RVA: 0x0003EAF4 File Offset: 0x0003CCF4
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M12.45,15.24 A0.8017,-0.8017 0 0 1 12.08,15.15 L7.988,13.01 L3.899,15.15 A0.8017,-0.8017 0 0 1 2.737,14.3 L3.538,9.784 L0.2354,6.577 A0.8017,-0.8017 0 0 1 0.035,5.776 A0.8017,-0.8017 0 0 1 0.6844,5.23 L5.254,4.565 L7.266,0.4523 A0.8017,-0.8017 0 0 1 8.71,0.4523 L10.75,4.557 L15.32,5.222 A0.8017,-0.8017 0 0 1 15.97,5.768 A0.8017,-0.8017 0 0 1 15.76,6.569 L12.46,9.776 L13.26,14.29 A0.8017,-0.8017 0 0 1 12.94,15.09 A0.8017,-0.8017 0 0 1 12.45,15.24 z M7.988,11.31 A0.7376,-0.7376 0 0 1 8.357,11.4 L11.38,13 L10.8,9.624 A0.8017,-0.8017 0 0 1 11.03,8.91 L13.44,6.561 L10.07,6.064 A0.8017,-0.8017 0 0 1 9.503,5.615 L7.988,2.609 L6.473,5.615 A0.8017,-0.8017 0 0 1 5.871,6.048 L2.504,6.545 L4.909,8.894 A0.8017,-0.8017 0 0 1 5.142,9.608 L4.565,12.94 L7.587,11.34 A0.7376,-0.7376 0 0 1 7.988,11.31 z");
			}
		}

		// Token: 0x020000A2 RID: 162
		private class XamlClosure_7
		{
			// Token: 0x0600064F RID: 1615 RVA: 0x0003EB60 File Offset: 0x0003CD60
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M28.297 7.256l-4.73-5.126c-.448-.485-.448-1.268 0-1.766.448-.485 1.175-.485 1.623 0l6.493 7.04c.274.3.36.71.297 1.096.063.386-.023.796-.297 1.095l-6.493 7.04c-.448.486-1.175.486-1.624 0-.447-.484-.447-1.28 0-1.765l4.73-5.126H8.15C7.514 9.744 7 9.184 7 8.5c0-.684.514-1.244 1.148-1.244h20.15zM3.703 22.256l4.73-5.126c.448-.485.448-1.268 0-1.766-.448-.485-1.175-.485-1.623 0l-6.493 7.04c-.274.3-.36.71-.297 1.096-.063.386.023.796.297 1.095l6.493 7.04c.448.486 1.175.486 1.624 0 .447-.484.447-1.28 0-1.765l-4.73-5.126H23.85c.634 0 1.148-.56 1.148-1.244 0-.684-.514-1.244-1.148-1.244H3.702z");
			}
		}

		// Token: 0x020000A3 RID: 163
		private class XamlClosure_8
		{
			// Token: 0x06000650 RID: 1616 RVA: 0x0003EBCC File Offset: 0x0003CDCC
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M.966 17.051c-.244 0-.441-.252-.441-.562 0-.31.197-.563.441-.563h14.118c.243 0 .44.252.44.563 0 .31-.197.562-.44.562H.966zM3.164 11.013l9.915-9.915a.562.562 0 1 1 .796.796L3.96 11.809h5.767a.562.562 0 1 1 0 1.125H2.039V5.246a.562.562 0 1 1 1.125 0v5.767z");
			}
		}

		// Token: 0x020000A4 RID: 164
		private class XamlClosure_9
		{
			// Token: 0x06000651 RID: 1617 RVA: 0x0003EC38 File Offset: 0x0003CE38
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M14.13,0 L16,1.875 L8,9.875 L0,1.875 L1.875,0 L8,6.125 z");
			}
		}

		// Token: 0x020000A5 RID: 165
		private class XamlClosure_10
		{
			// Token: 0x06000652 RID: 1618 RVA: 0x0003ECA4 File Offset: 0x0003CEA4
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M8,0 L16,8 L14.13,9.875 L8,3.75 L1.875,9.875 L0,8 z");
			}
		}

		// Token: 0x020000A6 RID: 166
		private class XamlClosure_11
		{
			// Token: 0x06000653 RID: 1619 RVA: 0x0003ED10 File Offset: 0x0003CF10
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M4.8,4.8 L4.8,1.6 C4.8,0.72 5.52,0 6.4,0 L14.4,0 A1.6,1.6 0 0 1 16,1.6 L16,9.6 A1.6,1.6 0 0 1 14.4,11.2 L11.2,11.2 L11.2,14.4 A1.6,1.6 0 0 1 9.6,16 L1.6,16 A1.6,1.6 0 0 1 0,14.4 L0,6.4 C0,5.52 0.72,4.8 1.6,4.8 L4.8,4.8 z M6.4,4.8 L9.6,4.8 A1.6,1.6 0 0 1 11.2,6.4 L11.2,9.6 L14.4,9.6 L14.4,1.6 L6.4,1.6 L6.4,4.8 z M1.6,6.4 L1.6,14.4 L9.6,14.4 L9.6,6.4 L1.6,6.4 z");
			}
		}

		// Token: 0x020000A7 RID: 167
		private class XamlClosure_12
		{
			// Token: 0x06000654 RID: 1620 RVA: 0x0003ED7C File Offset: 0x0003CF7C
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("m22.389 2h-14.285a.617.617 0 0 0 -.432.176.596.596 0 0 0 -.179.425v4.17h-5.882a.616.616 0 0 0 -.432.175.596.596 0 0 0 -.179.425v14.029c0 .16.064.312.179.425s.27.176.432.176h14.285a.617.617 0 0 0 .432-.176.596.596 0 0 0 .179-.425v-4.17h5.882a.616.616 0 0 0 .432-.175.596.596 0 0 0 .179-.425v-14.03a.596.596 0 0 0 -.179-.425.617.617 0 0 0 -.432-.176zm-7.104 18.798h-13.063v-12.826h13.063zm6.493-4.77h-5.271v-8.657a.596.596 0 0 0 -.179-.425.616.616 0 0 0 -.432-.176h-7.18v-3.568h13.062z");
			}
		}

		// Token: 0x020000A8 RID: 168
		private class XamlClosure_13
		{
			// Token: 0x06000655 RID: 1621 RVA: 0x0003EDE8 File Offset: 0x0003CFE8
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M16,0 L15,0.01 L8,7 L1,0.01 L0,0 L0,1 L7,8 L0,15 L0,16 L1,16 L8,9 L15,16 L16,16 L16,15 L9,8 L16,1 L16,0 z");
			}
		}

		// Token: 0x020000A9 RID: 169
		private class XamlClosure_14
		{
			// Token: 0x06000656 RID: 1622 RVA: 0x0003EE54 File Offset: 0x0003D054
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M8,1.831E-007 C6.9,1.831E-007 6,0.9 6,2 C6,3.1 6.9,4 8,4 C9.1,4 10,3.1 10,2 C10,0.9 9.1,1.831E-007 8,1.831E-007 z M14,1.831E-007 C12.9,1.831E-007 12,0.9 12,2 C12,3.1 12.9,4 14,4 C15.1,4 16,3.1 16,2 C16,0.9 15.1,1.831E-007 14,1.831E-007 z M2,1.831E-007 C0.9,1.831E-007 -1.745E-007,0.9 -1.745E-007,2 C-1.745E-007,3.1 0.9,4 2,4 C3.1,4 4,3.1 4,2 C4,0.9 3.1,1.831E-007 2,1.831E-007 z");
			}
		}

		// Token: 0x020000AA RID: 170
		private class XamlClosure_15
		{
			// Token: 0x06000657 RID: 1623 RVA: 0x0003EEC0 File Offset: 0x0003D0C0
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M8,16 C3.582,16 7.324E-007,12.42 7.324E-007,8 C7.324E-007,3.582 3.582,0 8,0 C12.42,0 16,3.582 16,8 C16,10.12 15.16,12.16 13.66,13.66 C12.16,15.16 10.12,16 8,16 z");
			}
		}

		// Token: 0x020000AB RID: 171
		private class XamlClosure_16
		{
			// Token: 0x06000658 RID: 1624 RVA: 0x0003EF2C File Offset: 0x0003D12C
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M8 0L4 4 0 0z");
			}
		}

		// Token: 0x020000AC RID: 172
		private class XamlClosure_17
		{
			// Token: 0x06000659 RID: 1625 RVA: 0x0003EF98 File Offset: 0x0003D198
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M11.658 9.235c-.003.015-.007.029-.007.07v4.01l.62.11c.214 0 .387.202.387.45 0 .247-.173.448-.387.448H9.024c-.213 0-.386-.201-.386-.449 0-.247.173-.449.386-.449l.622-.11v-3.008l-.622-.116c-.213 0-.386-.201-.386-.449s.173-.45.386-.45h2.52c.078 0 .103-.031.114-.057zm-1.01-2.942l.02.004h.983v.943c0 .022.012.04.012.061 0 .022-.011.04-.012.061v.94h-.97c-.012.001-.022.007-.033.007l-.033-.007h-.97v-.94c-.001-.022-.012-.039-.012-.061 0-.021.01-.04.013-.06v-.944h.982c.007 0 .013-.004.02-.004z");
			}
		}

		// Token: 0x020000AD RID: 173
		private class XamlClosure_18
		{
			// Token: 0x0600065A RID: 1626 RVA: 0x0003F004 File Offset: 0x0003D204
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M19.324 12.69c-.408-.406-1.07-.406-1.477 0l-5.17 5.172c-.41.41-.41 1.07 0 1.48.407.406 1.068.406 1.476 0l5.17-5.172c.41-.41.41-1.07 0-1.48zM30.776 2.7l-1.478-1.476c-1.632-1.632-4.278-1.632-5.91 0l-7.39 7.388c-1.09 1.09-1.434 2.632-1.066 4.023L24.865 2.7c.816-.814 2.14-.814 2.956 0L29.3 4.18c.816.816.816 2.138 0 2.954l-9.933 9.934c1.39.367 2.932.023 4.023-1.07l7.388-7.386c1.632-1.632 1.632-4.28 0-5.91zM7.134 29.298c-.816.817-2.14.817-2.956 0L2.702 27.82c-.816-.816-.816-2.14 0-2.955l9.933-9.933c-1.39-.368-2.932-.023-4.023 1.067l-7.388 7.388c-1.632 1.632-1.632 4.278 0 5.91l1.478 1.478c1.63 1.632 4.277 1.632 5.91 0L16 23.388c1.09-1.09 1.436-2.632 1.068-4.023l-9.934 9.932z");
			}
		}

		// Token: 0x020000AE RID: 174
		private class XamlClosure_19
		{
			// Token: 0x0600065B RID: 1627 RVA: 0x0003F070 File Offset: 0x0003D270
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M1 20h10c.552 0 1 .45 1 1s-.448 1-1 1H3.365c2.25 4.73 7.053 8 12.635 8 7.05 0 12.868-5.22 13.84-12h2.023C30.875 25.89 24.158 32 16 32c-6.028 0-11.272-3.34-14-8.26V31c0 .55-.448 1-1 1s-1-.45-1-1V21c0-1.06 1-1 1-1zm30-8H21c-.552 0-1-.45-1-1s.448-1 1-1h7.64C26.395 5.27 21.584 2 16 2 8.95 2 3.132 7.22 2.16 14H.138C1.125 6.11 7.842 0 16 0c6.028 0 11.272 3.34 14 8.26V1c0-.55.448-1 1-1s1 .45 1 1v10c0 .97-1 1-1 1z");
			}
		}

		// Token: 0x020000AF RID: 175
		private class XamlClosure_20
		{
			// Token: 0x0600065C RID: 1628 RVA: 0x0003F0DC File Offset: 0x0003D2DC
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.121l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.458c.536-.194 1.006.128.832.943z");
			}
		}

		// Token: 0x020000B0 RID: 176
		private class XamlClosure_21
		{
			// Token: 0x0600065D RID: 1629 RVA: 0x0003F148 File Offset: 0x0003D348
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm7.93 9h-3.18a15.7 15.7 0 0 0-1.38-5.38A8.04 8.04 0 0 1 19.93 11zM12 4.07a13.74 13.74 0 0 1 1.92 6.93H10.08A13.74 13.74 0 0 1 12 4.07zM4.07 13h3.18a15.7 15.7 0 0 0 1.38 5.38A8.04 8.04 0 0 1 4.07 13zm3.18-2H4.07a8.04 8.04 0 0 1 4.56-5.38A15.7 15.7 0 0 0 7.25 11zM12 19.93a13.74 13.74 0 0 1-1.92-6.93h3.84A13.74 13.74 0 0 1 12 19.93zm2.63-8.93H9.37a11.75 11.75 0 0 1 0-2h5.26a11.75 11.75 0 0 1 0 2zm.74 7.38a15.7 15.7 0 0 0 1.38-5.38h3.18a8.04 8.04 0 0 1-4.56 5.38z");
			}
		}

		// Token: 0x020000B1 RID: 177
		private class XamlClosure_22
		{
			// Token: 0x0600065E RID: 1630 RVA: 0x0003F1B4 File Offset: 0x0003D3B4
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<Styles> context = new XamlIlContext.Context<Styles>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Assets/Resources/Icons/Icons.axaml.Singleton
				}, "avares://Exodus/Assets/Resources/Icons/Icons.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (Styles)obj;
					}
				}
				return Geometry.Parse("M19 19H5V5h7V3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z");
			}
		}

		// Token: 0x020000B2 RID: 178
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x0600065F RID: 1631 RVA: 0x0003F220 File Offset: 0x0003D420
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x06000660 RID: 1632 RVA: 0x0003F240 File Offset: 0x0003D440
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(4)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					}
				};
			}

			// Token: 0x17000112 RID: 274
			// (get) Token: 0x06000661 RID: 1633 RVA: 0x0003F504 File Offset: 0x0003D704
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x06000663 RID: 1635 RVA: 0x0003F544 File Offset: 0x0003D744
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml();
			}

			// Token: 0x040002E9 RID: 745
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002EA RID: 746
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000B3 RID: 179
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x06000664 RID: 1636 RVA: 0x0003F55C File Offset: 0x0003D75C
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x06000665 RID: 1637 RVA: 0x0003F57C File Offset: 0x0003D77C
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(2)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					}
				};
			}

			// Token: 0x17000113 RID: 275
			// (get) Token: 0x06000666 RID: 1638 RVA: 0x0003F820 File Offset: 0x0003DA20
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x06000668 RID: 1640 RVA: 0x0003F860 File Offset: 0x0003DA60
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml();
			}

			// Token: 0x040002EB RID: 747
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002EC RID: 748
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000B4 RID: 180
		private class XamlClosure_24
		{
			// Token: 0x06000669 RID: 1641 RVA: 0x0003F878 File Offset: 0x0003DA78
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
				}, "avares://Exodus/Resources/CoinBanners.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				DataTemplate dataTemplate;
				object result = dataTemplate = new DataTemplate();
				context.PushParent(dataTemplate);
				dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_24.XamlClosure_25.Build), context);
				context.PopParent();
				return result;
			}

			// Token: 0x020000B5 RID: 181
			private class XamlClosure_25
			{
				// Token: 0x0600066A RID: 1642 RVA: 0x0003F908 File Offset: 0x0003DB08
				public static object Build(IServiceProvider A_0)
				{
					XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
					{
						(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
					}, "avares://Exodus/Resources/CoinBanners.axaml");
					if (A_0 != null)
					{
						object obj = A_0.GetService(typeof(IRootObjectProvider));
						if (obj != null)
						{
							obj = ((IRootObjectProvider)obj).RootObject;
							context.RootObject = (ResourceDictionary)obj;
						}
					}
					context.IntermediateRoot = new UserControl();
					object intermediateRoot = context.IntermediateRoot;
					((ISupportInitialize)intermediateRoot).BeginInit();
					UserControl userControl = intermediateRoot;
					context.PushParent(userControl);
					UserControl userControl2 = userControl;
					userControl2.Height = 84.0;
					Image image2;
					Image image = image2 = new Image();
					((ISupportInitialize)image).BeginInit();
					userControl2.Content = image;
					Image image3;
					ISupportInitialize supportInitialize = image3 = image2;
					context.PushParent(image3);
					Image image4 = image3;
					image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/bitcoin.png");
					image4.Width = 84.0;
					image4.Stretch = Stretch.Uniform;
					RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
					image4.HorizontalAlignment = HorizontalAlignment.Center;
					image4.VerticalAlignment = VerticalAlignment.Center;
					context.PopParent();
					supportInitialize.EndInit();
					context.PopParent();
					((ISupportInitialize)intermediateRoot).EndInit();
					return intermediateRoot;
				}
			}
		}

		// Token: 0x020000B6 RID: 182
		private class XamlClosure_26
		{
			// Token: 0x0600066B RID: 1643 RVA: 0x0003FA1C File Offset: 0x0003DC1C
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
				}, "avares://Exodus/Resources/CoinBanners.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				DataTemplate dataTemplate;
				object result = dataTemplate = new DataTemplate();
				context.PushParent(dataTemplate);
				dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_26.XamlClosure_27.Build), context);
				context.PopParent();
				return result;
			}

			// Token: 0x020000B7 RID: 183
			private class XamlClosure_27
			{
				// Token: 0x0600066C RID: 1644 RVA: 0x0003FAAC File Offset: 0x0003DCAC
				public static object Build(IServiceProvider A_0)
				{
					XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
					{
						(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
					}, "avares://Exodus/Resources/CoinBanners.axaml");
					if (A_0 != null)
					{
						object obj = A_0.GetService(typeof(IRootObjectProvider));
						if (obj != null)
						{
							obj = ((IRootObjectProvider)obj).RootObject;
							context.RootObject = (ResourceDictionary)obj;
						}
					}
					context.IntermediateRoot = new UserControl();
					object intermediateRoot = context.IntermediateRoot;
					((ISupportInitialize)intermediateRoot).BeginInit();
					UserControl userControl = intermediateRoot;
					context.PushParent(userControl);
					UserControl userControl2 = userControl;
					userControl2.Height = 104.0;
					StackPanel stackPanel2;
					StackPanel stackPanel = stackPanel2 = new StackPanel();
					((ISupportInitialize)stackPanel).BeginInit();
					userControl2.Content = stackPanel;
					StackPanel stackPanel3;
					ISupportInitialize supportInitialize = stackPanel3 = stackPanel2;
					context.PushParent(stackPanel3);
					StackPanel stackPanel4 = stackPanel3;
					AvaloniaList<Control> children = stackPanel4.Children;
					Image image2;
					Image image = image2 = new Image();
					((ISupportInitialize)image).BeginInit();
					children.Add(image);
					Image image3;
					ISupportInitialize supportInitialize2 = image3 = image2;
					context.PushParent(image3);
					Image image4 = image3;
					image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/ethereum_1.png");
					image4.Width = 84.0;
					image4.Stretch = Stretch.Uniform;
					RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
					image4.HorizontalAlignment = HorizontalAlignment.Center;
					image4.ZIndex = 3;
					image4.VerticalAlignment = VerticalAlignment.Center;
					context.PopParent();
					supportInitialize2.EndInit();
					AvaloniaList<Control> children2 = stackPanel4.Children;
					Image image6;
					Image image5 = image6 = new Image();
					((ISupportInitialize)image5).BeginInit();
					children2.Add(image5);
					ISupportInitialize supportInitialize3 = image3 = image6;
					context.PushParent(image3);
					Image image7 = image3;
					image7.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/ethereum_2.png");
					image7.Width = 73.0;
					image7.Stretch = Stretch.Uniform;
					image7.Opacity = 0.5;
					image7.Margin = new Thickness(0.0, -63.0, 0.0, 0.0);
					RenderOptions.SetBitmapInterpolationMode(image7, BitmapInterpolationMode.HighQuality);
					image7.HorizontalAlignment = HorizontalAlignment.Center;
					image7.ZIndex = 2;
					image7.VerticalAlignment = VerticalAlignment.Center;
					context.PopParent();
					supportInitialize3.EndInit();
					AvaloniaList<Control> children3 = stackPanel4.Children;
					Image image9;
					Image image8 = image9 = new Image();
					((ISupportInitialize)image8).BeginInit();
					children3.Add(image8);
					ISupportInitialize supportInitialize4 = image3 = image9;
					context.PushParent(image3);
					Image image10 = image3;
					image10.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/ethereum_3.png");
					image10.Width = 60.0;
					image10.Stretch = Stretch.Uniform;
					image10.Opacity = 0.25;
					image10.Margin = new Thickness(0.0, -50.0, 0.0, 0.0);
					RenderOptions.SetBitmapInterpolationMode(image10, BitmapInterpolationMode.HighQuality);
					image10.HorizontalAlignment = HorizontalAlignment.Center;
					image10.ZIndex = 1;
					image10.VerticalAlignment = VerticalAlignment.Center;
					context.PopParent();
					supportInitialize4.EndInit();
					context.PopParent();
					supportInitialize.EndInit();
					context.PopParent();
					((ISupportInitialize)intermediateRoot).EndInit();
					return intermediateRoot;
				}
			}
		}

		// Token: 0x020000B8 RID: 184
		private class XamlClosure_28
		{
			// Token: 0x0600066D RID: 1645 RVA: 0x0003FD84 File Offset: 0x0003DF84
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
				}, "avares://Exodus/Resources/CoinBanners.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				DataTemplate dataTemplate;
				object result = dataTemplate = new DataTemplate();
				context.PushParent(dataTemplate);
				dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_28.XamlClosure_29.Build), context);
				context.PopParent();
				return result;
			}

			// Token: 0x020000B9 RID: 185
			private class XamlClosure_29
			{
				// Token: 0x0600066E RID: 1646 RVA: 0x0003FE14 File Offset: 0x0003E014
				public static object Build(IServiceProvider A_0)
				{
					XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
					{
						(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
					}, "avares://Exodus/Resources/CoinBanners.axaml");
					if (A_0 != null)
					{
						object obj = A_0.GetService(typeof(IRootObjectProvider));
						if (obj != null)
						{
							obj = ((IRootObjectProvider)obj).RootObject;
							context.RootObject = (ResourceDictionary)obj;
						}
					}
					context.IntermediateRoot = new UserControl();
					object intermediateRoot = context.IntermediateRoot;
					((ISupportInitialize)intermediateRoot).BeginInit();
					UserControl userControl = intermediateRoot;
					context.PushParent(userControl);
					UserControl userControl2 = userControl;
					userControl2.Height = 84.0;
					Image image2;
					Image image = image2 = new Image();
					((ISupportInitialize)image).BeginInit();
					userControl2.Content = image;
					Image image3;
					ISupportInitialize supportInitialize = image3 = image2;
					context.PushParent(image3);
					Image image4 = image3;
					image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/solana.png");
					image4.Width = 84.0;
					image4.Height = 84.0;
					image4.Stretch = Stretch.Uniform;
					RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
					image4.HorizontalAlignment = HorizontalAlignment.Center;
					image4.VerticalAlignment = VerticalAlignment.Center;
					context.PopParent();
					supportInitialize.EndInit();
					context.PopParent();
					((ISupportInitialize)intermediateRoot).EndInit();
					return intermediateRoot;
				}
			}
		}

		// Token: 0x020000BA RID: 186
		private class XamlClosure_30
		{
			// Token: 0x0600066F RID: 1647 RVA: 0x0003FF38 File Offset: 0x0003E138
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
				}, "avares://Exodus/Resources/CoinBanners.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				DataTemplate dataTemplate;
				object result = dataTemplate = new DataTemplate();
				context.PushParent(dataTemplate);
				dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_30.XamlClosure_31.Build), context);
				context.PopParent();
				return result;
			}

			// Token: 0x020000BB RID: 187
			private class XamlClosure_31
			{
				// Token: 0x06000670 RID: 1648 RVA: 0x0003FFC8 File Offset: 0x0003E1C8
				public static object Build(IServiceProvider A_0)
				{
					XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
					{
						(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
					}, "avares://Exodus/Resources/CoinBanners.axaml");
					if (A_0 != null)
					{
						object obj = A_0.GetService(typeof(IRootObjectProvider));
						if (obj != null)
						{
							obj = ((IRootObjectProvider)obj).RootObject;
							context.RootObject = (ResourceDictionary)obj;
						}
					}
					context.IntermediateRoot = new UserControl();
					object intermediateRoot = context.IntermediateRoot;
					((ISupportInitialize)intermediateRoot).BeginInit();
					UserControl userControl = intermediateRoot;
					context.PushParent(userControl);
					UserControl userControl2 = userControl;
					userControl2.Height = 84.0;
					Image image2;
					Image image = image2 = new Image();
					((ISupportInitialize)image).BeginInit();
					userControl2.Content = image;
					Image image3;
					ISupportInitialize supportInitialize = image3 = image2;
					context.PushParent(image3);
					Image image4 = image3;
					image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/bnb.png");
					image4.Width = 84.0;
					image4.Height = 84.0;
					image4.Stretch = Stretch.Uniform;
					RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
					image4.HorizontalAlignment = HorizontalAlignment.Center;
					image4.VerticalAlignment = VerticalAlignment.Center;
					context.PopParent();
					supportInitialize.EndInit();
					context.PopParent();
					((ISupportInitialize)intermediateRoot).EndInit();
					return intermediateRoot;
				}
			}
		}

		// Token: 0x020000BC RID: 188
		private class XamlClosure_32
		{
			// Token: 0x06000671 RID: 1649 RVA: 0x000400EC File Offset: 0x0003E2EC
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
				}, "avares://Exodus/Resources/CoinBanners.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				DataTemplate dataTemplate;
				object result = dataTemplate = new DataTemplate();
				context.PushParent(dataTemplate);
				dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_32.XamlClosure_33.Build), context);
				context.PopParent();
				return result;
			}

			// Token: 0x020000BD RID: 189
			private class XamlClosure_33
			{
				// Token: 0x06000672 RID: 1650 RVA: 0x0004017C File Offset: 0x0003E37C
				public static object Build(IServiceProvider A_0)
				{
					XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
					{
						(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
					}, "avares://Exodus/Resources/CoinBanners.axaml");
					if (A_0 != null)
					{
						object obj = A_0.GetService(typeof(IRootObjectProvider));
						if (obj != null)
						{
							obj = ((IRootObjectProvider)obj).RootObject;
							context.RootObject = (ResourceDictionary)obj;
						}
					}
					context.IntermediateRoot = new UserControl();
					object intermediateRoot = context.IntermediateRoot;
					((ISupportInitialize)intermediateRoot).BeginInit();
					UserControl userControl = intermediateRoot;
					context.PushParent(userControl);
					UserControl userControl2 = userControl;
					userControl2.Height = 84.0;
					Image image2;
					Image image = image2 = new Image();
					((ISupportInitialize)image).BeginInit();
					userControl2.Content = image;
					Image image3;
					ISupportInitialize supportInitialize = image3 = image2;
					context.PushParent(image3);
					Image image4 = image3;
					image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/tether.png");
					image4.Width = 84.0;
					image4.Height = 84.0;
					image4.Stretch = Stretch.Uniform;
					RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
					image4.HorizontalAlignment = HorizontalAlignment.Center;
					image4.VerticalAlignment = VerticalAlignment.Center;
					context.PopParent();
					supportInitialize.EndInit();
					context.PopParent();
					((ISupportInitialize)intermediateRoot).EndInit();
					return intermediateRoot;
				}
			}
		}

		// Token: 0x020000BE RID: 190
		private class XamlClosure_34
		{
			// Token: 0x06000673 RID: 1651 RVA: 0x000402A0 File Offset: 0x0003E4A0
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
				}, "avares://Exodus/Resources/CoinBanners.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				DataTemplate dataTemplate;
				object result = dataTemplate = new DataTemplate();
				context.PushParent(dataTemplate);
				dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_34.XamlClosure_35.Build), context);
				context.PopParent();
				return result;
			}

			// Token: 0x020000BF RID: 191
			private class XamlClosure_35
			{
				// Token: 0x06000674 RID: 1652 RVA: 0x00040330 File Offset: 0x0003E530
				public static object Build(IServiceProvider A_0)
				{
					XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
					{
						(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
					}, "avares://Exodus/Resources/CoinBanners.axaml");
					if (A_0 != null)
					{
						object obj = A_0.GetService(typeof(IRootObjectProvider));
						if (obj != null)
						{
							obj = ((IRootObjectProvider)obj).RootObject;
							context.RootObject = (ResourceDictionary)obj;
						}
					}
					context.IntermediateRoot = new UserControl();
					object intermediateRoot = context.IntermediateRoot;
					((ISupportInitialize)intermediateRoot).BeginInit();
					UserControl userControl = intermediateRoot;
					context.PushParent(userControl);
					UserControl userControl2 = userControl;
					userControl2.Height = 84.0;
					Image image2;
					Image image = image2 = new Image();
					((ISupportInitialize)image).BeginInit();
					userControl2.Content = image;
					Image image3;
					ISupportInitialize supportInitialize = image3 = image2;
					context.PushParent(image3);
					Image image4 = image3;
					image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/tron.png");
					image4.Width = 84.0;
					image4.Height = 84.0;
					image4.Stretch = Stretch.Uniform;
					RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
					image4.HorizontalAlignment = HorizontalAlignment.Center;
					image4.VerticalAlignment = VerticalAlignment.Center;
					context.PopParent();
					supportInitialize.EndInit();
					context.PopParent();
					((ISupportInitialize)intermediateRoot).EndInit();
					return intermediateRoot;
				}
			}
		}

		// Token: 0x020000C0 RID: 192
		private class XamlClosure_36
		{
			// Token: 0x06000675 RID: 1653 RVA: 0x00040454 File Offset: 0x0003E654
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
				}, "avares://Exodus/Resources/CoinBanners.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new DataTemplate
				{
					Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_36.XamlClosure_37.Build), context)
				};
			}

			// Token: 0x020000C1 RID: 193
			private class XamlClosure_37
			{
				// Token: 0x06000676 RID: 1654 RVA: 0x000404D4 File Offset: 0x0003E6D4
				public static object Build(IServiceProvider A_0)
				{
					XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
					{
						(object)!AvaloniaResources.NamespaceInfo:/Resources/CoinBanners.axaml.Singleton
					}, "avares://Exodus/Resources/CoinBanners.axaml");
					if (A_0 != null)
					{
						object obj = A_0.GetService(typeof(IRootObjectProvider));
						if (obj != null)
						{
							obj = ((IRootObjectProvider)obj).RootObject;
							context.RootObject = (ResourceDictionary)obj;
						}
					}
					context.IntermediateRoot = new UserControl();
					object intermediateRoot = context.IntermediateRoot;
					((ISupportInitialize)intermediateRoot).BeginInit();
					intermediateRoot.Height = 84.0;
					Border border2;
					Border border = border2 = new Border();
					((ISupportInitialize)border).BeginInit();
					intermediateRoot.Content = border;
					Border border3 = border2;
					border3.Width = 84.0;
					border3.Height = 84.0;
					border3.CornerRadius = new CornerRadius(42.0, 42.0, 42.0, 42.0);
					border3.Background = new ImmutableSolidColorBrush(4280032810U);
					border3.BorderBrush = new ImmutableSolidColorBrush(4282007384U);
					border3.BorderThickness = new Thickness(2.0, 2.0, 2.0, 2.0);
					TextBlock textBlock2;
					TextBlock textBlock = textBlock2 = new TextBlock();
					((ISupportInitialize)textBlock).BeginInit();
					border3.Child = textBlock;
					TextBlock textBlock3 = textBlock2;
					textBlock3.Text = "★";
					textBlock3.FontSize = 36.0;
					textBlock3.Foreground = new ImmutableSolidColorBrush(4288717757U);
					textBlock3.HorizontalAlignment = HorizontalAlignment.Center;
					textBlock3.VerticalAlignment = VerticalAlignment.Center;
					((ISupportInitialize)textBlock3).EndInit();
					((ISupportInitialize)border3).EndInit();
					((ISupportInitialize)intermediateRoot).EndInit();
					return intermediateRoot;
				}
			}
		}

		// Token: 0x020000C2 RID: 194
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x06000677 RID: 1655 RVA: 0x0004066C File Offset: 0x0003E86C
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x06000678 RID: 1656 RVA: 0x0004068C File Offset: 0x0003E88C
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(2)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					}
				};
			}

			// Token: 0x17000114 RID: 276
			// (get) Token: 0x06000679 RID: 1657 RVA: 0x00040930 File Offset: 0x0003EB30
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x0600067B RID: 1659 RVA: 0x00040970 File Offset: 0x0003EB70
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml();
			}

			// Token: 0x040002ED RID: 749
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002EE RID: 750
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000C3 RID: 195
		private class XamlClosure_38
		{
			// Token: 0x0600067C RID: 1660 RVA: 0x00040988 File Offset: 0x0003EB88
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto/Roboto-Regular.ttf#Roboto");
			}
		}

		// Token: 0x020000C4 RID: 196
		private class XamlClosure_39
		{
			// Token: 0x0600067D RID: 1661 RVA: 0x00040A00 File Offset: 0x0003EC00
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto/Roboto-Medium.ttf#Roboto");
			}
		}

		// Token: 0x020000C5 RID: 197
		private class XamlClosure_40
		{
			// Token: 0x0600067E RID: 1662 RVA: 0x00040A78 File Offset: 0x0003EC78
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto/Roboto-Thin.ttf#Roboto");
			}
		}

		// Token: 0x020000C6 RID: 198
		private class XamlClosure_41
		{
			// Token: 0x0600067F RID: 1663 RVA: 0x00040AF0 File Offset: 0x0003ECF0
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto/Roboto-Light.ttf#Roboto");
			}
		}

		// Token: 0x020000C7 RID: 199
		private class XamlClosure_42
		{
			// Token: 0x06000680 RID: 1664 RVA: 0x00040B68 File Offset: 0x0003ED68
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto/Roboto-LightItalic.ttf#Roboto");
			}
		}

		// Token: 0x020000C8 RID: 200
		private class XamlClosure_43
		{
			// Token: 0x06000681 RID: 1665 RVA: 0x00040BE0 File Offset: 0x0003EDE0
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto/Roboto-Bold.ttf#Roboto");
			}
		}

		// Token: 0x020000C9 RID: 201
		private class XamlClosure_44
		{
			// Token: 0x06000682 RID: 1666 RVA: 0x00040C58 File Offset: 0x0003EE58
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto/Roboto-Black.ttf#Roboto");
			}
		}

		// Token: 0x020000CA RID: 202
		private class XamlClosure_45
		{
			// Token: 0x06000683 RID: 1667 RVA: 0x00040CD0 File Offset: 0x0003EED0
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto-condensed/RobotoCondensed-Light.ttf#Roboto");
			}
		}

		// Token: 0x020000CB RID: 203
		private class XamlClosure_46
		{
			// Token: 0x06000684 RID: 1668 RVA: 0x00040D48 File Offset: 0x0003EF48
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto-condensed/RobotoCondensed-Regular.ttf#Roboto");
			}
		}

		// Token: 0x020000CC RID: 204
		private class XamlClosure_47
		{
			// Token: 0x06000685 RID: 1669 RVA: 0x00040DC0 File Offset: 0x0003EFC0
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto-condensed/RobotoCondensed-Bold.ttf#Roboto");
			}
		}

		// Token: 0x020000CD RID: 205
		private class XamlClosure_48
		{
			// Token: 0x06000686 RID: 1670 RVA: 0x00040E38 File Offset: 0x0003F038
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto-condensed/RobotoCondensed-Medium.ttf#Roboto");
			}
		}

		// Token: 0x020000CE RID: 206
		private class XamlClosure_49
		{
			// Token: 0x06000687 RID: 1671 RVA: 0x00040EB0 File Offset: 0x0003F0B0
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/roboto-condensed/RobotoCondensed-SemiBold.ttf#Roboto");
			}
		}

		// Token: 0x020000CF RID: 207
		private class XamlClosure_50
		{
			// Token: 0x06000688 RID: 1672 RVA: 0x00040F28 File Offset: 0x0003F128
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/nunito/Nunito-VariableFont_wght.ttf#Nunito");
			}
		}

		// Token: 0x020000D0 RID: 208
		private class XamlClosure_51
		{
			// Token: 0x06000689 RID: 1673 RVA: 0x00040FA0 File Offset: 0x0003F1A0
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/nunito/Nunito-Italic-VariableFont_wght.ttf#Nunito");
			}
		}

		// Token: 0x020000D1 RID: 209
		private class XamlClosure_52
		{
			// Token: 0x0600068A RID: 1674 RVA: 0x00041018 File Offset: 0x0003F218
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/FontResources.axaml.Singleton
				}, "avares://Exodus/Resources/FontResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				return new FontFamily(((IUriContext)context).BaseUri, "avares://Exodus/Assets/Resources/Fonts/icomoon/icomoon.ttf#icomoon");
			}
		}

		// Token: 0x020000D2 RID: 210
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x0600068B RID: 1675 RVA: 0x00041090 File Offset: 0x0003F290
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x0600068C RID: 1676 RVA: 0x000410B0 File Offset: 0x0003F2B0
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(3)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"scroll",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaceInfo("CompositionScroll", null)
						}
					}
				};
			}

			// Token: 0x17000115 RID: 277
			// (get) Token: 0x0600068D RID: 1677 RVA: 0x00041374 File Offset: 0x0003F574
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x0600068F RID: 1679 RVA: 0x000413B4 File Offset: 0x0003F5B4
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml();
			}

			// Token: 0x040002EF RID: 751
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002F0 RID: 752
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000D3 RID: 211
		private class XamlClosure_53
		{
			// Token: 0x06000690 RID: 1680 RVA: 0x000413CC File Offset: 0x0003F5CC
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.Singleton
				}, "avares://Exodus/Resources/SmoothScrollThemeResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				ControlTheme controlTheme;
				object result = controlTheme = new ControlTheme();
				context.PushParent(controlTheme);
				ControlTheme controlTheme2 = controlTheme;
				controlTheme2.TargetType = typeof(ScrollViewer);
				controlTheme2.Add(new Setter
				{
					Property = TemplatedControl.BackgroundProperty,
					Value = new ImmutableSolidColorBrush(16777215U)
				});
				Setter setter2;
				SetterBase setter = setter2 = new Setter();
				context.PushParent(setter2);
				Setter setter3 = setter2;
				setter3.Property = TemplatedControl.TemplateProperty;
				ControlTemplate controlTemplate;
				object value = controlTemplate = new ControlTemplate();
				context.PushParent(controlTemplate);
				controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(!AvaloniaResources.XamlClosure_53.XamlClosure_54.Build), context);
				context.PopParent();
				setter3.Value = value;
				context.PopParent();
				controlTheme2.Add(setter);
				Style style = new Style();
				style.Selector = Selectors.Nesting((Selector)null).PropertyEquals(ScrollViewer.IsExpandedProperty, true).Template().OfType(typeof(Panel)).Name("PART_ScrollBarsSeparator");
				style.Add(new Setter
				{
					Property = Visual.OpacityProperty,
					Value = 1.0
				});
				controlTheme2.Add(style);
				context.PopParent();
				return result;
			}

			// Token: 0x020000D4 RID: 212
			private class XamlClosure_54
			{
				// Token: 0x06000691 RID: 1681 RVA: 0x00041540 File Offset: 0x0003F740
				public static object Build(IServiceProvider A_0)
				{
					XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
					{
						(object)!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.Singleton
					}, "avares://Exodus/Resources/SmoothScrollThemeResources.axaml");
					object obj;
					if (A_0 != null)
					{
						obj = A_0.GetService(typeof(IRootObjectProvider));
						if (obj != null)
						{
							obj = ((IRootObjectProvider)obj).RootObject;
							context.RootObject = (ResourceDictionary)obj;
						}
					}
					context.IntermediateRoot = new Grid();
					object intermediateRoot = context.IntermediateRoot;
					((ISupportInitialize)intermediateRoot).BeginInit();
					Grid grid = intermediateRoot;
					context.PushParent(grid);
					Grid grid2 = grid;
					ColumnDefinitions columnDefinitions = new ColumnDefinitions();
					columnDefinitions.Capacity = 2;
					columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					grid2.ColumnDefinitions = columnDefinitions;
					RowDefinitions rowDefinitions = new RowDefinitions();
					rowDefinitions.Capacity = 2;
					rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
					grid2.RowDefinitions = rowDefinitions;
					AvaloniaList<Control> children = grid2.Children;
					CompositionScrollContentPresenter compositionScrollContentPresenter2;
					CompositionScrollContentPresenter compositionScrollContentPresenter = compositionScrollContentPresenter2 = new CompositionScrollContentPresenter();
					((ISupportInitialize)compositionScrollContentPresenter).BeginInit();
					children.Add(compositionScrollContentPresenter);
					CompositionScrollContentPresenter compositionScrollContentPresenter3 = compositionScrollContentPresenter2;
					compositionScrollContentPresenter3.Name = "PART_ContentPresenter";
					obj = compositionScrollContentPresenter3;
					context.AvaloniaNameScope.Register("PART_ContentPresenter", obj);
					compositionScrollContentPresenter3.SetValue<int>(Grid.RowProperty, 0, BindingPriority.Template);
					compositionScrollContentPresenter3.SetValue<int>(Grid.ColumnProperty, 0, BindingPriority.Template);
					compositionScrollContentPresenter3.SetValue<int>(Grid.RowSpanProperty, 2, BindingPriority.Template);
					compositionScrollContentPresenter3.SetValue<int>(Grid.ColumnSpanProperty, 2, BindingPriority.Template);
					compositionScrollContentPresenter3.Bind(ContentPresenter.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue(), null);
					compositionScrollContentPresenter3.Bind(CompositionScrollContentPresenter.HorizontalSnapPointsTypeProperty, new TemplateBinding(ScrollViewer.HorizontalSnapPointsTypeProperty).ProvideValue(), null);
					compositionScrollContentPresenter3.Bind(CompositionScrollContentPresenter.VerticalSnapPointsTypeProperty, new TemplateBinding(ScrollViewer.VerticalSnapPointsTypeProperty).ProvideValue(), null);
					compositionScrollContentPresenter3.Bind(CompositionScrollContentPresenter.HorizontalSnapPointsAlignmentProperty, new TemplateBinding(ScrollViewer.HorizontalSnapPointsAlignmentProperty).ProvideValue(), null);
					compositionScrollContentPresenter3.Bind(CompositionScrollContentPresenter.VerticalSnapPointsAlignmentProperty, new TemplateBinding(ScrollViewer.VerticalSnapPointsAlignmentProperty).ProvideValue(), null);
					compositionScrollContentPresenter3.Bind(ContentPresenter.PaddingProperty, new TemplateBinding(TemplatedControl.PaddingProperty).ProvideValue(), null);
					compositionScrollContentPresenter3.Bind(ScrollViewer.IsScrollInertiaEnabledProperty, new TemplateBinding(ScrollViewer.IsScrollInertiaEnabledProperty).ProvideValue(), null);
					compositionScrollContentPresenter3.Bind(CompositionScrollContentPresenter.ScrollFeaturesProperty, new TemplateBinding(CompositionScrollContentPresenter.ScrollFeaturesProperty).ProvideValue(), null);
					((ISupportInitialize)compositionScrollContentPresenter3).EndInit();
					AvaloniaList<Control> children2 = grid2.Children;
					ScrollBar scrollBar2;
					ScrollBar scrollBar = scrollBar2 = new ScrollBar();
					((ISupportInitialize)scrollBar).BeginInit();
					children2.Add(scrollBar);
					ScrollBar scrollBar3 = scrollBar2;
					scrollBar3.Name = "PART_HorizontalScrollBar";
					obj = scrollBar3;
					context.AvaloniaNameScope.Register("PART_HorizontalScrollBar", obj);
					scrollBar3.SetValue<Orientation>(ScrollBar.OrientationProperty, Orientation.Horizontal, BindingPriority.Template);
					scrollBar3.SetValue<int>(Grid.RowProperty, 1, BindingPriority.Template);
					((ISupportInitialize)scrollBar3).EndInit();
					AvaloniaList<Control> children3 = grid2.Children;
					ScrollBar scrollBar5;
					ScrollBar scrollBar4 = scrollBar5 = new ScrollBar();
					((ISupportInitialize)scrollBar4).BeginInit();
					children3.Add(scrollBar4);
					ScrollBar scrollBar6 = scrollBar5;
					scrollBar6.Name = "PART_VerticalScrollBar";
					obj = scrollBar6;
					context.AvaloniaNameScope.Register("PART_VerticalScrollBar", obj);
					scrollBar6.SetValue<Orientation>(ScrollBar.OrientationProperty, Orientation.Vertical, BindingPriority.Template);
					scrollBar6.SetValue<int>(Grid.ColumnProperty, 1, BindingPriority.Template);
					((ISupportInitialize)scrollBar6).EndInit();
					AvaloniaList<Control> children4 = grid2.Children;
					Panel panel2;
					Panel panel = panel2 = new Panel();
					((ISupportInitialize)panel).BeginInit();
					children4.Add(panel);
					Panel panel3;
					ISupportInitialize supportInitialize = panel3 = panel2;
					context.PushParent(panel3);
					Panel panel4 = panel3;
					panel4.Name = "PART_ScrollBarsSeparator";
					obj = panel4;
					context.AvaloniaNameScope.Register("PART_ScrollBarsSeparator", obj);
					panel4.SetValue<int>(Grid.RowProperty, 1, BindingPriority.Template);
					panel4.SetValue<int>(Grid.ColumnProperty, 1, BindingPriority.Template);
					AvaloniaProperty backgroundProperty = Panel.BackgroundProperty;
					DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ScrollViewerScrollBarsSeparatorBackground");
					IServiceProvider serviceProvider = context;
					context.ProvideTargetProperty = Panel.BackgroundProperty;
					IBinding binding = dynamicResourceExtension.ProvideValue(serviceProvider);
					context.ProvideTargetProperty = null;
					panel4.Bind(backgroundProperty, binding, null);
					panel4.SetValue<double>(Visual.OpacityProperty, 0.0, BindingPriority.Template);
					panel4.SetValue<Transitions>(Animatable.TransitionsProperty, new Transitions
					{
						new DoubleTransition
						{
							Property = Visual.OpacityProperty,
							Duration = TimeSpan.FromTicks(2000000L)
						}
					}, BindingPriority.Template);
					context.PopParent();
					supportInitialize.EndInit();
					context.PopParent();
					((ISupportInitialize)intermediateRoot).EndInit();
					return intermediateRoot;
				}
			}
		}

		// Token: 0x020000D5 RID: 213
		private class XamlClosure_55
		{
			// Token: 0x06000692 RID: 1682 RVA: 0x0004196C File Offset: 0x0003FB6C
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.Singleton
				}, "avares://Exodus/Resources/SmoothScrollThemeResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				ControlTheme controlTheme;
				object result = controlTheme = new ControlTheme();
				context.PushParent(controlTheme);
				ControlTheme controlTheme2 = controlTheme;
				controlTheme2.TargetType = typeof(ScrollViewer);
				StaticResourceExtension staticResourceExtension = new StaticResourceExtension(typeof(ScrollViewer));
				IServiceProvider serviceProvider = context;
				context.ProvideTargetProperty = XamlIlHelpers.Avalonia.Styling.ControlTheme,Avalonia.Base.BasedOn!Property();
				object obj2 = staticResourceExtension.ProvideValue(serviceProvider);
				context.ProvideTargetProperty = null;
				controlTheme2.BasedOn = (ControlTheme)obj2;
				controlTheme2.Add(new Setter
				{
					Property = CompositionScrollContentPresenter.ScrollFeaturesProperty,
					Value = (ScrollFeaturesEnum.MousePressedScroll | ScrollFeaturesEnum.MousePressedScrollEnertia)
				});
				context.PopParent();
				return result;
			}
		}

		// Token: 0x020000D6 RID: 214
		private class XamlClosure_56
		{
			// Token: 0x06000693 RID: 1683 RVA: 0x00041A48 File Offset: 0x0003FC48
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<ResourceDictionary> context = new XamlIlContext.Context<ResourceDictionary>(A_0, new object[]
				{
					(object)!AvaloniaResources.NamespaceInfo:/Resources/SmoothScrollThemeResources.axaml.Singleton
				}, "avares://Exodus/Resources/SmoothScrollThemeResources.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (ResourceDictionary)obj;
					}
				}
				ControlTheme controlTheme;
				object result = controlTheme = new ControlTheme();
				context.PushParent(controlTheme);
				ControlTheme controlTheme2 = controlTheme;
				controlTheme2.TargetType = typeof(ScrollViewer);
				StaticResourceExtension staticResourceExtension = new StaticResourceExtension(typeof(ScrollViewer));
				IServiceProvider serviceProvider = context;
				context.ProvideTargetProperty = XamlIlHelpers.Avalonia.Styling.ControlTheme,Avalonia.Base.BasedOn!Property();
				object obj2 = staticResourceExtension.ProvideValue(serviceProvider);
				context.ProvideTargetProperty = null;
				controlTheme2.BasedOn = (ControlTheme)obj2;
				controlTheme2.Add(new Setter
				{
					Property = CompositionScrollContentPresenter.ScrollFeaturesProperty,
					Value = (ScrollFeaturesEnum.MousePressedScroll | ScrollFeaturesEnum.MousePressedScrollEnertia | ScrollFeaturesEnum.WheelSwapDirections)
				});
				context.PopParent();
				return result;
			}
		}

		// Token: 0x020000D7 RID: 215
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x06000694 RID: 1684 RVA: 0x00041B24 File Offset: 0x0003FD24
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x06000695 RID: 1685 RVA: 0x00041B44 File Offset: 0x0003FD44
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(2)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					}
				};
			}

			// Token: 0x17000116 RID: 278
			// (get) Token: 0x06000696 RID: 1686 RVA: 0x00041DE8 File Offset: 0x0003FFE8
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x06000698 RID: 1688 RVA: 0x00041E28 File Offset: 0x00040028
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Styles/ButtonStyles.axaml();
			}

			// Token: 0x040002F1 RID: 753
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002F2 RID: 754
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000D8 RID: 216
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x06000699 RID: 1689 RVA: 0x00041E40 File Offset: 0x00040040
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x0600069A RID: 1690 RVA: 0x00041E60 File Offset: 0x00040060
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(2)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					}
				};
			}

			// Token: 0x17000117 RID: 279
			// (get) Token: 0x0600069B RID: 1691 RVA: 0x00042104 File Offset: 0x00040304
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x0600069D RID: 1693 RVA: 0x00042144 File Offset: 0x00040344
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Styles/TextBoxStyles.axaml();
			}

			// Token: 0x040002F3 RID: 755
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002F4 RID: 756
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000D9 RID: 217
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x0600069E RID: 1694 RVA: 0x0004215C File Offset: 0x0004035C
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x0600069F RID: 1695 RVA: 0x0004217C File Offset: 0x0004037C
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(2)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					}
				};
			}

			// Token: 0x17000118 RID: 280
			// (get) Token: 0x060006A0 RID: 1696 RVA: 0x00042420 File Offset: 0x00040620
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006A2 RID: 1698 RVA: 0x00042460 File Offset: 0x00040660
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Styles/ToggleButtonStyles.axaml();
			}

			// Token: 0x040002F5 RID: 757
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002F6 RID: 758
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000DA RID: 218
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x060006A3 RID: 1699 RVA: 0x00042478 File Offset: 0x00040678
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x060006A4 RID: 1700 RVA: 0x00042498 File Offset: 0x00040698
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(5)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"viewModels",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaceInfo("Exodus.ViewModels", "Exodus")
						}
					}
				};
			}

			// Token: 0x17000119 RID: 281
			// (get) Token: 0x060006A5 RID: 1701 RVA: 0x00042780 File Offset: 0x00040980
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006A7 RID: 1703 RVA: 0x000427C0 File Offset: 0x000409C0
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Views/AddTransactionWindow.axaml();
			}

			// Token: 0x040002F7 RID: 759
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002F8 RID: 760
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000DB RID: 219
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x060006A8 RID: 1704 RVA: 0x000427D8 File Offset: 0x000409D8
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x060006A9 RID: 1705 RVA: 0x000427F8 File Offset: 0x000409F8
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(7)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"vm",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Exodus.ViewModels", "Exodus")
						}
					},
					{
						"models",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Exodus.Models", "Exodus")
						}
					},
					{
						"views",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaceInfo("Exodus.Views", "Exodus")
						}
					}
				};
			}

			// Token: 0x1700011A RID: 282
			// (get) Token: 0x060006AA RID: 1706 RVA: 0x00042B28 File Offset: 0x00040D28
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006AC RID: 1708 RVA: 0x00042B68 File Offset: 0x00040D68
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml();
			}

			// Token: 0x040002F9 RID: 761
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002FA RID: 762
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000DC RID: 220
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x060006AD RID: 1709 RVA: 0x00042B80 File Offset: 0x00040D80
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x060006AE RID: 1710 RVA: 0x00042BA0 File Offset: 0x00040DA0
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(7)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"viewModels",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Exodus.ViewModels", "Exodus")
						}
					},
					{
						"views",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Exodus.Views", "Exodus")
						}
					},
					{
						"controls",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaceInfo("Exodus.Controls", "Exodus")
						}
					}
				};
			}

			// Token: 0x1700011B RID: 283
			// (get) Token: 0x060006AF RID: 1711 RVA: 0x00042ED0 File Offset: 0x000410D0
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006B1 RID: 1713 RVA: 0x00042F10 File Offset: 0x00041110
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml();
			}

			// Token: 0x040002FB RID: 763
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002FC RID: 764
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000DD RID: 221
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x060006B2 RID: 1714 RVA: 0x00042F28 File Offset: 0x00041128
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x060006B3 RID: 1715 RVA: 0x00042F48 File Offset: 0x00041148
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(7)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"vm",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Exodus.ViewModels", null)
						}
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"views",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Exodus.Views", "Exodus")
						}
					},
					{
						"viewModels",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaceInfo("Exodus.ViewModels", "Exodus")
						}
					}
				};
			}

			// Token: 0x1700011C RID: 284
			// (get) Token: 0x060006B4 RID: 1716 RVA: 0x00043274 File Offset: 0x00041474
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006B6 RID: 1718 RVA: 0x000432B4 File Offset: 0x000414B4
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml();
			}

			// Token: 0x040002FD RID: 765
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x040002FE RID: 766
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000DE RID: 222
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x060006B7 RID: 1719 RVA: 0x000432CC File Offset: 0x000414CC
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x060006B8 RID: 1720 RVA: 0x000432EC File Offset: 0x000414EC
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(5)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"viewModels",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaceInfo("Exodus.ViewModels", "Exodus")
						}
					}
				};
			}

			// Token: 0x1700011D RID: 285
			// (get) Token: 0x060006B9 RID: 1721 RVA: 0x000435D4 File Offset: 0x000417D4
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006BB RID: 1723 RVA: 0x00043614 File Offset: 0x00041814
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml();
			}

			// Token: 0x040002FF RID: 767
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x04000300 RID: 768
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000DF RID: 223
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x060006BC RID: 1724 RVA: 0x0004362C File Offset: 0x0004182C
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x060006BD RID: 1725 RVA: 0x0004364C File Offset: 0x0004184C
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(7)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"viewModels",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Exodus.ViewModels", "Exodus")
						}
					},
					{
						"views",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Exodus.Views", "Exodus")
						}
					},
					{
						"models",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaceInfo("Exodus.Models", "Exodus")
						}
					}
				};
			}

			// Token: 0x1700011E RID: 286
			// (get) Token: 0x060006BE RID: 1726 RVA: 0x0004397C File Offset: 0x00041B7C
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006C0 RID: 1728 RVA: 0x000439BC File Offset: 0x00041BBC
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml();
			}

			// Token: 0x04000301 RID: 769
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x04000302 RID: 770
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000E0 RID: 224
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x060006C1 RID: 1729 RVA: 0x000439D4 File Offset: 0x00041BD4
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x060006C2 RID: 1730 RVA: 0x000439F4 File Offset: 0x00041BF4
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(5)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"viewModels",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaceInfo("Exodus.ViewModels", "Exodus")
						}
					}
				};
			}

			// Token: 0x1700011F RID: 287
			// (get) Token: 0x060006C3 RID: 1731 RVA: 0x00043CDC File Offset: 0x00041EDC
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006C5 RID: 1733 RVA: 0x00043D1C File Offset: 0x00041F1C
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml();
			}

			// Token: 0x04000303 RID: 771
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x04000304 RID: 772
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000E1 RID: 225
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x060006C6 RID: 1734 RVA: 0x00043D34 File Offset: 0x00041F34
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x060006C7 RID: 1735 RVA: 0x00043D54 File Offset: 0x00041F54
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(5)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"viewModels",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaceInfo("Exodus.ViewModels", "Exodus")
						}
					}
				};
			}

			// Token: 0x17000120 RID: 288
			// (get) Token: 0x060006C8 RID: 1736 RVA: 0x0004403C File Offset: 0x0004223C
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006CA RID: 1738 RVA: 0x0004407C File Offset: 0x0004227C
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml();
			}

			// Token: 0x04000305 RID: 773
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x04000306 RID: 774
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000E2 RID: 226
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x060006CB RID: 1739 RVA: 0x00044094 File Offset: 0x00042294
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x060006CC RID: 1740 RVA: 0x000440B4 File Offset: 0x000422B4
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(5)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"viewModels",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaceInfo("Exodus.ViewModels", "Exodus")
						}
					}
				};
			}

			// Token: 0x17000121 RID: 289
			// (get) Token: 0x060006CD RID: 1741 RVA: 0x0004439C File Offset: 0x0004259C
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006CF RID: 1743 RVA: 0x000443DC File Offset: 0x000425DC
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Views/SettingsModalView.axaml();
			}

			// Token: 0x04000307 RID: 775
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x04000308 RID: 776
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000E3 RID: 227
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x060006D0 RID: 1744 RVA: 0x000443F4 File Offset: 0x000425F4
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x060006D1 RID: 1745 RVA: 0x00044414 File Offset: 0x00042614
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(7)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"vm",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Exodus.ViewModels", "Exodus")
						}
					},
					{
						"models",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Exodus.Models", "Exodus")
						}
					},
					{
						"views",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaceInfo("Exodus.Views", "Exodus")
						}
					}
				};
			}

			// Token: 0x17000122 RID: 290
			// (get) Token: 0x060006D2 RID: 1746 RVA: 0x00044744 File Offset: 0x00042944
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006D4 RID: 1748 RVA: 0x00044784 File Offset: 0x00042984
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Views/SwapView.axaml();
			}

			// Token: 0x04000309 RID: 777
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x0400030A RID: 778
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}

		// Token: 0x020000E4 RID: 228
		public class axaml : IAvaloniaXamlIlXmlNamespaceInfoProvider
		{
			// Token: 0x060006D5 RID: 1749 RVA: 0x0004479C File Offset: 0x0004299C
			static AvaloniaXamlIlXmlNamespaceInfo CreateNamespaceInfo(string A_0, string A_1)
			{
				return new AvaloniaXamlIlXmlNamespaceInfo
				{
					ClrNamespace = A_0,
					ClrAssemblyName = A_1
				};
			}

			// Token: 0x060006D6 RID: 1750 RVA: 0x000447BC File Offset: 0x000429BC
			static IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> CreateNamespaces()
			{
				return new Dictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>>(5)
				{
					{
						"",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Animation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Animation.Easings", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Data.Converters", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Input", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Input.GestureRecognizers", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Input.TextInput", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Layout", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.LogicalTree", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Media", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Media.Imaging", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Media.Transformation", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Styling", "Avalonia.Base"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Automation", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Controls", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Embedding", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Presenters", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Primitives", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Shapes", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Templates", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Notifications", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Chrome", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Controls.Documents", "Avalonia.Controls"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Fonts.Inter", "Avalonia.Fonts.Inter"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Data", "Avalonia.Markup"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.MarkupExtensions", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Styling", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Markup.Xaml.Templates", "Avalonia.Markup.Xaml"),
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Avalonia.Themes.Fluent", "Avalonia.Themes.Fluent")
						}
					},
					{
						"x",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"d",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"mc",
						new AvaloniaXamlIlXmlNamespaceInfo[0]
					},
					{
						"viewModels",
						new AvaloniaXamlIlXmlNamespaceInfo[]
						{
							!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaceInfo("Exodus.ViewModels", "Exodus")
						}
					}
				};
			}

			// Token: 0x17000123 RID: 291
			// (get) Token: 0x060006D7 RID: 1751 RVA: 0x00044AA4 File Offset: 0x00042CA4
			public virtual IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> XmlNamespaces
			{
				get
				{
					if (this._xmlNamespaces == null)
					{
						this._xmlNamespaces = !AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.CreateNamespaces();
					}
					return this._xmlNamespaces;
				}
			}

			// Token: 0x060006D9 RID: 1753 RVA: 0x00044AE4 File Offset: 0x00042CE4
			static axaml()
			{
				!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.Singleton = new !AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml();
			}

			// Token: 0x0400030B RID: 779
			IReadOnlyDictionary<string, IReadOnlyList<AvaloniaXamlIlXmlNamespaceInfo>> _xmlNamespaces;

			// Token: 0x0400030C RID: 780
			public static IAvaloniaXamlIlXmlNamespaceInfoProvider Singleton;
		}
	}
}
