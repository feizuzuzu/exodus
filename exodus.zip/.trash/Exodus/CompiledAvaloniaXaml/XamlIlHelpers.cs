﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reactive;
using Avalonia;
using Avalonia.Data.Core;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Styling;
using Exodus.Models;
using Exodus.ViewModels;
using ReactiveUI;

namespace CompiledAvaloniaXaml
{
	// Token: 0x02000092 RID: 146
	internal class XamlIlHelpers
	{
		// Token: 0x060003F9 RID: 1017 RVA: 0x00036868 File Offset: 0x00034A68
		static object BasedOn!Getter(object A_0)
		{
			return ((ControlTheme)A_0).BasedOn;
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x00036880 File Offset: 0x00034A80
		static void BasedOn!Setter(object A_0, object A_1)
		{
			((ControlTheme)A_0).BasedOn = (ControlTheme)A_1;
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x000368A0 File Offset: 0x00034AA0
		public static IPropertyInfo BasedOn!Property()
		{
			if (XamlIlHelpers.Avalonia.Styling.ControlTheme,Avalonia.Base.BasedOn!Field != null)
			{
				return XamlIlHelpers.Avalonia.Styling.ControlTheme,Avalonia.Base.BasedOn!Field;
			}
			XamlIlHelpers.Avalonia.Styling.ControlTheme,Avalonia.Base.BasedOn!Field = new ClrPropertyInfo("BasedOn", new Func<object, object>(XamlIlHelpers.Avalonia.Styling.ControlTheme,Avalonia.Base.BasedOn!Getter), new Action<object, object>(XamlIlHelpers.Avalonia.Styling.ControlTheme,Avalonia.Base.BasedOn!Setter), typeof(ControlTheme));
			return XamlIlHelpers.Avalonia.Styling.ControlTheme,Avalonia.Base.BasedOn!Field;
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x000368F4 File Offset: 0x00034AF4
		static object AmountInput!Getter(object A_0)
		{
			return ((AddTransactionWindowViewModel)A_0).AmountInput;
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x0003690C File Offset: 0x00034B0C
		static void AmountInput!Setter(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).AmountInput = (string)A_1;
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x0003692C File Offset: 0x00034B2C
		public static IPropertyInfo AmountInput!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.AmountInput!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.AmountInput!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.AmountInput!Field = new ClrPropertyInfo("AmountInput", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.AmountInput!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.AmountInput!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.AmountInput!Field;
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x00036980 File Offset: 0x00034B80
		static object LivePreviewText!Getter(object A_0)
		{
			return ((AddTransactionWindowViewModel)A_0).LivePreviewText;
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x00036998 File Offset: 0x00034B98
		static void LivePreviewText!Setter(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).LivePreviewText = (string)A_1;
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x000369B8 File Offset: 0x00034BB8
		public static IPropertyInfo LivePreviewText!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.LivePreviewText!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.LivePreviewText!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.LivePreviewText!Field = new ClrPropertyInfo("LivePreviewText", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.LivePreviewText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.LivePreviewText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.LivePreviewText!Field;
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x00036A0C File Offset: 0x00034C0C
		static object Chip1Text!Getter(object A_0)
		{
			return ((AddTransactionWindowViewModel)A_0).Chip1Text;
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x00036A24 File Offset: 0x00034C24
		static void Chip1Text!Setter(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Chip1Text = (string)A_1;
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x00036A44 File Offset: 0x00034C44
		public static IPropertyInfo Chip1Text!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip1Text!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip1Text!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip1Text!Field = new ClrPropertyInfo("Chip1Text", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip1Text!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip1Text!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip1Text!Field;
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x00036A98 File Offset: 0x00034C98
		static object Chip2Text!Getter(object A_0)
		{
			return ((AddTransactionWindowViewModel)A_0).Chip2Text;
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x00036AB0 File Offset: 0x00034CB0
		static void Chip2Text!Setter(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Chip2Text = (string)A_1;
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x00036AD0 File Offset: 0x00034CD0
		public static IPropertyInfo Chip2Text!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip2Text!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip2Text!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip2Text!Field = new ClrPropertyInfo("Chip2Text", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip2Text!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip2Text!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip2Text!Field;
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x00036B24 File Offset: 0x00034D24
		static object Chip3Text!Getter(object A_0)
		{
			return ((AddTransactionWindowViewModel)A_0).Chip3Text;
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x00036B3C File Offset: 0x00034D3C
		static void Chip3Text!Setter(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Chip3Text = (string)A_1;
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x00036B5C File Offset: 0x00034D5C
		public static IPropertyInfo Chip3Text!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip3Text!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip3Text!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip3Text!Field = new ClrPropertyInfo("Chip3Text", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip3Text!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip3Text!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip3Text!Field;
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x00036BB0 File Offset: 0x00034DB0
		static object Chip4Text!Getter(object A_0)
		{
			return ((AddTransactionWindowViewModel)A_0).Chip4Text;
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x00036BC8 File Offset: 0x00034DC8
		static void Chip4Text!Setter(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Chip4Text = (string)A_1;
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x00036BE8 File Offset: 0x00034DE8
		public static IPropertyInfo Chip4Text!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip4Text!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip4Text!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip4Text!Field = new ClrPropertyInfo("Chip4Text", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip4Text!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip4Text!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip4Text!Field;
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x00036C3C File Offset: 0x00034E3C
		static object Chip5Text!Getter(object A_0)
		{
			return ((AddTransactionWindowViewModel)A_0).Chip5Text;
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x00036C54 File Offset: 0x00034E54
		static void Chip5Text!Setter(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).Chip5Text = (string)A_1;
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x00036C74 File Offset: 0x00034E74
		public static IPropertyInfo Chip5Text!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip5Text!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip5Text!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip5Text!Field = new ClrPropertyInfo("Chip5Text", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip5Text!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip5Text!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.Chip5Text!Field;
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x00036CC8 File Offset: 0x00034EC8
		static object MyTransaction!Getter(object A_0)
		{
			return ((AddTransactionWindowViewModel)A_0).MyTransaction;
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x00036CE0 File Offset: 0x00034EE0
		static void MyTransaction!Setter(object A_0, object A_1)
		{
			((AddTransactionWindowViewModel)A_0).MyTransaction = (Transaction)A_1;
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x00036D00 File Offset: 0x00034F00
		public static IPropertyInfo MyTransaction!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.MyTransaction!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.MyTransaction!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.MyTransaction!Field = new ClrPropertyInfo("MyTransaction", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.MyTransaction!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.MyTransaction!Setter), typeof(Transaction));
			return XamlIlHelpers.Exodus.ViewModels.AddTransactionWindowViewModel,Exodus.MyTransaction!Field;
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x00036D54 File Offset: 0x00034F54
		static object From!Getter(object A_0)
		{
			return ((Transaction)A_0).From;
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x00036D6C File Offset: 0x00034F6C
		static void From!Setter(object A_0, object A_1)
		{
			((Transaction)A_0).From = (string)A_1;
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x00036D8C File Offset: 0x00034F8C
		public static IPropertyInfo From!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Transaction,Exodus.From!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Transaction,Exodus.From!Field;
			}
			XamlIlHelpers.Exodus.Models.Transaction,Exodus.From!Field = new ClrPropertyInfo("From", new Func<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.From!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.From!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.Transaction,Exodus.From!Field;
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x00036DE0 File Offset: 0x00034FE0
		static object To!Getter(object A_0)
		{
			return ((Transaction)A_0).To;
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x00036DF8 File Offset: 0x00034FF8
		static void To!Setter(object A_0, object A_1)
		{
			((Transaction)A_0).To = (string)A_1;
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x00036E18 File Offset: 0x00035018
		public static IPropertyInfo To!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Transaction,Exodus.To!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Transaction,Exodus.To!Field;
			}
			XamlIlHelpers.Exodus.Models.Transaction,Exodus.To!Field = new ClrPropertyInfo("To", new Func<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.To!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.To!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.Transaction,Exodus.To!Field;
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x00036E6C File Offset: 0x0003506C
		static object TransactionId!Getter(object A_0)
		{
			return ((Transaction)A_0).TransactionId;
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x00036E84 File Offset: 0x00035084
		static void TransactionId!Setter(object A_0, object A_1)
		{
			((Transaction)A_0).TransactionId = (string)A_1;
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x00036EA4 File Offset: 0x000350A4
		public static IPropertyInfo TransactionId!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Transaction,Exodus.TransactionId!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Transaction,Exodus.TransactionId!Field;
			}
			XamlIlHelpers.Exodus.Models.Transaction,Exodus.TransactionId!Field = new ClrPropertyInfo("TransactionId", new Func<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.TransactionId!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.TransactionId!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.Transaction,Exodus.TransactionId!Field;
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x00036EF8 File Offset: 0x000350F8
		static object Height!Getter(object A_0)
		{
			return ((Rect)A_0).Height;
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x00036F18 File Offset: 0x00035118
		public static IPropertyInfo Height!Property()
		{
			if (XamlIlHelpers.Avalonia.Rect,Avalonia.Base.Height!Field != null)
			{
				return XamlIlHelpers.Avalonia.Rect,Avalonia.Base.Height!Field;
			}
			XamlIlHelpers.Avalonia.Rect,Avalonia.Base.Height!Field = new ClrPropertyInfo("Height", new Func<object, object>(XamlIlHelpers.Avalonia.Rect,Avalonia.Base.Height!Getter), null, typeof(double));
			return XamlIlHelpers.Avalonia.Rect,Avalonia.Base.Height!Field;
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x00036F60 File Offset: 0x00035160
		static object SelectedFiat!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).SelectedFiat;
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x00036F78 File Offset: 0x00035178
		static void SelectedFiat!Setter(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).SelectedFiat = (FiatItem)A_1;
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x00036F98 File Offset: 0x00035198
		public static IPropertyInfo SelectedFiat!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedFiat!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedFiat!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedFiat!Field = new ClrPropertyInfo("SelectedFiat", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedFiat!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedFiat!Setter), typeof(FiatItem));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedFiat!Field;
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x00036FEC File Offset: 0x000351EC
		static object FlagEmoji!Getter(object A_0)
		{
			return ((FiatItem)A_0).FlagEmoji;
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x00037004 File Offset: 0x00035204
		static void FlagEmoji!Setter(object A_0, object A_1)
		{
			((FiatItem)A_0).FlagEmoji = (string)A_1;
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x00037024 File Offset: 0x00035224
		public static IPropertyInfo FlagEmoji!Property()
		{
			if (XamlIlHelpers.Exodus.Models.FiatItem,Exodus.FlagEmoji!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.FiatItem,Exodus.FlagEmoji!Field;
			}
			XamlIlHelpers.Exodus.Models.FiatItem,Exodus.FlagEmoji!Field = new ClrPropertyInfo("FlagEmoji", new Func<object, object>(XamlIlHelpers.Exodus.Models.FiatItem,Exodus.FlagEmoji!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.FiatItem,Exodus.FlagEmoji!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.FiatItem,Exodus.FlagEmoji!Field;
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x00037078 File Offset: 0x00035278
		static object Code!Getter(object A_0)
		{
			return ((FiatItem)A_0).Code;
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x00037090 File Offset: 0x00035290
		static void Code!Setter(object A_0, object A_1)
		{
			((FiatItem)A_0).Code = (string)A_1;
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x000370B0 File Offset: 0x000352B0
		public static IPropertyInfo Code!Property()
		{
			if (XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Code!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Code!Field;
			}
			XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Code!Field = new ClrPropertyInfo("Code", new Func<object, object>(XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Code!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Code!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Code!Field;
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x00037104 File Offset: 0x00035304
		static object PayAmountString!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).PayAmountString;
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x0003711C File Offset: 0x0003531C
		static void PayAmountString!Setter(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).PayAmountString = (string)A_1;
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x0003713C File Offset: 0x0003533C
		public static IPropertyInfo PayAmountString!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.PayAmountString!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.PayAmountString!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.PayAmountString!Field = new ClrPropertyInfo("PayAmountString", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.PayAmountString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.PayAmountString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.PayAmountString!Field;
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x00037190 File Offset: 0x00035390
		static object SelectedCrypto!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).SelectedCrypto;
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x000371A8 File Offset: 0x000353A8
		static void SelectedCrypto!Setter(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).SelectedCrypto = (SwapCoinItem)A_1;
		}

		// Token: 0x0600042D RID: 1069 RVA: 0x000371C8 File Offset: 0x000353C8
		public static IPropertyInfo SelectedCrypto!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedCrypto!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedCrypto!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedCrypto!Field = new ClrPropertyInfo("SelectedCrypto", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedCrypto!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedCrypto!Setter), typeof(SwapCoinItem));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedCrypto!Field;
		}

		// Token: 0x0600042E RID: 1070 RVA: 0x0003721C File Offset: 0x0003541C
		static object Icon!Getter(object A_0)
		{
			return ((SwapCoinItem)A_0).Icon;
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x00037234 File Offset: 0x00035434
		static void Icon!Setter(object A_0, object A_1)
		{
			((SwapCoinItem)A_0).Icon = (Bitmap)A_1;
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x00037254 File Offset: 0x00035454
		public static IPropertyInfo Icon!Property()
		{
			if (XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Icon!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Icon!Field;
			}
			XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Icon!Field = new ClrPropertyInfo("Icon", new Func<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Icon!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Icon!Setter), typeof(Bitmap));
			return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Icon!Field;
		}

		// Token: 0x06000431 RID: 1073 RVA: 0x000372A8 File Offset: 0x000354A8
		static object Symbol!Getter(object A_0)
		{
			return ((SwapCoinItem)A_0).Symbol;
		}

		// Token: 0x06000432 RID: 1074 RVA: 0x000372C0 File Offset: 0x000354C0
		static void Symbol!Setter(object A_0, object A_1)
		{
			((SwapCoinItem)A_0).Symbol = (string)A_1;
		}

		// Token: 0x06000433 RID: 1075 RVA: 0x000372E0 File Offset: 0x000354E0
		public static IPropertyInfo Symbol!Property()
		{
			if (XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Symbol!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Symbol!Field;
			}
			XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Symbol!Field = new ClrPropertyInfo("Symbol", new Func<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Symbol!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Symbol!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Symbol!Field;
		}

		// Token: 0x06000434 RID: 1076 RVA: 0x00037334 File Offset: 0x00035534
		static object ReceiveCryptoString!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).ReceiveCryptoString;
		}

		// Token: 0x06000435 RID: 1077 RVA: 0x0003734C File Offset: 0x0003554C
		static void ReceiveCryptoString!Setter(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).ReceiveCryptoString = (string)A_1;
		}

		// Token: 0x06000436 RID: 1078 RVA: 0x0003736C File Offset: 0x0003556C
		public static IPropertyInfo ReceiveCryptoString!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ReceiveCryptoString!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ReceiveCryptoString!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ReceiveCryptoString!Field = new ClrPropertyInfo("ReceiveCryptoString", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ReceiveCryptoString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ReceiveCryptoString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ReceiveCryptoString!Field;
		}

		// Token: 0x06000437 RID: 1079 RVA: 0x000373C0 File Offset: 0x000355C0
		static object RateInfoText!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).RateInfoText;
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x000373D8 File Offset: 0x000355D8
		static void RateInfoText!Setter(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).RateInfoText = (string)A_1;
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x000373F8 File Offset: 0x000355F8
		public static IPropertyInfo RateInfoText!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.RateInfoText!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.RateInfoText!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.RateInfoText!Field = new ClrPropertyInfo("RateInfoText", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.RateInfoText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.RateInfoText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.RateInfoText!Field;
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x0003744C File Offset: 0x0003564C
		static object IsCryptoPickerOpen!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).IsCryptoPickerOpen;
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x0003746C File Offset: 0x0003566C
		static void IsCryptoPickerOpen!Setter(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).IsCryptoPickerOpen = (bool)A_1;
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x0003748C File Offset: 0x0003568C
		public static IPropertyInfo IsCryptoPickerOpen!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsCryptoPickerOpen!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsCryptoPickerOpen!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsCryptoPickerOpen!Field = new ClrPropertyInfo("IsCryptoPickerOpen", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsCryptoPickerOpen!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsCryptoPickerOpen!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsCryptoPickerOpen!Field;
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x000374E0 File Offset: 0x000356E0
		static object SearchQuery!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).SearchQuery;
		}

		// Token: 0x0600043E RID: 1086 RVA: 0x000374F8 File Offset: 0x000356F8
		static void SearchQuery!Setter(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).SearchQuery = (string)A_1;
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x00037518 File Offset: 0x00035718
		public static IPropertyInfo SearchQuery!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SearchQuery!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SearchQuery!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SearchQuery!Field = new ClrPropertyInfo("SearchQuery", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SearchQuery!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SearchQuery!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SearchQuery!Field;
		}

		// Token: 0x06000440 RID: 1088 RVA: 0x0003756C File Offset: 0x0003576C
		static object FilteredCryptoCoins!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).FilteredCryptoCoins;
		}

		// Token: 0x06000441 RID: 1089 RVA: 0x00037584 File Offset: 0x00035784
		public static IPropertyInfo FilteredCryptoCoins!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FilteredCryptoCoins!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FilteredCryptoCoins!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FilteredCryptoCoins!Field = new ClrPropertyInfo("FilteredCryptoCoins", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FilteredCryptoCoins!Getter), null, typeof(ObservableCollection<SwapCoinItem>));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FilteredCryptoCoins!Field;
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x000375CC File Offset: 0x000357CC
		static object SubNetwork!Getter(object A_0)
		{
			return ((SwapCoinItem)A_0).SubNetwork;
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x000375E4 File Offset: 0x000357E4
		static void SubNetwork!Setter(object A_0, object A_1)
		{
			((SwapCoinItem)A_0).SubNetwork = (string)A_1;
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x00037604 File Offset: 0x00035804
		public static IPropertyInfo SubNetwork!Property()
		{
			if (XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.SubNetwork!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.SubNetwork!Field;
			}
			XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.SubNetwork!Field = new ClrPropertyInfo("SubNetwork", new Func<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.SubNetwork!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.SubNetwork!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.SubNetwork!Field;
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x00037658 File Offset: 0x00035858
		static object Name!Getter(object A_0)
		{
			return ((SwapCoinItem)A_0).Name;
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x00037670 File Offset: 0x00035870
		static void Name!Setter(object A_0, object A_1)
		{
			((SwapCoinItem)A_0).Name = (string)A_1;
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x00037690 File Offset: 0x00035890
		public static IPropertyInfo Name!Property()
		{
			if (XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Name!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Name!Field;
			}
			XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Name!Field = new ClrPropertyInfo("Name", new Func<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Name!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Name!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Name!Field;
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x000376E4 File Offset: 0x000358E4
		static object DisplaySubtitle!Getter(object A_0)
		{
			return ((SwapCoinItem)A_0).DisplaySubtitle;
		}

		// Token: 0x06000449 RID: 1097 RVA: 0x000376FC File Offset: 0x000358FC
		static void DisplaySubtitle!Setter(object A_0, object A_1)
		{
			((SwapCoinItem)A_0).DisplaySubtitle = (string)A_1;
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x0003771C File Offset: 0x0003591C
		public static IPropertyInfo DisplaySubtitle!Property()
		{
			if (XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.DisplaySubtitle!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.DisplaySubtitle!Field;
			}
			XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.DisplaySubtitle!Field = new ClrPropertyInfo("DisplaySubtitle", new Func<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.DisplaySubtitle!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.DisplaySubtitle!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.DisplaySubtitle!Field;
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x00037770 File Offset: 0x00035970
		static object ValueInUsdString!Getter(object A_0)
		{
			return ((SwapCoinItem)A_0).ValueInUsdString;
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x00037788 File Offset: 0x00035988
		static void ValueInUsdString!Setter(object A_0, object A_1)
		{
			((SwapCoinItem)A_0).ValueInUsdString = (string)A_1;
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x000377A8 File Offset: 0x000359A8
		public static IPropertyInfo ValueInUsdString!Property()
		{
			if (XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.ValueInUsdString!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.ValueInUsdString!Field;
			}
			XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.ValueInUsdString!Field = new ClrPropertyInfo("ValueInUsdString", new Func<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.ValueInUsdString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.ValueInUsdString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.ValueInUsdString!Field;
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x000377FC File Offset: 0x000359FC
		static object IsFiatPickerOpen!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).IsFiatPickerOpen;
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x0003781C File Offset: 0x00035A1C
		static void IsFiatPickerOpen!Setter(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).IsFiatPickerOpen = (bool)A_1;
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x0003783C File Offset: 0x00035A3C
		public static IPropertyInfo IsFiatPickerOpen!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsFiatPickerOpen!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsFiatPickerOpen!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsFiatPickerOpen!Field = new ClrPropertyInfo("IsFiatPickerOpen", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsFiatPickerOpen!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsFiatPickerOpen!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsFiatPickerOpen!Field;
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x00037890 File Offset: 0x00035A90
		static object FiatCurrencies!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).FiatCurrencies;
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x000378A8 File Offset: 0x00035AA8
		public static IPropertyInfo FiatCurrencies!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FiatCurrencies!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FiatCurrencies!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FiatCurrencies!Field = new ClrPropertyInfo("FiatCurrencies", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FiatCurrencies!Getter), null, typeof(List<FiatItem>));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FiatCurrencies!Field;
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x000378F0 File Offset: 0x00035AF0
		static object Name!Getter(object A_0)
		{
			return ((FiatItem)A_0).Name;
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x00037908 File Offset: 0x00035B08
		static void Name!Setter(object A_0, object A_1)
		{
			((FiatItem)A_0).Name = (string)A_1;
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x00037928 File Offset: 0x00035B28
		public static IPropertyInfo Name!Property()
		{
			if (XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Name!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Name!Field;
			}
			XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Name!Field = new ClrPropertyInfo("Name", new Func<object, object>(XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Name!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Name!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Name!Field;
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x0003797C File Offset: 0x00035B7C
		static object IsToastVisible!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).IsToastVisible;
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x0003799C File Offset: 0x00035B9C
		static void IsToastVisible!Setter(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).IsToastVisible = (bool)A_1;
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x000379BC File Offset: 0x00035BBC
		public static IPropertyInfo IsToastVisible!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsToastVisible!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsToastVisible!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsToastVisible!Field = new ClrPropertyInfo("IsToastVisible", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsToastVisible!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsToastVisible!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsToastVisible!Field;
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x00037A10 File Offset: 0x00035C10
		static object ToastMessage!Getter(object A_0)
		{
			return ((BuySellViewModel)A_0).ToastMessage;
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x00037A28 File Offset: 0x00035C28
		static void ToastMessage!Setter(object A_0, object A_1)
		{
			((BuySellViewModel)A_0).ToastMessage = (string)A_1;
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x00037A48 File Offset: 0x00035C48
		public static IPropertyInfo ToastMessage!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ToastMessage!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ToastMessage!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ToastMessage!Field = new ClrPropertyInfo("ToastMessage", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ToastMessage!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ToastMessage!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ToastMessage!Field;
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x00037A9C File Offset: 0x00035C9C
		static object BannerControlHeight!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).BannerControlHeight;
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x00037ABC File Offset: 0x00035CBC
		static void BannerControlHeight!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).BannerControlHeight = (double)A_1;
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x00037ADC File Offset: 0x00035CDC
		public static IPropertyInfo BannerControlHeight!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControlHeight!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControlHeight!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControlHeight!Field = new ClrPropertyInfo("BannerControlHeight", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControlHeight!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControlHeight!Setter), typeof(double));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControlHeight!Field;
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x00037B30 File Offset: 0x00035D30
		static object IsShowRefresh!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).IsShowRefresh;
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x00037B50 File Offset: 0x00035D50
		static void IsShowRefresh!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).IsShowRefresh = (bool)A_1;
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x00037B70 File Offset: 0x00035D70
		public static IPropertyInfo IsShowRefresh!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowRefresh!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowRefresh!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowRefresh!Field = new ClrPropertyInfo("IsShowRefresh", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowRefresh!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowRefresh!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowRefresh!Field;
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x00037BC4 File Offset: 0x00035DC4
		static object BannerControl!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).BannerControl;
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x00037BDC File Offset: 0x00035DDC
		static void BannerControl!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).BannerControl = (DataTemplate)A_1;
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x00037BFC File Offset: 0x00035DFC
		public static IPropertyInfo BannerControl!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControl!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControl!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControl!Field = new ClrPropertyInfo("BannerControl", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControl!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControl!Setter), typeof(DataTemplate));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControl!Field;
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x00037C50 File Offset: 0x00035E50
		static object Foreground2!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).Foreground2;
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x00037C68 File Offset: 0x00035E68
		static void Foreground2!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).Foreground2 = (LinearGradientBrush)A_1;
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x00037C88 File Offset: 0x00035E88
		public static IPropertyInfo Foreground2!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground2!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground2!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground2!Field = new ClrPropertyInfo("Foreground2", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground2!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground2!Setter), typeof(LinearGradientBrush));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground2!Field;
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x00037CDC File Offset: 0x00035EDC
		static object IsPlayRefresh!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).IsPlayRefresh;
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x00037CFC File Offset: 0x00035EFC
		static void IsPlayRefresh!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).IsPlayRefresh = (bool)A_1;
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x00037D1C File Offset: 0x00035F1C
		public static IPropertyInfo IsPlayRefresh!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsPlayRefresh!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsPlayRefresh!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsPlayRefresh!Field = new ClrPropertyInfo("IsPlayRefresh", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsPlayRefresh!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsPlayRefresh!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsPlayRefresh!Field;
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x00037D70 File Offset: 0x00035F70
		static object IsShowNetworkPill!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).IsShowNetworkPill;
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x00037D90 File Offset: 0x00035F90
		static void IsShowNetworkPill!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).IsShowNetworkPill = (bool)A_1;
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x00037DB0 File Offset: 0x00035FB0
		public static IPropertyInfo IsShowNetworkPill!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowNetworkPill!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowNetworkPill!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowNetworkPill!Field = new ClrPropertyInfo("IsShowNetworkPill", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowNetworkPill!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowNetworkPill!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowNetworkPill!Field;
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x00037E04 File Offset: 0x00036004
		static object NetworkPillIcon!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).NetworkPillIcon;
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x00037E1C File Offset: 0x0003601C
		static void NetworkPillIcon!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).NetworkPillIcon = (Bitmap)A_1;
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x00037E3C File Offset: 0x0003603C
		public static IPropertyInfo NetworkPillIcon!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillIcon!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillIcon!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillIcon!Field = new ClrPropertyInfo("NetworkPillIcon", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillIcon!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillIcon!Setter), typeof(Bitmap));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillIcon!Field;
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x00037E90 File Offset: 0x00036090
		static object HasNetworkPillIcon!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).HasNetworkPillIcon;
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x00037EB0 File Offset: 0x000360B0
		static void HasNetworkPillIcon!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).HasNetworkPillIcon = (bool)A_1;
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x00037ED0 File Offset: 0x000360D0
		public static IPropertyInfo HasNetworkPillIcon!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.HasNetworkPillIcon!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.HasNetworkPillIcon!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.HasNetworkPillIcon!Field = new ClrPropertyInfo("HasNetworkPillIcon", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.HasNetworkPillIcon!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.HasNetworkPillIcon!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.HasNetworkPillIcon!Field;
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x00037F24 File Offset: 0x00036124
		static object NetworkPillText!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).NetworkPillText;
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x00037F3C File Offset: 0x0003613C
		static void NetworkPillText!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).NetworkPillText = (string)A_1;
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x00037F5C File Offset: 0x0003615C
		public static IPropertyInfo NetworkPillText!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillText!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillText!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillText!Field = new ClrPropertyInfo("NetworkPillText", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillText!Field;
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x00037FB0 File Offset: 0x000361B0
		static object NetworkPillHasDropdown!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).NetworkPillHasDropdown;
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x00037FD0 File Offset: 0x000361D0
		static void NetworkPillHasDropdown!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).NetworkPillHasDropdown = (bool)A_1;
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x00037FF0 File Offset: 0x000361F0
		public static IPropertyInfo NetworkPillHasDropdown!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillHasDropdown!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillHasDropdown!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillHasDropdown!Field = new ClrPropertyInfo("NetworkPillHasDropdown", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillHasDropdown!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillHasDropdown!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillHasDropdown!Field;
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x00038044 File Offset: 0x00036244
		static object FormattedBalance!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).FormattedBalance;
		}

		// Token: 0x0600047B RID: 1147 RVA: 0x0003805C File Offset: 0x0003625C
		static void FormattedBalance!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).FormattedBalance = (string)A_1;
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x0003807C File Offset: 0x0003627C
		public static IPropertyInfo FormattedBalance!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.FormattedBalance!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.FormattedBalance!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.FormattedBalance!Field = new ClrPropertyInfo("FormattedBalance", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.FormattedBalance!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.FormattedBalance!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.FormattedBalance!Field;
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x000380D0 File Offset: 0x000362D0
		static object Foreground1!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).Foreground1;
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x000380E8 File Offset: 0x000362E8
		static void Foreground1!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).Foreground1 = (SolidColorBrush)A_1;
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x00038108 File Offset: 0x00036308
		public static IPropertyInfo Foreground1!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Field = new ClrPropertyInfo("Foreground1", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Setter), typeof(SolidColorBrush));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Field;
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x0003815C File Offset: 0x0003635C
		static object MyCoin!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).MyCoin;
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x00038174 File Offset: 0x00036374
		static void MyCoin!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).MyCoin = (Coin)A_1;
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x00038194 File Offset: 0x00036394
		public static IPropertyInfo MyCoin!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.MyCoin!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.MyCoin!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.MyCoin!Field = new ClrPropertyInfo("MyCoin", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.MyCoin!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.MyCoin!Setter), typeof(Coin));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.MyCoin!Field;
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x000381E8 File Offset: 0x000363E8
		static object Symbol!Getter(object A_0)
		{
			return ((Coin)A_0).Symbol;
		}

		// Token: 0x06000484 RID: 1156 RVA: 0x00038200 File Offset: 0x00036400
		static void Symbol!Setter(object A_0, object A_1)
		{
			((Coin)A_0).Symbol = (string)A_1;
		}

		// Token: 0x06000485 RID: 1157 RVA: 0x00038220 File Offset: 0x00036420
		public static IPropertyInfo Symbol!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Coin,Exodus.Symbol!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Coin,Exodus.Symbol!Field;
			}
			XamlIlHelpers.Exodus.Models.Coin,Exodus.Symbol!Field = new ClrPropertyInfo("Symbol", new Func<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.Symbol!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.Symbol!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.Coin,Exodus.Symbol!Field;
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x00038274 File Offset: 0x00036474
		static object BalanceInUsdString!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).BalanceInUsdString;
		}

		// Token: 0x06000487 RID: 1159 RVA: 0x0003828C File Offset: 0x0003648C
		static void BalanceInUsdString!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).BalanceInUsdString = (string)A_1;
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x000382AC File Offset: 0x000364AC
		public static IPropertyInfo BalanceInUsdString!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BalanceInUsdString!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BalanceInUsdString!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BalanceInUsdString!Field = new ClrPropertyInfo("BalanceInUsdString", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BalanceInUsdString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BalanceInUsdString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BalanceInUsdString!Field;
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x00038300 File Offset: 0x00036500
		static object IsEthereum!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).IsEthereum;
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x00038320 File Offset: 0x00036520
		static void IsEthereum!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).IsEthereum = (bool)A_1;
		}

		// Token: 0x0600048B RID: 1163 RVA: 0x00038340 File Offset: 0x00036540
		public static IPropertyInfo IsEthereum!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Field = new ClrPropertyInfo("IsEthereum", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Field;
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x00038394 File Offset: 0x00036594
		static object IsTherePendingTransaction!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).IsTherePendingTransaction;
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x000383B4 File Offset: 0x000365B4
		static void IsTherePendingTransaction!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).IsTherePendingTransaction = (bool)A_1;
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x000383D4 File Offset: 0x000365D4
		public static IPropertyInfo IsTherePendingTransaction!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsTherePendingTransaction!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsTherePendingTransaction!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsTherePendingTransaction!Field = new ClrPropertyInfo("IsTherePendingTransaction", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsTherePendingTransaction!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsTherePendingTransaction!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsTherePendingTransaction!Field;
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x00038428 File Offset: 0x00036628
		static object TotalInPending!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).TotalInPending;
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x00038440 File Offset: 0x00036640
		static void TotalInPending!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).TotalInPending = (string)A_1;
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x00038460 File Offset: 0x00036660
		public static IPropertyInfo TotalInPending!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TotalInPending!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TotalInPending!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TotalInPending!Field = new ClrPropertyInfo("TotalInPending", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TotalInPending!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TotalInPending!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TotalInPending!Field;
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x000384B4 File Offset: 0x000366B4
		static object IsShowGasWarning!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).IsShowGasWarning;
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x000384D4 File Offset: 0x000366D4
		static void IsShowGasWarning!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).IsShowGasWarning = (bool)A_1;
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x000384F4 File Offset: 0x000366F4
		public static IPropertyInfo IsShowGasWarning!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowGasWarning!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowGasWarning!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowGasWarning!Field = new ClrPropertyInfo("IsShowGasWarning", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowGasWarning!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowGasWarning!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowGasWarning!Field;
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x00038548 File Offset: 0x00036748
		static object IsEmpty!Getter(object A_0)
		{
			return ((Coin)A_0).IsEmpty;
		}

		// Token: 0x06000496 RID: 1174 RVA: 0x00038568 File Offset: 0x00036768
		static void IsEmpty!Setter(object A_0, object A_1)
		{
			((Coin)A_0).IsEmpty = (bool)A_1;
		}

		// Token: 0x06000497 RID: 1175 RVA: 0x00038588 File Offset: 0x00036788
		public static IPropertyInfo IsEmpty!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Coin,Exodus.IsEmpty!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Coin,Exodus.IsEmpty!Field;
			}
			XamlIlHelpers.Exodus.Models.Coin,Exodus.IsEmpty!Field = new ClrPropertyInfo("IsEmpty", new Func<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsEmpty!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsEmpty!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.Models.Coin,Exodus.IsEmpty!Field;
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x000385DC File Offset: 0x000367DC
		static object GasWarningText!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).GasWarningText;
		}

		// Token: 0x06000499 RID: 1177 RVA: 0x000385F4 File Offset: 0x000367F4
		static void GasWarningText!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).GasWarningText = (string)A_1;
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x00038614 File Offset: 0x00036814
		public static IPropertyInfo GasWarningText!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.GasWarningText!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.GasWarningText!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.GasWarningText!Field = new ClrPropertyInfo("GasWarningText", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.GasWarningText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.GasWarningText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.GasWarningText!Field;
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x00038668 File Offset: 0x00036868
		static object IsThereAnyTransaction!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).IsThereAnyTransaction;
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x00038688 File Offset: 0x00036888
		static void IsThereAnyTransaction!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).IsThereAnyTransaction = (bool)A_1;
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x000386A8 File Offset: 0x000368A8
		public static IPropertyInfo IsThereAnyTransaction!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereAnyTransaction!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereAnyTransaction!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereAnyTransaction!Field = new ClrPropertyInfo("IsThereAnyTransaction", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereAnyTransaction!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereAnyTransaction!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereAnyTransaction!Field;
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x000386FC File Offset: 0x000368FC
		static object NoTransactionText!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).NoTransactionText;
		}

		// Token: 0x0600049F RID: 1183 RVA: 0x00038714 File Offset: 0x00036914
		static void NoTransactionText!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).NoTransactionText = (string)A_1;
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x00038734 File Offset: 0x00036934
		public static IPropertyInfo NoTransactionText!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NoTransactionText!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NoTransactionText!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NoTransactionText!Field = new ClrPropertyInfo("NoTransactionText", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NoTransactionText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NoTransactionText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NoTransactionText!Field;
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x00038788 File Offset: 0x00036988
		static object PendingTransactions!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).PendingTransactions;
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x000387A0 File Offset: 0x000369A0
		static void PendingTransactions!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).PendingTransactions = (ObservableCollection<Transaction>)A_1;
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x000387C0 File Offset: 0x000369C0
		public static IPropertyInfo PendingTransactions!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.PendingTransactions!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.PendingTransactions!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.PendingTransactions!Field = new ClrPropertyInfo("PendingTransactions", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.PendingTransactions!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.PendingTransactions!Setter), typeof(ObservableCollection<Transaction>));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.PendingTransactions!Field;
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x00038814 File Offset: 0x00036A14
		static object HeaderBackgroundColor!Getter(object A_0)
		{
			return ((Transaction)A_0).HeaderBackgroundColor;
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x0003882C File Offset: 0x00036A2C
		static void HeaderBackgroundColor!Setter(object A_0, object A_1)
		{
			((Transaction)A_0).HeaderBackgroundColor = (SolidColorBrush)A_1;
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x0003884C File Offset: 0x00036A4C
		public static IPropertyInfo HeaderBackgroundColor!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Transaction,Exodus.HeaderBackgroundColor!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Transaction,Exodus.HeaderBackgroundColor!Field;
			}
			XamlIlHelpers.Exodus.Models.Transaction,Exodus.HeaderBackgroundColor!Field = new ClrPropertyInfo("HeaderBackgroundColor", new Func<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.HeaderBackgroundColor!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.HeaderBackgroundColor!Setter), typeof(SolidColorBrush));
			return XamlIlHelpers.Exodus.Models.Transaction,Exodus.HeaderBackgroundColor!Field;
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x000388A0 File Offset: 0x00036AA0
		static object Value!Getter(object A_0)
		{
			return ((Setter)A_0).Value;
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x000388B8 File Offset: 0x00036AB8
		static void Value!Setter(object A_0, object A_1)
		{
			((Setter)A_0).Value = (object)A_1;
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x000388D8 File Offset: 0x00036AD8
		public static IPropertyInfo Value!Property()
		{
			if (XamlIlHelpers.Avalonia.Styling.Setter,Avalonia.Base.Value!Field != null)
			{
				return XamlIlHelpers.Avalonia.Styling.Setter,Avalonia.Base.Value!Field;
			}
			XamlIlHelpers.Avalonia.Styling.Setter,Avalonia.Base.Value!Field = new ClrPropertyInfo("Value", new Func<object, object>(XamlIlHelpers.Avalonia.Styling.Setter,Avalonia.Base.Value!Getter), new Action<object, object>(XamlIlHelpers.Avalonia.Styling.Setter,Avalonia.Base.Value!Setter), typeof(object));
			return XamlIlHelpers.Avalonia.Styling.Setter,Avalonia.Base.Value!Field;
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x0003892C File Offset: 0x00036B2C
		static object FormattedAmount!Getter(object A_0)
		{
			return ((Transaction)A_0).FormattedAmount;
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x00038944 File Offset: 0x00036B44
		static void FormattedAmount!Setter(object A_0, object A_1)
		{
			((Transaction)A_0).FormattedAmount = (string)A_1;
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x00038964 File Offset: 0x00036B64
		public static IPropertyInfo FormattedAmount!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Transaction,Exodus.FormattedAmount!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Transaction,Exodus.FormattedAmount!Field;
			}
			XamlIlHelpers.Exodus.Models.Transaction,Exodus.FormattedAmount!Field = new ClrPropertyInfo("FormattedAmount", new Func<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.FormattedAmount!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.FormattedAmount!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.Transaction,Exodus.FormattedAmount!Field;
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x000389B8 File Offset: 0x00036BB8
		static object IsExpanded!Getter(object A_0)
		{
			return ((Transaction)A_0).IsExpanded;
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x000389D8 File Offset: 0x00036BD8
		static void IsExpanded!Setter(object A_0, object A_1)
		{
			((Transaction)A_0).IsExpanded = (bool)A_1;
		}

		// Token: 0x060004AF RID: 1199 RVA: 0x000389F8 File Offset: 0x00036BF8
		public static IPropertyInfo IsExpanded!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Field;
			}
			XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Field = new ClrPropertyInfo("IsExpanded", new Func<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Field;
		}

		// Token: 0x060004B0 RID: 1200 RVA: 0x00038A4C File Offset: 0x00036C4C
		static object TimeString!Getter(object A_0)
		{
			return ((Transaction)A_0).TimeString;
		}

		// Token: 0x060004B1 RID: 1201 RVA: 0x00038A64 File Offset: 0x00036C64
		static void TimeString!Setter(object A_0, object A_1)
		{
			((Transaction)A_0).TimeString = (string)A_1;
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x00038A84 File Offset: 0x00036C84
		public static IPropertyInfo TimeString!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Transaction,Exodus.TimeString!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Transaction,Exodus.TimeString!Field;
			}
			XamlIlHelpers.Exodus.Models.Transaction,Exodus.TimeString!Field = new ClrPropertyInfo("TimeString", new Func<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.TimeString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.TimeString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.Transaction,Exodus.TimeString!Field;
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x00038AD8 File Offset: 0x00036CD8
		static object PriceNowString!Getter(object A_0)
		{
			return ((Transaction)A_0).PriceNowString;
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x00038AF0 File Offset: 0x00036CF0
		static void PriceNowString!Setter(object A_0, object A_1)
		{
			((Transaction)A_0).PriceNowString = (string)A_1;
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x00038B10 File Offset: 0x00036D10
		public static IPropertyInfo PriceNowString!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Transaction,Exodus.PriceNowString!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Transaction,Exodus.PriceNowString!Field;
			}
			XamlIlHelpers.Exodus.Models.Transaction,Exodus.PriceNowString!Field = new ClrPropertyInfo("PriceNowString", new Func<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.PriceNowString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.PriceNowString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.Transaction,Exodus.PriceNowString!Field;
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x00038B64 File Offset: 0x00036D64
		static object TransactionsGroups!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).TransactionsGroups;
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x00038B7C File Offset: 0x00036D7C
		static void TransactionsGroups!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).TransactionsGroups = (ObservableCollection<TransactionGroup>)A_1;
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x00038B9C File Offset: 0x00036D9C
		public static IPropertyInfo TransactionsGroups!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TransactionsGroups!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TransactionsGroups!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TransactionsGroups!Field = new ClrPropertyInfo("TransactionsGroups", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TransactionsGroups!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TransactionsGroups!Setter), typeof(ObservableCollection<TransactionGroup>));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TransactionsGroups!Field;
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x00038BF0 File Offset: 0x00036DF0
		static object IsThereTransaction!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).IsThereTransaction;
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x00038C10 File Offset: 0x00036E10
		static void IsThereTransaction!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).IsThereTransaction = (bool)A_1;
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x00038C30 File Offset: 0x00036E30
		public static IPropertyInfo IsThereTransaction!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereTransaction!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereTransaction!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereTransaction!Field = new ClrPropertyInfo("IsThereTransaction", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereTransaction!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereTransaction!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereTransaction!Field;
		}

		// Token: 0x060004BC RID: 1212 RVA: 0x00038C84 File Offset: 0x00036E84
		static object IsThereTransaction!Getter(object A_0)
		{
			return ((TransactionGroup)A_0).IsThereTransaction;
		}

		// Token: 0x060004BD RID: 1213 RVA: 0x00038CA4 File Offset: 0x00036EA4
		static void IsThereTransaction!Setter(object A_0, object A_1)
		{
			((TransactionGroup)A_0).IsThereTransaction = (bool)A_1;
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x00038CC4 File Offset: 0x00036EC4
		public static IPropertyInfo IsThereTransaction!Property()
		{
			if (XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.IsThereTransaction!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.IsThereTransaction!Field;
			}
			XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.IsThereTransaction!Field = new ClrPropertyInfo("IsThereTransaction", new Func<object, object>(XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.IsThereTransaction!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.IsThereTransaction!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.IsThereTransaction!Field;
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x00038D18 File Offset: 0x00036F18
		static object DateTitle!Getter(object A_0)
		{
			return ((TransactionGroup)A_0).DateTitle;
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x00038D30 File Offset: 0x00036F30
		static void DateTitle!Setter(object A_0, object A_1)
		{
			((TransactionGroup)A_0).DateTitle = (string)A_1;
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x00038D50 File Offset: 0x00036F50
		public static IPropertyInfo DateTitle!Property()
		{
			if (XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.DateTitle!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.DateTitle!Field;
			}
			XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.DateTitle!Field = new ClrPropertyInfo("DateTitle", new Func<object, object>(XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.DateTitle!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.DateTitle!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.DateTitle!Field;
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x00038DA4 File Offset: 0x00036FA4
		static object Transactions!Getter(object A_0)
		{
			return ((TransactionGroup)A_0).Transactions;
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x00038DBC File Offset: 0x00036FBC
		static void Transactions!Setter(object A_0, object A_1)
		{
			((TransactionGroup)A_0).Transactions = (ObservableCollection<Transaction>)A_1;
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x00038DDC File Offset: 0x00036FDC
		public static IPropertyInfo Transactions!Property()
		{
			if (XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.Transactions!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.Transactions!Field;
			}
			XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.Transactions!Field = new ClrPropertyInfo("Transactions", new Func<object, object>(XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.Transactions!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.Transactions!Setter), typeof(ObservableCollection<Transaction>));
			return XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.Transactions!Field;
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x00038E30 File Offset: 0x00037030
		static object SentDurationsAgo!Getter(object A_0)
		{
			return ((Transaction)A_0).SentDurationsAgo;
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x00038E48 File Offset: 0x00037048
		static void SentDurationsAgo!Setter(object A_0, object A_1)
		{
			((Transaction)A_0).SentDurationsAgo = (string)A_1;
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x00038E68 File Offset: 0x00037068
		public static IPropertyInfo SentDurationsAgo!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Transaction,Exodus.SentDurationsAgo!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Transaction,Exodus.SentDurationsAgo!Field;
			}
			XamlIlHelpers.Exodus.Models.Transaction,Exodus.SentDurationsAgo!Field = new ClrPropertyInfo("SentDurationsAgo", new Func<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.SentDurationsAgo!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Transaction,Exodus.SentDurationsAgo!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.Transaction,Exodus.SentDurationsAgo!Field;
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x00038EBC File Offset: 0x000370BC
		static object WindowTitle!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).WindowTitle;
		}

		// Token: 0x060004C9 RID: 1225 RVA: 0x00038ED4 File Offset: 0x000370D4
		static void WindowTitle!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).WindowTitle = (string)A_1;
		}

		// Token: 0x060004CA RID: 1226 RVA: 0x00038EF4 File Offset: 0x000370F4
		public static IPropertyInfo WindowTitle!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.WindowTitle!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.WindowTitle!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.WindowTitle!Field = new ClrPropertyInfo("WindowTitle", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.WindowTitle!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.WindowTitle!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.WindowTitle!Field;
		}

		// Token: 0x060004CB RID: 1227 RVA: 0x00038F48 File Offset: 0x00037148
		static object NotificationViewModel!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).NotificationViewModel;
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x00038F60 File Offset: 0x00037160
		static void NotificationViewModel!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).NotificationViewModel = (NotificationViewModel)A_1;
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x00038F80 File Offset: 0x00037180
		public static IPropertyInfo NotificationViewModel!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.NotificationViewModel!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.NotificationViewModel!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.NotificationViewModel!Field = new ClrPropertyInfo("NotificationViewModel", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.NotificationViewModel!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.NotificationViewModel!Setter), typeof(NotificationViewModel));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.NotificationViewModel!Field;
		}

		// Token: 0x060004CE RID: 1230 RVA: 0x00038FD4 File Offset: 0x000371D4
		static object IsShow!Getter(object A_0)
		{
			return ((NotificationViewModel)A_0).IsShow;
		}

		// Token: 0x060004CF RID: 1231 RVA: 0x00038FF4 File Offset: 0x000371F4
		static void IsShow!Setter(object A_0, object A_1)
		{
			((NotificationViewModel)A_0).IsShow = (bool)A_1;
		}

		// Token: 0x060004D0 RID: 1232 RVA: 0x00039014 File Offset: 0x00037214
		public static IPropertyInfo IsShow!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsShow!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsShow!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsShow!Field = new ClrPropertyInfo("IsShow", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsShow!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsShow!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsShow!Field;
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x00039068 File Offset: 0x00037268
		static object IsNotification!Getter(object A_0)
		{
			return ((NotificationViewModel)A_0).IsNotification;
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x00039088 File Offset: 0x00037288
		static void IsNotification!Setter(object A_0, object A_1)
		{
			((NotificationViewModel)A_0).IsNotification = (bool)A_1;
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x000390A8 File Offset: 0x000372A8
		public static IPropertyInfo IsNotification!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsNotification!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsNotification!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsNotification!Field = new ClrPropertyInfo("IsNotification", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsNotification!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsNotification!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsNotification!Field;
		}

		// Token: 0x060004D4 RID: 1236 RVA: 0x000390FC File Offset: 0x000372FC
		static object ReceiveAddressViewModel!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).ReceiveAddressViewModel;
		}

		// Token: 0x060004D5 RID: 1237 RVA: 0x00039114 File Offset: 0x00037314
		static void ReceiveAddressViewModel!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).ReceiveAddressViewModel = (ReceiveAddressViewModel)A_1;
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x00039134 File Offset: 0x00037334
		public static IPropertyInfo ReceiveAddressViewModel!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.ReceiveAddressViewModel!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.ReceiveAddressViewModel!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.ReceiveAddressViewModel!Field = new ClrPropertyInfo("ReceiveAddressViewModel", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.ReceiveAddressViewModel!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.ReceiveAddressViewModel!Setter), typeof(ReceiveAddressViewModel));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.ReceiveAddressViewModel!Field;
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x00039188 File Offset: 0x00037388
		static object IsVisible!Getter(object A_0)
		{
			return ((ReceiveAddressViewModel)A_0).IsVisible;
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x000391A8 File Offset: 0x000373A8
		static void IsVisible!Setter(object A_0, object A_1)
		{
			((ReceiveAddressViewModel)A_0).IsVisible = (bool)A_1;
		}

		// Token: 0x060004D9 RID: 1241 RVA: 0x000391C8 File Offset: 0x000373C8
		public static IPropertyInfo IsVisible!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsVisible!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsVisible!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsVisible!Field = new ClrPropertyInfo("IsVisible", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsVisible!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsVisible!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsVisible!Field;
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x0003921C File Offset: 0x0003741C
		static object RefreshViewModel!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).RefreshViewModel;
		}

		// Token: 0x060004DB RID: 1243 RVA: 0x00039234 File Offset: 0x00037434
		static void RefreshViewModel!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).RefreshViewModel = (RefreshViewModel)A_1;
		}

		// Token: 0x060004DC RID: 1244 RVA: 0x00039254 File Offset: 0x00037454
		public static IPropertyInfo RefreshViewModel!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.RefreshViewModel!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.RefreshViewModel!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.RefreshViewModel!Field = new ClrPropertyInfo("RefreshViewModel", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.RefreshViewModel!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.RefreshViewModel!Setter), typeof(RefreshViewModel));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.RefreshViewModel!Field;
		}

		// Token: 0x060004DD RID: 1245 RVA: 0x000392A8 File Offset: 0x000374A8
		static object IsVisible!Getter(object A_0)
		{
			return ((RefreshViewModel)A_0).IsVisible;
		}

		// Token: 0x060004DE RID: 1246 RVA: 0x000392C8 File Offset: 0x000374C8
		static void IsVisible!Setter(object A_0, object A_1)
		{
			((RefreshViewModel)A_0).IsVisible = (bool)A_1;
		}

		// Token: 0x060004DF RID: 1247 RVA: 0x000392E8 File Offset: 0x000374E8
		public static IPropertyInfo IsVisible!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsVisible!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsVisible!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsVisible!Field = new ClrPropertyInfo("IsVisible", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsVisible!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsVisible!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsVisible!Field;
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x0003933C File Offset: 0x0003753C
		static object SettingsModalViewModel!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).SettingsModalViewModel;
		}

		// Token: 0x060004E1 RID: 1249 RVA: 0x00039354 File Offset: 0x00037554
		static void SettingsModalViewModel!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).SettingsModalViewModel = (SettingsModalViewModel)A_1;
		}

		// Token: 0x060004E2 RID: 1250 RVA: 0x00039374 File Offset: 0x00037574
		public static IPropertyInfo SettingsModalViewModel!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SettingsModalViewModel!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SettingsModalViewModel!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SettingsModalViewModel!Field = new ClrPropertyInfo("SettingsModalViewModel", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SettingsModalViewModel!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SettingsModalViewModel!Setter), typeof(SettingsModalViewModel));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SettingsModalViewModel!Field;
		}

		// Token: 0x060004E3 RID: 1251 RVA: 0x000393C8 File Offset: 0x000375C8
		static object IsVisible!Getter(object A_0)
		{
			return ((SettingsModalViewModel)A_0).IsVisible;
		}

		// Token: 0x060004E4 RID: 1252 RVA: 0x000393E8 File Offset: 0x000375E8
		static void IsVisible!Setter(object A_0, object A_1)
		{
			((SettingsModalViewModel)A_0).IsVisible = (bool)A_1;
		}

		// Token: 0x060004E5 RID: 1253 RVA: 0x00039408 File Offset: 0x00037608
		public static IPropertyInfo IsVisible!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsVisible!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsVisible!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsVisible!Field = new ClrPropertyInfo("IsVisible", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsVisible!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsVisible!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsVisible!Field;
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x0003945C File Offset: 0x0003765C
		static object IsPortfolioViewActive!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).IsPortfolioViewActive;
		}

		// Token: 0x060004E7 RID: 1255 RVA: 0x0003947C File Offset: 0x0003767C
		static void IsPortfolioViewActive!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).IsPortfolioViewActive = (bool)A_1;
		}

		// Token: 0x060004E8 RID: 1256 RVA: 0x0003949C File Offset: 0x0003769C
		public static IPropertyInfo IsPortfolioViewActive!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsPortfolioViewActive!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsPortfolioViewActive!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsPortfolioViewActive!Field = new ClrPropertyInfo("IsPortfolioViewActive", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsPortfolioViewActive!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsPortfolioViewActive!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsPortfolioViewActive!Field;
		}

		// Token: 0x060004E9 RID: 1257 RVA: 0x000394F0 File Offset: 0x000376F0
		static object TotalBalanceInUsdPlayerString!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).TotalBalanceInUsdPlayerString;
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x00039508 File Offset: 0x00037708
		static void TotalBalanceInUsdPlayerString!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).TotalBalanceInUsdPlayerString = (string)A_1;
		}

		// Token: 0x060004EB RID: 1259 RVA: 0x00039528 File Offset: 0x00037728
		public static IPropertyInfo TotalBalanceInUsdPlayerString!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.TotalBalanceInUsdPlayerString!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.TotalBalanceInUsdPlayerString!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.TotalBalanceInUsdPlayerString!Field = new ClrPropertyInfo("TotalBalanceInUsdPlayerString", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.TotalBalanceInUsdPlayerString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.TotalBalanceInUsdPlayerString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.TotalBalanceInUsdPlayerString!Field;
		}

		// Token: 0x060004EC RID: 1260 RVA: 0x0003957C File Offset: 0x0003777C
		static object IsWalletViewActive!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).IsWalletViewActive;
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x0003959C File Offset: 0x0003779C
		static void IsWalletViewActive!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).IsWalletViewActive = (bool)A_1;
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x000395BC File Offset: 0x000377BC
		public static IPropertyInfo IsWalletViewActive!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsWalletViewActive!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsWalletViewActive!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsWalletViewActive!Field = new ClrPropertyInfo("IsWalletViewActive", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsWalletViewActive!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsWalletViewActive!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsWalletViewActive!Field;
		}

		// Token: 0x060004EF RID: 1263 RVA: 0x00039610 File Offset: 0x00037810
		static object IsSwapViewActive!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).IsSwapViewActive;
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x00039630 File Offset: 0x00037830
		static void IsSwapViewActive!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).IsSwapViewActive = (bool)A_1;
		}

		// Token: 0x060004F1 RID: 1265 RVA: 0x00039650 File Offset: 0x00037850
		public static IPropertyInfo IsSwapViewActive!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsSwapViewActive!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsSwapViewActive!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsSwapViewActive!Field = new ClrPropertyInfo("IsSwapViewActive", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsSwapViewActive!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsSwapViewActive!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsSwapViewActive!Field;
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x000396A4 File Offset: 0x000378A4
		static object IsBuySellViewActive!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).IsBuySellViewActive;
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x000396C4 File Offset: 0x000378C4
		static void IsBuySellViewActive!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).IsBuySellViewActive = (bool)A_1;
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x000396E4 File Offset: 0x000378E4
		public static IPropertyInfo IsBuySellViewActive!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsBuySellViewActive!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsBuySellViewActive!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsBuySellViewActive!Field = new ClrPropertyInfo("IsBuySellViewActive", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsBuySellViewActive!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsBuySellViewActive!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsBuySellViewActive!Field;
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x00039738 File Offset: 0x00037938
		static object PortfolioViewModel!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).PortfolioViewModel;
		}

		// Token: 0x060004F6 RID: 1270 RVA: 0x00039750 File Offset: 0x00037950
		static void PortfolioViewModel!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).PortfolioViewModel = (PortfolioViewModel)A_1;
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x00039770 File Offset: 0x00037970
		public static IPropertyInfo PortfolioViewModel!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.PortfolioViewModel!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.PortfolioViewModel!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.PortfolioViewModel!Field = new ClrPropertyInfo("PortfolioViewModel", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.PortfolioViewModel!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.PortfolioViewModel!Setter), typeof(PortfolioViewModel));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.PortfolioViewModel!Field;
		}

		// Token: 0x060004F8 RID: 1272 RVA: 0x000397C4 File Offset: 0x000379C4
		static object SwapViewModel!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).SwapViewModel;
		}

		// Token: 0x060004F9 RID: 1273 RVA: 0x000397DC File Offset: 0x000379DC
		static void SwapViewModel!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).SwapViewModel = (SwapViewModel)A_1;
		}

		// Token: 0x060004FA RID: 1274 RVA: 0x000397FC File Offset: 0x000379FC
		public static IPropertyInfo SwapViewModel!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SwapViewModel!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SwapViewModel!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SwapViewModel!Field = new ClrPropertyInfo("SwapViewModel", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SwapViewModel!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SwapViewModel!Setter), typeof(SwapViewModel));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SwapViewModel!Field;
		}

		// Token: 0x060004FB RID: 1275 RVA: 0x00039850 File Offset: 0x00037A50
		static object BuySellViewModel!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).BuySellViewModel;
		}

		// Token: 0x060004FC RID: 1276 RVA: 0x00039868 File Offset: 0x00037A68
		static void BuySellViewModel!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).BuySellViewModel = (BuySellViewModel)A_1;
		}

		// Token: 0x060004FD RID: 1277 RVA: 0x00039888 File Offset: 0x00037A88
		public static IPropertyInfo BuySellViewModel!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.BuySellViewModel!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.BuySellViewModel!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.BuySellViewModel!Field = new ClrPropertyInfo("BuySellViewModel", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.BuySellViewModel!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.BuySellViewModel!Setter), typeof(BuySellViewModel));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.BuySellViewModel!Field;
		}

		// Token: 0x060004FE RID: 1278 RVA: 0x000398DC File Offset: 0x00037ADC
		static object Coins!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).Coins;
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x000398F4 File Offset: 0x00037AF4
		static void Coins!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).Coins = (ObservableCollection<Coin>)A_1;
		}

		// Token: 0x06000500 RID: 1280 RVA: 0x00039914 File Offset: 0x00037B14
		public static IPropertyInfo Coins!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.Coins!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.Coins!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.Coins!Field = new ClrPropertyInfo("Coins", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.Coins!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.Coins!Setter), typeof(ObservableCollection<Coin>));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.Coins!Field;
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x00039968 File Offset: 0x00037B68
		static object IsShowPercentageIcon!Getter(object A_0)
		{
			return ((Coin)A_0).IsShowPercentageIcon;
		}

		// Token: 0x06000502 RID: 1282 RVA: 0x00039988 File Offset: 0x00037B88
		static void IsShowPercentageIcon!Setter(object A_0, object A_1)
		{
			((Coin)A_0).IsShowPercentageIcon = (bool)A_1;
		}

		// Token: 0x06000503 RID: 1283 RVA: 0x000399A8 File Offset: 0x00037BA8
		public static IPropertyInfo IsShowPercentageIcon!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Coin,Exodus.IsShowPercentageIcon!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Coin,Exodus.IsShowPercentageIcon!Field;
			}
			XamlIlHelpers.Exodus.Models.Coin,Exodus.IsShowPercentageIcon!Field = new ClrPropertyInfo("IsShowPercentageIcon", new Func<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsShowPercentageIcon!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsShowPercentageIcon!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.Models.Coin,Exodus.IsShowPercentageIcon!Field;
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x000399FC File Offset: 0x00037BFC
		static object IsSelected!Getter(object A_0)
		{
			return ((Coin)A_0).IsSelected;
		}

		// Token: 0x06000505 RID: 1285 RVA: 0x00039A1C File Offset: 0x00037C1C
		static void IsSelected!Setter(object A_0, object A_1)
		{
			((Coin)A_0).IsSelected = (bool)A_1;
		}

		// Token: 0x06000506 RID: 1286 RVA: 0x00039A3C File Offset: 0x00037C3C
		public static IPropertyInfo IsSelected!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Coin,Exodus.IsSelected!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Coin,Exodus.IsSelected!Field;
			}
			XamlIlHelpers.Exodus.Models.Coin,Exodus.IsSelected!Field = new ClrPropertyInfo("IsSelected", new Func<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsSelected!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsSelected!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.Models.Coin,Exodus.IsSelected!Field;
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x00039A90 File Offset: 0x00037C90
		static object Name!Getter(object A_0)
		{
			return ((Coin)A_0).Name;
		}

		// Token: 0x06000508 RID: 1288 RVA: 0x00039AA8 File Offset: 0x00037CA8
		static void Name!Setter(object A_0, object A_1)
		{
			((Coin)A_0).Name = (string)A_1;
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x00039AC8 File Offset: 0x00037CC8
		public static IPropertyInfo Name!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Coin,Exodus.Name!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Coin,Exodus.Name!Field;
			}
			XamlIlHelpers.Exodus.Models.Coin,Exodus.Name!Field = new ClrPropertyInfo("Name", new Func<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.Name!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.Name!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.Coin,Exodus.Name!Field;
		}

		// Token: 0x0600050A RID: 1290 RVA: 0x00039B1C File Offset: 0x00037D1C
		static object ViewPart!Getter(object A_0)
		{
			return ((Coin)A_0).ViewPart;
		}

		// Token: 0x0600050B RID: 1291 RVA: 0x00039B34 File Offset: 0x00037D34
		static void ViewPart!Setter(object A_0, object A_1)
		{
			((Coin)A_0).ViewPart = (CoinSpecificPartViewModel)A_1;
		}

		// Token: 0x0600050C RID: 1292 RVA: 0x00039B54 File Offset: 0x00037D54
		public static IPropertyInfo ViewPart!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Coin,Exodus.ViewPart!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Coin,Exodus.ViewPart!Field;
			}
			XamlIlHelpers.Exodus.Models.Coin,Exodus.ViewPart!Field = new ClrPropertyInfo("ViewPart", new Func<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.ViewPart!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.ViewPart!Setter), typeof(CoinSpecificPartViewModel));
			return XamlIlHelpers.Exodus.Models.Coin,Exodus.ViewPart!Field;
		}

		// Token: 0x0600050D RID: 1293 RVA: 0x00039BA8 File Offset: 0x00037DA8
		static object IsBscNetwork!Getter(object A_0)
		{
			return ((Coin)A_0).IsBscNetwork;
		}

		// Token: 0x0600050E RID: 1294 RVA: 0x00039BC8 File Offset: 0x00037DC8
		public static IPropertyInfo IsBscNetwork!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Coin,Exodus.IsBscNetwork!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Coin,Exodus.IsBscNetwork!Field;
			}
			XamlIlHelpers.Exodus.Models.Coin,Exodus.IsBscNetwork!Field = new ClrPropertyInfo("IsBscNetwork", new Func<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsBscNetwork!Getter), null, typeof(bool));
			return XamlIlHelpers.Exodus.Models.Coin,Exodus.IsBscNetwork!Field;
		}

		// Token: 0x0600050F RID: 1295 RVA: 0x00039C10 File Offset: 0x00037E10
		static object FormattedBalance!Getter(object A_0)
		{
			return ((Coin)A_0).FormattedBalance;
		}

		// Token: 0x06000510 RID: 1296 RVA: 0x00039C28 File Offset: 0x00037E28
		static void FormattedBalance!Setter(object A_0, object A_1)
		{
			((Coin)A_0).FormattedBalance = (string)A_1;
		}

		// Token: 0x06000511 RID: 1297 RVA: 0x00039C48 File Offset: 0x00037E48
		public static IPropertyInfo FormattedBalance!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Coin,Exodus.FormattedBalance!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Coin,Exodus.FormattedBalance!Field;
			}
			XamlIlHelpers.Exodus.Models.Coin,Exodus.FormattedBalance!Field = new ClrPropertyInfo("FormattedBalance", new Func<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.FormattedBalance!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.FormattedBalance!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.Coin,Exodus.FormattedBalance!Field;
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x00039C9C File Offset: 0x00037E9C
		static object SelectedCoinViewPart!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).SelectedCoinViewPart;
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x00039CB4 File Offset: 0x00037EB4
		static void SelectedCoinViewPart!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).SelectedCoinViewPart = (CoinSpecificPartViewModel)A_1;
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x00039CD4 File Offset: 0x00037ED4
		public static IPropertyInfo SelectedCoinViewPart!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Field = new ClrPropertyInfo("SelectedCoinViewPart", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Setter), typeof(CoinSpecificPartViewModel));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Field;
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x00039D28 File Offset: 0x00037F28
		static object Logo!Getter(object A_0)
		{
			return ((NotificationViewModel)A_0).Logo;
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x00039D40 File Offset: 0x00037F40
		static void Logo!Setter(object A_0, object A_1)
		{
			((NotificationViewModel)A_0).Logo = (Bitmap)A_1;
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x00039D60 File Offset: 0x00037F60
		public static IPropertyInfo Logo!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.Logo!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.Logo!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.Logo!Field = new ClrPropertyInfo("Logo", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.Logo!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.Logo!Setter), typeof(Bitmap));
			return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.Logo!Field;
		}

		// Token: 0x06000518 RID: 1304 RVA: 0x00039DB4 File Offset: 0x00037FB4
		static object ViewPart!Getter(object A_0)
		{
			return ((NotificationViewModel)A_0).ViewPart;
		}

		// Token: 0x06000519 RID: 1305 RVA: 0x00039DCC File Offset: 0x00037FCC
		static void ViewPart!Setter(object A_0, object A_1)
		{
			((NotificationViewModel)A_0).ViewPart = (CoinSpecificPartViewModel)A_1;
		}

		// Token: 0x0600051A RID: 1306 RVA: 0x00039DEC File Offset: 0x00037FEC
		public static IPropertyInfo ViewPart!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.ViewPart!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.ViewPart!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.ViewPart!Field = new ClrPropertyInfo("ViewPart", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.ViewPart!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.ViewPart!Setter), typeof(CoinSpecificPartViewModel));
			return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.ViewPart!Field;
		}

		// Token: 0x0600051B RID: 1307 RVA: 0x00039E40 File Offset: 0x00038040
		static object CurrentlyAdded!Getter(object A_0)
		{
			return ((NotificationViewModel)A_0).CurrentlyAdded;
		}

		// Token: 0x0600051C RID: 1308 RVA: 0x00039E60 File Offset: 0x00038060
		static void CurrentlyAdded!Setter(object A_0, object A_1)
		{
			((NotificationViewModel)A_0).CurrentlyAdded = (double)A_1;
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x00039E80 File Offset: 0x00038080
		public static IPropertyInfo CurrentlyAdded!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CurrentlyAdded!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CurrentlyAdded!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CurrentlyAdded!Field = new ClrPropertyInfo("CurrentlyAdded", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CurrentlyAdded!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CurrentlyAdded!Setter), typeof(double));
			return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CurrentlyAdded!Field;
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x00039ED4 File Offset: 0x000380D4
		static object CloseNotification!Getter(object A_0)
		{
			return ((NotificationViewModel)A_0).CloseNotification;
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x00039EEC File Offset: 0x000380EC
		static void CloseNotification!Setter(object A_0, object A_1)
		{
			((NotificationViewModel)A_0).CloseNotification = (ReactiveCommand<Unit, Unit>)A_1;
		}

		// Token: 0x06000520 RID: 1312 RVA: 0x00039F0C File Offset: 0x0003810C
		public static IPropertyInfo CloseNotification!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CloseNotification!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CloseNotification!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CloseNotification!Field = new ClrPropertyInfo("CloseNotification", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CloseNotification!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CloseNotification!Setter), typeof(ReactiveCommand<Unit, Unit>));
			return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CloseNotification!Field;
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x00039F60 File Offset: 0x00038160
		static object NotificationStripeWidth!Getter(object A_0)
		{
			return ((NotificationViewModel)A_0).NotificationStripeWidth;
		}

		// Token: 0x06000522 RID: 1314 RVA: 0x00039F80 File Offset: 0x00038180
		static void NotificationStripeWidth!Setter(object A_0, object A_1)
		{
			((NotificationViewModel)A_0).NotificationStripeWidth = (double)A_1;
		}

		// Token: 0x06000523 RID: 1315 RVA: 0x00039FA0 File Offset: 0x000381A0
		public static IPropertyInfo NotificationStripeWidth!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.NotificationStripeWidth!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.NotificationStripeWidth!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.NotificationStripeWidth!Field = new ClrPropertyInfo("NotificationStripeWidth", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.NotificationStripeWidth!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.NotificationStripeWidth!Setter), typeof(double));
			return XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.NotificationStripeWidth!Field;
		}

		// Token: 0x06000524 RID: 1316 RVA: 0x00039FF4 File Offset: 0x000381F4
		static object DonutSegments!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).DonutSegments;
		}

		// Token: 0x06000525 RID: 1317 RVA: 0x0003A00C File Offset: 0x0003820C
		public static IPropertyInfo DonutSegments!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DonutSegments!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DonutSegments!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DonutSegments!Field = new ClrPropertyInfo("DonutSegments", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DonutSegments!Getter), null, typeof(ObservableCollection<DonutSegment>));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DonutSegments!Field;
		}

		// Token: 0x06000526 RID: 1318 RVA: 0x0003A054 File Offset: 0x00038254
		static object PathData!Getter(object A_0)
		{
			return ((DonutSegment)A_0).PathData;
		}

		// Token: 0x06000527 RID: 1319 RVA: 0x0003A06C File Offset: 0x0003826C
		static void PathData!Setter(object A_0, object A_1)
		{
			((DonutSegment)A_0).PathData = (string)A_1;
		}

		// Token: 0x06000528 RID: 1320 RVA: 0x0003A08C File Offset: 0x0003828C
		public static IPropertyInfo PathData!Property()
		{
			if (XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.PathData!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.PathData!Field;
			}
			XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.PathData!Field = new ClrPropertyInfo("PathData", new Func<object, object>(XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.PathData!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.PathData!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.PathData!Field;
		}

		// Token: 0x06000529 RID: 1321 RVA: 0x0003A0E0 File Offset: 0x000382E0
		static object Brush!Getter(object A_0)
		{
			return ((DonutSegment)A_0).Brush;
		}

		// Token: 0x0600052A RID: 1322 RVA: 0x0003A0F8 File Offset: 0x000382F8
		static void Brush!Setter(object A_0, object A_1)
		{
			((DonutSegment)A_0).Brush = (IBrush)A_1;
		}

		// Token: 0x0600052B RID: 1323 RVA: 0x0003A118 File Offset: 0x00038318
		public static IPropertyInfo Brush!Property()
		{
			if (XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.Brush!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.Brush!Field;
			}
			XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.Brush!Field = new ClrPropertyInfo("Brush", new Func<object, object>(XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.Brush!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.Brush!Setter), typeof(IBrush));
			return XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.Brush!Field;
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x0003A16C File Offset: 0x0003836C
		static object TotalBalanceString!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).TotalBalanceString;
		}

		// Token: 0x0600052D RID: 1325 RVA: 0x0003A184 File Offset: 0x00038384
		static void TotalBalanceString!Setter(object A_0, object A_1)
		{
			((PortfolioViewModel)A_0).TotalBalanceString = (string)A_1;
		}

		// Token: 0x0600052E RID: 1326 RVA: 0x0003A1A4 File Offset: 0x000383A4
		public static IPropertyInfo TotalBalanceString!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.TotalBalanceString!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.TotalBalanceString!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.TotalBalanceString!Field = new ClrPropertyInfo("TotalBalanceString", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.TotalBalanceString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.TotalBalanceString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.TotalBalanceString!Field;
		}

		// Token: 0x0600052F RID: 1327 RVA: 0x0003A1F8 File Offset: 0x000383F8
		static object AssetCountText!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).AssetCountText;
		}

		// Token: 0x06000530 RID: 1328 RVA: 0x0003A210 File Offset: 0x00038410
		static void AssetCountText!Setter(object A_0, object A_1)
		{
			((PortfolioViewModel)A_0).AssetCountText = (string)A_1;
		}

		// Token: 0x06000531 RID: 1329 RVA: 0x0003A230 File Offset: 0x00038430
		public static IPropertyInfo AssetCountText!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.AssetCountText!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.AssetCountText!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.AssetCountText!Field = new ClrPropertyInfo("AssetCountText", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.AssetCountText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.AssetCountText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.AssetCountText!Field;
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x0003A284 File Offset: 0x00038484
		static object Change24HString!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).Change24HString;
		}

		// Token: 0x06000533 RID: 1331 RVA: 0x0003A29C File Offset: 0x0003849C
		static void Change24HString!Setter(object A_0, object A_1)
		{
			((PortfolioViewModel)A_0).Change24HString = (string)A_1;
		}

		// Token: 0x06000534 RID: 1332 RVA: 0x0003A2BC File Offset: 0x000384BC
		public static IPropertyInfo Change24HString!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HString!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HString!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HString!Field = new ClrPropertyInfo("Change24HString", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HString!Field;
		}

		// Token: 0x06000535 RID: 1333 RVA: 0x0003A310 File Offset: 0x00038510
		static object Change24HBrush!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).Change24HBrush;
		}

		// Token: 0x06000536 RID: 1334 RVA: 0x0003A328 File Offset: 0x00038528
		static void Change24HBrush!Setter(object A_0, object A_1)
		{
			((PortfolioViewModel)A_0).Change24HBrush = (IBrush)A_1;
		}

		// Token: 0x06000537 RID: 1335 RVA: 0x0003A348 File Offset: 0x00038548
		public static IPropertyInfo Change24HBrush!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HBrush!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HBrush!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HBrush!Field = new ClrPropertyInfo("Change24HBrush", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HBrush!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HBrush!Setter), typeof(IBrush));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HBrush!Field;
		}

		// Token: 0x06000538 RID: 1336 RVA: 0x0003A39C File Offset: 0x0003859C
		static object HighestBalanceText!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).HighestBalanceText;
		}

		// Token: 0x06000539 RID: 1337 RVA: 0x0003A3B4 File Offset: 0x000385B4
		static void HighestBalanceText!Setter(object A_0, object A_1)
		{
			((PortfolioViewModel)A_0).HighestBalanceText = (string)A_1;
		}

		// Token: 0x0600053A RID: 1338 RVA: 0x0003A3D4 File Offset: 0x000385D4
		public static IPropertyInfo HighestBalanceText!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.HighestBalanceText!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.HighestBalanceText!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.HighestBalanceText!Field = new ClrPropertyInfo("HighestBalanceText", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.HighestBalanceText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.HighestBalanceText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.HighestBalanceText!Field;
		}

		// Token: 0x0600053B RID: 1339 RVA: 0x0003A428 File Offset: 0x00038628
		static object PortfolioAgeText!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).PortfolioAgeText;
		}

		// Token: 0x0600053C RID: 1340 RVA: 0x0003A440 File Offset: 0x00038640
		static void PortfolioAgeText!Setter(object A_0, object A_1)
		{
			((PortfolioViewModel)A_0).PortfolioAgeText = (string)A_1;
		}

		// Token: 0x0600053D RID: 1341 RVA: 0x0003A460 File Offset: 0x00038660
		public static IPropertyInfo PortfolioAgeText!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.PortfolioAgeText!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.PortfolioAgeText!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.PortfolioAgeText!Field = new ClrPropertyInfo("PortfolioAgeText", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.PortfolioAgeText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.PortfolioAgeText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.PortfolioAgeText!Field;
		}

		// Token: 0x0600053E RID: 1342 RVA: 0x0003A4B4 File Offset: 0x000386B4
		static object Best24HAsset!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).Best24HAsset;
		}

		// Token: 0x0600053F RID: 1343 RVA: 0x0003A4CC File Offset: 0x000386CC
		static void Best24HAsset!Setter(object A_0, object A_1)
		{
			((PortfolioViewModel)A_0).Best24HAsset = (string)A_1;
		}

		// Token: 0x06000540 RID: 1344 RVA: 0x0003A4EC File Offset: 0x000386EC
		public static IPropertyInfo Best24HAsset!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Best24HAsset!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Best24HAsset!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Best24HAsset!Field = new ClrPropertyInfo("Best24HAsset", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Best24HAsset!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Best24HAsset!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Best24HAsset!Field;
		}

		// Token: 0x06000541 RID: 1345 RVA: 0x0003A540 File Offset: 0x00038740
		static object Worst24HAsset!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).Worst24HAsset;
		}

		// Token: 0x06000542 RID: 1346 RVA: 0x0003A558 File Offset: 0x00038758
		static void Worst24HAsset!Setter(object A_0, object A_1)
		{
			((PortfolioViewModel)A_0).Worst24HAsset = (string)A_1;
		}

		// Token: 0x06000543 RID: 1347 RVA: 0x0003A578 File Offset: 0x00038778
		public static IPropertyInfo Worst24HAsset!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Worst24HAsset!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Worst24HAsset!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Worst24HAsset!Field = new ClrPropertyInfo("Worst24HAsset", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Worst24HAsset!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Worst24HAsset!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Worst24HAsset!Field;
		}

		// Token: 0x06000544 RID: 1348 RVA: 0x0003A5CC File Offset: 0x000387CC
		static object FilterWithBalance!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).FilterWithBalance;
		}

		// Token: 0x06000545 RID: 1349 RVA: 0x0003A5EC File Offset: 0x000387EC
		static void FilterWithBalance!Setter(object A_0, object A_1)
		{
			((PortfolioViewModel)A_0).FilterWithBalance = (bool)A_1;
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x0003A60C File Offset: 0x0003880C
		public static IPropertyInfo FilterWithBalance!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterWithBalance!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterWithBalance!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterWithBalance!Field = new ClrPropertyInfo("FilterWithBalance", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterWithBalance!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterWithBalance!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterWithBalance!Field;
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x0003A660 File Offset: 0x00038860
		static object FilterFavorite!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).FilterFavorite;
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x0003A680 File Offset: 0x00038880
		static void FilterFavorite!Setter(object A_0, object A_1)
		{
			((PortfolioViewModel)A_0).FilterFavorite = (bool)A_1;
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x0003A6A0 File Offset: 0x000388A0
		public static IPropertyInfo FilterFavorite!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterFavorite!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterFavorite!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterFavorite!Field = new ClrPropertyInfo("FilterFavorite", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterFavorite!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterFavorite!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterFavorite!Field;
		}

		// Token: 0x0600054A RID: 1354 RVA: 0x0003A6F4 File Offset: 0x000388F4
		static object DisplayItems!Getter(object A_0)
		{
			return ((PortfolioViewModel)A_0).DisplayItems;
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x0003A70C File Offset: 0x0003890C
		public static IPropertyInfo DisplayItems!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DisplayItems!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DisplayItems!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DisplayItems!Field = new ClrPropertyInfo("DisplayItems", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DisplayItems!Getter), null, typeof(ObservableCollection<PortfolioCoinItem>));
			return XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DisplayItems!Field;
		}

		// Token: 0x0600054C RID: 1356 RVA: 0x0003A754 File Offset: 0x00038954
		static object Icon!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).Icon;
		}

		// Token: 0x0600054D RID: 1357 RVA: 0x0003A76C File Offset: 0x0003896C
		static void Icon!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).Icon = (Bitmap)A_1;
		}

		// Token: 0x0600054E RID: 1358 RVA: 0x0003A78C File Offset: 0x0003898C
		public static IPropertyInfo Icon!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Icon!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Icon!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Icon!Field = new ClrPropertyInfo("Icon", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Icon!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Icon!Setter), typeof(Bitmap));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Icon!Field;
		}

		// Token: 0x0600054F RID: 1359 RVA: 0x0003A7E0 File Offset: 0x000389E0
		static object Name!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).Name;
		}

		// Token: 0x06000550 RID: 1360 RVA: 0x0003A7F8 File Offset: 0x000389F8
		static void Name!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).Name = (string)A_1;
		}

		// Token: 0x06000551 RID: 1361 RVA: 0x0003A818 File Offset: 0x00038A18
		public static IPropertyInfo Name!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Name!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Name!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Name!Field = new ClrPropertyInfo("Name", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Name!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Name!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Name!Field;
		}

		// Token: 0x06000552 RID: 1362 RVA: 0x0003A86C File Offset: 0x00038A6C
		static object IsBsc!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).IsBsc;
		}

		// Token: 0x06000553 RID: 1363 RVA: 0x0003A88C File Offset: 0x00038A8C
		static void IsBsc!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).IsBsc = (bool)A_1;
		}

		// Token: 0x06000554 RID: 1364 RVA: 0x0003A8AC File Offset: 0x00038AAC
		public static IPropertyInfo IsBsc!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.IsBsc!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.IsBsc!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.IsBsc!Field = new ClrPropertyInfo("IsBsc", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.IsBsc!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.IsBsc!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.IsBsc!Field;
		}

		// Token: 0x06000555 RID: 1365 RVA: 0x0003A900 File Offset: 0x00038B00
		static object HasDropdown!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).HasDropdown;
		}

		// Token: 0x06000556 RID: 1366 RVA: 0x0003A920 File Offset: 0x00038B20
		static void HasDropdown!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).HasDropdown = (bool)A_1;
		}

		// Token: 0x06000557 RID: 1367 RVA: 0x0003A940 File Offset: 0x00038B40
		public static IPropertyInfo HasDropdown!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasDropdown!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasDropdown!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasDropdown!Field = new ClrPropertyInfo("HasDropdown", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasDropdown!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasDropdown!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasDropdown!Field;
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x0003A994 File Offset: 0x00038B94
		static object Symbol!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).Symbol;
		}

		// Token: 0x06000559 RID: 1369 RVA: 0x0003A9AC File Offset: 0x00038BAC
		static void Symbol!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).Symbol = (string)A_1;
		}

		// Token: 0x0600055A RID: 1370 RVA: 0x0003A9CC File Offset: 0x00038BCC
		public static IPropertyInfo Symbol!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Symbol!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Symbol!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Symbol!Field = new ClrPropertyInfo("Symbol", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Symbol!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Symbol!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Symbol!Field;
		}

		// Token: 0x0600055B RID: 1371 RVA: 0x0003AA20 File Offset: 0x00038C20
		static object HasApy!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).HasApy;
		}

		// Token: 0x0600055C RID: 1372 RVA: 0x0003AA40 File Offset: 0x00038C40
		static void HasApy!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).HasApy = (bool)A_1;
		}

		// Token: 0x0600055D RID: 1373 RVA: 0x0003AA60 File Offset: 0x00038C60
		public static IPropertyInfo HasApy!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasApy!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasApy!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasApy!Field = new ClrPropertyInfo("HasApy", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasApy!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasApy!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasApy!Field;
		}

		// Token: 0x0600055E RID: 1374 RVA: 0x0003AAB4 File Offset: 0x00038CB4
		static object ApyText!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).ApyText;
		}

		// Token: 0x0600055F RID: 1375 RVA: 0x0003AACC File Offset: 0x00038CCC
		static void ApyText!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).ApyText = (string)A_1;
		}

		// Token: 0x06000560 RID: 1376 RVA: 0x0003AAEC File Offset: 0x00038CEC
		public static IPropertyInfo ApyText!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ApyText!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ApyText!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ApyText!Field = new ClrPropertyInfo("ApyText", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ApyText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ApyText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ApyText!Field;
		}

		// Token: 0x06000561 RID: 1377 RVA: 0x0003AB40 File Offset: 0x00038D40
		static object PriceString!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).PriceString;
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x0003AB58 File Offset: 0x00038D58
		static void PriceString!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).PriceString = (string)A_1;
		}

		// Token: 0x06000563 RID: 1379 RVA: 0x0003AB78 File Offset: 0x00038D78
		public static IPropertyInfo PriceString!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PriceString!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PriceString!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PriceString!Field = new ClrPropertyInfo("PriceString", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PriceString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PriceString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PriceString!Field;
		}

		// Token: 0x06000564 RID: 1380 RVA: 0x0003ABCC File Offset: 0x00038DCC
		static object Change24HString!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).Change24HString;
		}

		// Token: 0x06000565 RID: 1381 RVA: 0x0003ABE4 File Offset: 0x00038DE4
		static void Change24HString!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).Change24HString = (string)A_1;
		}

		// Token: 0x06000566 RID: 1382 RVA: 0x0003AC04 File Offset: 0x00038E04
		public static IPropertyInfo Change24HString!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Change24HString!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Change24HString!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Change24HString!Field = new ClrPropertyInfo("Change24HString", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Change24HString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Change24HString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Change24HString!Field;
		}

		// Token: 0x06000567 RID: 1383 RVA: 0x0003AC58 File Offset: 0x00038E58
		static object ChangeBrush!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).ChangeBrush;
		}

		// Token: 0x06000568 RID: 1384 RVA: 0x0003AC70 File Offset: 0x00038E70
		static void ChangeBrush!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).ChangeBrush = (IBrush)A_1;
		}

		// Token: 0x06000569 RID: 1385 RVA: 0x0003AC90 File Offset: 0x00038E90
		public static IPropertyInfo ChangeBrush!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ChangeBrush!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ChangeBrush!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ChangeBrush!Field = new ClrPropertyInfo("ChangeBrush", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ChangeBrush!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ChangeBrush!Setter), typeof(IBrush));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ChangeBrush!Field;
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x0003ACE4 File Offset: 0x00038EE4
		static object MarketCap!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).MarketCap;
		}

		// Token: 0x0600056B RID: 1387 RVA: 0x0003ACFC File Offset: 0x00038EFC
		static void MarketCap!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).MarketCap = (string)A_1;
		}

		// Token: 0x0600056C RID: 1388 RVA: 0x0003AD1C File Offset: 0x00038F1C
		public static IPropertyInfo MarketCap!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.MarketCap!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.MarketCap!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.MarketCap!Field = new ClrPropertyInfo("MarketCap", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.MarketCap!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.MarketCap!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.MarketCap!Field;
		}

		// Token: 0x0600056D RID: 1389 RVA: 0x0003AD70 File Offset: 0x00038F70
		static object Volume24H!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).Volume24H;
		}

		// Token: 0x0600056E RID: 1390 RVA: 0x0003AD88 File Offset: 0x00038F88
		static void Volume24H!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).Volume24H = (string)A_1;
		}

		// Token: 0x0600056F RID: 1391 RVA: 0x0003ADA8 File Offset: 0x00038FA8
		public static IPropertyInfo Volume24H!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Volume24H!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Volume24H!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Volume24H!Field = new ClrPropertyInfo("Volume24H", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Volume24H!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Volume24H!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Volume24H!Field;
		}

		// Token: 0x06000570 RID: 1392 RVA: 0x0003ADFC File Offset: 0x00038FFC
		static object TrendPath!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).TrendPath;
		}

		// Token: 0x06000571 RID: 1393 RVA: 0x0003AE14 File Offset: 0x00039014
		static void TrendPath!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).TrendPath = (string)A_1;
		}

		// Token: 0x06000572 RID: 1394 RVA: 0x0003AE34 File Offset: 0x00039034
		public static IPropertyInfo TrendPath!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendPath!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendPath!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendPath!Field = new ClrPropertyInfo("TrendPath", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendPath!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendPath!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendPath!Field;
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x0003AE88 File Offset: 0x00039088
		static object TrendBrush!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).TrendBrush;
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x0003AEA0 File Offset: 0x000390A0
		static void TrendBrush!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).TrendBrush = (IBrush)A_1;
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x0003AEC0 File Offset: 0x000390C0
		public static IPropertyInfo TrendBrush!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendBrush!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendBrush!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendBrush!Field = new ClrPropertyInfo("TrendBrush", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendBrush!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendBrush!Setter), typeof(IBrush));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendBrush!Field;
		}

		// Token: 0x06000576 RID: 1398 RVA: 0x0003AF14 File Offset: 0x00039114
		static object BalanceString!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).BalanceString;
		}

		// Token: 0x06000577 RID: 1399 RVA: 0x0003AF2C File Offset: 0x0003912C
		static void BalanceString!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).BalanceString = (string)A_1;
		}

		// Token: 0x06000578 RID: 1400 RVA: 0x0003AF4C File Offset: 0x0003914C
		public static IPropertyInfo BalanceString!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.BalanceString!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.BalanceString!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.BalanceString!Field = new ClrPropertyInfo("BalanceString", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.BalanceString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.BalanceString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.BalanceString!Field;
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x0003AFA0 File Offset: 0x000391A0
		static object ValueInUsdString!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).ValueInUsdString;
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x0003AFB8 File Offset: 0x000391B8
		static void ValueInUsdString!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).ValueInUsdString = (string)A_1;
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x0003AFD8 File Offset: 0x000391D8
		public static IPropertyInfo ValueInUsdString!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ValueInUsdString!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ValueInUsdString!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ValueInUsdString!Field = new ClrPropertyInfo("ValueInUsdString", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ValueInUsdString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ValueInUsdString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ValueInUsdString!Field;
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x0003B02C File Offset: 0x0003922C
		static object PortfolioPercentageString!Getter(object A_0)
		{
			return ((PortfolioCoinItem)A_0).PortfolioPercentageString;
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x0003B044 File Offset: 0x00039244
		static void PortfolioPercentageString!Setter(object A_0, object A_1)
		{
			((PortfolioCoinItem)A_0).PortfolioPercentageString = (string)A_1;
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x0003B064 File Offset: 0x00039264
		public static IPropertyInfo PortfolioPercentageString!Property()
		{
			if (XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PortfolioPercentageString!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PortfolioPercentageString!Field;
			}
			XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PortfolioPercentageString!Field = new ClrPropertyInfo("PortfolioPercentageString", new Func<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PortfolioPercentageString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PortfolioPercentageString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PortfolioPercentageString!Field;
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x0003B0B8 File Offset: 0x000392B8
		static object Opacity!Getter(object A_0)
		{
			return ((ReceiveAddressViewModel)A_0).Opacity;
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x0003B0D8 File Offset: 0x000392D8
		static void Opacity!Setter(object A_0, object A_1)
		{
			((ReceiveAddressViewModel)A_0).Opacity = (double)A_1;
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x0003B0F8 File Offset: 0x000392F8
		public static IPropertyInfo Opacity!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.Opacity!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.Opacity!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.Opacity!Field = new ClrPropertyInfo("Opacity", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.Opacity!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.Opacity!Setter), typeof(double));
			return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.Opacity!Field;
		}

		// Token: 0x06000582 RID: 1410 RVA: 0x0003B14C File Offset: 0x0003934C
		static object SolidOpacity!Getter(object A_0)
		{
			return ((ReceiveAddressViewModel)A_0).SolidOpacity;
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x0003B16C File Offset: 0x0003936C
		static void SolidOpacity!Setter(object A_0, object A_1)
		{
			((ReceiveAddressViewModel)A_0).SolidOpacity = (double)A_1;
		}

		// Token: 0x06000584 RID: 1412 RVA: 0x0003B18C File Offset: 0x0003938C
		public static IPropertyInfo SolidOpacity!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.SolidOpacity!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.SolidOpacity!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.SolidOpacity!Field = new ClrPropertyInfo("SolidOpacity", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.SolidOpacity!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.SolidOpacity!Setter), typeof(double));
			return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.SolidOpacity!Field;
		}

		// Token: 0x06000585 RID: 1413 RVA: 0x0003B1E0 File Offset: 0x000393E0
		static object IsShow!Getter(object A_0)
		{
			return ((ReceiveAddressViewModel)A_0).IsShow;
		}

		// Token: 0x06000586 RID: 1414 RVA: 0x0003B200 File Offset: 0x00039400
		static void IsShow!Setter(object A_0, object A_1)
		{
			((ReceiveAddressViewModel)A_0).IsShow = (bool)A_1;
		}

		// Token: 0x06000587 RID: 1415 RVA: 0x0003B220 File Offset: 0x00039420
		public static IPropertyInfo IsShow!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsShow!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsShow!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsShow!Field = new ClrPropertyInfo("IsShow", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsShow!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsShow!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsShow!Field;
		}

		// Token: 0x06000588 RID: 1416 RVA: 0x0003B274 File Offset: 0x00039474
		static object MainWindowVm!Getter(object A_0)
		{
			return ((ReceiveAddressViewModel)A_0).MainWindowVm;
		}

		// Token: 0x06000589 RID: 1417 RVA: 0x0003B28C File Offset: 0x0003948C
		static void MainWindowVm!Setter(object A_0, object A_1)
		{
			((ReceiveAddressViewModel)A_0).MainWindowVm = (MainWindowViewModel)A_1;
		}

		// Token: 0x0600058A RID: 1418 RVA: 0x0003B2AC File Offset: 0x000394AC
		public static IPropertyInfo MainWindowVm!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Field = new ClrPropertyInfo("MainWindowVm", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Setter), typeof(MainWindowViewModel));
			return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Field;
		}

		// Token: 0x0600058B RID: 1419 RVA: 0x0003B300 File Offset: 0x00039500
		static object YourAddressTitle!Getter(object A_0)
		{
			return ((CoinSpecificPartViewModel)A_0).YourAddressTitle;
		}

		// Token: 0x0600058C RID: 1420 RVA: 0x0003B318 File Offset: 0x00039518
		static void YourAddressTitle!Setter(object A_0, object A_1)
		{
			((CoinSpecificPartViewModel)A_0).YourAddressTitle = (string)A_1;
		}

		// Token: 0x0600058D RID: 1421 RVA: 0x0003B338 File Offset: 0x00039538
		public static IPropertyInfo YourAddressTitle!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.YourAddressTitle!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.YourAddressTitle!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.YourAddressTitle!Field = new ClrPropertyInfo("YourAddressTitle", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.YourAddressTitle!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.YourAddressTitle!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.YourAddressTitle!Field;
		}

		// Token: 0x0600058E RID: 1422 RVA: 0x0003B38C File Offset: 0x0003958C
		static object AddressOpacity!Getter(object A_0)
		{
			return ((ReceiveAddressViewModel)A_0).AddressOpacity;
		}

		// Token: 0x0600058F RID: 1423 RVA: 0x0003B3AC File Offset: 0x000395AC
		static void AddressOpacity!Setter(object A_0, object A_1)
		{
			((ReceiveAddressViewModel)A_0).AddressOpacity = (double)A_1;
		}

		// Token: 0x06000590 RID: 1424 RVA: 0x0003B3CC File Offset: 0x000395CC
		public static IPropertyInfo AddressOpacity!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.AddressOpacity!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.AddressOpacity!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.AddressOpacity!Field = new ClrPropertyInfo("AddressOpacity", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.AddressOpacity!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.AddressOpacity!Setter), typeof(double));
			return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.AddressOpacity!Field;
		}

		// Token: 0x06000591 RID: 1425 RVA: 0x0003B420 File Offset: 0x00039620
		static object SelectedCoin!Getter(object A_0)
		{
			return ((MainWindowViewModel)A_0).SelectedCoin;
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x0003B438 File Offset: 0x00039638
		static void SelectedCoin!Setter(object A_0, object A_1)
		{
			((MainWindowViewModel)A_0).SelectedCoin = (Coin)A_1;
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x0003B458 File Offset: 0x00039658
		public static IPropertyInfo SelectedCoin!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoin!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoin!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoin!Field = new ClrPropertyInfo("SelectedCoin", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoin!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoin!Setter), typeof(Coin));
			return XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoin!Field;
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x0003B4AC File Offset: 0x000396AC
		static object Address!Getter(object A_0)
		{
			return ((Coin)A_0).Address;
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x0003B4C4 File Offset: 0x000396C4
		static void Address!Setter(object A_0, object A_1)
		{
			((Coin)A_0).Address = (string)A_1;
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x0003B4E4 File Offset: 0x000396E4
		public static IPropertyInfo Address!Property()
		{
			if (XamlIlHelpers.Exodus.Models.Coin,Exodus.Address!Field != null)
			{
				return XamlIlHelpers.Exodus.Models.Coin,Exodus.Address!Field;
			}
			XamlIlHelpers.Exodus.Models.Coin,Exodus.Address!Field = new ClrPropertyInfo("Address", new Func<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.Address!Getter), new Action<object, object>(XamlIlHelpers.Exodus.Models.Coin,Exodus.Address!Setter), typeof(string));
			return XamlIlHelpers.Exodus.Models.Coin,Exodus.Address!Field;
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x0003B538 File Offset: 0x00039738
		static object CopyCommand!Getter(object A_0)
		{
			return ((ReceiveAddressViewModel)A_0).CopyCommand;
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x0003B550 File Offset: 0x00039750
		static void CopyCommand!Setter(object A_0, object A_1)
		{
			((ReceiveAddressViewModel)A_0).CopyCommand = (ReactiveCommand<Unit, Unit>)A_1;
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x0003B570 File Offset: 0x00039770
		public static IPropertyInfo CopyCommand!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyCommand!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyCommand!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyCommand!Field = new ClrPropertyInfo("CopyCommand", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyCommand!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyCommand!Setter), typeof(ReactiveCommand<Unit, Unit>));
			return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyCommand!Field;
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x0003B5C4 File Offset: 0x000397C4
		static object CopyOpacity!Getter(object A_0)
		{
			return ((ReceiveAddressViewModel)A_0).CopyOpacity;
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x0003B5E4 File Offset: 0x000397E4
		static void CopyOpacity!Setter(object A_0, object A_1)
		{
			((ReceiveAddressViewModel)A_0).CopyOpacity = (double)A_1;
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x0003B604 File Offset: 0x00039804
		public static IPropertyInfo CopyOpacity!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyOpacity!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyOpacity!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyOpacity!Field = new ClrPropertyInfo("CopyOpacity", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyOpacity!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyOpacity!Setter), typeof(double));
			return XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyOpacity!Field;
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x0003B658 File Offset: 0x00039858
		static object Opacity!Getter(object A_0)
		{
			return ((RefreshViewModel)A_0).Opacity;
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x0003B678 File Offset: 0x00039878
		static void Opacity!Setter(object A_0, object A_1)
		{
			((RefreshViewModel)A_0).Opacity = (double)A_1;
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x0003B698 File Offset: 0x00039898
		public static IPropertyInfo Opacity!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.Opacity!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.Opacity!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.Opacity!Field = new ClrPropertyInfo("Opacity", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.Opacity!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.Opacity!Setter), typeof(double));
			return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.Opacity!Field;
		}

		// Token: 0x060005A0 RID: 1440 RVA: 0x0003B6EC File Offset: 0x000398EC
		static object SolidOpacity!Getter(object A_0)
		{
			return ((RefreshViewModel)A_0).SolidOpacity;
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x0003B70C File Offset: 0x0003990C
		static void SolidOpacity!Setter(object A_0, object A_1)
		{
			((RefreshViewModel)A_0).SolidOpacity = (double)A_1;
		}

		// Token: 0x060005A2 RID: 1442 RVA: 0x0003B72C File Offset: 0x0003992C
		public static IPropertyInfo SolidOpacity!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.SolidOpacity!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.SolidOpacity!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.SolidOpacity!Field = new ClrPropertyInfo("SolidOpacity", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.SolidOpacity!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.SolidOpacity!Setter), typeof(double));
			return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.SolidOpacity!Field;
		}

		// Token: 0x060005A3 RID: 1443 RVA: 0x0003B780 File Offset: 0x00039980
		static object IsShow!Getter(object A_0)
		{
			return ((RefreshViewModel)A_0).IsShow;
		}

		// Token: 0x060005A4 RID: 1444 RVA: 0x0003B7A0 File Offset: 0x000399A0
		static void IsShow!Setter(object A_0, object A_1)
		{
			((RefreshViewModel)A_0).IsShow = (bool)A_1;
		}

		// Token: 0x060005A5 RID: 1445 RVA: 0x0003B7C0 File Offset: 0x000399C0
		public static IPropertyInfo IsShow!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShow!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShow!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShow!Field = new ClrPropertyInfo("IsShow", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShow!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShow!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShow!Field;
		}

		// Token: 0x060005A6 RID: 1446 RVA: 0x0003B814 File Offset: 0x00039A14
		static object RefreshText!Getter(object A_0)
		{
			return ((RefreshViewModel)A_0).RefreshText;
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x0003B82C File Offset: 0x00039A2C
		static void RefreshText!Setter(object A_0, object A_1)
		{
			((RefreshViewModel)A_0).RefreshText = (string)A_1;
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x0003B84C File Offset: 0x00039A4C
		public static IPropertyInfo RefreshText!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.RefreshText!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.RefreshText!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.RefreshText!Field = new ClrPropertyInfo("RefreshText", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.RefreshText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.RefreshText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.RefreshText!Field;
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x0003B8A0 File Offset: 0x00039AA0
		static object IsShowButtons!Getter(object A_0)
		{
			return ((RefreshViewModel)A_0).IsShowButtons;
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x0003B8C0 File Offset: 0x00039AC0
		static void IsShowButtons!Setter(object A_0, object A_1)
		{
			((RefreshViewModel)A_0).IsShowButtons = (bool)A_1;
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x0003B8E0 File Offset: 0x00039AE0
		public static IPropertyInfo IsShowButtons!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShowButtons!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShowButtons!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShowButtons!Field = new ClrPropertyInfo("IsShowButtons", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShowButtons!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShowButtons!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShowButtons!Field;
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x0003B934 File Offset: 0x00039B34
		static object ButtonsOpacity!Getter(object A_0)
		{
			return ((RefreshViewModel)A_0).ButtonsOpacity;
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x0003B954 File Offset: 0x00039B54
		static void ButtonsOpacity!Setter(object A_0, object A_1)
		{
			((RefreshViewModel)A_0).ButtonsOpacity = (double)A_1;
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x0003B974 File Offset: 0x00039B74
		public static IPropertyInfo ButtonsOpacity!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.ButtonsOpacity!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.ButtonsOpacity!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.ButtonsOpacity!Field = new ClrPropertyInfo("ButtonsOpacity", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.ButtonsOpacity!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.ButtonsOpacity!Setter), typeof(double));
			return XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.ButtonsOpacity!Field;
		}

		// Token: 0x060005AF RID: 1455 RVA: 0x0003B9C8 File Offset: 0x00039BC8
		static object Opacity!Getter(object A_0)
		{
			return ((SettingsModalViewModel)A_0).Opacity;
		}

		// Token: 0x060005B0 RID: 1456 RVA: 0x0003B9E8 File Offset: 0x00039BE8
		static void Opacity!Setter(object A_0, object A_1)
		{
			((SettingsModalViewModel)A_0).Opacity = (double)A_1;
		}

		// Token: 0x060005B1 RID: 1457 RVA: 0x0003BA08 File Offset: 0x00039C08
		public static IPropertyInfo Opacity!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.Opacity!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.Opacity!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.Opacity!Field = new ClrPropertyInfo("Opacity", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.Opacity!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.Opacity!Setter), typeof(double));
			return XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.Opacity!Field;
		}

		// Token: 0x060005B2 RID: 1458 RVA: 0x0003BA5C File Offset: 0x00039C5C
		static object VersionBadge!Getter(object A_0)
		{
			return ((SettingsModalViewModel)A_0).VersionBadge;
		}

		// Token: 0x060005B3 RID: 1459 RVA: 0x0003BA74 File Offset: 0x00039C74
		static void VersionBadge!Setter(object A_0, object A_1)
		{
			((SettingsModalViewModel)A_0).VersionBadge = (string)A_1;
		}

		// Token: 0x060005B4 RID: 1460 RVA: 0x0003BA94 File Offset: 0x00039C94
		public static IPropertyInfo VersionBadge!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.VersionBadge!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.VersionBadge!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.VersionBadge!Field = new ClrPropertyInfo("VersionBadge", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.VersionBadge!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.VersionBadge!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.VersionBadge!Field;
		}

		// Token: 0x060005B5 RID: 1461 RVA: 0x0003BAE8 File Offset: 0x00039CE8
		static object IsFeedbackVisible!Getter(object A_0)
		{
			return ((SettingsModalViewModel)A_0).IsFeedbackVisible;
		}

		// Token: 0x060005B6 RID: 1462 RVA: 0x0003BB08 File Offset: 0x00039D08
		static void IsFeedbackVisible!Setter(object A_0, object A_1)
		{
			((SettingsModalViewModel)A_0).IsFeedbackVisible = (bool)A_1;
		}

		// Token: 0x060005B7 RID: 1463 RVA: 0x0003BB28 File Offset: 0x00039D28
		public static IPropertyInfo IsFeedbackVisible!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsFeedbackVisible!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsFeedbackVisible!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsFeedbackVisible!Field = new ClrPropertyInfo("IsFeedbackVisible", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsFeedbackVisible!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsFeedbackVisible!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsFeedbackVisible!Field;
		}

		// Token: 0x060005B8 RID: 1464 RVA: 0x0003BB7C File Offset: 0x00039D7C
		static object CopyFeedbackMessage!Getter(object A_0)
		{
			return ((SettingsModalViewModel)A_0).CopyFeedbackMessage;
		}

		// Token: 0x060005B9 RID: 1465 RVA: 0x0003BB94 File Offset: 0x00039D94
		static void CopyFeedbackMessage!Setter(object A_0, object A_1)
		{
			((SettingsModalViewModel)A_0).CopyFeedbackMessage = (string)A_1;
		}

		// Token: 0x060005BA RID: 1466 RVA: 0x0003BBB4 File Offset: 0x00039DB4
		public static IPropertyInfo CopyFeedbackMessage!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.CopyFeedbackMessage!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.CopyFeedbackMessage!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.CopyFeedbackMessage!Field = new ClrPropertyInfo("CopyFeedbackMessage", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.CopyFeedbackMessage!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.CopyFeedbackMessage!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.CopyFeedbackMessage!Field;
		}

		// Token: 0x060005BB RID: 1467 RVA: 0x0003BC08 File Offset: 0x00039E08
		static object SelectedHaveCoin!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).SelectedHaveCoin;
		}

		// Token: 0x060005BC RID: 1468 RVA: 0x0003BC20 File Offset: 0x00039E20
		static void SelectedHaveCoin!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).SelectedHaveCoin = (SwapCoinItem)A_1;
		}

		// Token: 0x060005BD RID: 1469 RVA: 0x0003BC40 File Offset: 0x00039E40
		public static IPropertyInfo SelectedHaveCoin!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedHaveCoin!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedHaveCoin!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedHaveCoin!Field = new ClrPropertyInfo("SelectedHaveCoin", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedHaveCoin!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedHaveCoin!Setter), typeof(SwapCoinItem));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedHaveCoin!Field;
		}

		// Token: 0x060005BE RID: 1470 RVA: 0x0003BC94 File Offset: 0x00039E94
		static object HaveAmountString!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).HaveAmountString;
		}

		// Token: 0x060005BF RID: 1471 RVA: 0x0003BCAC File Offset: 0x00039EAC
		static void HaveAmountString!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).HaveAmountString = (string)A_1;
		}

		// Token: 0x060005C0 RID: 1472 RVA: 0x0003BCCC File Offset: 0x00039ECC
		public static IPropertyInfo HaveAmountString!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveAmountString!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveAmountString!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveAmountString!Field = new ClrPropertyInfo("HaveAmountString", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveAmountString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveAmountString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveAmountString!Field;
		}

		// Token: 0x060005C1 RID: 1473 RVA: 0x0003BD20 File Offset: 0x00039F20
		static object HaveUsdString!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).HaveUsdString;
		}

		// Token: 0x060005C2 RID: 1474 RVA: 0x0003BD38 File Offset: 0x00039F38
		static void HaveUsdString!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).HaveUsdString = (string)A_1;
		}

		// Token: 0x060005C3 RID: 1475 RVA: 0x0003BD58 File Offset: 0x00039F58
		public static IPropertyInfo HaveUsdString!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveUsdString!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveUsdString!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveUsdString!Field = new ClrPropertyInfo("HaveUsdString", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveUsdString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveUsdString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.HaveUsdString!Field;
		}

		// Token: 0x060005C4 RID: 1476 RVA: 0x0003BDAC File Offset: 0x00039FAC
		static object SelectedWantCoin!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).SelectedWantCoin;
		}

		// Token: 0x060005C5 RID: 1477 RVA: 0x0003BDC4 File Offset: 0x00039FC4
		static void SelectedWantCoin!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).SelectedWantCoin = (SwapCoinItem)A_1;
		}

		// Token: 0x060005C6 RID: 1478 RVA: 0x0003BDE4 File Offset: 0x00039FE4
		public static IPropertyInfo SelectedWantCoin!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedWantCoin!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedWantCoin!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedWantCoin!Field = new ClrPropertyInfo("SelectedWantCoin", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedWantCoin!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedWantCoin!Setter), typeof(SwapCoinItem));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SelectedWantCoin!Field;
		}

		// Token: 0x060005C7 RID: 1479 RVA: 0x0003BE38 File Offset: 0x0003A038
		static object WantAmountString!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).WantAmountString;
		}

		// Token: 0x060005C8 RID: 1480 RVA: 0x0003BE50 File Offset: 0x0003A050
		static void WantAmountString!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).WantAmountString = (string)A_1;
		}

		// Token: 0x060005C9 RID: 1481 RVA: 0x0003BE70 File Offset: 0x0003A070
		public static IPropertyInfo WantAmountString!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantAmountString!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantAmountString!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantAmountString!Field = new ClrPropertyInfo("WantAmountString", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantAmountString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantAmountString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantAmountString!Field;
		}

		// Token: 0x060005CA RID: 1482 RVA: 0x0003BEC4 File Offset: 0x0003A0C4
		static object WantUsdString!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).WantUsdString;
		}

		// Token: 0x060005CB RID: 1483 RVA: 0x0003BEDC File Offset: 0x0003A0DC
		static void WantUsdString!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).WantUsdString = (string)A_1;
		}

		// Token: 0x060005CC RID: 1484 RVA: 0x0003BEFC File Offset: 0x0003A0FC
		public static IPropertyInfo WantUsdString!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantUsdString!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantUsdString!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantUsdString!Field = new ClrPropertyInfo("WantUsdString", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantUsdString!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantUsdString!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.WantUsdString!Field;
		}

		// Token: 0x060005CD RID: 1485 RVA: 0x0003BF50 File Offset: 0x0003A150
		static object ActionButtonText!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).ActionButtonText;
		}

		// Token: 0x060005CE RID: 1486 RVA: 0x0003BF68 File Offset: 0x0003A168
		static void ActionButtonText!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).ActionButtonText = (string)A_1;
		}

		// Token: 0x060005CF RID: 1487 RVA: 0x0003BF88 File Offset: 0x0003A188
		public static IPropertyInfo ActionButtonText!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ActionButtonText!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ActionButtonText!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ActionButtonText!Field = new ClrPropertyInfo("ActionButtonText", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ActionButtonText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ActionButtonText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ActionButtonText!Field;
		}

		// Token: 0x060005D0 RID: 1488 RVA: 0x0003BFDC File Offset: 0x0003A1DC
		static object ExchangeRateText!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).ExchangeRateText;
		}

		// Token: 0x060005D1 RID: 1489 RVA: 0x0003BFF4 File Offset: 0x0003A1F4
		static void ExchangeRateText!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).ExchangeRateText = (string)A_1;
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x0003C014 File Offset: 0x0003A214
		public static IPropertyInfo ExchangeRateText!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ExchangeRateText!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ExchangeRateText!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ExchangeRateText!Field = new ClrPropertyInfo("ExchangeRateText", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ExchangeRateText!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ExchangeRateText!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ExchangeRateText!Field;
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x0003C068 File Offset: 0x0003A268
		static object IsAssetPickerOpen!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).IsAssetPickerOpen;
		}

		// Token: 0x060005D4 RID: 1492 RVA: 0x0003C088 File Offset: 0x0003A288
		static void IsAssetPickerOpen!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).IsAssetPickerOpen = (bool)A_1;
		}

		// Token: 0x060005D5 RID: 1493 RVA: 0x0003C0A8 File Offset: 0x0003A2A8
		public static IPropertyInfo IsAssetPickerOpen!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsAssetPickerOpen!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsAssetPickerOpen!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsAssetPickerOpen!Field = new ClrPropertyInfo("IsAssetPickerOpen", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsAssetPickerOpen!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsAssetPickerOpen!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsAssetPickerOpen!Field;
		}

		// Token: 0x060005D6 RID: 1494 RVA: 0x0003C0FC File Offset: 0x0003A2FC
		static object PickerTitle!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).PickerTitle;
		}

		// Token: 0x060005D7 RID: 1495 RVA: 0x0003C114 File Offset: 0x0003A314
		static void PickerTitle!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).PickerTitle = (string)A_1;
		}

		// Token: 0x060005D8 RID: 1496 RVA: 0x0003C134 File Offset: 0x0003A334
		public static IPropertyInfo PickerTitle!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.PickerTitle!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.PickerTitle!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.PickerTitle!Field = new ClrPropertyInfo("PickerTitle", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.PickerTitle!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.PickerTitle!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.PickerTitle!Field;
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x0003C188 File Offset: 0x0003A388
		static object SearchQuery!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).SearchQuery;
		}

		// Token: 0x060005DA RID: 1498 RVA: 0x0003C1A0 File Offset: 0x0003A3A0
		static void SearchQuery!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).SearchQuery = (string)A_1;
		}

		// Token: 0x060005DB RID: 1499 RVA: 0x0003C1C0 File Offset: 0x0003A3C0
		public static IPropertyInfo SearchQuery!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SearchQuery!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SearchQuery!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SearchQuery!Field = new ClrPropertyInfo("SearchQuery", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SearchQuery!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SearchQuery!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.SearchQuery!Field;
		}

		// Token: 0x060005DC RID: 1500 RVA: 0x0003C214 File Offset: 0x0003A414
		static object FilteredCoins!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).FilteredCoins;
		}

		// Token: 0x060005DD RID: 1501 RVA: 0x0003C22C File Offset: 0x0003A42C
		public static IPropertyInfo FilteredCoins!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.FilteredCoins!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.FilteredCoins!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.FilteredCoins!Field = new ClrPropertyInfo("FilteredCoins", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.FilteredCoins!Getter), null, typeof(ObservableCollection<SwapCoinItem>));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.FilteredCoins!Field;
		}

		// Token: 0x060005DE RID: 1502 RVA: 0x0003C274 File Offset: 0x0003A474
		static object IsToastVisible!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).IsToastVisible;
		}

		// Token: 0x060005DF RID: 1503 RVA: 0x0003C294 File Offset: 0x0003A494
		static void IsToastVisible!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).IsToastVisible = (bool)A_1;
		}

		// Token: 0x060005E0 RID: 1504 RVA: 0x0003C2B4 File Offset: 0x0003A4B4
		public static IPropertyInfo IsToastVisible!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsToastVisible!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsToastVisible!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsToastVisible!Field = new ClrPropertyInfo("IsToastVisible", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsToastVisible!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsToastVisible!Setter), typeof(bool));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.IsToastVisible!Field;
		}

		// Token: 0x060005E1 RID: 1505 RVA: 0x0003C308 File Offset: 0x0003A508
		static object ToastMessage!Getter(object A_0)
		{
			return ((SwapViewModel)A_0).ToastMessage;
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x0003C320 File Offset: 0x0003A520
		static void ToastMessage!Setter(object A_0, object A_1)
		{
			((SwapViewModel)A_0).ToastMessage = (string)A_1;
		}

		// Token: 0x060005E3 RID: 1507 RVA: 0x0003C340 File Offset: 0x0003A540
		public static IPropertyInfo ToastMessage!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ToastMessage!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ToastMessage!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ToastMessage!Field = new ClrPropertyInfo("ToastMessage", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ToastMessage!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ToastMessage!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.SwapViewModel,Exodus.ToastMessage!Field;
		}

		// Token: 0x060005E4 RID: 1508 RVA: 0x0003C394 File Offset: 0x0003A594
		static object DraftAddress!Getter(object A_0)
		{
			return ((UpdateAddressWindowViewModel)A_0).DraftAddress;
		}

		// Token: 0x060005E5 RID: 1509 RVA: 0x0003C3AC File Offset: 0x0003A5AC
		static void DraftAddress!Setter(object A_0, object A_1)
		{
			((UpdateAddressWindowViewModel)A_0).DraftAddress = (string)A_1;
		}

		// Token: 0x060005E6 RID: 1510 RVA: 0x0003C3CC File Offset: 0x0003A5CC
		public static IPropertyInfo DraftAddress!Property()
		{
			if (XamlIlHelpers.Exodus.ViewModels.UpdateAddressWindowViewModel,Exodus.DraftAddress!Field != null)
			{
				return XamlIlHelpers.Exodus.ViewModels.UpdateAddressWindowViewModel,Exodus.DraftAddress!Field;
			}
			XamlIlHelpers.Exodus.ViewModels.UpdateAddressWindowViewModel,Exodus.DraftAddress!Field = new ClrPropertyInfo("DraftAddress", new Func<object, object>(XamlIlHelpers.Exodus.ViewModels.UpdateAddressWindowViewModel,Exodus.DraftAddress!Getter), new Action<object, object>(XamlIlHelpers.Exodus.ViewModels.UpdateAddressWindowViewModel,Exodus.DraftAddress!Setter), typeof(string));
			return XamlIlHelpers.Exodus.ViewModels.UpdateAddressWindowViewModel,Exodus.DraftAddress!Field;
		}

		// Token: 0x0400022A RID: 554
		static IPropertyInfo BasedOn!Field;

		// Token: 0x0400022B RID: 555
		static IPropertyInfo AmountInput!Field;

		// Token: 0x0400022C RID: 556
		static IPropertyInfo LivePreviewText!Field;

		// Token: 0x0400022D RID: 557
		static IPropertyInfo Chip1Text!Field;

		// Token: 0x0400022E RID: 558
		static IPropertyInfo Chip2Text!Field;

		// Token: 0x0400022F RID: 559
		static IPropertyInfo Chip3Text!Field;

		// Token: 0x04000230 RID: 560
		static IPropertyInfo Chip4Text!Field;

		// Token: 0x04000231 RID: 561
		static IPropertyInfo Chip5Text!Field;

		// Token: 0x04000232 RID: 562
		static IPropertyInfo MyTransaction!Field;

		// Token: 0x04000233 RID: 563
		static IPropertyInfo From!Field;

		// Token: 0x04000234 RID: 564
		static IPropertyInfo To!Field;

		// Token: 0x04000235 RID: 565
		static IPropertyInfo TransactionId!Field;

		// Token: 0x04000236 RID: 566
		static IPropertyInfo Height!Field;

		// Token: 0x04000237 RID: 567
		static IPropertyInfo SelectedFiat!Field;

		// Token: 0x04000238 RID: 568
		static IPropertyInfo FlagEmoji!Field;

		// Token: 0x04000239 RID: 569
		static IPropertyInfo Code!Field;

		// Token: 0x0400023A RID: 570
		static IPropertyInfo PayAmountString!Field;

		// Token: 0x0400023B RID: 571
		static IPropertyInfo SelectedCrypto!Field;

		// Token: 0x0400023C RID: 572
		static IPropertyInfo Icon!Field;

		// Token: 0x0400023D RID: 573
		static IPropertyInfo Symbol!Field;

		// Token: 0x0400023E RID: 574
		static IPropertyInfo ReceiveCryptoString!Field;

		// Token: 0x0400023F RID: 575
		static IPropertyInfo RateInfoText!Field;

		// Token: 0x04000240 RID: 576
		static IPropertyInfo IsCryptoPickerOpen!Field;

		// Token: 0x04000241 RID: 577
		static IPropertyInfo SearchQuery!Field;

		// Token: 0x04000242 RID: 578
		static IPropertyInfo FilteredCryptoCoins!Field;

		// Token: 0x04000243 RID: 579
		static IPropertyInfo SubNetwork!Field;

		// Token: 0x04000244 RID: 580
		static IPropertyInfo Name!Field;

		// Token: 0x04000245 RID: 581
		static IPropertyInfo DisplaySubtitle!Field;

		// Token: 0x04000246 RID: 582
		static IPropertyInfo ValueInUsdString!Field;

		// Token: 0x04000247 RID: 583
		static IPropertyInfo IsFiatPickerOpen!Field;

		// Token: 0x04000248 RID: 584
		static IPropertyInfo FiatCurrencies!Field;

		// Token: 0x04000249 RID: 585
		static IPropertyInfo Name!Field;

		// Token: 0x0400024A RID: 586
		static IPropertyInfo IsToastVisible!Field;

		// Token: 0x0400024B RID: 587
		static IPropertyInfo ToastMessage!Field;

		// Token: 0x0400024C RID: 588
		static IPropertyInfo BannerControlHeight!Field;

		// Token: 0x0400024D RID: 589
		static IPropertyInfo IsShowRefresh!Field;

		// Token: 0x0400024E RID: 590
		static IPropertyInfo BannerControl!Field;

		// Token: 0x0400024F RID: 591
		static IPropertyInfo Foreground2!Field;

		// Token: 0x04000250 RID: 592
		static IPropertyInfo IsPlayRefresh!Field;

		// Token: 0x04000251 RID: 593
		static IPropertyInfo IsShowNetworkPill!Field;

		// Token: 0x04000252 RID: 594
		static IPropertyInfo NetworkPillIcon!Field;

		// Token: 0x04000253 RID: 595
		static IPropertyInfo HasNetworkPillIcon!Field;

		// Token: 0x04000254 RID: 596
		static IPropertyInfo NetworkPillText!Field;

		// Token: 0x04000255 RID: 597
		static IPropertyInfo NetworkPillHasDropdown!Field;

		// Token: 0x04000256 RID: 598
		static IPropertyInfo FormattedBalance!Field;

		// Token: 0x04000257 RID: 599
		static IPropertyInfo Foreground1!Field;

		// Token: 0x04000258 RID: 600
		static IPropertyInfo MyCoin!Field;

		// Token: 0x04000259 RID: 601
		static IPropertyInfo Symbol!Field;

		// Token: 0x0400025A RID: 602
		static IPropertyInfo BalanceInUsdString!Field;

		// Token: 0x0400025B RID: 603
		static IPropertyInfo IsEthereum!Field;

		// Token: 0x0400025C RID: 604
		static IPropertyInfo IsTherePendingTransaction!Field;

		// Token: 0x0400025D RID: 605
		static IPropertyInfo TotalInPending!Field;

		// Token: 0x0400025E RID: 606
		static IPropertyInfo IsShowGasWarning!Field;

		// Token: 0x0400025F RID: 607
		static IPropertyInfo IsEmpty!Field;

		// Token: 0x04000260 RID: 608
		static IPropertyInfo GasWarningText!Field;

		// Token: 0x04000261 RID: 609
		static IPropertyInfo IsThereAnyTransaction!Field;

		// Token: 0x04000262 RID: 610
		static IPropertyInfo NoTransactionText!Field;

		// Token: 0x04000263 RID: 611
		static IPropertyInfo PendingTransactions!Field;

		// Token: 0x04000264 RID: 612
		static IPropertyInfo HeaderBackgroundColor!Field;

		// Token: 0x04000265 RID: 613
		static IPropertyInfo Value!Field;

		// Token: 0x04000266 RID: 614
		static IPropertyInfo FormattedAmount!Field;

		// Token: 0x04000267 RID: 615
		static IPropertyInfo IsExpanded!Field;

		// Token: 0x04000268 RID: 616
		static IPropertyInfo TimeString!Field;

		// Token: 0x04000269 RID: 617
		static IPropertyInfo PriceNowString!Field;

		// Token: 0x0400026A RID: 618
		static IPropertyInfo TransactionsGroups!Field;

		// Token: 0x0400026B RID: 619
		static IPropertyInfo IsThereTransaction!Field;

		// Token: 0x0400026C RID: 620
		static IPropertyInfo IsThereTransaction!Field;

		// Token: 0x0400026D RID: 621
		static IPropertyInfo DateTitle!Field;

		// Token: 0x0400026E RID: 622
		static IPropertyInfo Transactions!Field;

		// Token: 0x0400026F RID: 623
		static IPropertyInfo SentDurationsAgo!Field;

		// Token: 0x04000270 RID: 624
		static IPropertyInfo WindowTitle!Field;

		// Token: 0x04000271 RID: 625
		static IPropertyInfo NotificationViewModel!Field;

		// Token: 0x04000272 RID: 626
		static IPropertyInfo IsShow!Field;

		// Token: 0x04000273 RID: 627
		static IPropertyInfo IsNotification!Field;

		// Token: 0x04000274 RID: 628
		static IPropertyInfo ReceiveAddressViewModel!Field;

		// Token: 0x04000275 RID: 629
		static IPropertyInfo IsVisible!Field;

		// Token: 0x04000276 RID: 630
		static IPropertyInfo RefreshViewModel!Field;

		// Token: 0x04000277 RID: 631
		static IPropertyInfo IsVisible!Field;

		// Token: 0x04000278 RID: 632
		static IPropertyInfo SettingsModalViewModel!Field;

		// Token: 0x04000279 RID: 633
		static IPropertyInfo IsVisible!Field;

		// Token: 0x0400027A RID: 634
		static IPropertyInfo IsPortfolioViewActive!Field;

		// Token: 0x0400027B RID: 635
		static IPropertyInfo TotalBalanceInUsdPlayerString!Field;

		// Token: 0x0400027C RID: 636
		static IPropertyInfo IsWalletViewActive!Field;

		// Token: 0x0400027D RID: 637
		static IPropertyInfo IsSwapViewActive!Field;

		// Token: 0x0400027E RID: 638
		static IPropertyInfo IsBuySellViewActive!Field;

		// Token: 0x0400027F RID: 639
		static IPropertyInfo PortfolioViewModel!Field;

		// Token: 0x04000280 RID: 640
		static IPropertyInfo SwapViewModel!Field;

		// Token: 0x04000281 RID: 641
		static IPropertyInfo BuySellViewModel!Field;

		// Token: 0x04000282 RID: 642
		static IPropertyInfo Coins!Field;

		// Token: 0x04000283 RID: 643
		static IPropertyInfo IsShowPercentageIcon!Field;

		// Token: 0x04000284 RID: 644
		static IPropertyInfo IsSelected!Field;

		// Token: 0x04000285 RID: 645
		static IPropertyInfo Name!Field;

		// Token: 0x04000286 RID: 646
		static IPropertyInfo ViewPart!Field;

		// Token: 0x04000287 RID: 647
		static IPropertyInfo IsBscNetwork!Field;

		// Token: 0x04000288 RID: 648
		static IPropertyInfo FormattedBalance!Field;

		// Token: 0x04000289 RID: 649
		static IPropertyInfo SelectedCoinViewPart!Field;

		// Token: 0x0400028A RID: 650
		static IPropertyInfo Logo!Field;

		// Token: 0x0400028B RID: 651
		static IPropertyInfo ViewPart!Field;

		// Token: 0x0400028C RID: 652
		static IPropertyInfo CurrentlyAdded!Field;

		// Token: 0x0400028D RID: 653
		static IPropertyInfo CloseNotification!Field;

		// Token: 0x0400028E RID: 654
		static IPropertyInfo NotificationStripeWidth!Field;

		// Token: 0x0400028F RID: 655
		static IPropertyInfo DonutSegments!Field;

		// Token: 0x04000290 RID: 656
		static IPropertyInfo PathData!Field;

		// Token: 0x04000291 RID: 657
		static IPropertyInfo Brush!Field;

		// Token: 0x04000292 RID: 658
		static IPropertyInfo TotalBalanceString!Field;

		// Token: 0x04000293 RID: 659
		static IPropertyInfo AssetCountText!Field;

		// Token: 0x04000294 RID: 660
		static IPropertyInfo Change24HString!Field;

		// Token: 0x04000295 RID: 661
		static IPropertyInfo Change24HBrush!Field;

		// Token: 0x04000296 RID: 662
		static IPropertyInfo HighestBalanceText!Field;

		// Token: 0x04000297 RID: 663
		static IPropertyInfo PortfolioAgeText!Field;

		// Token: 0x04000298 RID: 664
		static IPropertyInfo Best24HAsset!Field;

		// Token: 0x04000299 RID: 665
		static IPropertyInfo Worst24HAsset!Field;

		// Token: 0x0400029A RID: 666
		static IPropertyInfo FilterWithBalance!Field;

		// Token: 0x0400029B RID: 667
		static IPropertyInfo FilterFavorite!Field;

		// Token: 0x0400029C RID: 668
		static IPropertyInfo DisplayItems!Field;

		// Token: 0x0400029D RID: 669
		static IPropertyInfo Icon!Field;

		// Token: 0x0400029E RID: 670
		static IPropertyInfo Name!Field;

		// Token: 0x0400029F RID: 671
		static IPropertyInfo IsBsc!Field;

		// Token: 0x040002A0 RID: 672
		static IPropertyInfo HasDropdown!Field;

		// Token: 0x040002A1 RID: 673
		static IPropertyInfo Symbol!Field;

		// Token: 0x040002A2 RID: 674
		static IPropertyInfo HasApy!Field;

		// Token: 0x040002A3 RID: 675
		static IPropertyInfo ApyText!Field;

		// Token: 0x040002A4 RID: 676
		static IPropertyInfo PriceString!Field;

		// Token: 0x040002A5 RID: 677
		static IPropertyInfo Change24HString!Field;

		// Token: 0x040002A6 RID: 678
		static IPropertyInfo ChangeBrush!Field;

		// Token: 0x040002A7 RID: 679
		static IPropertyInfo MarketCap!Field;

		// Token: 0x040002A8 RID: 680
		static IPropertyInfo Volume24H!Field;

		// Token: 0x040002A9 RID: 681
		static IPropertyInfo TrendPath!Field;

		// Token: 0x040002AA RID: 682
		static IPropertyInfo TrendBrush!Field;

		// Token: 0x040002AB RID: 683
		static IPropertyInfo BalanceString!Field;

		// Token: 0x040002AC RID: 684
		static IPropertyInfo ValueInUsdString!Field;

		// Token: 0x040002AD RID: 685
		static IPropertyInfo PortfolioPercentageString!Field;

		// Token: 0x040002AE RID: 686
		static IPropertyInfo Opacity!Field;

		// Token: 0x040002AF RID: 687
		static IPropertyInfo SolidOpacity!Field;

		// Token: 0x040002B0 RID: 688
		static IPropertyInfo IsShow!Field;

		// Token: 0x040002B1 RID: 689
		static IPropertyInfo MainWindowVm!Field;

		// Token: 0x040002B2 RID: 690
		static IPropertyInfo YourAddressTitle!Field;

		// Token: 0x040002B3 RID: 691
		static IPropertyInfo AddressOpacity!Field;

		// Token: 0x040002B4 RID: 692
		static IPropertyInfo SelectedCoin!Field;

		// Token: 0x040002B5 RID: 693
		static IPropertyInfo Address!Field;

		// Token: 0x040002B6 RID: 694
		static IPropertyInfo CopyCommand!Field;

		// Token: 0x040002B7 RID: 695
		static IPropertyInfo CopyOpacity!Field;

		// Token: 0x040002B8 RID: 696
		static IPropertyInfo Opacity!Field;

		// Token: 0x040002B9 RID: 697
		static IPropertyInfo SolidOpacity!Field;

		// Token: 0x040002BA RID: 698
		static IPropertyInfo IsShow!Field;

		// Token: 0x040002BB RID: 699
		static IPropertyInfo RefreshText!Field;

		// Token: 0x040002BC RID: 700
		static IPropertyInfo IsShowButtons!Field;

		// Token: 0x040002BD RID: 701
		static IPropertyInfo ButtonsOpacity!Field;

		// Token: 0x040002BE RID: 702
		static IPropertyInfo Opacity!Field;

		// Token: 0x040002BF RID: 703
		static IPropertyInfo VersionBadge!Field;

		// Token: 0x040002C0 RID: 704
		static IPropertyInfo IsFeedbackVisible!Field;

		// Token: 0x040002C1 RID: 705
		static IPropertyInfo CopyFeedbackMessage!Field;

		// Token: 0x040002C2 RID: 706
		static IPropertyInfo SelectedHaveCoin!Field;

		// Token: 0x040002C3 RID: 707
		static IPropertyInfo HaveAmountString!Field;

		// Token: 0x040002C4 RID: 708
		static IPropertyInfo HaveUsdString!Field;

		// Token: 0x040002C5 RID: 709
		static IPropertyInfo SelectedWantCoin!Field;

		// Token: 0x040002C6 RID: 710
		static IPropertyInfo WantAmountString!Field;

		// Token: 0x040002C7 RID: 711
		static IPropertyInfo WantUsdString!Field;

		// Token: 0x040002C8 RID: 712
		static IPropertyInfo ActionButtonText!Field;

		// Token: 0x040002C9 RID: 713
		static IPropertyInfo ExchangeRateText!Field;

		// Token: 0x040002CA RID: 714
		static IPropertyInfo IsAssetPickerOpen!Field;

		// Token: 0x040002CB RID: 715
		static IPropertyInfo PickerTitle!Field;

		// Token: 0x040002CC RID: 716
		static IPropertyInfo SearchQuery!Field;

		// Token: 0x040002CD RID: 717
		static IPropertyInfo FilteredCoins!Field;

		// Token: 0x040002CE RID: 718
		static IPropertyInfo IsToastVisible!Field;

		// Token: 0x040002CF RID: 719
		static IPropertyInfo ToastMessage!Field;

		// Token: 0x040002D0 RID: 720
		static IPropertyInfo DraftAddress!Field;
	}
}
