﻿using System;
using System.Runtime.CompilerServices;

namespace Exodus.Services
{
	// Token: 0x0200006D RID: 109
	[NullableContext(1)]
	[Nullable(0)]
	public class GeneralServices
	{
		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060002C6 RID: 710 RVA: 0x00030AAE File Offset: 0x0002ECAE
		public static GeneralServices Instance { get; } = new GeneralServices();

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x060002C7 RID: 711 RVA: 0x00030AB8 File Offset: 0x0002ECB8
		// (remove) Token: 0x060002C8 RID: 712 RVA: 0x00030AF0 File Offset: 0x0002ECF0
		public event EventHandler CopyTextToClipBoardEvent;

		// Token: 0x060002C9 RID: 713 RVA: 0x00030B25 File Offset: 0x0002ED25
		public void CopyTextToClipBoard(string text)
		{
			EventHandler copyTextToClipBoardEvent = this.CopyTextToClipBoardEvent;
			if (copyTextToClipBoardEvent == null)
			{
				return;
			}
			copyTextToClipBoardEvent(text, EventArgs.Empty);
		}
	}
}
