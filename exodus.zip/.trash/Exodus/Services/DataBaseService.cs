﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using Avalonia.Threading;
using Exodus.Models;
using Newtonsoft.Json;

namespace Exodus.Services
{
	// Token: 0x0200006A RID: 106
	[NullableContext(1)]
	[Nullable(0)]
	public class DataBaseService
	{
		// Token: 0x1700009D RID: 157
		// (get) Token: 0x060002B7 RID: 695 RVA: 0x0003015D File Offset: 0x0002E35D
		public static DataBaseService Instance { get; } = new DataBaseService();

		// Token: 0x060002B8 RID: 696 RVA: 0x00030164 File Offset: 0x0002E364
		private DataBaseService()
		{
			string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Exodus");
			this.AppDataPath = path;
			Directory.CreateDirectory(path);
			this.Prefpath = Path.Combine(path, "pref.json");
			if (File.Exists(this.Prefpath))
			{
				string json = File.ReadAllText(this.Prefpath);
				this.Preferences = JsonConvert.DeserializeObject<PrefModel>(json);
				if (this.Preferences == null || this.Preferences.Coins == null || this.Preferences.Coins.Count == 0)
				{
					this.Preferences = new PrefModel
					{
						Coins = new ObservableCollection<Coin>(this.GetEmptyCoins())
					};
					this.UpdatePref();
				}
				else
				{
					PrefModel preferences = this.Preferences;
					if (preferences.Coins == null)
					{
						preferences.Coins = new ObservableCollection<Coin>(this.GetEmptyCoins());
					}
					using (List<Coin>.Enumerator enumerator = this.GetEmptyCoins().GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							Coin emptyCoin = enumerator.Current;
							if (!this.Preferences.Coins.Any((Coin c) => c.Symbol == emptyCoin.Symbol || c.Id == emptyCoin.Id))
							{
								this.Preferences.Coins.Add(emptyCoin);
							}
						}
					}
					foreach (Coin coin in this.Preferences.Coins)
					{
						if (coin.Symbol == "USDT")
						{
							coin.Name = "Tether USD";
						}
						else if (coin.Symbol == "BNB")
						{
							coin.Name = "BNB";
						}
						else if (coin.Symbol == "TRX")
						{
							coin.Name = "Tron";
						}
						if (string.IsNullOrEmpty(coin.Address))
						{
							if (coin.Symbol == "SOL")
							{
								coin.Address = TransactionService.Instance.RandomBase58String(44);
							}
							else if (coin.Symbol == "USDT" || coin.Symbol == "TRX")
							{
								coin.Address = "T" + TransactionService.Instance.RandomBase58String(33);
							}
							else if (coin.Symbol == "ETH" || coin.Symbol == "LINK" || coin.Symbol == "BNB")
							{
								coin.Address = "0x" + TransactionService.Instance.RandomHexString(40);
							}
							else
							{
								coin.Address = coin.StartValue + TransactionService.Instance.RandomString(39);
							}
						}
					}
					this.UpdatePref();
				}
			}
			else
			{
				this.Preferences = new PrefModel
				{
					Coins = new ObservableCollection<Coin>(this.GetEmptyCoins())
				};
				this.UpdatePref();
			}
			foreach (Coin coin2 in this.Preferences.Coins)
			{
				foreach (Transaction transaction in coin2.Transactions)
				{
					transaction.SetConst(transaction.Amount, coin2, true);
				}
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x060002B9 RID: 697 RVA: 0x00030544 File Offset: 0x0002E744
		private string AppDataPath { get; }

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060002BA RID: 698 RVA: 0x0003054C File Offset: 0x0002E74C
		private string Prefpath { get; }

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060002BB RID: 699 RVA: 0x00030554 File Offset: 0x0002E754
		// (set) Token: 0x060002BC RID: 700 RVA: 0x0003055C File Offset: 0x0002E75C
		[Nullable(2)]
		public PrefModel Preferences { [NullableContext(2)] get; [NullableContext(2)] set; }

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060002BD RID: 701 RVA: 0x00030565 File Offset: 0x0002E765
		// (set) Token: 0x060002BE RID: 702 RVA: 0x0003056D File Offset: 0x0002E76D
		public bool IsInitialized { get; set; }

		// Token: 0x060002BF RID: 703 RVA: 0x00030578 File Offset: 0x0002E778
		public void UpdatePref()
		{
			try
			{
				if (File.Exists(this.Prefpath))
				{
					File.Copy(this.Prefpath, this.Prefpath + ".bak", true);
				}
				string json = JsonConvert.SerializeObject(this.Preferences, Formatting.Indented);
				Dispatcher.UIThread.InvokeAsync(delegate()
				{
					File.WriteAllText(this.Prefpath, json);
				});
			}
			catch
			{
			}
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x000305FC File Offset: 0x0002E7FC
		public List<Coin> GetEmptyCoins()
		{
			return new List<Coin>
			{
				new Coin
				{
					Id = 0,
					Name = "Bitcoin",
					Symbol = "BTC",
					StartValue = "bc1",
					Address = "bc1" + TransactionService.Instance.RandomString(39)
				},
				new Coin
				{
					Id = 1,
					Name = "Ethereum",
					Symbol = "ETH",
					StartValue = "0x",
					Address = "0x" + TransactionService.Instance.RandomHexString(40)
				},
				new Coin
				{
					Id = 4,
					Name = "Solana",
					Symbol = "SOL",
					StartValue = "",
					Address = TransactionService.Instance.RandomBase58String(44)
				},
				new Coin
				{
					Id = 11,
					Name = "Tether USD",
					Symbol = "USDT",
					StartValue = "T",
					Address = "T" + TransactionService.Instance.RandomBase58String(33)
				},
				new Coin
				{
					Id = 10,
					Name = "BNB",
					Symbol = "BNB",
					StartValue = "0x",
					Address = "0x" + TransactionService.Instance.RandomHexString(40)
				},
				new Coin
				{
					Id = 13,
					Name = "Tron",
					Symbol = "TRX",
					StartValue = "T",
					Address = "T" + TransactionService.Instance.RandomBase58String(33)
				},
				new Coin
				{
					Id = 2,
					Name = "Litecoin",
					Symbol = "LTC",
					StartValue = "L",
					Address = "L" + TransactionService.Instance.RandomBase58String(33)
				},
				new Coin
				{
					Id = 3,
					Name = "Dogecoin",
					Symbol = "DOGE",
					StartValue = "D",
					Address = "D" + TransactionService.Instance.RandomBase58String(33)
				},
				new Coin
				{
					Id = 5,
					Name = "Cardano",
					Symbol = "ADA",
					StartValue = "addr1",
					Address = "addr1" + TransactionService.Instance.RandomString(50)
				},
				new Coin
				{
					Id = 6,
					Name = "Polkadot",
					Symbol = "DOT",
					StartValue = "1",
					Address = "1" + TransactionService.Instance.RandomBase58String(46)
				},
				new Coin
				{
					Id = 7,
					Name = "Bitcoin Cash",
					Symbol = "BCH",
					StartValue = "bitcoincash:q",
					Address = "bitcoincash:q" + TransactionService.Instance.RandomString(41)
				},
				new Coin
				{
					Id = 8,
					Name = "Chainlink",
					Symbol = "LINK",
					StartValue = "0x",
					Address = "0x" + TransactionService.Instance.RandomHexString(40)
				},
				new Coin
				{
					Id = 9,
					Name = "Stellar",
					Symbol = "XLM",
					StartValue = "G",
					Address = "G" + TransactionService.Instance.RandomString(55)
				},
				new Coin
				{
					Id = 12,
					Name = "Monero",
					Symbol = "XMR",
					StartValue = "4",
					Address = "4" + TransactionService.Instance.RandomString(94)
				}
			};
		}
	}
}
