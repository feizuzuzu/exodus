﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Linq;
using System.Runtime.CompilerServices;

namespace Exodus.Services
{
	// Token: 0x0200006E RID: 110
	[NullableContext(1)]
	[Nullable(0)]
	public class TransactionService
	{
		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060002CC RID: 716 RVA: 0x00030B49 File Offset: 0x0002ED49
		public static TransactionService Instance { get; } = new TransactionService();

		// Token: 0x060002CD RID: 717 RVA: 0x00030B50 File Offset: 0x0002ED50
		public TransactionService()
		{
			this.CurrentCoinsPriceApi();
			Observable.Interval(TimeSpan.FromMinutes(5.0)).Subscribe(delegate(long _)
			{
				this.CurrentCoinsPriceApi();
			});
		}

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x060002CE RID: 718 RVA: 0x00030D04 File Offset: 0x0002EF04
		// (remove) Token: 0x060002CF RID: 719 RVA: 0x00030D3C File Offset: 0x0002EF3C
		[Nullable(2)]
		[method: NullableContext(2)]
		[Nullable(2)]
		public event EventHandler PriceUpdated;

		// Token: 0x060002D0 RID: 720 RVA: 0x00030D74 File Offset: 0x0002EF74
		public double GetPrice(string symbol)
		{
			double price;
			if (this._prices.TryGetValue(symbol, out price))
			{
				return price;
			}
			return 1.0;
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060002D1 RID: 721 RVA: 0x00030D9C File Offset: 0x0002EF9C
		public List<double> CurrentCoinsPrice
		{
			get
			{
				return new List<double>
				{
					this.GetPrice("BTC"),
					this.GetPrice("ETH"),
					this.GetPrice("LTC"),
					this.GetPrice("DOGE"),
					this.GetPrice("SOL"),
					this.GetPrice("ADA"),
					this.GetPrice("DOT"),
					this.GetPrice("BCH"),
					this.GetPrice("LINK"),
					this.GetPrice("XLM"),
					this.GetPrice("BNB"),
					this.GetPrice("USDT"),
					this.GetPrice("XMR"),
					this.GetPrice("TRX")
				};
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x060002D2 RID: 722 RVA: 0x00030E9C File Offset: 0x0002F09C
		public List<string> CoinsSymbol { get; } = new List<string>
		{
			"BTC",
			"ETH",
			"SOL",
			"USDT",
			"BNB",
			"TRX"
		};

		// Token: 0x060002D3 RID: 723 RVA: 0x00030EA4 File Offset: 0x0002F0A4
		private void CurrentCoinsPriceApi()
		{
			TransactionService.<CurrentCoinsPriceApi>d__16 <CurrentCoinsPriceApi>d__;
			<CurrentCoinsPriceApi>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<CurrentCoinsPriceApi>d__.<>4__this = this;
			<CurrentCoinsPriceApi>d__.<>1__state = -1;
			<CurrentCoinsPriceApi>d__.<>t__builder.Start<TransactionService.<CurrentCoinsPriceApi>d__16>(ref <CurrentCoinsPriceApi>d__);
		}

		// Token: 0x060002D4 RID: 724 RVA: 0x00030EDC File Offset: 0x0002F0DC
		public string RandomString(int length)
		{
			Random random = new Random();
			return new string((from s in Enumerable.Repeat<string>("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz", length)
			select s[random.Next(s.Length)]).ToArray<char>());
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x00030F20 File Offset: 0x0002F120
		public string RandomBase58String(int length)
		{
			Random random = new Random();
			return new string((from s in Enumerable.Repeat<string>("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz", length)
			select s[random.Next(s.Length)]).ToArray<char>());
		}

		// Token: 0x060002D6 RID: 726 RVA: 0x00030F64 File Offset: 0x0002F164
		public string RandomHexString(int length)
		{
			Random random = new Random();
			return new string((from s in Enumerable.Repeat<string>("0123456789abcdef", length)
			select s[random.Next(s.Length)]).ToArray<char>());
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x060002D7 RID: 727 RVA: 0x00030FA8 File Offset: 0x0002F1A8
		// (remove) Token: 0x060002D8 RID: 728 RVA: 0x00030FE0 File Offset: 0x0002F1E0
		public event EventHandler AddTransactionEvent;

		// Token: 0x060002D9 RID: 729 RVA: 0x00031015 File Offset: 0x0002F215
		public void AddTransaction()
		{
			this.AddTransactionEvent(this, EventArgs.Empty);
		}

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x060002DA RID: 730 RVA: 0x00031028 File Offset: 0x0002F228
		// (remove) Token: 0x060002DB RID: 731 RVA: 0x00031060 File Offset: 0x0002F260
		public event EventHandler TransactionAddedEvent;

		// Token: 0x060002DC RID: 732 RVA: 0x00031095 File Offset: 0x0002F295
		public void TransactionAdded()
		{
			this.TransactionAddedEvent(this, EventArgs.Empty);
		}

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x060002DD RID: 733 RVA: 0x000310A8 File Offset: 0x0002F2A8
		// (remove) Token: 0x060002DE RID: 734 RVA: 0x000310E0 File Offset: 0x0002F2E0
		public event EventHandler StopPendingEvent;

		// Token: 0x060002DF RID: 735 RVA: 0x00031115 File Offset: 0x0002F315
		public void StopPending()
		{
			this.StopPendingEvent(this, EventArgs.Empty);
		}

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x060002E0 RID: 736 RVA: 0x00031128 File Offset: 0x0002F328
		// (remove) Token: 0x060002E1 RID: 737 RVA: 0x00031160 File Offset: 0x0002F360
		public event EventHandler DeleteLastTransactionEvent;

		// Token: 0x060002E2 RID: 738 RVA: 0x00031195 File Offset: 0x0002F395
		public void DeleteLastTransaction()
		{
			this.DeleteLastTransactionEvent(this, EventArgs.Empty);
		}

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x060002E3 RID: 739 RVA: 0x000311A8 File Offset: 0x0002F3A8
		// (remove) Token: 0x060002E4 RID: 740 RVA: 0x000311E0 File Offset: 0x0002F3E0
		public event EventHandler ResetEvent;

		// Token: 0x060002E5 RID: 741 RVA: 0x00031215 File Offset: 0x0002F415
		public void Reset()
		{
			this.ResetEvent(this, EventArgs.Empty);
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x060002E6 RID: 742 RVA: 0x00031228 File Offset: 0x0002F428
		// (remove) Token: 0x060002E7 RID: 743 RVA: 0x00031260 File Offset: 0x0002F460
		public event EventHandler ChangeAddressEvent;

		// Token: 0x060002E8 RID: 744 RVA: 0x00031295 File Offset: 0x0002F495
		public void ChangeAddress()
		{
			this.ChangeAddressEvent(this, EventArgs.Empty);
		}

		// Token: 0x04000148 RID: 328
		private const string ApiKey = "7b71a7d2-7174-468b-8432-93b0cb4df622";

		// Token: 0x04000149 RID: 329
		private const string Url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest?symbol=";

		// Token: 0x0400014A RID: 330
		private readonly Dictionary<string, double> _prices = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
		{
			{
				"BTC",
				96000.0
			},
			{
				"ETH",
				3400.0
			},
			{
				"SOL",
				195.0
			},
			{
				"USDT",
				1.0
			},
			{
				"LTC",
				100.0
			},
			{
				"DOGE",
				0.25
			},
			{
				"BNB",
				650.0
			},
			{
				"ADA",
				0.8
			},
			{
				"DOT",
				8.0
			},
			{
				"BCH",
				350.0
			},
			{
				"LINK",
				18.0
			},
			{
				"XLM",
				0.3
			},
			{
				"XMR",
				150.0
			},
			{
				"TRX",
				0.24
			}
		};
	}
}
