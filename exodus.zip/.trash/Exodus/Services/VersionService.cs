﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Exodus.Services
{
	// Token: 0x02000077 RID: 119
	[NullableContext(1)]
	[Nullable(0)]
	public class VersionService
	{
		// Token: 0x170000AC RID: 172
		// (get) Token: 0x06000308 RID: 776 RVA: 0x0003341A File Offset: 0x0003161A
		public static VersionService Instance { get; } = new VersionService();

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x06000309 RID: 777 RVA: 0x00033421 File Offset: 0x00031621
		// (set) Token: 0x0600030A RID: 778 RVA: 0x00033429 File Offset: 0x00031629
		public string CurrentVersion { get; private set; }

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x0600030B RID: 779 RVA: 0x00033434 File Offset: 0x00031634
		// (remove) Token: 0x0600030C RID: 780 RVA: 0x0003346C File Offset: 0x0003166C
		[Nullable(new byte[]
		{
			2,
			1
		})]
		[Nullable(new byte[]
		{
			2,
			1
		})]
		public event Action<string> VersionUpdated;

		// Token: 0x0600030D RID: 781 RVA: 0x000334A4 File Offset: 0x000316A4
		private VersionService()
		{
			this._primaryFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "version.txt");
			string appData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Exodus");
			this._appDataFilePath = Path.Combine(appData, "version.txt");
			this.CurrentVersion = this.LoadSavedVersion();
		}

		// Token: 0x0600030E RID: 782 RVA: 0x00033500 File Offset: 0x00031700
		private string LoadSavedVersion()
		{
			try
			{
				if (File.Exists(this._primaryFilePath))
				{
					string txt = File.ReadAllText(this._primaryFilePath).Trim();
					if (this.IsValidVersion(txt))
					{
						return txt;
					}
				}
				if (File.Exists(this._appDataFilePath))
				{
					string txt2 = File.ReadAllText(this._appDataFilePath).Trim();
					if (this.IsValidVersion(txt2))
					{
						return txt2;
					}
				}
			}
			catch
			{
			}
			this.SaveVersion("26.8.27");
			return "26.8.27";
		}

		// Token: 0x0600030F RID: 783 RVA: 0x0003358C File Offset: 0x0003178C
		public bool IsValidVersion(string version)
		{
			return !string.IsNullOrWhiteSpace(version) && Regex.IsMatch(version, "^\\d{1,2}\\.\\d{1,2}\\.\\d{1,2}$");
		}

		// Token: 0x06000310 RID: 784 RVA: 0x000335A4 File Offset: 0x000317A4
		public void SaveVersion(string version)
		{
			try
			{
				File.WriteAllText(this._primaryFilePath, version);
			}
			catch
			{
			}
			try
			{
				string dir = Path.GetDirectoryName(this._appDataFilePath);
				if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
				{
					Directory.CreateDirectory(dir);
				}
				File.WriteAllText(this._appDataFilePath, version);
			}
			catch
			{
			}
		}

		// Token: 0x06000311 RID: 785 RVA: 0x00033614 File Offset: 0x00031814
		public Task<string> CheckAndUpdateVersionAsync()
		{
			VersionService.<CheckAndUpdateVersionAsync>d__18 <CheckAndUpdateVersionAsync>d__;
			<CheckAndUpdateVersionAsync>d__.<>t__builder = AsyncTaskMethodBuilder<string>.Create();
			<CheckAndUpdateVersionAsync>d__.<>4__this = this;
			<CheckAndUpdateVersionAsync>d__.<>1__state = -1;
			<CheckAndUpdateVersionAsync>d__.<>t__builder.Start<VersionService.<CheckAndUpdateVersionAsync>d__18>(ref <CheckAndUpdateVersionAsync>d__);
			return <CheckAndUpdateVersionAsync>d__.<>t__builder.Task;
		}

		// Token: 0x040001B4 RID: 436
		public const string DefaultVersion = "26.8.27";

		// Token: 0x040001B5 RID: 437
		private const string ReleasesUrl = "https://www.exodus.com/releases";

		// Token: 0x040001B8 RID: 440
		private readonly string _primaryFilePath;

		// Token: 0x040001B9 RID: 441
		private readonly string _appDataFilePath;
	}
}
