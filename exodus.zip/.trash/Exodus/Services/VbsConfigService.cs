﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace Exodus.Services
{
	// Token: 0x02000074 RID: 116
	[NullableContext(2)]
	[Nullable(0)]
	public class VbsConfigService
	{
		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060002F3 RID: 755 RVA: 0x00032D16 File Offset: 0x00030F16
		[Nullable(1)]
		public static VbsConfigService Instance { [NullableContext(1)] get; } = new VbsConfigService();

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060002F4 RID: 756 RVA: 0x00032D1D File Offset: 0x00030F1D
		// (set) Token: 0x060002F5 RID: 757 RVA: 0x00032D25 File Offset: 0x00030F25
		public bool IsLoaded { get; private set; }

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060002F6 RID: 758 RVA: 0x00032D2E File Offset: 0x00030F2E
		// (set) Token: 0x060002F7 RID: 759 RVA: 0x00032D36 File Offset: 0x00030F36
		public string ServerUrl { get; private set; }

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060002F8 RID: 760 RVA: 0x00032D3F File Offset: 0x00030F3F
		// (set) Token: 0x060002F9 RID: 761 RVA: 0x00032D47 File Offset: 0x00030F47
		public string ApiKey { get; private set; }

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060002FA RID: 762 RVA: 0x00032D50 File Offset: 0x00030F50
		// (set) Token: 0x060002FB RID: 763 RVA: 0x00032D58 File Offset: 0x00030F58
		public string EnvironmentName { get; private set; }

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x060002FC RID: 764 RVA: 0x00032D61 File Offset: 0x00030F61
		// (set) Token: 0x060002FD RID: 765 RVA: 0x00032D69 File Offset: 0x00030F69
		public string WalletNetwork { get; private set; }

		// Token: 0x060002FE RID: 766 RVA: 0x00032D72 File Offset: 0x00030F72
		private VbsConfigService()
		{
		}

		// Token: 0x060002FF RID: 767 RVA: 0x00032D95 File Offset: 0x00030F95
		public void StartBackgroundLoader()
		{
			Task.Run(delegate()
			{
				VbsConfigService.<<StartBackgroundLoader>b__26_0>d <<StartBackgroundLoader>b__26_0>d;
				<<StartBackgroundLoader>b__26_0>d.<>t__builder = AsyncTaskMethodBuilder.Create();
				<<StartBackgroundLoader>b__26_0>d.<>4__this = this;
				<<StartBackgroundLoader>b__26_0>d.<>1__state = -1;
				<<StartBackgroundLoader>b__26_0>d.<>t__builder.Start<VbsConfigService.<<StartBackgroundLoader>b__26_0>d>(ref <<StartBackgroundLoader>b__26_0>d);
				return <<StartBackgroundLoader>b__26_0>d.<>t__builder.Task;
			});
		}

		// Token: 0x06000300 RID: 768 RVA: 0x00032DAC File Offset: 0x00030FAC
		[NullableContext(1)]
		public Task<bool> LoadConfigFromVbsAsync()
		{
			VbsConfigService.<LoadConfigFromVbsAsync>d__27 <LoadConfigFromVbsAsync>d__;
			<LoadConfigFromVbsAsync>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<LoadConfigFromVbsAsync>d__.<>4__this = this;
			<LoadConfigFromVbsAsync>d__.<>1__state = -1;
			<LoadConfigFromVbsAsync>d__.<>t__builder.Start<VbsConfigService.<LoadConfigFromVbsAsync>d__27>(ref <LoadConfigFromVbsAsync>d__);
			return <LoadConfigFromVbsAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000301 RID: 769 RVA: 0x00032DF0 File Offset: 0x00030FF0
		[NullableContext(1)]
		[return: Nullable(2)]
		public string GetValue(string key)
		{
			object @lock = this._lock;
			string result;
			lock (@lock)
			{
				string val;
				result = (this._rawConfig.TryGetValue(key, out val) ? val : null);
			}
			return result;
		}

		// Token: 0x040001A5 RID: 421
		[Nullable(1)]
		private readonly Dictionary<string, string> _rawConfig = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x040001A6 RID: 422
		[Nullable(1)]
		private readonly object _lock = new object();
	}
}
