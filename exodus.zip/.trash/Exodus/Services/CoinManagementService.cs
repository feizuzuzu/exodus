﻿using System;
using System.Runtime.CompilerServices;
using Exodus.Models;

namespace Exodus.Services
{
	// Token: 0x02000069 RID: 105
	[NullableContext(1)]
	[Nullable(0)]
	public class CoinManagementService
	{
		// Token: 0x1700009C RID: 156
		// (get) Token: 0x060002B1 RID: 689 RVA: 0x000300C4 File Offset: 0x0002E2C4
		public static CoinManagementService Instance { get; } = new CoinManagementService();

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x060002B2 RID: 690 RVA: 0x000300CC File Offset: 0x0002E2CC
		// (remove) Token: 0x060002B3 RID: 691 RVA: 0x00030104 File Offset: 0x0002E304
		public event EventHandler CoinSelectedEvent;

		// Token: 0x060002B4 RID: 692 RVA: 0x00030139 File Offset: 0x0002E339
		public void CoinSelected(Coin coin)
		{
			EventHandler coinSelectedEvent = this.CoinSelectedEvent;
			if (coinSelectedEvent == null)
			{
				return;
			}
			coinSelectedEvent(coin, EventArgs.Empty);
		}
	}
}
