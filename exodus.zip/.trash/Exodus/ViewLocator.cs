﻿using System;
using System.Runtime.CompilerServices;
using Avalonia.Controls;
using Avalonia.Controls.Templates;
using Exodus.ViewModels;

namespace Exodus
{
	// Token: 0x02000009 RID: 9
	public class ViewLocator : IDataTemplate, ITemplate<object, Control>
	{
		// Token: 0x0600000F RID: 15 RVA: 0x00002330 File Offset: 0x00000530
		[NullableContext(1)]
		public Control Build(object data)
		{
			string name = data.GetType().FullName.Replace("ViewModel", "View");
			Type type = Type.GetType(name);
			if (type != null)
			{
				return (Control)Activator.CreateInstance(type);
			}
			return new TextBlock
			{
				Text = "Not Found: " + name
			};
		}

		// Token: 0x06000010 RID: 16 RVA: 0x0000238A File Offset: 0x0000058A
		[NullableContext(1)]
		public bool Match(object data)
		{
			return data is ViewModelBase;
		}
	}
}
