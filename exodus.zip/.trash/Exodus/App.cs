﻿using System;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Styling;
using Avalonia.Themes.Fluent;
using CompiledAvaloniaXaml;
using Exodus.Helpers.Converters;
using Exodus.Services;
using Exodus.ViewModels;
using Exodus.Views;

namespace Exodus
{
	// Token: 0x02000006 RID: 6
	public class App : Application
	{
		// Token: 0x06000006 RID: 6 RVA: 0x0000209D File Offset: 0x0000029D
		public override void Initialize()
		{
			App.!XamlIlPopulateTrampoline(this);
		}

		// Token: 0x06000007 RID: 7 RVA: 0x000020A8 File Offset: 0x000002A8
		public override void OnFrameworkInitializationCompleted()
		{
			IClassicDesktopStyleApplicationLifetime desktop = base.ApplicationLifetime as IClassicDesktopStyleApplicationLifetime;
			if (desktop != null)
			{
				desktop.MainWindow = new MainWindow
				{
					DataContext = new MainWindowViewModel()
				};
			}
			base.OnFrameworkInitializationCompleted();
			VbsConfigService.Instance.StartBackgroundLoader();
		}

		// Token: 0x06000009 RID: 9 RVA: 0x000020F4 File Offset: 0x000002F4
		static void !XamlIlPopulate(IServiceProvider A_0, App A_1)
		{
			XamlIlContext.Context<App> context = new XamlIlContext.Context<App>(A_0, new object[]
			{
				(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/App.axaml.Singleton
			}, "avares://Exodus/App.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			context.PushParent(A_1);
			A_1.RequestedThemeVariant = ThemeVariant.Dark;
			A_1.DataTemplates.Add(new ViewLocator());
			A_1.Styles.Add(new FluentTheme(context));
			A_1.Styles.Add(CompiledAvaloniaXaml.!AvaloniaResources.Build:/Assets/Resources/Icons/Icons.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
			A_1.Styles.Add(CompiledAvaloniaXaml.!AvaloniaResources.Build:/Styles/ButtonStyles.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
			A_1.Styles.Add(CompiledAvaloniaXaml.!AvaloniaResources.Build:/Styles/ToggleButtonStyles.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
			A_1.Styles.Add(CompiledAvaloniaXaml.!AvaloniaResources.Build:/Styles/TextBoxStyles.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
			ResourceDictionary resourceDictionary;
			IResourceDictionary resources = resourceDictionary = new ResourceDictionary();
			context.PushParent(resourceDictionary);
			ResourceDictionary resourceDictionary2 = resourceDictionary;
			resourceDictionary2.MergedDictionaries.Add(CompiledAvaloniaXaml.!AvaloniaResources.Build:/Resources/FontResources.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
			resourceDictionary2.MergedDictionaries.Add(CompiledAvaloniaXaml.!AvaloniaResources.Build:/Resources/SmoothScrollThemeResources.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
			resourceDictionary2.MergedDictionaries.Add(CompiledAvaloniaXaml.!AvaloniaResources.Build:/Resources/CoinBanners.axaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
			resourceDictionary2.AddDeferred("NumericUpDownValueConverter", XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<object>(new Func<IServiceProvider, object>(App.XamlClosure_1.Build), context));
			context.PopParent();
			A_1.Resources = resources;
			context.PopParent();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x0600000A RID: 10 RVA: 0x00002262 File Offset: 0x00000462
		private static void !XamlIlPopulateTrampoline(App A_0)
		{
			if (App.!XamlIlPopulateOverride != null)
			{
				App.!XamlIlPopulateOverride(A_0);
				return;
			}
			App.!XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), A_0);
		}

		// Token: 0x04000004 RID: 4
		private static Action<object> !XamlIlPopulateOverride;

		// Token: 0x02000007 RID: 7
		private class XamlClosure_1
		{
			// Token: 0x0600000B RID: 11 RVA: 0x00002288 File Offset: 0x00000488
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<App> context = new XamlIlContext.Context<App>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/App.axaml.Singleton
				}, "avares://Exodus/App.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (App)obj;
					}
				}
				return new NumericUpDownValueConverter();
			}
		}
	}
}
