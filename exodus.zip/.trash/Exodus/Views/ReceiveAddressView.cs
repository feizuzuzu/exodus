﻿using System;
using System.ComponentModel;
using System.Globalization;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Animation.Easings;
using Avalonia.Collections;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Data.Core;
using Avalonia.Data.Core.Plugins;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;

namespace Exodus.Views
{
	// Token: 0x0200002C RID: 44
	public class ReceiveAddressView : Border
	{
		// Token: 0x06000060 RID: 96 RVA: 0x0001D581 File Offset: 0x0001B781
		public ReceiveAddressView()
		{
			this.InitializeComponent(true);
		}

		// Token: 0x06000061 RID: 97 RVA: 0x0001D590 File Offset: 0x0001B790
		public void InitializeComponent(bool loadXaml = true)
		{
			if (loadXaml)
			{
				ReceiveAddressView.!XamlIlPopulateTrampoline(this);
			}
		}

		// Token: 0x06000062 RID: 98 RVA: 0x0001D59C File Offset: 0x0001B79C
		static void !XamlIlPopulate(IServiceProvider A_0, ReceiveAddressView A_1)
		{
			XamlIlContext.Context<ReceiveAddressView> context = new XamlIlContext.Context<ReceiveAddressView>(A_0, new object[]
			{
				(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/ReceiveAddressView.axaml.Singleton
			}, "avares://Exodus/Views/ReceiveAddressView.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			((ISupportInitialize)A_1).BeginInit();
			context.PushParent(A_1);
			A_1.Background = new ImmutableSolidColorBrush(4279901215U);
			AvaloniaProperty opacityProperty = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.Opacity!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider = context;
			context.ProvideTargetProperty = Visual.OpacityProperty;
			IBinding binding = compiledBindingExtension.ProvideValue(provider);
			context.ProvideTargetProperty = null;
			A_1.Bind(opacityProperty, binding, null);
			A_1.Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = Visual.OpacityProperty,
					Duration = TimeSpan.FromTicks(3500000L)
				}
			};
			Grid grid2;
			Grid grid = grid2 = new Grid();
			((ISupportInitialize)grid).BeginInit();
			A_1.Child = grid;
			Grid grid3;
			ISupportInitialize supportInitialize = grid3 = grid2;
			context.PushParent(grid3);
			AvaloniaList<Control> children = grid3.Children;
			Grid grid5;
			Grid grid4 = grid5 = new Grid();
			((ISupportInitialize)grid4).BeginInit();
			children.Add(grid4);
			ISupportInitialize supportInitialize2 = grid3 = grid5;
			context.PushParent(grid3);
			Grid grid6 = grid3;
			grid6.VerticalAlignment = VerticalAlignment.Stretch;
			grid6.HorizontalAlignment = HorizontalAlignment.Stretch;
			RowDefinitions rowDefinitions = new RowDefinitions();
			rowDefinitions.Capacity = 2;
			rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid6.RowDefinitions = rowDefinitions;
			grid6.Margin = new Thickness(25.0, 32.0, 25.0, 32.0);
			AvaloniaList<Control> children2 = grid6.Children;
			Button button2;
			Button button = button2 = new Button();
			((ISupportInitialize)button).BeginInit();
			children2.Add(button);
			Button button3;
			ISupportInitialize supportInitialize3 = button3 = button2;
			context.PushParent(button3);
			Button button4 = button3;
			Grid.SetRow(button4, 0);
			button4.Background = new ImmutableSolidColorBrush(16777215U);
			AvaloniaProperty commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("CloseCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.ReceiveAddressViewModel+CloseCommand_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider2 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding2 = compiledBindingExtension2.ProvideValue(provider2);
			context.ProvideTargetProperty = null;
			button4.Bind(commandProperty, binding2, null);
			button4.HorizontalAlignment = HorizontalAlignment.Right;
			AvaloniaProperty opacityProperty2 = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.SolidOpacity!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider3 = context;
			context.ProvideTargetProperty = Visual.OpacityProperty;
			IBinding binding3 = compiledBindingExtension3.ProvideValue(provider3);
			context.ProvideTargetProperty = null;
			button4.Bind(opacityProperty2, binding3, null);
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsShow!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider4 = context;
			context.ProvideTargetProperty = "class:IsShow";
			IBinding binding4 = compiledBindingExtension4.ProvideValue(provider4);
			context.ProvideTargetProperty = null;
			IBinding source = binding4;
			button4.BindClass("IsShow", source, null);
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsShow!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider5 = context;
			context.ProvideTargetProperty = "class:NotIsShow";
			IBinding binding5 = compiledBindingExtension5.ProvideValue(provider5);
			context.ProvideTargetProperty = null;
			source = binding5;
			button4.BindClass("NotIsShow", source, null);
			button4.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Button)).Class("IsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(3600000L),
						Easing = Easing.Parse("SineEaseOut"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 100.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							}
						}
					}
				}
			});
			button4.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Button)).Class("NotIsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(3600000L),
						Easing = Easing.Parse("SineEaseIn"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 100.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							}
						}
					}
				}
			});
			button4.Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = Visual.OpacityProperty,
					Duration = TimeSpan.FromTicks(3100000L)
				}
			};
			Border border2;
			Border border = border2 = new Border();
			((ISupportInitialize)border).BeginInit();
			button4.Content = border;
			Border border3;
			ISupportInitialize supportInitialize4 = border3 = border2;
			context.PushParent(border3);
			Border border4 = border3;
			border4.Height = 38.0;
			border4.Width = 38.0;
			border4.Background = new ImmutableSolidColorBrush(4281019696U);
			border4.CornerRadius = new CornerRadius(100.0, 100.0, 100.0, 100.0);
			Viewbox viewbox2;
			Viewbox viewbox = viewbox2 = new Viewbox();
			((ISupportInitialize)viewbox).BeginInit();
			border4.Child = viewbox;
			Viewbox viewbox3;
			ISupportInitialize supportInitialize5 = viewbox3 = viewbox2;
			context.PushParent(viewbox3);
			Viewbox viewbox4 = viewbox3;
			viewbox4.Height = 14.0;
			viewbox4.VerticalAlignment = VerticalAlignment.Center;
			viewbox4.HorizontalAlignment = HorizontalAlignment.Center;
			Path path2;
			Path path = path2 = new Path();
			((ISupportInitialize)path).BeginInit();
			viewbox4.Child = path;
			Path path3;
			ISupportInitialize supportInitialize6 = path3 = path2;
			context.PushParent(path3);
			Path path4 = path3;
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("Close");
			IServiceProvider serviceProvider = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj = staticResourceExtension.ProvideValue(serviceProvider);
			context.ProvideTargetProperty = null;
			ReceiveAddressView.DynamicSetters_83.DynamicSetter_1(path4, obj);
			path4.Fill = new ImmutableSolidColorBrush(1560281087U);
			path4.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize6.EndInit();
			context.PopParent();
			supportInitialize5.EndInit();
			context.PopParent();
			supportInitialize4.EndInit();
			context.PopParent();
			supportInitialize3.EndInit();
			AvaloniaList<Control> children3 = grid6.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = stackPanel2 = new StackPanel();
			((ISupportInitialize)stackPanel).BeginInit();
			children3.Add(stackPanel);
			StackPanel stackPanel3;
			ISupportInitialize supportInitialize7 = stackPanel3 = stackPanel2;
			context.PushParent(stackPanel3);
			StackPanel stackPanel4 = stackPanel3;
			Grid.SetRow(stackPanel4, 1);
			stackPanel4.Margin = new Thickness(0.0, -45.0, 0.0, 0.0);
			AvaloniaProperty opacityProperty3 = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.SolidOpacity!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider6 = context;
			context.ProvideTargetProperty = Visual.OpacityProperty;
			IBinding binding6 = compiledBindingExtension6.ProvideValue(provider6);
			context.ProvideTargetProperty = null;
			stackPanel4.Bind(opacityProperty3, binding6, null);
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsShow!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider7 = context;
			context.ProvideTargetProperty = "class:IsShow";
			IBinding binding7 = compiledBindingExtension7.ProvideValue(provider7);
			context.ProvideTargetProperty = null;
			source = binding7;
			stackPanel4.BindClass("IsShow", source, null);
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsShow!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider8 = context;
			context.ProvideTargetProperty = "class:NotIsShow";
			IBinding binding8 = compiledBindingExtension8.ProvideValue(provider8);
			context.ProvideTargetProperty = null;
			source = binding8;
			stackPanel4.BindClass("NotIsShow", source, null);
			stackPanel4.VerticalAlignment = VerticalAlignment.Center;
			stackPanel4.HorizontalAlignment = HorizontalAlignment.Center;
			stackPanel4.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(StackPanel)).Class("IsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(9000000L),
						Delay = TimeSpan.FromTicks(3750000L),
						Easing = Easing.Parse("QuadraticEaseOut"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = -75.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("60%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 12.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							}
						}
					}
				}
			});
			stackPanel4.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(StackPanel)).Class("NotIsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(5000000L),
						Easing = Easing.Parse("QuadraticEaseIn"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = -75.0
									}
								}
							}
						}
					}
				}
			});
			stackPanel4.Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = Visual.OpacityProperty,
					Delay = TimeSpan.FromTicks(3900000L),
					Duration = TimeSpan.FromTicks(4000000L)
				}
			};
			AvaloniaList<Control> children4 = stackPanel4.Children;
			StackPanel stackPanel6;
			StackPanel stackPanel5 = stackPanel6 = new StackPanel();
			((ISupportInitialize)stackPanel5).BeginInit();
			children4.Add(stackPanel5);
			ISupportInitialize supportInitialize8 = stackPanel3 = stackPanel6;
			context.PushParent(stackPanel3);
			StackPanel stackPanel7 = stackPanel3;
			AvaloniaList<Control> children5 = stackPanel7.Children;
			UserControl userControl2;
			UserControl userControl = userControl2 = new UserControl();
			((ISupportInitialize)userControl).BeginInit();
			children5.Add(userControl);
			UserControl userControl3;
			ISupportInitialize supportInitialize9 = userControl3 = userControl2;
			context.PushParent(userControl3);
			UserControl userControl4 = userControl3;
			AvaloniaProperty contentTemplateProperty = ContentControl.ContentTemplateProperty;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControl!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider9 = context;
			context.ProvideTargetProperty = ContentControl.ContentTemplateProperty;
			IBinding binding9 = compiledBindingExtension9.ProvideValue(provider9);
			context.ProvideTargetProperty = null;
			userControl4.Bind(contentTemplateProperty, binding9, null);
			userControl4.Margin = new Thickness(0.0, 0.0, 0.0, 10.0);
			context.PopParent();
			supportInitialize9.EndInit();
			AvaloniaList<Control> children6 = stackPanel7.Children;
			Border border6;
			Border border5 = border6 = new Border();
			((ISupportInitialize)border5).BeginInit();
			children6.Add(border5);
			ISupportInitialize supportInitialize10 = border3 = border6;
			context.PushParent(border3);
			Border border7 = border3;
			border7.Margin = new Thickness(0.0, 4.0, 0.0, 6.0);
			border7.HorizontalAlignment = HorizontalAlignment.Center;
			border7.Height = 28.0;
			border7.CornerRadius = new CornerRadius(14.0, 14.0, 14.0, 14.0);
			border7.Background = new ImmutableSolidColorBrush(637534208U);
			border7.Padding = new Thickness(10.0, 0.0, 10.0, 0.0);
			AvaloniaProperty isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowNetworkPill!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider10 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding10 = compiledBindingExtension10.ProvideValue(provider10);
			context.ProvideTargetProperty = null;
			border7.Bind(isVisibleProperty, binding10, null);
			Grid grid8;
			Grid grid7 = grid8 = new Grid();
			((ISupportInitialize)grid7).BeginInit();
			border7.Child = grid7;
			ISupportInitialize supportInitialize11 = grid3 = grid8;
			context.PushParent(grid3);
			Grid grid9 = grid3;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 3;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid9.ColumnDefinitions = columnDefinitions;
			AvaloniaList<Control> children7 = grid9.Children;
			Image image2;
			Image image = image2 = new Image();
			((ISupportInitialize)image).BeginInit();
			children7.Add(image);
			Image image3;
			ISupportInitialize supportInitialize12 = image3 = image2;
			context.PushParent(image3);
			Image image4 = image3;
			Grid.SetColumn(image4, 0);
			AvaloniaProperty sourceProperty = Image.SourceProperty;
			CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillIcon!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider11 = context;
			context.ProvideTargetProperty = Image.SourceProperty;
			IBinding binding11 = compiledBindingExtension11.ProvideValue(provider11);
			context.ProvideTargetProperty = null;
			image4.Bind(sourceProperty, binding11, null);
			image4.Width = 14.0;
			image4.Height = 14.0;
			image4.Stretch = Stretch.Uniform;
			image4.VerticalAlignment = VerticalAlignment.Center;
			image4.HorizontalAlignment = HorizontalAlignment.Center;
			RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
			AvaloniaProperty isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.HasNetworkPillIcon!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider12 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding12 = compiledBindingExtension12.ProvideValue(provider12);
			context.ProvideTargetProperty = null;
			image4.Bind(isVisibleProperty2, binding12, null);
			image4.Margin = new Thickness(0.0, 0.0, 6.0, 0.0);
			context.PopParent();
			supportInitialize12.EndInit();
			AvaloniaList<Control> children8 = grid9.Children;
			TextBlock textBlock2;
			TextBlock textBlock = textBlock2 = new TextBlock();
			((ISupportInitialize)textBlock).BeginInit();
			children8.Add(textBlock);
			TextBlock textBlock3;
			ISupportInitialize supportInitialize13 = textBlock3 = textBlock2;
			context.PushParent(textBlock3);
			TextBlock textBlock4 = textBlock3;
			Grid.SetColumn(textBlock4, 1);
			textBlock4.FontSize = 12.5;
			StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider2 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj2 = staticResourceExtension2.ProvideValue(serviceProvider2);
			context.ProvideTargetProperty = null;
			ReceiveAddressView.DynamicSetters_83.DynamicSetter_2(textBlock4, obj2);
			AvaloniaProperty textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillText!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider13 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding13 = compiledBindingExtension13.ProvideValue(provider13);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(textProperty, binding13, null);
			textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock4.VerticalAlignment = VerticalAlignment.Center;
			textBlock4.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock4.Opacity = 0.85;
			context.PopParent();
			supportInitialize13.EndInit();
			AvaloniaList<Control> children9 = grid9.Children;
			Viewbox viewbox6;
			Viewbox viewbox5 = viewbox6 = new Viewbox();
			((ISupportInitialize)viewbox5).BeginInit();
			children9.Add(viewbox5);
			ISupportInitialize supportInitialize14 = viewbox3 = viewbox6;
			context.PushParent(viewbox3);
			Viewbox viewbox7 = viewbox3;
			Grid.SetColumn(viewbox7, 2);
			viewbox7.HorizontalAlignment = HorizontalAlignment.Right;
			viewbox7.VerticalAlignment = VerticalAlignment.Center;
			viewbox7.Width = 7.0;
			viewbox7.Height = 4.0;
			viewbox7.Margin = new Thickness(6.0, 0.0, 0.0, 0.0);
			AvaloniaProperty isVisibleProperty3 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillHasDropdown!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider14 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding14 = compiledBindingExtension14.ProvideValue(provider14);
			context.ProvideTargetProperty = null;
			viewbox7.Bind(isVisibleProperty3, binding14, null);
			Path path6;
			Path path5 = path6 = new Path();
			((ISupportInitialize)path5).BeginInit();
			viewbox7.Child = path5;
			ISupportInitialize supportInitialize15 = path3 = path6;
			context.PushParent(path3);
			Path path7 = path3;
			StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("PointDownFullArrow");
			IServiceProvider serviceProvider3 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj3 = staticResourceExtension3.ProvideValue(serviceProvider3);
			context.ProvideTargetProperty = null;
			ReceiveAddressView.DynamicSetters_83.DynamicSetter_1(path7, obj3);
			path7.Stretch = Stretch.Uniform;
			path7.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			path7.Opacity = 0.4;
			context.PopParent();
			supportInitialize15.EndInit();
			context.PopParent();
			supportInitialize14.EndInit();
			context.PopParent();
			supportInitialize11.EndInit();
			context.PopParent();
			supportInitialize10.EndInit();
			context.PopParent();
			supportInitialize8.EndInit();
			AvaloniaList<Control> children10 = stackPanel4.Children;
			Grid grid11;
			Grid grid10 = grid11 = new Grid();
			((ISupportInitialize)grid10).BeginInit();
			children10.Add(grid10);
			ISupportInitialize supportInitialize16 = grid3 = grid11;
			context.PushParent(grid3);
			Grid grid12 = grid3;
			grid12.Margin = new Thickness(0.0, 22.0, 0.0, 16.0);
			grid12.HorizontalAlignment = HorizontalAlignment.Center;
			Styles styles = grid12.Styles;
			Style style;
			IStyle item = style = new Style();
			context.PushParent(style);
			Style style2 = style;
			style2.Selector = Selectors.OfType((Selector)null, typeof(TextBlock));
			style2.Add(new Setter
			{
				Property = TextBlock.FontSizeProperty,
				Value = 16.0
			});
			Setter setter2;
			SetterBase setter = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter3 = setter2;
			setter3.Property = TextBlock.FontFamilyProperty;
			StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider4 = context;
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia.Styling.Setter,Avalonia.Base.Value!Property();
			object value = staticResourceExtension4.ProvideValue(serviceProvider4);
			context.ProvideTargetProperty = null;
			setter3.Value = value;
			context.PopParent();
			style2.Add(setter);
			style2.Add(new Setter
			{
				Property = Layoutable.HorizontalAlignmentProperty,
				Value = HorizontalAlignment.Center
			});
			style2.Add(new Setter
			{
				Property = TextBlock.TextAlignmentProperty,
				Value = TextAlignment.Center
			});
			context.PopParent();
			styles.Add(item);
			AvaloniaList<Control> children11 = grid12.Children;
			TextBlock textBlock6;
			TextBlock textBlock5 = textBlock6 = new TextBlock();
			((ISupportInitialize)textBlock5).BeginInit();
			children11.Add(textBlock5);
			ISupportInitialize supportInitialize17 = textBlock3 = textBlock6;
			context.PushParent(textBlock3);
			AvaloniaObject target = textBlock3;
			AvaloniaProperty textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.YourAddressTitle!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider15 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding15 = compiledBindingExtension15.ProvideValue(provider15);
			context.ProvideTargetProperty = null;
			target.Bind(textProperty2, binding15, null);
			context.PopParent();
			supportInitialize17.EndInit();
			context.PopParent();
			supportInitialize16.EndInit();
			AvaloniaList<Control> children12 = stackPanel4.Children;
			Border border9;
			Border border8 = border9 = new Border();
			((ISupportInitialize)border8).BeginInit();
			children12.Add(border8);
			ISupportInitialize supportInitialize18 = border3 = border9;
			context.PushParent(border3);
			Border border10 = border3;
			border10.Margin = new Thickness(0.0, 3.0, 0.0, 20.0);
			border10.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
			border10.Width = 550.0;
			border10.Height = 45.0;
			Styles styles2 = border10.Styles;
			Style style3 = new Style();
			style3.Selector = Selectors.OfType((Selector)null, typeof(Border));
			style3.Add(new Setter
			{
				Property = Border.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(184549375U)
			});
			styles2.Add(style3);
			Styles styles3 = border10.Styles;
			Style style4 = new Style();
			style4.Selector = Selectors.OfType((Selector)null, typeof(Border)).Class(":pointerover");
			style4.Add(new Setter
			{
				Property = Border.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(234881023U)
			});
			styles3.Add(style4);
			border10.Transitions = new Transitions
			{
				new BrushTransition
				{
					Property = Border.BackgroundProperty,
					Duration = TimeSpan.FromTicks(1200000L),
					Easing = Easing.Parse("SineEaseInOut")
				}
			};
			Grid grid14;
			Grid grid13 = grid14 = new Grid();
			((ISupportInitialize)grid13).BeginInit();
			border10.Child = grid13;
			ISupportInitialize supportInitialize19 = grid3 = grid14;
			context.PushParent(grid3);
			Grid grid15 = grid3;
			AvaloniaList<Control> children13 = grid15.Children;
			Grid grid17;
			Grid grid16 = grid17 = new Grid();
			((ISupportInitialize)grid16).BeginInit();
			children13.Add(grid16);
			ISupportInitialize supportInitialize20 = grid3 = grid17;
			context.PushParent(grid3);
			Grid grid18 = grid3;
			AvaloniaProperty opacityProperty4 = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.AddressOpacity!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider16 = context;
			context.ProvideTargetProperty = Visual.OpacityProperty;
			IBinding binding16 = compiledBindingExtension16.ProvideValue(provider16);
			context.ProvideTargetProperty = null;
			grid18.Bind(opacityProperty4, binding16, null);
			ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
			columnDefinitions2.Capacity = 2;
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid18.ColumnDefinitions = columnDefinitions2;
			grid18.Margin = new Thickness(4.0, 0.0, 4.0, 0.0);
			grid18.Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = Visual.OpacityProperty,
					Duration = TimeSpan.FromTicks(4000000L)
				}
			};
			AvaloniaList<Control> children14 = grid18.Children;
			TextBlock textBlock8;
			TextBlock textBlock7 = textBlock8 = new TextBlock();
			((ISupportInitialize)textBlock7).BeginInit();
			children14.Add(textBlock7);
			ISupportInitialize supportInitialize21 = textBlock3 = textBlock8;
			context.PushParent(textBlock3);
			TextBlock textBlock9 = textBlock3;
			Grid.SetColumn(textBlock9, 0);
			Grid.SetColumnSpan(textBlock9, 2);
			AvaloniaProperty foregroundProperty = TextBlock.ForegroundProperty;
			CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider17 = context;
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			IBinding binding17 = compiledBindingExtension17.ProvideValue(provider17);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(foregroundProperty, binding17, null);
			textBlock9.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock9.VerticalAlignment = VerticalAlignment.Center;
			textBlock9.TextAlignment = TextAlignment.Center;
			textBlock9.FontSize = 16.0;
			StaticResourceExtension staticResourceExtension5 = new StaticResourceExtension("RobotoCondensedLight");
			IServiceProvider serviceProvider5 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj4 = staticResourceExtension5.ProvideValue(serviceProvider5);
			context.ProvideTargetProperty = null;
			ReceiveAddressView.DynamicSetters_83.DynamicSetter_2(textBlock9, obj4);
			textBlock9.Opacity = 0.9;
			textBlock9.LetterSpacing = -0.2;
			AvaloniaProperty textProperty3 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.MainWindowVm!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoin!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.Address!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider18 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding18 = compiledBindingExtension18.ProvideValue(provider18);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(textProperty3, binding18, null);
			context.PopParent();
			supportInitialize21.EndInit();
			AvaloniaList<Control> children15 = grid18.Children;
			Button button6;
			Button button5 = button6 = new Button();
			((ISupportInitialize)button5).BeginInit();
			children15.Add(button5);
			ISupportInitialize supportInitialize22 = button3 = button6;
			context.PushParent(button3);
			Button button7 = button3;
			Grid.SetColumn(button7, 1);
			button7.Background = new ImmutableSolidColorBrush(16777215U);
			AvaloniaProperty commandProperty2 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyCommand!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider19 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding19 = compiledBindingExtension19.ProvideValue(provider19);
			context.ProvideTargetProperty = null;
			button7.Bind(commandProperty2, binding19, null);
			Styles styles4 = button7.Styles;
			IStyle item2 = style = new Style();
			context.PushParent(style);
			Style style5 = style;
			style5.Selector = Selectors.OfType((Selector)null, typeof(Button));
			style5.Add(new Setter
			{
				Property = TemplatedControl.ForegroundProperty,
				Value = new ImmutableSolidColorBrush(2164260863U)
			});
			SetterBase setter4 = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter5 = setter2;
			setter5.Property = Visual.RenderTransformProperty;
			setter5.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(1)");
			context.PopParent();
			style5.Add(setter4);
			context.PopParent();
			styles4.Add(item2);
			Styles styles5 = button7.Styles;
			IStyle item3 = style = new Style();
			context.PushParent(style);
			Style style6 = style;
			style6.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pointerover");
			style6.Add(new Setter
			{
				Property = TemplatedControl.ForegroundProperty,
				Value = new ImmutableSolidColorBrush(3019898879U)
			});
			SetterBase setter6 = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter7 = setter2;
			setter7.Property = Visual.RenderTransformProperty;
			setter7.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(0.995)");
			context.PopParent();
			style6.Add(setter6);
			context.PopParent();
			styles5.Add(item3);
			Styles styles6 = button7.Styles;
			IStyle item4 = style = new Style();
			context.PushParent(style);
			Style style7 = style;
			style7.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pressed");
			style7.Add(new Setter
			{
				Property = TemplatedControl.ForegroundProperty,
				Value = new ImmutableSolidColorBrush(3019898879U)
			});
			SetterBase setter8 = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter9 = setter2;
			setter9.Property = Visual.RenderTransformProperty;
			setter9.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(0.993)");
			context.PopParent();
			style7.Add(setter8);
			context.PopParent();
			styles6.Add(item4);
			Viewbox viewbox9;
			Viewbox viewbox8 = viewbox9 = new Viewbox();
			((ISupportInitialize)viewbox8).BeginInit();
			button7.Content = viewbox8;
			ISupportInitialize supportInitialize23 = viewbox3 = viewbox9;
			context.PushParent(viewbox3);
			Viewbox viewbox10 = viewbox3;
			viewbox10.VerticalAlignment = VerticalAlignment.Center;
			viewbox10.Height = 20.0;
			Path path9;
			Path path8 = path9 = new Path();
			((ISupportInitialize)path8).BeginInit();
			viewbox10.Child = path8;
			ISupportInitialize supportInitialize24 = path3 = path9;
			context.PushParent(path3);
			Path path10 = path3;
			StaticResourceExtension staticResourceExtension6 = new StaticResourceExtension("CopyLight");
			IServiceProvider serviceProvider6 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj5 = staticResourceExtension6.ProvideValue(serviceProvider6);
			context.ProvideTargetProperty = null;
			ReceiveAddressView.DynamicSetters_83.DynamicSetter_1(path10, obj5);
			AvaloniaProperty fillProperty = Shape.FillProperty;
			CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(Button), 0).Property(TemplatedControl.ForegroundProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).Build());
			IServiceProvider provider20 = context;
			context.ProvideTargetProperty = Shape.FillProperty;
			IBinding binding20 = compiledBindingExtension20.ProvideValue(provider20);
			context.ProvideTargetProperty = null;
			path10.Bind(fillProperty, binding20, null);
			path10.Opacity = 0.5;
			path10.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize24.EndInit();
			context.PopParent();
			supportInitialize23.EndInit();
			context.PopParent();
			supportInitialize22.EndInit();
			context.PopParent();
			supportInitialize20.EndInit();
			AvaloniaList<Control> children16 = grid15.Children;
			TextBlock textBlock11;
			TextBlock textBlock10 = textBlock11 = new TextBlock();
			((ISupportInitialize)textBlock10).BeginInit();
			children16.Add(textBlock10);
			ISupportInitialize supportInitialize25 = textBlock3 = textBlock11;
			context.PushParent(textBlock3);
			TextBlock textBlock12 = textBlock3;
			AvaloniaProperty opacityProperty5 = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.CopyOpacity!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider21 = context;
			context.ProvideTargetProperty = Visual.OpacityProperty;
			IBinding binding21 = compiledBindingExtension21.ProvideValue(provider21);
			context.ProvideTargetProperty = null;
			textBlock12.Bind(opacityProperty5, binding21, null);
			textBlock12.Foreground = new ImmutableSolidColorBrush(4286283908U);
			textBlock12.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock12.VerticalAlignment = VerticalAlignment.Center;
			textBlock12.TextAlignment = TextAlignment.Center;
			textBlock12.FontSize = 14.0;
			StaticResourceExtension staticResourceExtension7 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider7 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj6 = staticResourceExtension7.ProvideValue(serviceProvider7);
			context.ProvideTargetProperty = null;
			ReceiveAddressView.DynamicSetters_83.DynamicSetter_2(textBlock12, obj6);
			textBlock12.Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = Visual.OpacityProperty,
					Duration = TimeSpan.FromTicks(4000000L)
				}
			};
			textBlock12.Inlines.Add("Copied to clipboard");
			context.PopParent();
			supportInitialize25.EndInit();
			context.PopParent();
			supportInitialize19.EndInit();
			context.PopParent();
			supportInitialize18.EndInit();
			AvaloniaList<Control> children17 = stackPanel4.Children;
			Border border12;
			Border border11 = border12 = new Border();
			((ISupportInitialize)border11).BeginInit();
			children17.Add(border11);
			ISupportInitialize supportInitialize26 = border3 = border12;
			context.PushParent(border3);
			Border border13 = border3;
			border13.Margin = new Thickness(0.0, 10.0, 0.0, 20.0);
			border13.Height = 165.0;
			border13.Width = 165.0;
			border13.Background = new ImmutableSolidColorBrush(uint.MaxValue);
			border13.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
			border13.HorizontalAlignment = HorizontalAlignment.Center;
			Image image6;
			Image image5 = image6 = new Image();
			((ISupportInitialize)image5).BeginInit();
			border13.Child = image5;
			ISupportInitialize supportInitialize27 = image3 = image6;
			context.PushParent(image3);
			Image image7 = image3;
			image7.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/qrcode.png");
			image7.Stretch = Stretch.Uniform;
			image7.Margin = new Thickness(10.0, 10.0, 10.0, 10.0);
			RenderOptions.SetBitmapInterpolationMode(image7, BitmapInterpolationMode.HighQuality);
			image7.HorizontalAlignment = HorizontalAlignment.Stretch;
			image7.VerticalAlignment = VerticalAlignment.Stretch;
			context.PopParent();
			supportInitialize27.EndInit();
			context.PopParent();
			supportInitialize26.EndInit();
			AvaloniaList<Control> children18 = stackPanel4.Children;
			Grid grid20;
			Grid grid19 = grid20 = new Grid();
			((ISupportInitialize)grid19).BeginInit();
			children18.Add(grid19);
			ISupportInitialize supportInitialize28 = grid3 = grid20;
			context.PushParent(grid3);
			Grid grid21 = grid3;
			ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
			columnDefinitions3.Capacity = 2;
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid21.ColumnDefinitions = columnDefinitions3;
			grid21.HorizontalAlignment = HorizontalAlignment.Center;
			grid21.Margin = new Thickness(0.0, 20.0, 0.0, 20.0);
			grid21.Width = 238.0;
			Styles styles7 = grid21.Styles;
			IStyle item5 = style = new Style();
			context.PushParent(style);
			Style style8 = style;
			style8.Selector = Selectors.OfType((Selector)null, typeof(Button));
			SetterBase setter10 = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter11 = setter2;
			setter11.Property = Visual.RenderTransformProperty;
			setter11.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(1)");
			context.PopParent();
			style8.Add(setter10);
			context.PopParent();
			styles7.Add(item5);
			Styles styles8 = grid21.Styles;
			IStyle item6 = style = new Style();
			context.PushParent(style);
			Style style9 = style;
			style9.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pointerover");
			SetterBase setter12 = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter13 = setter2;
			setter13.Property = Visual.RenderTransformProperty;
			setter13.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(0.990)");
			context.PopParent();
			style9.Add(setter12);
			context.PopParent();
			styles8.Add(item6);
			Styles styles9 = grid21.Styles;
			IStyle item7 = style = new Style();
			context.PushParent(style);
			Style style10 = style;
			style10.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pressed");
			SetterBase setter14 = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter15 = setter2;
			setter15.Property = Visual.RenderTransformProperty;
			setter15.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(0.985)");
			context.PopParent();
			style10.Add(setter14);
			context.PopParent();
			styles9.Add(item7);
			AvaloniaList<Control> children19 = grid21.Children;
			Button button9;
			Button button8 = button9 = new Button();
			((ISupportInitialize)button8).BeginInit();
			children19.Add(button8);
			ISupportInitialize supportInitialize29 = button3 = button9;
			context.PushParent(button3);
			Button button10 = button3;
			Grid.SetColumn(button10, 0);
			button10.Background = new ImmutableSolidColorBrush(16777215U);
			button10.HorizontalAlignment = HorizontalAlignment.Left;
			Grid grid23;
			Grid grid22 = grid23 = new Grid();
			((ISupportInitialize)grid22).BeginInit();
			button10.Content = grid22;
			ISupportInitialize supportInitialize30 = grid3 = grid23;
			context.PushParent(grid3);
			Grid grid24 = grid3;
			RowDefinitions rowDefinitions2 = new RowDefinitions();
			rowDefinitions2.Capacity = 3;
			rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions2.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid24.RowDefinitions = rowDefinitions2;
			grid24.Height = 112.0;
			grid24.Width = 105.0;
			AvaloniaList<Control> children20 = grid24.Children;
			Border border15;
			Border border14 = border15 = new Border();
			((ISupportInitialize)border14).BeginInit();
			children20.Add(border14);
			ISupportInitialize supportInitialize31 = border3 = border15;
			context.PushParent(border3);
			Border border16 = border3;
			Grid.SetRow(border16, 0);
			border16.Height = 50.0;
			border16.Width = 50.0;
			border16.CornerRadius = new CornerRadius(16.0, 16.0, 16.0, 16.0);
			border16.Background = new ImmutableSolidColorBrush(232315096U);
			border16.HorizontalAlignment = HorizontalAlignment.Center;
			Image image9;
			Image image8 = image9 = new Image();
			((ISupportInitialize)image8).BeginInit();
			border16.Child = image8;
			ISupportInitialize supportInitialize32 = image3 = image9;
			context.PushParent(image3);
			Image image10 = image3;
			image10.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/icon-unread.png");
			image10.Stretch = Stretch.Uniform;
			image10.Width = 23.0;
			image10.Opacity = 0.5;
			RenderOptions.SetBitmapInterpolationMode(image10, BitmapInterpolationMode.HighQuality);
			context.PopParent();
			supportInitialize32.EndInit();
			context.PopParent();
			supportInitialize31.EndInit();
			AvaloniaList<Control> children21 = grid24.Children;
			Grid grid26;
			Grid grid25 = grid26 = new Grid();
			((ISupportInitialize)grid25).BeginInit();
			children21.Add(grid25);
			Grid grid27 = grid26;
			Grid.SetRow(grid27, 1);
			grid27.VerticalAlignment = VerticalAlignment.Stretch;
			((ISupportInitialize)grid27).EndInit();
			AvaloniaList<Control> children22 = grid24.Children;
			TextBlock textBlock14;
			TextBlock textBlock13 = textBlock14 = new TextBlock();
			((ISupportInitialize)textBlock13).BeginInit();
			children22.Add(textBlock13);
			ISupportInitialize supportInitialize33 = textBlock3 = textBlock14;
			context.PushParent(textBlock3);
			TextBlock textBlock15 = textBlock3;
			Grid.SetRow(textBlock15, 2);
			textBlock15.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock15.Opacity = 0.4;
			textBlock15.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock15.VerticalAlignment = VerticalAlignment.Center;
			textBlock15.TextAlignment = TextAlignment.Center;
			textBlock15.FontSize = 14.0;
			StaticResourceExtension staticResourceExtension8 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider8 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj7 = staticResourceExtension8.ProvideValue(serviceProvider8);
			context.ProvideTargetProperty = null;
			ReceiveAddressView.DynamicSetters_83.DynamicSetter_2(textBlock15, obj7);
			textBlock15.Text = "Email This Address";
			textBlock15.TextWrapping = TextWrapping.WrapWithOverflow;
			context.PopParent();
			supportInitialize33.EndInit();
			context.PopParent();
			supportInitialize30.EndInit();
			context.PopParent();
			supportInitialize29.EndInit();
			AvaloniaList<Control> children23 = grid21.Children;
			Button button12;
			Button button11 = button12 = new Button();
			((ISupportInitialize)button11).BeginInit();
			children23.Add(button11);
			ISupportInitialize supportInitialize34 = button3 = button12;
			context.PushParent(button3);
			Button button13 = button3;
			Grid.SetColumn(button13, 1);
			button13.Background = new ImmutableSolidColorBrush(16777215U);
			button13.HorizontalAlignment = HorizontalAlignment.Right;
			AvaloniaProperty commandProperty3 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("ChainCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.ReceiveAddressViewModel+ChainCommand_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider22 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding22 = compiledBindingExtension22.ProvideValue(provider22);
			context.ProvideTargetProperty = null;
			button13.Bind(commandProperty3, binding22, null);
			Grid grid29;
			Grid grid28 = grid29 = new Grid();
			((ISupportInitialize)grid28).BeginInit();
			button13.Content = grid28;
			ISupportInitialize supportInitialize35 = grid3 = grid29;
			context.PushParent(grid3);
			Grid grid30 = grid3;
			RowDefinitions rowDefinitions3 = new RowDefinitions();
			rowDefinitions3.Capacity = 3;
			rowDefinitions3.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions3.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			rowDefinitions3.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid30.RowDefinitions = rowDefinitions3;
			grid30.Height = 112.0;
			grid30.Width = 105.0;
			AvaloniaList<Control> children24 = grid30.Children;
			Border border18;
			Border border17 = border18 = new Border();
			((ISupportInitialize)border17).BeginInit();
			children24.Add(border17);
			ISupportInitialize supportInitialize36 = border3 = border18;
			context.PushParent(border3);
			Border border19 = border3;
			Grid.SetRow(border19, 0);
			border19.Height = 50.0;
			border19.Width = 50.0;
			border19.CornerRadius = new CornerRadius(16.0, 16.0, 16.0, 16.0);
			border19.Background = new ImmutableSolidColorBrush(232315096U);
			border19.HorizontalAlignment = HorizontalAlignment.Center;
			Viewbox viewbox12;
			Viewbox viewbox11 = viewbox12 = new Viewbox();
			((ISupportInitialize)viewbox11).BeginInit();
			border19.Child = viewbox11;
			ISupportInitialize supportInitialize37 = viewbox3 = viewbox12;
			context.PushParent(viewbox3);
			Viewbox viewbox13 = viewbox3;
			viewbox13.Width = 23.0;
			viewbox13.VerticalAlignment = VerticalAlignment.Center;
			viewbox13.HorizontalAlignment = HorizontalAlignment.Center;
			Path path12;
			Path path11 = path12 = new Path();
			((ISupportInitialize)path11).BeginInit();
			viewbox13.Child = path11;
			ISupportInitialize supportInitialize38 = path3 = path12;
			context.PushParent(path3);
			Path path13 = path3;
			StaticResourceExtension staticResourceExtension9 = new StaticResourceExtension("Chain");
			IServiceProvider serviceProvider9 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj8 = staticResourceExtension9.ProvideValue(serviceProvider9);
			context.ProvideTargetProperty = null;
			ReceiveAddressView.DynamicSetters_83.DynamicSetter_1(path13, obj8);
			path13.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			path13.Opacity = 0.5;
			path13.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize38.EndInit();
			context.PopParent();
			supportInitialize37.EndInit();
			context.PopParent();
			supportInitialize36.EndInit();
			AvaloniaList<Control> children25 = grid30.Children;
			Grid grid32;
			Grid grid31 = grid32 = new Grid();
			((ISupportInitialize)grid31).BeginInit();
			children25.Add(grid31);
			Grid grid33 = grid32;
			Grid.SetRow(grid33, 1);
			grid33.VerticalAlignment = VerticalAlignment.Stretch;
			((ISupportInitialize)grid33).EndInit();
			AvaloniaList<Control> children26 = grid30.Children;
			TextBlock textBlock17;
			TextBlock textBlock16 = textBlock17 = new TextBlock();
			((ISupportInitialize)textBlock16).BeginInit();
			children26.Add(textBlock16);
			ISupportInitialize supportInitialize39 = textBlock3 = textBlock17;
			context.PushParent(textBlock3);
			TextBlock textBlock18 = textBlock3;
			Grid.SetRow(textBlock18, 2);
			textBlock18.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock18.Opacity = 0.4;
			textBlock18.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock18.VerticalAlignment = VerticalAlignment.Center;
			textBlock18.TextAlignment = TextAlignment.Center;
			textBlock18.FontSize = 14.0;
			StaticResourceExtension staticResourceExtension10 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider10 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj9 = staticResourceExtension10.ProvideValue(serviceProvider10);
			context.ProvideTargetProperty = null;
			ReceiveAddressView.DynamicSetters_83.DynamicSetter_2(textBlock18, obj9);
			textBlock18.Text = "View On Blockchain";
			textBlock18.TextWrapping = TextWrapping.WrapWithOverflow;
			context.PopParent();
			supportInitialize39.EndInit();
			context.PopParent();
			supportInitialize35.EndInit();
			context.PopParent();
			supportInitialize34.EndInit();
			context.PopParent();
			supportInitialize28.EndInit();
			context.PopParent();
			supportInitialize7.EndInit();
			context.PopParent();
			supportInitialize2.EndInit();
			context.PopParent();
			supportInitialize.EndInit();
			context.PopParent();
			((ISupportInitialize)A_1).EndInit();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x06000063 RID: 99 RVA: 0x0001FF5B File Offset: 0x0001E15B
		private static void !XamlIlPopulateTrampoline(ReceiveAddressView A_0)
		{
			if (ReceiveAddressView.!XamlIlPopulateOverride != null)
			{
				ReceiveAddressView.!XamlIlPopulateOverride(A_0);
				return;
			}
			ReceiveAddressView.!XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), A_0);
		}

		// Token: 0x04000014 RID: 20
		private static Action<object> !XamlIlPopulateOverride;

		// Token: 0x0200002D RID: 45
		private class DynamicSetters_83
		{
			// Token: 0x06000064 RID: 100 RVA: 0x0001FF80 File Offset: 0x0001E180
			public static void DynamicSetter_1(Path A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(Path.DataProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(Path.DataProperty, A_1, null);
					return;
				}
				if (A_1 is Geometry)
				{
					A_0.Data = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.Data = A_1;
					return;
				}
				throw new InvalidCastException();
			}

			// Token: 0x06000065 RID: 101 RVA: 0x0001FFEC File Offset: 0x0001E1EC
			public static void DynamicSetter_2(TextBlock A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
					return;
				}
				if (A_1 is FontFamily)
				{
					A_0.FontFamily = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.FontFamily = A_1;
					return;
				}
				throw new InvalidCastException();
			}
		}
	}
}
