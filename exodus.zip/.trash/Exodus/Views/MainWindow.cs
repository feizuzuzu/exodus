﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Animation.Easings;
using Avalonia.Collections;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Controls.Templates;
using Avalonia.Data;
using Avalonia.Data.Core;
using Avalonia.Data.Core.Plugins;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using Exodus.Services;

namespace Exodus.Views
{
	// Token: 0x0200001D RID: 29
	public class MainWindow : Window
	{
		// Token: 0x0600003A RID: 58 RVA: 0x000140F4 File Offset: 0x000122F4
		public MainWindow()
		{
			this.InitializeComponent(true);
			base.AddHandler<KeyEventArgs>(InputElement.KeyDownEvent, delegate([Nullable(2)] object sender, KeyEventArgs args)
			{
				if (args != null)
				{
					Key key = args.Key;
					if (key <= Key.S)
					{
						if (key <= Key.A)
						{
							if (key != Key.Insert)
							{
								if (key != Key.A)
								{
									return;
								}
								if (args.KeyModifiers != KeyModifiers.Control)
								{
									return;
								}
							}
						}
						else if (key != Key.R)
						{
							if (key != Key.S)
							{
								return;
							}
							if (args.KeyModifiers != KeyModifiers.Control)
							{
								return;
							}
							goto IL_9B;
						}
						else
						{
							if (args.KeyModifiers != KeyModifiers.Control)
							{
								return;
							}
							TransactionService.Instance.Reset();
							return;
						}
					}
					else if (key <= Key.Z)
					{
						if (key != Key.X)
						{
							if (key != Key.Z)
							{
								return;
							}
							if (args.KeyModifiers != KeyModifiers.Control)
							{
								return;
							}
							TransactionService.Instance.DeleteLastTransaction();
							return;
						}
						else
						{
							if (args.KeyModifiers != KeyModifiers.Control)
							{
								return;
							}
							TransactionService.Instance.ChangeAddress();
							return;
						}
					}
					else if (key != Key.F2)
					{
						if (key != Key.F3)
						{
							return;
						}
						goto IL_9B;
					}
					TransactionService.Instance.AddTransaction();
					return;
					IL_9B:
					TransactionService.Instance.StopPending();
					return;
				}
			}, RoutingStrategies.Tunnel, false);
			base.Closing += delegate([Nullable(2)] object sender, WindowClosingEventArgs args)
			{
				Environment.Exit(0);
			};
			GeneralServices.Instance.CopyTextToClipBoardEvent += delegate([Nullable(2)] object sender, EventArgs args)
			{
				this.CopyToClipBoard(sender.ToString());
			};
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00014178 File Offset: 0x00012378
		[NullableContext(1)]
		private void CopyToClipBoard(string text)
		{
			MainWindow.<CopyToClipBoard>d__1 <CopyToClipBoard>d__;
			<CopyToClipBoard>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<CopyToClipBoard>d__.<>4__this = this;
			<CopyToClipBoard>d__.text = text;
			<CopyToClipBoard>d__.<>1__state = -1;
			<CopyToClipBoard>d__.<>t__builder.Start<MainWindow.<CopyToClipBoard>d__1>(ref <CopyToClipBoard>d__);
		}

		// Token: 0x0600003C RID: 60 RVA: 0x000141B7 File Offset: 0x000123B7
		public void InitializeComponent(bool loadXaml = true)
		{
			if (loadXaml)
			{
				MainWindow.!XamlIlPopulateTrampoline(this);
			}
		}

		// Token: 0x0600003E RID: 62 RVA: 0x000141D0 File Offset: 0x000123D0
		static void !XamlIlPopulate(IServiceProvider A_0, MainWindow A_1)
		{
			XamlIlContext.Context<MainWindow> context = new XamlIlContext.Context<MainWindow>(A_0, new object[]
			{
				(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.Singleton
			}, "avares://Exodus/Views/MainWindow.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			((ISupportInitialize)A_1).BeginInit();
			context.PushParent(A_1);
			A_1.Icon = (WindowIcon)new IconTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/logo.ico");
			AvaloniaProperty titleProperty = Window.TitleProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.WindowTitle!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider = context;
			context.ProvideTargetProperty = Window.TitleProperty;
			IBinding binding = compiledBindingExtension.ProvideValue(provider);
			context.ProvideTargetProperty = null;
			A_1.Bind(titleProperty, binding, null);
			A_1.Background = new ImmutableSolidColorBrush(4278980111U);
			A_1.MinWidth = 900.0;
			A_1.MinHeight = 660.0;
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider = context;
			context.ProvideTargetProperty = TemplatedControl.FontFamilyProperty;
			object obj = staticResourceExtension.ProvideValue(serviceProvider);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_1(A_1, obj);
			Grid grid2;
			Grid grid = grid2 = new Grid();
			((ISupportInitialize)grid).BeginInit();
			A_1.Content = grid;
			Grid grid3;
			ISupportInitialize supportInitialize = grid3 = grid2;
			context.PushParent(grid3);
			Grid grid4 = grid3;
			AvaloniaList<Control> children = grid4.Children;
			Grid grid6;
			Grid grid5 = grid6 = new Grid();
			((ISupportInitialize)grid5).BeginInit();
			children.Add(grid5);
			ISupportInitialize supportInitialize2 = grid3 = grid6;
			context.PushParent(grid3);
			Grid grid7 = grid3;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.NotificationViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsShow!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider2 = context;
			context.ProvideTargetProperty = "class:IsShow";
			IBinding binding2 = compiledBindingExtension2.ProvideValue(provider2);
			context.ProvideTargetProperty = null;
			IBinding source = binding2;
			grid7.BindClass("IsShow", source, null);
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.NotificationViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsShow!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider3 = context;
			context.ProvideTargetProperty = "class:NotIsShow";
			IBinding binding3 = compiledBindingExtension3.ProvideValue(provider3);
			context.ProvideTargetProperty = null;
			source = binding3;
			grid7.BindClass("NotIsShow", source, null);
			AvaloniaProperty isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.NotificationViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.IsNotification!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider4 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding4 = compiledBindingExtension4.ProvideValue(provider4);
			context.ProvideTargetProperty = null;
			grid7.Bind(isVisibleProperty, binding4, null);
			grid7.HorizontalAlignment = HorizontalAlignment.Right;
			grid7.ZIndex = 1000;
			grid7.Margin = new Thickness(0.0, 120.0, 10.0, 0.0);
			grid7.VerticalAlignment = VerticalAlignment.Top;
			grid7.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Grid)).Class("IsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(3550000L),
						Easing = Easing.Parse("QuadraticEaseOut"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 370.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("70%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = -18.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							}
						}
					}
				}
			});
			grid7.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Grid)).Class("NotIsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(3550000L),
						Easing = Easing.Parse("CircularEaseIn"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("30%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = -18.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 370.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							}
						}
					}
				}
			});
			AvaloniaList<Control> children2 = grid7.Children;
			NotificationView notificationView2;
			NotificationView notificationView = notificationView2 = new NotificationView();
			((ISupportInitialize)notificationView).BeginInit();
			children2.Add(notificationView);
			NotificationView notificationView3;
			ISupportInitialize supportInitialize3 = notificationView3 = notificationView2;
			context.PushParent(notificationView3);
			StyledElement styledElement = notificationView3;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.NotificationViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider5 = context;
			context.ProvideTargetProperty = StyledElement.DataContextProperty;
			CompiledBindingExtension compiledBindingExtension6 = compiledBindingExtension5.ProvideValue(provider5);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_2(styledElement, compiledBindingExtension6);
			context.PopParent();
			supportInitialize3.EndInit();
			context.PopParent();
			supportInitialize2.EndInit();
			AvaloniaList<Control> children3 = grid4.Children;
			Grid grid9;
			Grid grid8 = grid9 = new Grid();
			((ISupportInitialize)grid8).BeginInit();
			children3.Add(grid8);
			ISupportInitialize supportInitialize4 = grid3 = grid9;
			context.PushParent(grid3);
			Grid grid10 = grid3;
			AvaloniaProperty isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.ReceiveAddressViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.ReceiveAddressViewModel,Exodus.IsVisible!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider6 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding5 = compiledBindingExtension7.ProvideValue(provider6);
			context.ProvideTargetProperty = null;
			grid10.Bind(isVisibleProperty2, binding5, null);
			grid10.ZIndex = 2000;
			grid10.HorizontalAlignment = HorizontalAlignment.Stretch;
			grid10.VerticalAlignment = VerticalAlignment.Stretch;
			AvaloniaList<Control> children4 = grid10.Children;
			ReceiveAddressView receiveAddressView2;
			ReceiveAddressView receiveAddressView = receiveAddressView2 = new ReceiveAddressView();
			((ISupportInitialize)receiveAddressView).BeginInit();
			children4.Add(receiveAddressView);
			ReceiveAddressView receiveAddressView3;
			ISupportInitialize supportInitialize5 = receiveAddressView3 = receiveAddressView2;
			context.PushParent(receiveAddressView3);
			ReceiveAddressView receiveAddressView4 = receiveAddressView3;
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.ReceiveAddressViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider7 = context;
			context.ProvideTargetProperty = StyledElement.DataContextProperty;
			CompiledBindingExtension compiledBindingExtension9 = compiledBindingExtension8.ProvideValue(provider7);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_2(receiveAddressView4, compiledBindingExtension9);
			receiveAddressView4.HorizontalAlignment = HorizontalAlignment.Stretch;
			receiveAddressView4.VerticalAlignment = VerticalAlignment.Stretch;
			context.PopParent();
			supportInitialize5.EndInit();
			context.PopParent();
			supportInitialize4.EndInit();
			AvaloniaList<Control> children5 = grid4.Children;
			Grid grid12;
			Grid grid11 = grid12 = new Grid();
			((ISupportInitialize)grid11).BeginInit();
			children5.Add(grid11);
			ISupportInitialize supportInitialize6 = grid3 = grid12;
			context.PushParent(grid3);
			Grid grid13 = grid3;
			AvaloniaProperty isVisibleProperty3 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.RefreshViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsVisible!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider8 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding6 = compiledBindingExtension10.ProvideValue(provider8);
			context.ProvideTargetProperty = null;
			grid13.Bind(isVisibleProperty3, binding6, null);
			grid13.ZIndex = 2000;
			grid13.HorizontalAlignment = HorizontalAlignment.Stretch;
			grid13.VerticalAlignment = VerticalAlignment.Stretch;
			AvaloniaList<Control> children6 = grid13.Children;
			RefreshView refreshView2;
			RefreshView refreshView = refreshView2 = new RefreshView();
			((ISupportInitialize)refreshView).BeginInit();
			children6.Add(refreshView);
			RefreshView refreshView3;
			ISupportInitialize supportInitialize7 = refreshView3 = refreshView2;
			context.PushParent(refreshView3);
			RefreshView refreshView4 = refreshView3;
			CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.RefreshViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider9 = context;
			context.ProvideTargetProperty = StyledElement.DataContextProperty;
			CompiledBindingExtension compiledBindingExtension12 = compiledBindingExtension11.ProvideValue(provider9);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_2(refreshView4, compiledBindingExtension12);
			refreshView4.HorizontalAlignment = HorizontalAlignment.Stretch;
			refreshView4.VerticalAlignment = VerticalAlignment.Stretch;
			context.PopParent();
			supportInitialize7.EndInit();
			context.PopParent();
			supportInitialize6.EndInit();
			AvaloniaList<Control> children7 = grid4.Children;
			Grid grid15;
			Grid grid14 = grid15 = new Grid();
			((ISupportInitialize)grid14).BeginInit();
			children7.Add(grid14);
			ISupportInitialize supportInitialize8 = grid3 = grid15;
			context.PushParent(grid3);
			Grid grid16 = grid3;
			AvaloniaProperty isVisibleProperty4 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SettingsModalViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.SettingsModalViewModel,Exodus.IsVisible!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider10 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding7 = compiledBindingExtension13.ProvideValue(provider10);
			context.ProvideTargetProperty = null;
			grid16.Bind(isVisibleProperty4, binding7, null);
			grid16.ZIndex = 2500;
			grid16.HorizontalAlignment = HorizontalAlignment.Stretch;
			grid16.VerticalAlignment = VerticalAlignment.Stretch;
			AvaloniaList<Control> children8 = grid16.Children;
			SettingsModalView settingsModalView2;
			SettingsModalView settingsModalView = settingsModalView2 = new SettingsModalView();
			((ISupportInitialize)settingsModalView).BeginInit();
			children8.Add(settingsModalView);
			SettingsModalView settingsModalView3;
			ISupportInitialize supportInitialize9 = settingsModalView3 = settingsModalView2;
			context.PushParent(settingsModalView3);
			SettingsModalView settingsModalView4 = settingsModalView3;
			CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SettingsModalViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider11 = context;
			context.ProvideTargetProperty = StyledElement.DataContextProperty;
			CompiledBindingExtension compiledBindingExtension15 = compiledBindingExtension14.ProvideValue(provider11);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_2(settingsModalView4, compiledBindingExtension15);
			settingsModalView4.HorizontalAlignment = HorizontalAlignment.Stretch;
			settingsModalView4.VerticalAlignment = VerticalAlignment.Stretch;
			context.PopParent();
			supportInitialize9.EndInit();
			context.PopParent();
			supportInitialize8.EndInit();
			AvaloniaList<Control> children9 = grid4.Children;
			Grid grid18;
			Grid grid17 = grid18 = new Grid();
			((ISupportInitialize)grid17).BeginInit();
			children9.Add(grid17);
			ISupportInitialize supportInitialize10 = grid3 = grid18;
			context.PushParent(grid3);
			Grid grid19 = grid3;
			RowDefinitions rowDefinitions = new RowDefinitions();
			rowDefinitions.Capacity = 2;
			rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid19.RowDefinitions = rowDefinitions;
			AvaloniaList<Control> children10 = grid19.Children;
			Border border2;
			Border border = border2 = new Border();
			((ISupportInitialize)border).BeginInit();
			children10.Add(border);
			Border border3;
			ISupportInitialize supportInitialize11 = border3 = border2;
			context.PushParent(border3);
			Border border4 = border3;
			Grid.SetRow(border4, 0);
			border4.Padding = new Thickness(30.0, 0.0, 30.0, 0.0);
			Grid grid21;
			Grid grid20 = grid21 = new Grid();
			((ISupportInitialize)grid20).BeginInit();
			border4.Child = grid20;
			ISupportInitialize supportInitialize12 = grid3 = grid21;
			context.PushParent(grid3);
			Grid grid22 = grid3;
			grid22.Height = 80.0;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 3;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid22.ColumnDefinitions = columnDefinitions;
			AvaloniaList<Control> children11 = grid22.Children;
			Button button2;
			Button button = button2 = new Button();
			((ISupportInitialize)button).BeginInit();
			children11.Add(button);
			Button button3;
			ISupportInitialize supportInitialize13 = button3 = button2;
			context.PushParent(button3);
			Button button4 = button3;
			Grid.SetColumn(button4, 0);
			button4.Background = new ImmutableSolidColorBrush(16777215U);
			button4.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			button4.Margin = new Thickness(0.0, 0.0, 0.0, 0.0);
			button4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
			button4.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaProperty commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("NavigateToPortfolio", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.MainWindowViewModel+NavigateToPortfolio_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider12 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding8 = compiledBindingExtension16.ProvideValue(provider12);
			context.ProvideTargetProperty = null;
			button4.Bind(commandProperty, binding8, null);
			Grid grid24;
			Grid grid23 = grid24 = new Grid();
			((ISupportInitialize)grid23).BeginInit();
			button4.Content = grid23;
			ISupportInitialize supportInitialize14 = grid3 = grid24;
			context.PushParent(grid3);
			Grid grid25 = grid3;
			ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
			columnDefinitions2.Capacity = 2;
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid25.ColumnDefinitions = columnDefinitions2;
			grid25.VerticalAlignment = VerticalAlignment.Center;
			AvaloniaList<Control> children12 = grid25.Children;
			Image image2;
			Image image = image2 = new Image();
			((ISupportInitialize)image).BeginInit();
			children12.Add(image);
			Image image3;
			ISupportInitialize supportInitialize15 = image3 = image2;
			context.PushParent(image3);
			Image image4 = image3;
			Grid.SetColumn(image4, 0);
			image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/exodus-logomark.png");
			RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
			image4.Width = 36.0;
			image4.Stretch = Stretch.Uniform;
			image4.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			supportInitialize15.EndInit();
			AvaloniaList<Control> children13 = grid25.Children;
			Grid grid27;
			Grid grid26 = grid27 = new Grid();
			((ISupportInitialize)grid26).BeginInit();
			children13.Add(grid26);
			ISupportInitialize supportInitialize16 = grid3 = grid27;
			context.PushParent(grid3);
			Grid grid28 = grid3;
			Grid.SetColumn(grid28, 1);
			ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
			columnDefinitions3.Capacity = 2;
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid28.ColumnDefinitions = columnDefinitions3;
			grid28.Margin = new Thickness(18.0, 0.0, 0.0, 0.0);
			AvaloniaProperty isVisibleProperty5 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsPortfolioViewActive!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider13 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding9 = compiledBindingExtension17.ProvideValue(provider13);
			context.ProvideTargetProperty = null;
			grid28.Bind(isVisibleProperty5, binding9, null);
			AvaloniaList<Control> children14 = grid28.Children;
			TextBlock textBlock2;
			TextBlock textBlock = textBlock2 = new TextBlock();
			((ISupportInitialize)textBlock).BeginInit();
			children14.Add(textBlock);
			TextBlock textBlock3;
			ISupportInitialize supportInitialize17 = textBlock3 = textBlock2;
			context.PushParent(textBlock3);
			TextBlock textBlock4 = textBlock3;
			Grid.SetColumn(textBlock4, 0);
			textBlock4.FontSize = 17.6;
			StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider2 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj2 = staticResourceExtension2.ProvideValue(serviceProvider2);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_3(textBlock4, obj2);
			textBlock4.FontWeight = FontWeight.Normal;
			textBlock4.Opacity = 0.5;
			textBlock4.Text = "$";
			textBlock4.VerticalAlignment = VerticalAlignment.Center;
			textBlock4.Margin = new Thickness(0.0, 0.0, 0.75, 0.0);
			context.PopParent();
			supportInitialize17.EndInit();
			AvaloniaList<Control> children15 = grid28.Children;
			TextBlock textBlock6;
			TextBlock textBlock5 = textBlock6 = new TextBlock();
			((ISupportInitialize)textBlock5).BeginInit();
			children15.Add(textBlock5);
			ISupportInitialize supportInitialize18 = textBlock3 = textBlock6;
			context.PushParent(textBlock3);
			TextBlock textBlock7 = textBlock3;
			Grid.SetColumn(textBlock7, 1);
			textBlock7.FontSize = 22.0;
			StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider3 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj3 = staticResourceExtension3.ProvideValue(serviceProvider3);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_3(textBlock7, obj3);
			textBlock7.FontWeight = FontWeight.Normal;
			AvaloniaProperty textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.TotalBalanceInUsdPlayerString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider14 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding10 = compiledBindingExtension18.ProvideValue(provider14);
			context.ProvideTargetProperty = null;
			textBlock7.Bind(textProperty, binding10, null);
			textBlock7.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			supportInitialize18.EndInit();
			context.PopParent();
			supportInitialize16.EndInit();
			AvaloniaList<Control> children16 = grid25.Children;
			TextBlock textBlock9;
			TextBlock textBlock8 = textBlock9 = new TextBlock();
			((ISupportInitialize)textBlock8).BeginInit();
			children16.Add(textBlock8);
			ISupportInitialize supportInitialize19 = textBlock3 = textBlock9;
			context.PushParent(textBlock3);
			TextBlock textBlock10 = textBlock3;
			Grid.SetColumn(textBlock10, 1);
			textBlock10.Text = "EXODUS";
			textBlock10.Margin = new Thickness(14.0, 0.0, 0.0, 0.0);
			textBlock10.FontSize = 20.0;
			StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider4 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj4 = staticResourceExtension4.ProvideValue(serviceProvider4);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_3(textBlock10, obj4);
			textBlock10.FontWeight = FontWeight.Medium;
			textBlock10.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock10.LetterSpacing = 3.0;
			textBlock10.VerticalAlignment = VerticalAlignment.Center;
			AvaloniaProperty isVisibleProperty6 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsPortfolioViewActive!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider15 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding11 = compiledBindingExtension19.ProvideValue(provider15);
			context.ProvideTargetProperty = null;
			textBlock10.Bind(isVisibleProperty6, binding11, null);
			context.PopParent();
			supportInitialize19.EndInit();
			context.PopParent();
			supportInitialize14.EndInit();
			context.PopParent();
			supportInitialize13.EndInit();
			AvaloniaList<Control> children17 = grid22.Children;
			Grid grid30;
			Grid grid29 = grid30 = new Grid();
			((ISupportInitialize)grid29).BeginInit();
			children17.Add(grid29);
			ISupportInitialize supportInitialize20 = grid3 = grid30;
			context.PushParent(grid3);
			Grid grid31 = grid3;
			Grid.SetColumn(grid31, 1);
			grid31.HorizontalAlignment = HorizontalAlignment.Stretch;
			grid31.VerticalAlignment = VerticalAlignment.Center;
			AvaloniaList<Control> children18 = grid31.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = stackPanel2 = new StackPanel();
			((ISupportInitialize)stackPanel).BeginInit();
			children18.Add(stackPanel);
			StackPanel stackPanel3;
			ISupportInitialize supportInitialize21 = stackPanel3 = stackPanel2;
			context.PushParent(stackPanel3);
			StackPanel stackPanel4 = stackPanel3;
			stackPanel4.HorizontalAlignment = HorizontalAlignment.Center;
			stackPanel4.VerticalAlignment = VerticalAlignment.Center;
			stackPanel4.Orientation = Orientation.Horizontal;
			stackPanel4.Spacing = -8.0;
			AvaloniaList<Control> children19 = stackPanel4.Children;
			Grid grid33;
			Grid grid32 = grid33 = new Grid();
			((ISupportInitialize)grid32).BeginInit();
			children19.Add(grid32);
			ISupportInitialize supportInitialize22 = grid3 = grid33;
			context.PushParent(grid3);
			Grid grid34 = grid3;
			AvaloniaList<Control> children20 = grid34.Children;
			Button button6;
			Button button5 = button6 = new Button();
			((ISupportInitialize)button5).BeginInit();
			children20.Add(button5);
			ISupportInitialize supportInitialize23 = button3 = button6;
			context.PushParent(button3);
			Button button7 = button3;
			button7.Background = new ImmutableSolidColorBrush(16777215U);
			button7.Margin = new Thickness(0.0, 2.0, 1.0, 2.0);
			button7.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaProperty commandProperty2 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("NavigateToPortfolio", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.MainWindowViewModel+NavigateToPortfolio_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider16 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding12 = compiledBindingExtension20.ProvideValue(provider16);
			context.ProvideTargetProperty = null;
			button7.Bind(commandProperty2, binding12, null);
			Image image6;
			Image image5 = image6 = new Image();
			((ISupportInitialize)image5).BeginInit();
			button7.Content = image5;
			ISupportInitialize supportInitialize24 = image3 = image6;
			context.PushParent(image3);
			Image image7 = image3;
			image7.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/icon-global-nav-portfolio.png");
			RenderOptions.SetBitmapInterpolationMode(image7, BitmapInterpolationMode.HighQuality);
			image7.Width = 50.0;
			image7.Stretch = Stretch.Uniform;
			image7.VerticalAlignment = VerticalAlignment.Center;
			image7.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize24.EndInit();
			context.PopParent();
			supportInitialize23.EndInit();
			AvaloniaList<Control> children21 = grid34.Children;
			Border border6;
			Border border5 = border6 = new Border();
			((ISupportInitialize)border5).BeginInit();
			children21.Add(border5);
			ISupportInitialize supportInitialize25 = border3 = border6;
			context.PushParent(border3);
			Border border7 = border3;
			border7.CornerRadius = new CornerRadius(3.0, 3.0, 3.0, 3.0);
			border7.Width = 40.0;
			border7.Height = 3.0;
			border7.Background = new ImmutableSolidColorBrush(4283016900U);
			border7.Margin = new Thickness(0.0, 0.0, 0.0, -7.5);
			AvaloniaProperty isVisibleProperty7 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsPortfolioViewActive!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider17 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding13 = compiledBindingExtension21.ProvideValue(provider17);
			context.ProvideTargetProperty = null;
			border7.Bind(isVisibleProperty7, binding13, null);
			border7.VerticalAlignment = VerticalAlignment.Bottom;
			border7.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize25.EndInit();
			context.PopParent();
			supportInitialize22.EndInit();
			AvaloniaList<Control> children22 = stackPanel4.Children;
			Grid grid36;
			Grid grid35 = grid36 = new Grid();
			((ISupportInitialize)grid35).BeginInit();
			children22.Add(grid35);
			ISupportInitialize supportInitialize26 = grid3 = grid36;
			context.PushParent(grid3);
			Grid grid37 = grid3;
			AvaloniaList<Control> children23 = grid37.Children;
			Button button9;
			Button button8 = button9 = new Button();
			((ISupportInitialize)button8).BeginInit();
			children23.Add(button8);
			ISupportInitialize supportInitialize27 = button3 = button9;
			context.PushParent(button3);
			Button button10 = button3;
			button10.Background = new ImmutableSolidColorBrush(16777215U);
			button10.Margin = new Thickness(0.0, 2.0, 1.0, 2.0);
			button10.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaProperty commandProperty3 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("NavigateToWallet", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.MainWindowViewModel+NavigateToWallet_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider18 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding14 = compiledBindingExtension22.ProvideValue(provider18);
			context.ProvideTargetProperty = null;
			button10.Bind(commandProperty3, binding14, null);
			Image image9;
			Image image8 = image9 = new Image();
			((ISupportInitialize)image8).BeginInit();
			button10.Content = image8;
			ISupportInitialize supportInitialize28 = image3 = image9;
			context.PushParent(image3);
			Image image10 = image3;
			image10.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/icon-global-nav-wallet.png");
			RenderOptions.SetBitmapInterpolationMode(image10, BitmapInterpolationMode.HighQuality);
			image10.Width = 50.0;
			image10.Stretch = Stretch.Uniform;
			image10.VerticalAlignment = VerticalAlignment.Center;
			image10.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize28.EndInit();
			context.PopParent();
			supportInitialize27.EndInit();
			AvaloniaList<Control> children24 = grid37.Children;
			Border border9;
			Border border8 = border9 = new Border();
			((ISupportInitialize)border8).BeginInit();
			children24.Add(border8);
			ISupportInitialize supportInitialize29 = border3 = border9;
			context.PushParent(border3);
			Border border10 = border3;
			border10.CornerRadius = new CornerRadius(3.0, 3.0, 3.0, 3.0);
			border10.Width = 40.0;
			border10.Height = 3.0;
			border10.Background = new ImmutableSolidColorBrush(4283016900U);
			border10.Margin = new Thickness(0.0, 0.0, 0.0, -7.5);
			AvaloniaProperty isVisibleProperty8 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension23 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsWalletViewActive!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider19 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding15 = compiledBindingExtension23.ProvideValue(provider19);
			context.ProvideTargetProperty = null;
			border10.Bind(isVisibleProperty8, binding15, null);
			border10.VerticalAlignment = VerticalAlignment.Bottom;
			border10.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize29.EndInit();
			context.PopParent();
			supportInitialize26.EndInit();
			AvaloniaList<Control> children25 = stackPanel4.Children;
			Rectangle rectangle2;
			Rectangle rectangle = rectangle2 = new Rectangle();
			((ISupportInitialize)rectangle).BeginInit();
			children25.Add(rectangle);
			Rectangle rectangle3 = rectangle2;
			rectangle3.Height = 25.0;
			rectangle3.Width = 1.0;
			rectangle3.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			rectangle3.Opacity = 0.15;
			rectangle3.Margin = new Thickness(10.0, 2.0, 11.0, 2.0);
			rectangle3.VerticalAlignment = VerticalAlignment.Center;
			((ISupportInitialize)rectangle3).EndInit();
			AvaloniaList<Control> children26 = stackPanel4.Children;
			Grid grid39;
			Grid grid38 = grid39 = new Grid();
			((ISupportInitialize)grid38).BeginInit();
			children26.Add(grid38);
			ISupportInitialize supportInitialize30 = grid3 = grid39;
			context.PushParent(grid3);
			Grid grid40 = grid3;
			AvaloniaList<Control> children27 = grid40.Children;
			Button button12;
			Button button11 = button12 = new Button();
			((ISupportInitialize)button11).BeginInit();
			children27.Add(button11);
			ISupportInitialize supportInitialize31 = button3 = button12;
			context.PushParent(button3);
			Button button13 = button3;
			button13.Background = new ImmutableSolidColorBrush(16777215U);
			button13.Margin = new Thickness(0.0, 2.0, 1.0, 2.0);
			button13.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaProperty commandProperty4 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension24 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("NavigateToSwap", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.MainWindowViewModel+NavigateToSwap_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider20 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding16 = compiledBindingExtension24.ProvideValue(provider20);
			context.ProvideTargetProperty = null;
			button13.Bind(commandProperty4, binding16, null);
			Image image12;
			Image image11 = image12 = new Image();
			((ISupportInitialize)image11).BeginInit();
			button13.Content = image11;
			ISupportInitialize supportInitialize32 = image3 = image12;
			context.PushParent(image3);
			Image image13 = image3;
			image13.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/icon-global-nav-exchange.png");
			RenderOptions.SetBitmapInterpolationMode(image13, BitmapInterpolationMode.HighQuality);
			image13.Width = 50.0;
			image13.Stretch = Stretch.Uniform;
			image13.VerticalAlignment = VerticalAlignment.Center;
			image13.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize32.EndInit();
			context.PopParent();
			supportInitialize31.EndInit();
			AvaloniaList<Control> children28 = grid40.Children;
			Border border12;
			Border border11 = border12 = new Border();
			((ISupportInitialize)border11).BeginInit();
			children28.Add(border11);
			ISupportInitialize supportInitialize33 = border3 = border12;
			context.PushParent(border3);
			Border border13 = border3;
			border13.CornerRadius = new CornerRadius(3.0, 3.0, 3.0, 3.0);
			border13.Width = 40.0;
			border13.Height = 3.0;
			border13.Background = new ImmutableSolidColorBrush(4283016900U);
			border13.Margin = new Thickness(0.0, 0.0, 0.0, -7.5);
			AvaloniaProperty isVisibleProperty9 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension25 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsSwapViewActive!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider21 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding17 = compiledBindingExtension25.ProvideValue(provider21);
			context.ProvideTargetProperty = null;
			border13.Bind(isVisibleProperty9, binding17, null);
			border13.VerticalAlignment = VerticalAlignment.Bottom;
			border13.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize33.EndInit();
			context.PopParent();
			supportInitialize30.EndInit();
			AvaloniaList<Control> children29 = stackPanel4.Children;
			Grid grid42;
			Grid grid41 = grid42 = new Grid();
			((ISupportInitialize)grid41).BeginInit();
			children29.Add(grid41);
			ISupportInitialize supportInitialize34 = grid3 = grid42;
			context.PushParent(grid3);
			Grid grid43 = grid3;
			AvaloniaList<Control> children30 = grid43.Children;
			Button button15;
			Button button14 = button15 = new Button();
			((ISupportInitialize)button14).BeginInit();
			children30.Add(button14);
			ISupportInitialize supportInitialize35 = button3 = button15;
			context.PushParent(button3);
			Button button16 = button3;
			button16.Background = new ImmutableSolidColorBrush(16777215U);
			button16.Margin = new Thickness(0.0, 2.0, 1.0, 2.0);
			button16.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaProperty commandProperty5 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension26 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("NavigateToBuySell", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.MainWindowViewModel+NavigateToBuySell_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider22 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding18 = compiledBindingExtension26.ProvideValue(provider22);
			context.ProvideTargetProperty = null;
			button16.Bind(commandProperty5, binding18, null);
			Image image15;
			Image image14 = image15 = new Image();
			((ISupportInitialize)image14).BeginInit();
			button16.Content = image14;
			ISupportInitialize supportInitialize36 = image3 = image15;
			context.PushParent(image3);
			Image image16 = image3;
			image16.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/icon-global-nav-fiat-onramp.png");
			RenderOptions.SetBitmapInterpolationMode(image16, BitmapInterpolationMode.HighQuality);
			image16.Width = 50.0;
			image16.Stretch = Stretch.Uniform;
			image16.VerticalAlignment = VerticalAlignment.Center;
			image16.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize36.EndInit();
			context.PopParent();
			supportInitialize35.EndInit();
			AvaloniaList<Control> children31 = grid43.Children;
			Border border15;
			Border border14 = border15 = new Border();
			((ISupportInitialize)border14).BeginInit();
			children31.Add(border14);
			ISupportInitialize supportInitialize37 = border3 = border15;
			context.PushParent(border3);
			Border border16 = border3;
			border16.CornerRadius = new CornerRadius(3.0, 3.0, 3.0, 3.0);
			border16.Width = 40.0;
			border16.Height = 3.0;
			border16.Background = new ImmutableSolidColorBrush(4283016900U);
			border16.Margin = new Thickness(0.0, 0.0, 0.0, -7.5);
			AvaloniaProperty isVisibleProperty10 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension27 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsBuySellViewActive!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider23 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding19 = compiledBindingExtension27.ProvideValue(provider23);
			context.ProvideTargetProperty = null;
			border16.Bind(isVisibleProperty10, binding19, null);
			border16.VerticalAlignment = VerticalAlignment.Bottom;
			border16.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize37.EndInit();
			context.PopParent();
			supportInitialize34.EndInit();
			AvaloniaList<Control> children32 = stackPanel4.Children;
			Button button18;
			Button button17 = button18 = new Button();
			((ISupportInitialize)button17).BeginInit();
			children32.Add(button17);
			ISupportInitialize supportInitialize38 = button3 = button18;
			context.PushParent(button3);
			Button button19 = button3;
			button19.Background = new ImmutableSolidColorBrush(16777215U);
			button19.Margin = new Thickness(0.0, 2.0, 1.0, 2.0);
			Image image18;
			Image image17 = image18 = new Image();
			((ISupportInitialize)image17).BeginInit();
			button19.Content = image17;
			ISupportInitialize supportInitialize39 = image3 = image18;
			context.PushParent(image3);
			Image image19 = image3;
			image19.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/icon-global-nav-earn-rewards.png");
			RenderOptions.SetBitmapInterpolationMode(image19, BitmapInterpolationMode.HighQuality);
			image19.Width = 50.0;
			image19.Stretch = Stretch.Uniform;
			image19.VerticalAlignment = VerticalAlignment.Center;
			image19.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize39.EndInit();
			context.PopParent();
			supportInitialize38.EndInit();
			AvaloniaList<Control> children33 = stackPanel4.Children;
			Rectangle rectangle5;
			Rectangle rectangle4 = rectangle5 = new Rectangle();
			((ISupportInitialize)rectangle4).BeginInit();
			children33.Add(rectangle4);
			Rectangle rectangle6 = rectangle5;
			rectangle6.Height = 25.0;
			rectangle6.Width = 1.0;
			rectangle6.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			rectangle6.Opacity = 0.15;
			rectangle6.Margin = new Thickness(10.0, 2.0, 11.0, 2.0);
			rectangle6.VerticalAlignment = VerticalAlignment.Center;
			((ISupportInitialize)rectangle6).EndInit();
			AvaloniaList<Control> children34 = stackPanel4.Children;
			Button button21;
			Button button20 = button21 = new Button();
			((ISupportInitialize)button20).BeginInit();
			children34.Add(button20);
			ISupportInitialize supportInitialize40 = button3 = button21;
			context.PushParent(button3);
			Button button22 = button3;
			button22.Background = new ImmutableSolidColorBrush(16777215U);
			button22.Margin = new Thickness(0.0, 2.0, 1.0, 2.0);
			Image image21;
			Image image20 = image21 = new Image();
			((ISupportInitialize)image20).BeginInit();
			button22.Content = image20;
			ISupportInitialize supportInitialize41 = image3 = image21;
			context.PushParent(image3);
			Image image22 = image3;
			image22.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/icon-global-nav-plus.png");
			RenderOptions.SetBitmapInterpolationMode(image22, BitmapInterpolationMode.HighQuality);
			image22.Width = 50.0;
			image22.Stretch = Stretch.Uniform;
			image22.VerticalAlignment = VerticalAlignment.Center;
			image22.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize41.EndInit();
			context.PopParent();
			supportInitialize40.EndInit();
			context.PopParent();
			supportInitialize21.EndInit();
			context.PopParent();
			supportInitialize20.EndInit();
			AvaloniaList<Control> children35 = grid22.Children;
			Grid grid45;
			Grid grid44 = grid45 = new Grid();
			((ISupportInitialize)grid44).BeginInit();
			children35.Add(grid44);
			ISupportInitialize supportInitialize42 = grid3 = grid45;
			context.PushParent(grid3);
			Grid grid46 = grid3;
			Grid.SetColumn(grid46, 2);
			ColumnDefinitions columnDefinitions4 = new ColumnDefinitions();
			columnDefinitions4.Capacity = 3;
			columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid46.ColumnDefinitions = columnDefinitions4;
			grid46.VerticalAlignment = VerticalAlignment.Center;
			grid46.Width = 123.0;
			AvaloniaList<Control> children36 = grid46.Children;
			Button button24;
			Button button23 = button24 = new Button();
			((ISupportInitialize)button23).BeginInit();
			children36.Add(button23);
			ISupportInitialize supportInitialize43 = button3 = button24;
			context.PushParent(button3);
			Button button25 = button3;
			Grid.SetColumn(button25, 0);
			button25.Background = new ImmutableSolidColorBrush(16777215U);
			button25.HorizontalAlignment = HorizontalAlignment.Center;
			button25.VerticalAlignment = VerticalAlignment.Center;
			button25.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaProperty commandProperty6 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension28 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("OpenSettingsCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.MainWindowViewModel+OpenSettingsCommand_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider24 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding20 = compiledBindingExtension28.ProvideValue(provider24);
			context.ProvideTargetProperty = null;
			button25.Bind(commandProperty6, binding20, null);
			ToolTip.SetTip(button25, "History & Activity");
			Viewbox viewbox2;
			Viewbox viewbox = viewbox2 = new Viewbox();
			((ISupportInitialize)viewbox).BeginInit();
			button25.Content = viewbox;
			Viewbox viewbox3;
			ISupportInitialize supportInitialize44 = viewbox3 = viewbox2;
			context.PushParent(viewbox3);
			Viewbox viewbox4 = viewbox3;
			viewbox4.Width = 21.0;
			Path path2;
			Path path = path2 = new Path();
			((ISupportInitialize)path).BeginInit();
			viewbox4.Child = path;
			Path path3;
			ISupportInitialize supportInitialize45 = path3 = path2;
			context.PushParent(path3);
			Path path4 = path3;
			AvaloniaProperty dataProperty = Path.DataProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("History");
			IServiceProvider serviceProvider5 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			IBinding binding21 = dynamicResourceExtension.ProvideValue(serviceProvider5);
			context.ProvideTargetProperty = null;
			path4.Bind(dataProperty, binding21, null);
			path4.Fill = new ImmutableSolidColorBrush(4284375137U);
			path4.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize45.EndInit();
			context.PopParent();
			supportInitialize44.EndInit();
			context.PopParent();
			supportInitialize43.EndInit();
			AvaloniaList<Control> children37 = grid46.Children;
			Button button27;
			Button button26 = button27 = new Button();
			((ISupportInitialize)button26).BeginInit();
			children37.Add(button26);
			ISupportInitialize supportInitialize46 = button3 = button27;
			context.PushParent(button3);
			Button button28 = button3;
			Grid.SetColumn(button28, 1);
			button28.Background = new ImmutableSolidColorBrush(16777215U);
			button28.HorizontalAlignment = HorizontalAlignment.Center;
			button28.VerticalAlignment = VerticalAlignment.Center;
			button28.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaProperty commandProperty7 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension29 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("OpenSettingsCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.MainWindowViewModel+OpenSettingsCommand_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider25 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding22 = compiledBindingExtension29.ProvideValue(provider25);
			context.ProvideTargetProperty = null;
			button28.Bind(commandProperty7, binding22, null);
			ToolTip.SetTip(button28, "Support & Help");
			Grid grid48;
			Grid grid47 = grid48 = new Grid();
			((ISupportInitialize)grid47).BeginInit();
			button28.Content = grid47;
			ISupportInitialize supportInitialize47 = grid3 = grid48;
			context.PushParent(grid3);
			Grid grid49 = grid3;
			AvaloniaList<Control> children38 = grid49.Children;
			Viewbox viewbox6;
			Viewbox viewbox5 = viewbox6 = new Viewbox();
			((ISupportInitialize)viewbox5).BeginInit();
			children38.Add(viewbox5);
			ISupportInitialize supportInitialize48 = viewbox3 = viewbox6;
			context.PushParent(viewbox3);
			Viewbox viewbox7 = viewbox3;
			viewbox7.Width = 18.0;
			viewbox7.VerticalAlignment = VerticalAlignment.Center;
			viewbox7.HorizontalAlignment = HorizontalAlignment.Center;
			Path path6;
			Path path5 = path6 = new Path();
			((ISupportInitialize)path5).BeginInit();
			viewbox7.Child = path5;
			ISupportInitialize supportInitialize49 = path3 = path6;
			context.PushParent(path3);
			Path path7 = path3;
			AvaloniaProperty dataProperty2 = Path.DataProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("Support");
			IServiceProvider serviceProvider6 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			IBinding binding23 = dynamicResourceExtension2.ProvideValue(serviceProvider6);
			context.ProvideTargetProperty = null;
			path7.Bind(dataProperty2, binding23, null);
			path7.Fill = new ImmutableSolidColorBrush(4284375137U);
			path7.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize49.EndInit();
			context.PopParent();
			supportInitialize48.EndInit();
			AvaloniaList<Control> children39 = grid49.Children;
			Ellipse ellipse2;
			Ellipse ellipse = ellipse2 = new Ellipse();
			((ISupportInitialize)ellipse).BeginInit();
			children39.Add(ellipse);
			Ellipse ellipse3 = ellipse2;
			ellipse3.Width = 22.0;
			ellipse3.Height = 22.0;
			ellipse3.Fill = new ImmutableSolidColorBrush(16777215U);
			ellipse3.Stroke = new ImmutableSolidColorBrush(4284375137U);
			ellipse3.StrokeThickness = 1.0;
			ellipse3.HorizontalAlignment = HorizontalAlignment.Center;
			ellipse3.VerticalAlignment = VerticalAlignment.Center;
			((ISupportInitialize)ellipse3).EndInit();
			context.PopParent();
			supportInitialize47.EndInit();
			context.PopParent();
			supportInitialize46.EndInit();
			AvaloniaList<Control> children40 = grid46.Children;
			Button button30;
			Button button29 = button30 = new Button();
			((ISupportInitialize)button29).BeginInit();
			children40.Add(button29);
			ISupportInitialize supportInitialize50 = button3 = button30;
			context.PushParent(button3);
			Button button31 = button3;
			Grid.SetColumn(button31, 2);
			button31.Background = new ImmutableSolidColorBrush(16777215U);
			button31.HorizontalAlignment = HorizontalAlignment.Center;
			button31.VerticalAlignment = VerticalAlignment.Center;
			button31.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaProperty commandProperty8 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension30 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("OpenSettingsCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.MainWindowViewModel+OpenSettingsCommand_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider26 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding24 = compiledBindingExtension30.ProvideValue(provider26);
			context.ProvideTargetProperty = null;
			button31.Bind(commandProperty8, binding24, null);
			ToolTip.SetTip(button31, "Settings & About");
			Viewbox viewbox9;
			Viewbox viewbox8 = viewbox9 = new Viewbox();
			((ISupportInitialize)viewbox8).BeginInit();
			button31.Content = viewbox8;
			ISupportInitialize supportInitialize51 = viewbox3 = viewbox9;
			context.PushParent(viewbox3);
			Viewbox viewbox10 = viewbox3;
			viewbox10.Width = 21.0;
			Path path9;
			Path path8 = path9 = new Path();
			((ISupportInitialize)path8).BeginInit();
			viewbox10.Child = path8;
			ISupportInitialize supportInitialize52 = path3 = path9;
			context.PushParent(path3);
			Path path10 = path3;
			AvaloniaProperty dataProperty3 = Path.DataProperty;
			DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("Settings");
			IServiceProvider serviceProvider7 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			IBinding binding25 = dynamicResourceExtension3.ProvideValue(serviceProvider7);
			context.ProvideTargetProperty = null;
			path10.Bind(dataProperty3, binding25, null);
			path10.Fill = new ImmutableSolidColorBrush(4284375137U);
			path10.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize52.EndInit();
			context.PopParent();
			supportInitialize51.EndInit();
			context.PopParent();
			supportInitialize50.EndInit();
			context.PopParent();
			supportInitialize42.EndInit();
			context.PopParent();
			supportInitialize12.EndInit();
			context.PopParent();
			supportInitialize11.EndInit();
			AvaloniaList<Control> children41 = grid19.Children;
			Grid grid51;
			Grid grid50 = grid51 = new Grid();
			((ISupportInitialize)grid50).BeginInit();
			children41.Add(grid50);
			ISupportInitialize supportInitialize53 = grid3 = grid51;
			context.PushParent(grid3);
			Grid grid52 = grid3;
			Grid.SetRow(grid52, 1);
			AvaloniaProperty isVisibleProperty11 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension31 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsPortfolioViewActive!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider27 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding26 = compiledBindingExtension31.ProvideValue(provider27);
			context.ProvideTargetProperty = null;
			grid52.Bind(isVisibleProperty11, binding26, null);
			AvaloniaList<Control> children42 = grid52.Children;
			PortfolioView portfolioView2;
			PortfolioView portfolioView = portfolioView2 = new PortfolioView();
			((ISupportInitialize)portfolioView).BeginInit();
			children42.Add(portfolioView);
			PortfolioView portfolioView3;
			ISupportInitialize supportInitialize54 = portfolioView3 = portfolioView2;
			context.PushParent(portfolioView3);
			StyledElement styledElement2 = portfolioView3;
			CompiledBindingExtension compiledBindingExtension32 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.PortfolioViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider28 = context;
			context.ProvideTargetProperty = StyledElement.DataContextProperty;
			CompiledBindingExtension compiledBindingExtension33 = compiledBindingExtension32.ProvideValue(provider28);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_2(styledElement2, compiledBindingExtension33);
			context.PopParent();
			supportInitialize54.EndInit();
			context.PopParent();
			supportInitialize53.EndInit();
			AvaloniaList<Control> children43 = grid19.Children;
			Grid grid54;
			Grid grid53 = grid54 = new Grid();
			((ISupportInitialize)grid53).BeginInit();
			children43.Add(grid53);
			ISupportInitialize supportInitialize55 = grid3 = grid54;
			context.PushParent(grid3);
			Grid grid55 = grid3;
			Grid.SetRow(grid55, 1);
			grid55.HorizontalAlignment = HorizontalAlignment.Stretch;
			grid55.VerticalAlignment = VerticalAlignment.Stretch;
			AvaloniaProperty isVisibleProperty12 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension34 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsSwapViewActive!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider29 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding27 = compiledBindingExtension34.ProvideValue(provider29);
			context.ProvideTargetProperty = null;
			grid55.Bind(isVisibleProperty12, binding27, null);
			AvaloniaList<Control> children44 = grid55.Children;
			SwapView swapView2;
			SwapView swapView = swapView2 = new SwapView();
			((ISupportInitialize)swapView).BeginInit();
			children44.Add(swapView);
			SwapView swapView3;
			ISupportInitialize supportInitialize56 = swapView3 = swapView2;
			context.PushParent(swapView3);
			SwapView swapView4 = swapView3;
			swapView4.HorizontalAlignment = HorizontalAlignment.Stretch;
			swapView4.VerticalAlignment = VerticalAlignment.Stretch;
			CompiledBindingExtension compiledBindingExtension35 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SwapViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider30 = context;
			context.ProvideTargetProperty = StyledElement.DataContextProperty;
			CompiledBindingExtension compiledBindingExtension36 = compiledBindingExtension35.ProvideValue(provider30);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_2(swapView4, compiledBindingExtension36);
			context.PopParent();
			supportInitialize56.EndInit();
			context.PopParent();
			supportInitialize55.EndInit();
			AvaloniaList<Control> children45 = grid19.Children;
			Grid grid57;
			Grid grid56 = grid57 = new Grid();
			((ISupportInitialize)grid56).BeginInit();
			children45.Add(grid56);
			ISupportInitialize supportInitialize57 = grid3 = grid57;
			context.PushParent(grid3);
			Grid grid58 = grid3;
			Grid.SetRow(grid58, 1);
			grid58.HorizontalAlignment = HorizontalAlignment.Stretch;
			grid58.VerticalAlignment = VerticalAlignment.Stretch;
			AvaloniaProperty isVisibleProperty13 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension37 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsBuySellViewActive!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider31 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding28 = compiledBindingExtension37.ProvideValue(provider31);
			context.ProvideTargetProperty = null;
			grid58.Bind(isVisibleProperty13, binding28, null);
			AvaloniaList<Control> children46 = grid58.Children;
			BuySellView buySellView2;
			BuySellView buySellView = buySellView2 = new BuySellView();
			((ISupportInitialize)buySellView).BeginInit();
			children46.Add(buySellView);
			BuySellView buySellView3;
			ISupportInitialize supportInitialize58 = buySellView3 = buySellView2;
			context.PushParent(buySellView3);
			BuySellView buySellView4 = buySellView3;
			buySellView4.HorizontalAlignment = HorizontalAlignment.Stretch;
			buySellView4.VerticalAlignment = VerticalAlignment.Stretch;
			CompiledBindingExtension compiledBindingExtension38 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.BuySellViewModel!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider32 = context;
			context.ProvideTargetProperty = StyledElement.DataContextProperty;
			CompiledBindingExtension compiledBindingExtension39 = compiledBindingExtension38.ProvideValue(provider32);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_2(buySellView4, compiledBindingExtension39);
			context.PopParent();
			supportInitialize58.EndInit();
			context.PopParent();
			supportInitialize57.EndInit();
			AvaloniaList<Control> children47 = grid19.Children;
			Border border18;
			Border border17 = border18 = new Border();
			((ISupportInitialize)border17).BeginInit();
			children47.Add(border17);
			ISupportInitialize supportInitialize59 = border3 = border18;
			context.PushParent(border3);
			Border border19 = border3;
			Grid.SetRow(border19, 1);
			border19.Background = new ImmutableSolidColorBrush(4279440664U);
			border19.CornerRadius = new CornerRadius(26.0, 26.0, 0.0, 0.0);
			AvaloniaProperty isVisibleProperty14 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension40 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.IsWalletViewActive!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider33 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding29 = compiledBindingExtension40.ProvideValue(provider33);
			context.ProvideTargetProperty = null;
			border19.Bind(isVisibleProperty14, binding29, null);
			Grid grid60;
			Grid grid59 = grid60 = new Grid();
			((ISupportInitialize)grid59).BeginInit();
			border19.Child = grid59;
			ISupportInitialize supportInitialize60 = grid3 = grid60;
			context.PushParent(grid3);
			Grid grid61 = grid3;
			grid61.HorizontalAlignment = HorizontalAlignment.Stretch;
			grid61.VerticalAlignment = VerticalAlignment.Stretch;
			RowDefinitions rowDefinitions2 = new RowDefinitions();
			rowDefinitions2.Capacity = 2;
			rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions2.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid61.RowDefinitions = rowDefinitions2;
			AvaloniaList<Control> children48 = grid61.Children;
			Grid grid63;
			Grid grid62 = grid63 = new Grid();
			((ISupportInitialize)grid62).BeginInit();
			children48.Add(grid62);
			ISupportInitialize supportInitialize61 = grid3 = grid63;
			context.PushParent(grid3);
			Grid grid64 = grid3;
			Grid.SetRow(grid64, 0);
			grid64.Height = 68.0;
			ColumnDefinitions columnDefinitions5 = new ColumnDefinitions();
			columnDefinitions5.Capacity = 3;
			columnDefinitions5.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions5.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid64.ColumnDefinitions = columnDefinitions5;
			AvaloniaList<Control> children49 = grid64.Children;
			Border border21;
			Border border20 = border21 = new Border();
			((ISupportInitialize)border20).BeginInit();
			children49.Add(border20);
			ISupportInitialize supportInitialize62 = border3 = border21;
			context.PushParent(border3);
			Border border22 = border3;
			Grid.SetColumn(border22, 0);
			border22.BorderThickness = new Thickness(0.0, 0.0, 1.0, 0.0);
			border22.BorderBrush = new ImmutableSolidColorBrush(452984831U);
			border22.Width = 60.0;
			border22.VerticalAlignment = VerticalAlignment.Stretch;
			Button button33;
			Button button32 = button33 = new Button();
			((ISupportInitialize)button32).BeginInit();
			border22.Child = button32;
			ISupportInitialize supportInitialize63 = button3 = button33;
			context.PushParent(button3);
			Button button34 = button3;
			button34.Background = new ImmutableSolidColorBrush(16777215U);
			button34.VerticalAlignment = VerticalAlignment.Center;
			button34.HorizontalAlignment = HorizontalAlignment.Center;
			Grid grid66;
			Grid grid65 = grid66 = new Grid();
			((ISupportInitialize)grid65).BeginInit();
			button34.Content = grid65;
			ISupportInitialize supportInitialize64 = grid3 = grid66;
			context.PushParent(grid3);
			Grid grid67 = grid3;
			RowDefinitions rowDefinitions3 = new RowDefinitions();
			rowDefinitions3.Capacity = 2;
			rowDefinitions3.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			rowDefinitions3.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid67.RowDefinitions = rowDefinitions3;
			grid67.VerticalAlignment = VerticalAlignment.Stretch;
			AvaloniaList<Control> children50 = grid67.Children;
			Image image24;
			Image image23 = image24 = new Image();
			((ISupportInitialize)image23).BeginInit();
			children50.Add(image23);
			ISupportInitialize supportInitialize65 = image3 = image24;
			context.PushParent(image3);
			Image image25 = image3;
			Grid.SetRow(image25, 0);
			image25.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/filter.png");
			RenderOptions.SetBitmapInterpolationMode(image25, BitmapInterpolationMode.HighQuality);
			image25.Width = 23.0;
			image25.Stretch = Stretch.Uniform;
			image25.VerticalAlignment = VerticalAlignment.Center;
			image25.Opacity = 1.0;
			image25.HorizontalAlignment = HorizontalAlignment.Center;
			image25.Margin = new Thickness(0.0, 14.0, 0.0, 0.0);
			context.PopParent();
			supportInitialize65.EndInit();
			AvaloniaList<Control> children51 = grid67.Children;
			Viewbox viewbox12;
			Viewbox viewbox11 = viewbox12 = new Viewbox();
			((ISupportInitialize)viewbox11).BeginInit();
			children51.Add(viewbox11);
			ISupportInitialize supportInitialize66 = viewbox3 = viewbox12;
			context.PushParent(viewbox3);
			Viewbox viewbox13 = viewbox3;
			Grid.SetRow(viewbox13, 1);
			viewbox13.HorizontalAlignment = HorizontalAlignment.Center;
			viewbox13.Width = 8.0;
			viewbox13.Margin = new Thickness(0.0, 9.0, 0.0, 0.0);
			Path path12;
			Path path11 = path12 = new Path();
			((ISupportInitialize)path11).BeginInit();
			viewbox13.Child = path11;
			ISupportInitialize supportInitialize67 = path3 = path12;
			context.PushParent(path3);
			Path path13 = path3;
			StaticResourceExtension staticResourceExtension5 = new StaticResourceExtension("PointDownFullArrow");
			IServiceProvider serviceProvider8 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj5 = staticResourceExtension5.ProvideValue(serviceProvider8);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_4(path13, obj5);
			path13.Stretch = Stretch.Uniform;
			path13.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			path13.Opacity = 0.3;
			context.PopParent();
			supportInitialize67.EndInit();
			context.PopParent();
			supportInitialize66.EndInit();
			context.PopParent();
			supportInitialize64.EndInit();
			context.PopParent();
			supportInitialize63.EndInit();
			context.PopParent();
			supportInitialize62.EndInit();
			AvaloniaList<Control> children52 = grid64.Children;
			Border border24;
			Border border23 = border24 = new Border();
			((ISupportInitialize)border23).BeginInit();
			children52.Add(border23);
			ISupportInitialize supportInitialize68 = border3 = border24;
			context.PushParent(border3);
			Border border25 = border3;
			Grid.SetColumn(border25, 1);
			border25.BorderThickness = new Thickness(0.0, 0.0, 1.0, 0.0);
			border25.BorderBrush = new ImmutableSolidColorBrush(452984831U);
			border25.Width = 60.0;
			border25.VerticalAlignment = VerticalAlignment.Stretch;
			Button button36;
			Button button35 = button36 = new Button();
			((ISupportInitialize)button35).BeginInit();
			border25.Child = button35;
			ISupportInitialize supportInitialize69 = button3 = button36;
			context.PushParent(button3);
			Button button37 = button3;
			button37.Background = new ImmutableSolidColorBrush(16777215U);
			button37.VerticalAlignment = VerticalAlignment.Center;
			button37.HorizontalAlignment = HorizontalAlignment.Center;
			Image image27;
			Image image26 = image27 = new Image();
			((ISupportInitialize)image26).BeginInit();
			button37.Content = image26;
			ISupportInitialize supportInitialize70 = image3 = image27;
			context.PushParent(image3);
			Image image28 = image3;
			image28.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/icon-magnifying-glass.png");
			image28.Width = 20.0;
			image28.Stretch = Stretch.Uniform;
			image28.VerticalAlignment = VerticalAlignment.Center;
			image28.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize70.EndInit();
			context.PopParent();
			supportInitialize69.EndInit();
			context.PopParent();
			supportInitialize68.EndInit();
			AvaloniaList<Control> children53 = grid64.Children;
			ScrollViewer scrollViewer2;
			ScrollViewer scrollViewer = scrollViewer2 = new ScrollViewer();
			((ISupportInitialize)scrollViewer).BeginInit();
			children53.Add(scrollViewer);
			ScrollViewer scrollViewer3;
			ISupportInitialize supportInitialize71 = scrollViewer3 = scrollViewer2;
			context.PushParent(scrollViewer3);
			ScrollViewer scrollViewer4 = scrollViewer3;
			Grid.SetColumn(scrollViewer4, 2);
			scrollViewer4.HorizontalAlignment = HorizontalAlignment.Stretch;
			scrollViewer4.VerticalAlignment = VerticalAlignment.Stretch;
			scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden;
			scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Disabled;
			StaticResourceExtension staticResourceExtension6 = new StaticResourceExtension("ScrollViewerWithMouse");
			IServiceProvider serviceProvider9 = context;
			context.ProvideTargetProperty = StyledElement.ThemeProperty;
			object obj6 = staticResourceExtension6.ProvideValue(serviceProvider9);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_5(scrollViewer4, obj6);
			scrollViewer4.IsScrollInertiaEnabled = true;
			scrollViewer4.VerticalContentAlignment = VerticalAlignment.Center;
			ItemsControl itemsControl2;
			ItemsControl itemsControl = itemsControl2 = new ItemsControl();
			((ISupportInitialize)itemsControl).BeginInit();
			scrollViewer4.Content = itemsControl;
			ItemsControl itemsControl3;
			ISupportInitialize supportInitialize72 = itemsControl3 = itemsControl2;
			context.PushParent(itemsControl3);
			ItemsControl itemsControl4 = itemsControl3;
			AvaloniaProperty itemsSourceProperty = ItemsControl.ItemsSourceProperty;
			CompiledBindingExtension compiledBindingExtension41 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.Coins!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider34 = context;
			context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
			IBinding binding30 = compiledBindingExtension41.ProvideValue(provider34);
			context.ProvideTargetProperty = null;
			itemsControl4.Bind(itemsSourceProperty, binding30, null);
			itemsControl4.ItemsPanel = new ItemsPanelTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(MainWindow.XamlClosure_74.Build), context)
			};
			DataTemplate dataTemplate;
			IDataTemplate itemTemplate = dataTemplate = new DataTemplate();
			context.PushParent(dataTemplate);
			dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(MainWindow.XamlClosure_75.Build), context);
			context.PopParent();
			itemsControl4.ItemTemplate = itemTemplate;
			context.PopParent();
			supportInitialize72.EndInit();
			context.PopParent();
			supportInitialize71.EndInit();
			context.PopParent();
			supportInitialize61.EndInit();
			AvaloniaList<Control> children54 = grid61.Children;
			CoinSpecificPartView coinSpecificPartView2;
			CoinSpecificPartView coinSpecificPartView = coinSpecificPartView2 = new CoinSpecificPartView();
			((ISupportInitialize)coinSpecificPartView).BeginInit();
			children54.Add(coinSpecificPartView);
			CoinSpecificPartView coinSpecificPartView3;
			ISupportInitialize supportInitialize73 = coinSpecificPartView3 = coinSpecificPartView2;
			context.PushParent(coinSpecificPartView3);
			CoinSpecificPartView coinSpecificPartView4 = coinSpecificPartView3;
			Grid.SetRow(coinSpecificPartView4, 1);
			CompiledBindingExtension compiledBindingExtension42 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.MainWindowViewModel,Exodus.SelectedCoinViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider35 = context;
			context.ProvideTargetProperty = StyledElement.DataContextProperty;
			CompiledBindingExtension compiledBindingExtension43 = compiledBindingExtension42.ProvideValue(provider35);
			context.ProvideTargetProperty = null;
			MainWindow.DynamicSetters_73.DynamicSetter_2(coinSpecificPartView4, compiledBindingExtension43);
			context.PopParent();
			supportInitialize73.EndInit();
			context.PopParent();
			supportInitialize60.EndInit();
			context.PopParent();
			supportInitialize59.EndInit();
			context.PopParent();
			supportInitialize10.EndInit();
			context.PopParent();
			supportInitialize.EndInit();
			context.PopParent();
			((ISupportInitialize)A_1).EndInit();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x0600003F RID: 63 RVA: 0x00017353 File Offset: 0x00015553
		private static void !XamlIlPopulateTrampoline(MainWindow A_0)
		{
			if (MainWindow.!XamlIlPopulateOverride != null)
			{
				MainWindow.!XamlIlPopulateOverride(A_0);
				return;
			}
			MainWindow.!XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), A_0);
		}

		// Token: 0x04000009 RID: 9
		private static Action<object> !XamlIlPopulateOverride;

		// Token: 0x02000020 RID: 32
		private class DynamicSetters_73
		{
			// Token: 0x06000046 RID: 70 RVA: 0x0001753C File Offset: 0x0001573C
			public static void DynamicSetter_1(TemplatedControl A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(TemplatedControl.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(TemplatedControl.FontFamilyProperty, A_1, null);
					return;
				}
				if (A_1 is FontFamily)
				{
					A_0.FontFamily = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.FontFamily = A_1;
					return;
				}
				throw new InvalidCastException();
			}

			// Token: 0x06000047 RID: 71 RVA: 0x000175A8 File Offset: 0x000157A8
			public static void DynamicSetter_2(StyledElement A_0, CompiledBindingExtension A_1)
			{
				if (A_1 != null)
				{
					A_0.Bind(StyledElement.DataContextProperty, A_1, null);
					return;
				}
				A_0.DataContext = A_1;
			}

			// Token: 0x06000048 RID: 72 RVA: 0x000175D4 File Offset: 0x000157D4
			public static void DynamicSetter_3(TextBlock A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
					return;
				}
				if (A_1 is FontFamily)
				{
					A_0.FontFamily = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.FontFamily = A_1;
					return;
				}
				throw new InvalidCastException();
			}

			// Token: 0x06000049 RID: 73 RVA: 0x00017640 File Offset: 0x00015840
			public static void DynamicSetter_4(Path A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(Path.DataProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(Path.DataProperty, A_1, null);
					return;
				}
				if (A_1 is Geometry)
				{
					A_0.Data = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.Data = A_1;
					return;
				}
				throw new InvalidCastException();
			}

			// Token: 0x0600004A RID: 74 RVA: 0x000176AC File Offset: 0x000158AC
			public static void DynamicSetter_5(StyledElement A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(StyledElement.ThemeProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(StyledElement.ThemeProperty, A_1, null);
					return;
				}
				if (A_1 is ControlTheme)
				{
					A_0.Theme = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.Theme = A_1;
					return;
				}
				throw new InvalidCastException();
			}
		}

		// Token: 0x02000021 RID: 33
		private class XamlClosure_74
		{
			// Token: 0x0600004B RID: 75 RVA: 0x00017718 File Offset: 0x00015918
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<MainWindow> context = new XamlIlContext.Context<MainWindow>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.Singleton
				}, "avares://Exodus/Views/MainWindow.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (MainWindow)obj;
					}
				}
				context.IntermediateRoot = new StackPanel();
				object intermediateRoot = context.IntermediateRoot;
				((ISupportInitialize)intermediateRoot).BeginInit();
				intermediateRoot.Spacing = -5.0;
				intermediateRoot.Orientation = Orientation.Horizontal;
				((ISupportInitialize)intermediateRoot).EndInit();
				return intermediateRoot;
			}
		}

		// Token: 0x02000022 RID: 34
		private class XamlClosure_75
		{
			// Token: 0x0600004C RID: 76 RVA: 0x000177AC File Offset: 0x000159AC
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<MainWindow> context = new XamlIlContext.Context<MainWindow>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/MainWindow.axaml.Singleton
				}, "avares://Exodus/Views/MainWindow.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (MainWindow)obj;
					}
				}
				context.IntermediateRoot = new Grid();
				object intermediateRoot = context.IntermediateRoot;
				((ISupportInitialize)intermediateRoot).BeginInit();
				Grid grid = intermediateRoot;
				context.PushParent(grid);
				Grid grid2 = grid;
				RowDefinitions rowDefinitions = new RowDefinitions();
				rowDefinitions.Capacity = 2;
				rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				rowDefinitions.Add(new RowDefinition(new GridLength(2.0, GridUnitType.Pixel)));
				grid2.RowDefinitions = rowDefinitions;
				grid2.Height = 68.0;
				AvaloniaList<Control> children = grid2.Children;
				Grid grid4;
				Grid grid3 = grid4 = new Grid();
				((ISupportInitialize)grid3).BeginInit();
				children.Add(grid3);
				ISupportInitialize supportInitialize = grid = grid4;
				context.PushParent(grid);
				Grid grid5 = grid;
				Grid.SetRow(grid5, 0);
				AvaloniaList<Control> children2 = grid5.Children;
				Image image2;
				Image image = image2 = new Image();
				((ISupportInitialize)image).BeginInit();
				children2.Add(image);
				Image image3;
				ISupportInitialize supportInitialize2 = image3 = image2;
				context.PushParent(image3);
				Image image4 = image3;
				image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/interest.png");
				AvaloniaProperty isVisibleProperty = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsShowPercentageIcon!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding = compiledBindingExtension.ProvideValue(provider);
				context.ProvideTargetProperty = null;
				image4.Bind(isVisibleProperty, binding, null);
				RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
				image4.Width = 10.0;
				image4.Stretch = Stretch.Uniform;
				image4.Margin = new Thickness(0.0, 10.0, 10.0, 0.0);
				image4.VerticalAlignment = VerticalAlignment.Top;
				image4.HorizontalAlignment = HorizontalAlignment.Right;
				context.PopParent();
				supportInitialize2.EndInit();
				AvaloniaList<Control> children3 = grid5.Children;
				Grid grid7;
				Grid grid6 = grid7 = new Grid();
				((ISupportInitialize)grid6).BeginInit();
				children3.Add(grid6);
				ISupportInitialize supportInitialize3 = grid = grid7;
				context.PushParent(grid);
				Grid grid8 = grid;
				ColumnDefinitions columnDefinitions = new ColumnDefinitions();
				columnDefinitions.Capacity = 2;
				columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				grid8.ColumnDefinitions = columnDefinitions;
				AvaloniaList<Control> children4 = grid8.Children;
				Button button2;
				Button button = button2 = new Button();
				((ISupportInitialize)button).BeginInit();
				children4.Add(button);
				Button button3;
				ISupportInitialize supportInitialize4 = button3 = button2;
				context.PushParent(button3);
				Button button4 = button3;
				Grid.SetColumn(button4, 0);
				button4.Background = new ImmutableSolidColorBrush(16777215U);
				button4.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
				button4.Margin = new Thickness(0.0, 0.0, 0.0, 0.0);
				button4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
				button4.HorizontalAlignment = HorizontalAlignment.Stretch;
				button4.VerticalContentAlignment = VerticalAlignment.Stretch;
				AvaloniaProperty commandProperty = Button.CommandProperty;
				CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("SelectedCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.Models.Coin+SelectedCommand_0!CommandExecuteTrampoline), null, null).Build());
				IServiceProvider provider2 = context;
				context.ProvideTargetProperty = Button.CommandProperty;
				IBinding binding2 = compiledBindingExtension2.ProvideValue(provider2);
				context.ProvideTargetProperty = null;
				button4.Bind(commandProperty, binding2, null);
				Border border2;
				Border border = border2 = new Border();
				((ISupportInitialize)border).BeginInit();
				button4.Content = border;
				Border border3;
				ISupportInitialize supportInitialize5 = border3 = border2;
				context.PushParent(border3);
				Border border4 = border3;
				border4.Width = 155.0;
				border4.Padding = new Thickness(20.0, 0.0, 20.0, 0.0);
				border4.HorizontalAlignment = HorizontalAlignment.Stretch;
				border4.VerticalAlignment = VerticalAlignment.Stretch;
				Grid grid10;
				Grid grid9 = grid10 = new Grid();
				((ISupportInitialize)grid9).BeginInit();
				border4.Child = grid9;
				ISupportInitialize supportInitialize6 = grid = grid10;
				context.PushParent(grid);
				Grid grid11 = grid;
				grid11.HorizontalAlignment = HorizontalAlignment.Center;
				grid11.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children5 = grid11.Children;
				StackPanel stackPanel2;
				StackPanel stackPanel = stackPanel2 = new StackPanel();
				((ISupportInitialize)stackPanel).BeginInit();
				children5.Add(stackPanel);
				StackPanel stackPanel3;
				ISupportInitialize supportInitialize7 = stackPanel3 = stackPanel2;
				context.PushParent(stackPanel3);
				StackPanel stackPanel4 = stackPanel3;
				AvaloniaProperty isVisibleProperty2 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsSelected!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider3 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding3 = compiledBindingExtension3.ProvideValue(provider3);
				context.ProvideTargetProperty = null;
				stackPanel4.Bind(isVisibleProperty2, binding3, null);
				stackPanel4.HorizontalAlignment = HorizontalAlignment.Center;
				stackPanel4.VerticalAlignment = VerticalAlignment.Center;
				stackPanel4.Spacing = 3.0;
				AvaloniaList<Control> children6 = stackPanel4.Children;
				StackPanel stackPanel6;
				StackPanel stackPanel5 = stackPanel6 = new StackPanel();
				((ISupportInitialize)stackPanel5).BeginInit();
				children6.Add(stackPanel5);
				ISupportInitialize supportInitialize8 = stackPanel3 = stackPanel6;
				context.PushParent(stackPanel3);
				StackPanel stackPanel7 = stackPanel3;
				stackPanel7.Orientation = Orientation.Horizontal;
				stackPanel7.HorizontalAlignment = HorizontalAlignment.Center;
				stackPanel7.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children7 = stackPanel7.Children;
				TextBlock textBlock2;
				TextBlock textBlock = textBlock2 = new TextBlock();
				((ISupportInitialize)textBlock).BeginInit();
				children7.Add(textBlock);
				TextBlock textBlock3;
				ISupportInitialize supportInitialize9 = textBlock3 = textBlock2;
				context.PushParent(textBlock3);
				TextBlock textBlock4 = textBlock3;
				textBlock4.FontSize = 14.0;
				StaticResourceExtension staticResourceExtension = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj2 = staticResourceExtension.ProvideValue(serviceProvider);
				context.ProvideTargetProperty = null;
				MainWindow.XamlClosure_75.DynamicSetters_76.DynamicSetter_1(textBlock4, obj2);
				textBlock4.FontWeight = FontWeight.Normal;
				textBlock4.Opacity = 1.0;
				AvaloniaProperty textProperty = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.Name!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider4 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding4 = compiledBindingExtension4.ProvideValue(provider4);
				context.ProvideTargetProperty = null;
				textBlock4.Bind(textProperty, binding4, null);
				textBlock4.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaProperty foregroundProperty = TextBlock.ForegroundProperty;
				CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.ViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider5 = context;
				context.ProvideTargetProperty = TextBlock.ForegroundProperty;
				IBinding binding5 = compiledBindingExtension5.ProvideValue(provider5);
				context.ProvideTargetProperty = null;
				textBlock4.Bind(foregroundProperty, binding5, null);
				context.PopParent();
				supportInitialize9.EndInit();
				AvaloniaList<Control> children8 = stackPanel7.Children;
				Image image6;
				Image image5 = image6 = new Image();
				((ISupportInitialize)image5).BeginInit();
				children8.Add(image5);
				ISupportInitialize supportInitialize10 = image3 = image6;
				context.PushParent(image3);
				Image image7 = image3;
				image7.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/bsc_badge.png");
				image7.Width = 12.0;
				image7.Height = 12.0;
				image7.Stretch = Stretch.Uniform;
				image7.Margin = new Thickness(4.0, 0.0, 0.0, 0.0);
				image7.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaProperty isVisibleProperty3 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsBscNetwork!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider6 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding6 = compiledBindingExtension6.ProvideValue(provider6);
				context.ProvideTargetProperty = null;
				image7.Bind(isVisibleProperty3, binding6, null);
				RenderOptions.SetBitmapInterpolationMode(image7, BitmapInterpolationMode.HighQuality);
				context.PopParent();
				supportInitialize10.EndInit();
				context.PopParent();
				supportInitialize8.EndInit();
				AvaloniaList<Control> children9 = stackPanel4.Children;
				StackPanel stackPanel9;
				StackPanel stackPanel8 = stackPanel9 = new StackPanel();
				((ISupportInitialize)stackPanel8).BeginInit();
				children9.Add(stackPanel8);
				ISupportInitialize supportInitialize11 = stackPanel3 = stackPanel9;
				context.PushParent(stackPanel3);
				StackPanel stackPanel10 = stackPanel3;
				stackPanel10.Orientation = Orientation.Horizontal;
				stackPanel10.HorizontalAlignment = HorizontalAlignment.Center;
				stackPanel10.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children10 = stackPanel10.Children;
				TextBlock textBlock6;
				TextBlock textBlock5 = textBlock6 = new TextBlock();
				((ISupportInitialize)textBlock5).BeginInit();
				children10.Add(textBlock5);
				ISupportInitialize supportInitialize12 = textBlock3 = textBlock6;
				context.PushParent(textBlock3);
				TextBlock textBlock7 = textBlock3;
				textBlock7.FontSize = 12.0;
				StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider2 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj3 = staticResourceExtension2.ProvideValue(serviceProvider2);
				context.ProvideTargetProperty = null;
				MainWindow.XamlClosure_75.DynamicSetters_76.DynamicSetter_1(textBlock7, obj3);
				textBlock7.FontWeight = FontWeight.Normal;
				textBlock7.Opacity = 0.75;
				AvaloniaProperty textProperty2 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.FormattedBalance!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider7 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding7 = compiledBindingExtension7.ProvideValue(provider7);
				context.ProvideTargetProperty = null;
				textBlock7.Bind(textProperty2, binding7, null);
				textBlock7.TextAlignment = TextAlignment.Center;
				textBlock7.Margin = new Thickness(0.0, 0.0, 3.0, 0.0);
				textBlock7.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize12.EndInit();
				AvaloniaList<Control> children11 = stackPanel10.Children;
				TextBlock textBlock9;
				TextBlock textBlock8 = textBlock9 = new TextBlock();
				((ISupportInitialize)textBlock8).BeginInit();
				children11.Add(textBlock8);
				ISupportInitialize supportInitialize13 = textBlock3 = textBlock9;
				context.PushParent(textBlock3);
				TextBlock textBlock10 = textBlock3;
				textBlock10.FontSize = 12.0;
				StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider3 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj4 = staticResourceExtension3.ProvideValue(serviceProvider3);
				context.ProvideTargetProperty = null;
				MainWindow.XamlClosure_75.DynamicSetters_76.DynamicSetter_1(textBlock10, obj4);
				textBlock10.FontWeight = FontWeight.Normal;
				textBlock10.Opacity = 0.75;
				AvaloniaProperty textProperty3 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.Symbol!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider8 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding8 = compiledBindingExtension8.ProvideValue(provider8);
				context.ProvideTargetProperty = null;
				textBlock10.Bind(textProperty3, binding8, null);
				textBlock10.TextAlignment = TextAlignment.Center;
				textBlock10.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize13.EndInit();
				context.PopParent();
				supportInitialize11.EndInit();
				context.PopParent();
				supportInitialize7.EndInit();
				AvaloniaList<Control> children12 = grid11.Children;
				StackPanel stackPanel12;
				StackPanel stackPanel11 = stackPanel12 = new StackPanel();
				((ISupportInitialize)stackPanel11).BeginInit();
				children12.Add(stackPanel11);
				ISupportInitialize supportInitialize14 = stackPanel3 = stackPanel12;
				context.PushParent(stackPanel3);
				StackPanel stackPanel13 = stackPanel3;
				AvaloniaProperty isVisibleProperty4 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsSelected!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider9 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding9 = compiledBindingExtension9.ProvideValue(provider9);
				context.ProvideTargetProperty = null;
				stackPanel13.Bind(isVisibleProperty4, binding9, null);
				stackPanel13.HorizontalAlignment = HorizontalAlignment.Center;
				stackPanel13.VerticalAlignment = VerticalAlignment.Center;
				stackPanel13.Spacing = 3.0;
				AvaloniaList<Control> children13 = stackPanel13.Children;
				StackPanel stackPanel15;
				StackPanel stackPanel14 = stackPanel15 = new StackPanel();
				((ISupportInitialize)stackPanel14).BeginInit();
				children13.Add(stackPanel14);
				ISupportInitialize supportInitialize15 = stackPanel3 = stackPanel15;
				context.PushParent(stackPanel3);
				StackPanel stackPanel16 = stackPanel3;
				stackPanel16.Orientation = Orientation.Horizontal;
				stackPanel16.HorizontalAlignment = HorizontalAlignment.Center;
				stackPanel16.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children14 = stackPanel16.Children;
				TextBlock textBlock12;
				TextBlock textBlock11 = textBlock12 = new TextBlock();
				((ISupportInitialize)textBlock11).BeginInit();
				children14.Add(textBlock11);
				ISupportInitialize supportInitialize16 = textBlock3 = textBlock12;
				context.PushParent(textBlock3);
				TextBlock textBlock13 = textBlock3;
				textBlock13.FontSize = 14.0;
				StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider4 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj5 = staticResourceExtension4.ProvideValue(serviceProvider4);
				context.ProvideTargetProperty = null;
				MainWindow.XamlClosure_75.DynamicSetters_76.DynamicSetter_1(textBlock13, obj5);
				textBlock13.FontWeight = FontWeight.Normal;
				textBlock13.Opacity = 0.9;
				AvaloniaProperty textProperty4 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.Name!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider10 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding10 = compiledBindingExtension10.ProvideValue(provider10);
				context.ProvideTargetProperty = null;
				textBlock13.Bind(textProperty4, binding10, null);
				textBlock13.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize16.EndInit();
				AvaloniaList<Control> children15 = stackPanel16.Children;
				Image image9;
				Image image8 = image9 = new Image();
				((ISupportInitialize)image8).BeginInit();
				children15.Add(image8);
				ISupportInitialize supportInitialize17 = image3 = image9;
				context.PushParent(image3);
				Image image10 = image3;
				image10.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/bsc_badge.png");
				image10.Width = 12.0;
				image10.Height = 12.0;
				image10.Stretch = Stretch.Uniform;
				image10.Margin = new Thickness(4.0, 0.0, 0.0, 0.0);
				image10.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaProperty isVisibleProperty5 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsBscNetwork!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider11 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding11 = compiledBindingExtension11.ProvideValue(provider11);
				context.ProvideTargetProperty = null;
				image10.Bind(isVisibleProperty5, binding11, null);
				RenderOptions.SetBitmapInterpolationMode(image10, BitmapInterpolationMode.HighQuality);
				context.PopParent();
				supportInitialize17.EndInit();
				context.PopParent();
				supportInitialize15.EndInit();
				AvaloniaList<Control> children16 = stackPanel13.Children;
				StackPanel stackPanel18;
				StackPanel stackPanel17 = stackPanel18 = new StackPanel();
				((ISupportInitialize)stackPanel17).BeginInit();
				children16.Add(stackPanel17);
				ISupportInitialize supportInitialize18 = stackPanel3 = stackPanel18;
				context.PushParent(stackPanel3);
				StackPanel stackPanel19 = stackPanel3;
				stackPanel19.Orientation = Orientation.Horizontal;
				stackPanel19.HorizontalAlignment = HorizontalAlignment.Center;
				stackPanel19.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children17 = stackPanel19.Children;
				TextBlock textBlock15;
				TextBlock textBlock14 = textBlock15 = new TextBlock();
				((ISupportInitialize)textBlock14).BeginInit();
				children17.Add(textBlock14);
				ISupportInitialize supportInitialize19 = textBlock3 = textBlock15;
				context.PushParent(textBlock3);
				TextBlock textBlock16 = textBlock3;
				textBlock16.FontSize = 12.0;
				StaticResourceExtension staticResourceExtension5 = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider5 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj6 = staticResourceExtension5.ProvideValue(serviceProvider5);
				context.ProvideTargetProperty = null;
				MainWindow.XamlClosure_75.DynamicSetters_76.DynamicSetter_1(textBlock16, obj6);
				textBlock16.FontWeight = FontWeight.Normal;
				textBlock16.Opacity = 0.4;
				AvaloniaProperty textProperty5 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.FormattedBalance!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider12 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding12 = compiledBindingExtension12.ProvideValue(provider12);
				context.ProvideTargetProperty = null;
				textBlock16.Bind(textProperty5, binding12, null);
				textBlock16.TextAlignment = TextAlignment.Center;
				textBlock16.Margin = new Thickness(0.0, 0.0, 3.0, 0.0);
				textBlock16.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize19.EndInit();
				AvaloniaList<Control> children18 = stackPanel19.Children;
				TextBlock textBlock18;
				TextBlock textBlock17 = textBlock18 = new TextBlock();
				((ISupportInitialize)textBlock17).BeginInit();
				children18.Add(textBlock17);
				ISupportInitialize supportInitialize20 = textBlock3 = textBlock18;
				context.PushParent(textBlock3);
				TextBlock textBlock19 = textBlock3;
				textBlock19.FontSize = 12.0;
				StaticResourceExtension staticResourceExtension6 = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider6 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj7 = staticResourceExtension6.ProvideValue(serviceProvider6);
				context.ProvideTargetProperty = null;
				MainWindow.XamlClosure_75.DynamicSetters_76.DynamicSetter_1(textBlock19, obj7);
				textBlock19.FontWeight = FontWeight.Normal;
				textBlock19.Opacity = 0.4;
				AvaloniaProperty textProperty6 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.Symbol!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider13 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding13 = compiledBindingExtension13.ProvideValue(provider13);
				context.ProvideTargetProperty = null;
				textBlock19.Bind(textProperty6, binding13, null);
				textBlock19.TextAlignment = TextAlignment.Center;
				textBlock19.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize20.EndInit();
				context.PopParent();
				supportInitialize18.EndInit();
				context.PopParent();
				supportInitialize14.EndInit();
				context.PopParent();
				supportInitialize6.EndInit();
				context.PopParent();
				supportInitialize5.EndInit();
				context.PopParent();
				supportInitialize4.EndInit();
				AvaloniaList<Control> children19 = grid8.Children;
				Rectangle rectangle2;
				Rectangle rectangle = rectangle2 = new Rectangle();
				((ISupportInitialize)rectangle).BeginInit();
				children19.Add(rectangle);
				Rectangle rectangle3 = rectangle2;
				Grid.SetColumn(rectangle3, 1);
				rectangle3.Height = 20.0;
				rectangle3.Width = 1.0;
				rectangle3.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
				rectangle3.Opacity = 0.2;
				rectangle3.VerticalAlignment = VerticalAlignment.Center;
				((ISupportInitialize)rectangle3).EndInit();
				context.PopParent();
				supportInitialize3.EndInit();
				context.PopParent();
				supportInitialize.EndInit();
				AvaloniaList<Control> children20 = grid2.Children;
				Border border6;
				Border border5 = border6 = new Border();
				((ISupportInitialize)border5).BeginInit();
				children20.Add(border5);
				ISupportInitialize supportInitialize21 = border3 = border6;
				context.PushParent(border3);
				Border border7 = border3;
				Grid.SetRow(border7, 1);
				border7.Height = 2.0;
				border7.Width = 155.0;
				AvaloniaProperty backgroundProperty = Border.BackgroundProperty;
				CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.ViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider14 = context;
				context.ProvideTargetProperty = Border.BackgroundProperty;
				IBinding binding14 = compiledBindingExtension14.ProvideValue(provider14);
				context.ProvideTargetProperty = null;
				border7.Bind(backgroundProperty, binding14, null);
				border7.CornerRadius = new CornerRadius(1.0, 1.0, 1.0, 1.0);
				AvaloniaProperty isVisibleProperty6 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsSelected!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider15 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding15 = compiledBindingExtension15.ProvideValue(provider15);
				context.ProvideTargetProperty = null;
				border7.Bind(isVisibleProperty6, binding15, null);
				border7.VerticalAlignment = VerticalAlignment.Bottom;
				border7.HorizontalAlignment = HorizontalAlignment.Stretch;
				context.PopParent();
				supportInitialize21.EndInit();
				context.PopParent();
				((ISupportInitialize)intermediateRoot).EndInit();
				return intermediateRoot;
			}

			// Token: 0x02000023 RID: 35
			private class DynamicSetters_76
			{
				// Token: 0x0600004D RID: 77 RVA: 0x0001882C File Offset: 0x00016A2C
				public static void DynamicSetter_1(TextBlock A_0, object A_1)
				{
					if (A_1 is UnsetValueType)
					{
						A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
						return;
					}
					if (A_1 is IBinding)
					{
						A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
						return;
					}
					if (A_1 is FontFamily)
					{
						A_0.FontFamily = A_1;
						return;
					}
					if (A_1 == null)
					{
						A_0.FontFamily = A_1;
						return;
					}
					throw new InvalidCastException();
				}
			}
		}
	}
}
