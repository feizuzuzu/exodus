﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Collections;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Controls.Templates;
using Avalonia.Data;
using Avalonia.Data.Core;
using Avalonia.Data.Core.Plugins;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using Exodus.Controls;
using Exodus.ViewModels;

namespace Exodus.Views
{
	// Token: 0x02000012 RID: 18
	[NullableContext(1)]
	[Nullable(0)]
	public class CoinSpecificPartView : Border
	{
		// Token: 0x06000024 RID: 36 RVA: 0x00008D51 File Offset: 0x00006F51
		public CoinSpecificPartView()
		{
			this.InitializeComponent(true);
		}

		// Token: 0x06000025 RID: 37 RVA: 0x00008D60 File Offset: 0x00006F60
		private void LogoButton_OnPointerEntered([Nullable(2)] object sender, PointerEventArgs e)
		{
			(base.DataContext as CoinSpecificPartViewModel).IsShowRefresh = true;
		}

		// Token: 0x06000026 RID: 38 RVA: 0x00008D73 File Offset: 0x00006F73
		private void LogoButton_OnPointerExited([Nullable(2)] object sender, PointerEventArgs e)
		{
			(base.DataContext as CoinSpecificPartViewModel).IsShowRefresh = false;
		}

		// Token: 0x06000027 RID: 39 RVA: 0x00008D86 File Offset: 0x00006F86
		public void InitializeComponent(bool loadXaml = true)
		{
			if (loadXaml)
			{
				CoinSpecificPartView.!XamlIlPopulateTrampoline(this);
			}
		}

		// Token: 0x06000028 RID: 40 RVA: 0x00008D94 File Offset: 0x00006F94
		static void !XamlIlPopulate(IServiceProvider A_0, CoinSpecificPartView A_1)
		{
			XamlIlContext.Context<CoinSpecificPartView> context = new XamlIlContext.Context<CoinSpecificPartView>(A_0, new object[]
			{
				(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.Singleton
			}, "avares://Exodus/Views/CoinSpecificPartView.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			((ISupportInitialize)A_1).BeginInit();
			context.PushParent(A_1);
			A_1.Background = new LinearGradientBrush
			{
				StartPoint = new RelativePoint(0.0, 1.0, RelativeUnit.Relative),
				EndPoint = new RelativePoint(1.0, 0.0, RelativeUnit.Relative),
				GradientStops = 
				{
					new GradientStop
					{
						Color = Color.FromUInt32(4279374612U),
						Offset = 0.0
					},
					new GradientStop
					{
						Color = Color.FromUInt32(4280428589U),
						Offset = 1.0
					}
				}
			};
			ScrollViewer scrollViewer2;
			ScrollViewer scrollViewer = scrollViewer2 = new ScrollViewer();
			((ISupportInitialize)scrollViewer).BeginInit();
			A_1.Child = scrollViewer;
			ScrollViewer scrollViewer3;
			ISupportInitialize supportInitialize = scrollViewer3 = scrollViewer2;
			context.PushParent(scrollViewer3);
			ScrollViewer scrollViewer4 = scrollViewer3;
			scrollViewer4.HorizontalAlignment = HorizontalAlignment.Stretch;
			scrollViewer4.IsScrollInertiaEnabled = true;
			scrollViewer4.VerticalAlignment = VerticalAlignment.Stretch;
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("ScrollViewerWithMouse");
			IServiceProvider serviceProvider = context;
			context.ProvideTargetProperty = StyledElement.ThemeProperty;
			object obj = staticResourceExtension.ProvideValue(serviceProvider);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_1(scrollViewer4, obj);
			scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
			scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			StackPanel stackPanel2;
			StackPanel stackPanel = stackPanel2 = new StackPanel();
			((ISupportInitialize)stackPanel).BeginInit();
			scrollViewer4.Content = stackPanel;
			StackPanel stackPanel3;
			ISupportInitialize supportInitialize2 = stackPanel3 = stackPanel2;
			context.PushParent(stackPanel3);
			StackPanel stackPanel4 = stackPanel3;
			AvaloniaList<Control> children = stackPanel4.Children;
			Grid grid2;
			Grid grid = grid2 = new Grid();
			((ISupportInitialize)grid).BeginInit();
			children.Add(grid);
			Grid grid3;
			ISupportInitialize supportInitialize3 = grid3 = grid2;
			context.PushParent(grid3);
			Grid grid4 = grid3;
			AvaloniaList<Control> children2 = grid4.Children;
			StackPanel stackPanel6;
			StackPanel stackPanel5 = stackPanel6 = new StackPanel();
			((ISupportInitialize)stackPanel5).BeginInit();
			children2.Add(stackPanel5);
			ISupportInitialize supportInitialize4 = stackPanel3 = stackPanel6;
			context.PushParent(stackPanel3);
			StackPanel stackPanel7 = stackPanel3;
			stackPanel7.HorizontalAlignment = HorizontalAlignment.Right;
			stackPanel7.VerticalAlignment = VerticalAlignment.Top;
			stackPanel7.Margin = new Thickness(0.0, 24.0, 32.0, 0.0);
			stackPanel7.Orientation = Orientation.Horizontal;
			AvaloniaList<Control> children3 = stackPanel7.Children;
			Button button2;
			Button button = button2 = new Button();
			((ISupportInitialize)button).BeginInit();
			children3.Add(button);
			Button button3;
			ISupportInitialize supportInitialize5 = button3 = button2;
			context.PushParent(button3);
			Button button4 = button3;
			button4.Background = new ImmutableSolidColorBrush(16777215U);
			button4.HorizontalAlignment = HorizontalAlignment.Center;
			button4.VerticalAlignment = VerticalAlignment.Center;
			button4.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
			Viewbox viewbox2;
			Viewbox viewbox = viewbox2 = new Viewbox();
			((ISupportInitialize)viewbox).BeginInit();
			button4.Content = viewbox;
			Viewbox viewbox3;
			ISupportInitialize supportInitialize6 = viewbox3 = viewbox2;
			context.PushParent(viewbox3);
			Viewbox viewbox4 = viewbox3;
			viewbox4.Width = 18.0;
			Path path2;
			Path path = path2 = new Path();
			((ISupportInitialize)path).BeginInit();
			viewbox4.Child = path;
			Path path3;
			ISupportInitialize supportInitialize7 = path3 = path2;
			context.PushParent(path3);
			Path path4 = path3;
			AvaloniaProperty dataProperty = Path.DataProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("Star");
			IServiceProvider serviceProvider2 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			IBinding binding = dynamicResourceExtension.ProvideValue(serviceProvider2);
			context.ProvideTargetProperty = null;
			path4.Bind(dataProperty, binding, null);
			path4.Fill = new ImmutableSolidColorBrush(4284704618U);
			path4.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize7.EndInit();
			context.PopParent();
			supportInitialize6.EndInit();
			context.PopParent();
			supportInitialize5.EndInit();
			AvaloniaList<Control> children4 = stackPanel7.Children;
			Button button6;
			Button button5 = button6 = new Button();
			((ISupportInitialize)button5).BeginInit();
			children4.Add(button5);
			ISupportInitialize supportInitialize8 = button3 = button6;
			context.PushParent(button3);
			Button button7 = button3;
			button7.Background = new ImmutableSolidColorBrush(16777215U);
			button7.VerticalAlignment = VerticalAlignment.Center;
			Viewbox viewbox6;
			Viewbox viewbox5 = viewbox6 = new Viewbox();
			((ISupportInitialize)viewbox5).BeginInit();
			button7.Content = viewbox5;
			ISupportInitialize supportInitialize9 = viewbox3 = viewbox6;
			context.PushParent(viewbox3);
			Viewbox viewbox7 = viewbox3;
			viewbox7.Height = 18.0;
			Path path6;
			Path path5 = path6 = new Path();
			((ISupportInitialize)path5).BeginInit();
			viewbox7.Child = path5;
			ISupportInitialize supportInitialize10 = path3 = path6;
			context.PushParent(path3);
			Path path7 = path3;
			AvaloniaProperty dataProperty2 = Path.DataProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ThreeDot");
			IServiceProvider serviceProvider3 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			IBinding binding2 = dynamicResourceExtension2.ProvideValue(serviceProvider3);
			context.ProvideTargetProperty = null;
			path7.Bind(dataProperty2, binding2, null);
			path7.Fill = new ImmutableSolidColorBrush(4289704371U);
			path7.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize10.EndInit();
			context.PopParent();
			supportInitialize9.EndInit();
			context.PopParent();
			supportInitialize8.EndInit();
			context.PopParent();
			supportInitialize4.EndInit();
			AvaloniaList<Control> children5 = grid4.Children;
			StackPanel stackPanel9;
			StackPanel stackPanel8 = stackPanel9 = new StackPanel();
			((ISupportInitialize)stackPanel8).BeginInit();
			children5.Add(stackPanel8);
			ISupportInitialize supportInitialize11 = stackPanel3 = stackPanel9;
			context.PushParent(stackPanel3);
			StackPanel stackPanel10 = stackPanel3;
			stackPanel10.HorizontalAlignment = HorizontalAlignment.Center;
			stackPanel10.VerticalAlignment = VerticalAlignment.Top;
			stackPanel10.Margin = new Thickness(0.0, 55.0, 0.0, 6.0);
			AvaloniaList<Control> children6 = stackPanel10.Children;
			Button button9;
			Button button8 = button9 = new Button();
			((ISupportInitialize)button8).BeginInit();
			children6.Add(button8);
			ISupportInitialize supportInitialize12 = button3 = button9;
			context.PushParent(button3);
			Button button10 = button3;
			button10.Background = new ImmutableSolidColorBrush(16777215U);
			button10.Margin = new Thickness(0.0, 0.0, 0.0, 6.0);
			button10.HorizontalAlignment = HorizontalAlignment.Center;
			AvaloniaProperty commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("RefreshCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.CoinSpecificPartViewModel+RefreshCommand_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding3 = compiledBindingExtension.ProvideValue(provider);
			context.ProvideTargetProperty = null;
			button10.Bind(commandProperty, binding3, null);
			button10.PointerEntered += context.RootObject.LogoButton_OnPointerEntered;
			button10.PointerExited += context.RootObject.LogoButton_OnPointerExited;
			Grid grid6;
			Grid grid5 = grid6 = new Grid();
			((ISupportInitialize)grid5).BeginInit();
			button10.Content = grid5;
			ISupportInitialize supportInitialize13 = grid3 = grid6;
			context.PushParent(grid3);
			Grid grid7 = grid3;
			AvaloniaProperty heightProperty = Layoutable.HeightProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControlHeight!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider2 = context;
			context.ProvideTargetProperty = Layoutable.HeightProperty;
			IBinding binding4 = compiledBindingExtension2.ProvideValue(provider2);
			context.ProvideTargetProperty = null;
			grid7.Bind(heightProperty, binding4, null);
			AvaloniaProperty maxHeightProperty = Layoutable.MaxHeightProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControlHeight!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider3 = context;
			context.ProvideTargetProperty = Layoutable.MaxHeightProperty;
			IBinding binding5 = compiledBindingExtension3.ProvideValue(provider3);
			context.ProvideTargetProperty = null;
			grid7.Bind(maxHeightProperty, binding5, null);
			AvaloniaProperty minHeightProperty = Layoutable.MinHeightProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControlHeight!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider4 = context;
			context.ProvideTargetProperty = Layoutable.MinHeightProperty;
			IBinding binding6 = compiledBindingExtension4.ProvideValue(provider4);
			context.ProvideTargetProperty = null;
			grid7.Bind(minHeightProperty, binding6, null);
			AvaloniaList<Control> children7 = grid7.Children;
			Grid grid9;
			Grid grid8 = grid9 = new Grid();
			((ISupportInitialize)grid8).BeginInit();
			children7.Add(grid8);
			ISupportInitialize supportInitialize14 = grid3 = grid9;
			context.PushParent(grid3);
			Grid grid10 = grid3;
			AvaloniaProperty isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowRefresh!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider5 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding7 = compiledBindingExtension5.ProvideValue(provider5);
			context.ProvideTargetProperty = null;
			grid10.Bind(isVisibleProperty, binding7, null);
			grid10.VerticalAlignment = VerticalAlignment.Top;
			grid10.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Grid)).PropertyEquals(Visual.IsVisibleProperty, true),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(2300000L),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 0.85
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 0.85
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 1.0
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 1.0
									}
								}
							}
						}
					}
				}
			});
			grid10.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Grid)).PropertyEquals(Visual.IsVisibleProperty, false),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(2300000L),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 1.0
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 1.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 0.85
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 0.85
									}
								}
							}
						}
					}
				}
			});
			AvaloniaList<Control> children8 = grid10.Children;
			UserControl userControl2;
			UserControl userControl = userControl2 = new UserControl();
			((ISupportInitialize)userControl).BeginInit();
			children8.Add(userControl);
			UserControl userControl3;
			ISupportInitialize supportInitialize15 = userControl3 = userControl2;
			context.PushParent(userControl3);
			AvaloniaObject target = userControl3;
			AvaloniaProperty contentTemplateProperty = ContentControl.ContentTemplateProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BannerControl!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider6 = context;
			context.ProvideTargetProperty = ContentControl.ContentTemplateProperty;
			IBinding binding8 = compiledBindingExtension6.ProvideValue(provider6);
			context.ProvideTargetProperty = null;
			target.Bind(contentTemplateProperty, binding8, null);
			context.PopParent();
			supportInitialize15.EndInit();
			context.PopParent();
			supportInitialize14.EndInit();
			AvaloniaList<Control> children9 = grid7.Children;
			Border border2;
			Border border = border2 = new Border();
			((ISupportInitialize)border).BeginInit();
			children9.Add(border);
			Border border3;
			ISupportInitialize supportInitialize16 = border3 = border2;
			context.PushParent(border3);
			Border border4 = border3;
			AvaloniaProperty isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowRefresh!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider7 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding9 = compiledBindingExtension7.ProvideValue(provider7);
			context.ProvideTargetProperty = null;
			border4.Bind(isVisibleProperty2, binding9, null);
			border4.Width = 80.0;
			border4.Height = 80.0;
			AvaloniaProperty backgroundProperty = Border.BackgroundProperty;
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground2!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider8 = context;
			context.ProvideTargetProperty = Border.BackgroundProperty;
			IBinding binding10 = compiledBindingExtension8.ProvideValue(provider8);
			context.ProvideTargetProperty = null;
			border4.Bind(backgroundProperty, binding10, null);
			border4.CornerRadius = new CornerRadius(120.0, 120.0, 120.0, 120.0);
			border4.VerticalAlignment = VerticalAlignment.Top;
			border4.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Border)).PropertyEquals(Visual.IsVisibleProperty, true),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(2300000L),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 0.85
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 0.85
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 1.0
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 1.0
									}
								}
							}
						}
					}
				}
			});
			border4.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Border)).PropertyEquals(Visual.IsVisibleProperty, false),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(2300000L),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 1.0
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 1.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 0.85
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 0.85
									}
								}
							}
						}
					}
				}
			});
			Viewbox viewbox9;
			Viewbox viewbox8 = viewbox9 = new Viewbox();
			((ISupportInitialize)viewbox8).BeginInit();
			border4.Child = viewbox8;
			ISupportInitialize supportInitialize17 = viewbox3 = viewbox9;
			context.PushParent(viewbox3);
			Viewbox viewbox10 = viewbox3;
			viewbox10.Width = 32.0;
			viewbox10.VerticalAlignment = VerticalAlignment.Center;
			viewbox10.HorizontalAlignment = HorizontalAlignment.Center;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsPlayRefresh!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider9 = context;
			context.ProvideTargetProperty = "class:IsPlay";
			IBinding binding11 = compiledBindingExtension9.ProvideValue(provider9);
			context.ProvideTargetProperty = null;
			IBinding source = binding11;
			viewbox10.BindClass("IsPlay", source, null);
			viewbox10.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Viewbox)).Class("IsPlay"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(17500000L),
						IterationCount = IterationCount.Parse("Infinite"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = RotateTransform.AngleProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = RotateTransform.AngleProperty,
										Value = 360.0
									}
								}
							}
						}
					}
				}
			});
			Path path9;
			Path path8 = path9 = new Path();
			((ISupportInitialize)path8).BeginInit();
			viewbox10.Child = path8;
			ISupportInitialize supportInitialize18 = path3 = path9;
			context.PushParent(path3);
			Path path10 = path3;
			StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("Refresh");
			IServiceProvider serviceProvider4 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj2 = staticResourceExtension2.ProvideValue(serviceProvider4);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_2(path10, obj2);
			path10.Stretch = Stretch.Uniform;
			path10.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			context.PopParent();
			supportInitialize18.EndInit();
			context.PopParent();
			supportInitialize17.EndInit();
			context.PopParent();
			supportInitialize16.EndInit();
			context.PopParent();
			supportInitialize13.EndInit();
			context.PopParent();
			supportInitialize12.EndInit();
			AvaloniaList<Control> children10 = stackPanel10.Children;
			Button button12;
			Button button11 = button12 = new Button();
			((ISupportInitialize)button11).BeginInit();
			children10.Add(button11);
			ISupportInitialize supportInitialize19 = button3 = button12;
			context.PushParent(button3);
			Button button13 = button3;
			button13.Background = new ImmutableSolidColorBrush(16777215U);
			button13.BorderBrush = new ImmutableSolidColorBrush(16777215U);
			button13.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
			button13.Margin = new Thickness(0.0, 4.0, 0.0, 6.0);
			button13.HorizontalAlignment = HorizontalAlignment.Center;
			AvaloniaProperty isVisibleProperty3 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowNetworkPill!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider10 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding12 = compiledBindingExtension10.ProvideValue(provider10);
			context.ProvideTargetProperty = null;
			button13.Bind(isVisibleProperty3, binding12, null);
			Border border6;
			Border border5 = border6 = new Border();
			((ISupportInitialize)border5).BeginInit();
			button13.Content = border5;
			ISupportInitialize supportInitialize20 = border3 = border6;
			context.PushParent(border3);
			Border border7 = border3;
			border7.Height = 28.0;
			border7.CornerRadius = new CornerRadius(14.0, 14.0, 14.0, 14.0);
			border7.Background = new ImmutableSolidColorBrush(637534208U);
			border7.Padding = new Thickness(10.0, 0.0, 10.0, 0.0);
			Grid grid12;
			Grid grid11 = grid12 = new Grid();
			((ISupportInitialize)grid11).BeginInit();
			border7.Child = grid11;
			ISupportInitialize supportInitialize21 = grid3 = grid12;
			context.PushParent(grid3);
			Grid grid13 = grid3;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 3;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid13.ColumnDefinitions = columnDefinitions;
			AvaloniaList<Control> children11 = grid13.Children;
			Image image2;
			Image image = image2 = new Image();
			((ISupportInitialize)image).BeginInit();
			children11.Add(image);
			Image image3;
			ISupportInitialize supportInitialize22 = image3 = image2;
			context.PushParent(image3);
			Image image4 = image3;
			Grid.SetColumn(image4, 0);
			AvaloniaProperty sourceProperty = Image.SourceProperty;
			CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillIcon!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider11 = context;
			context.ProvideTargetProperty = Image.SourceProperty;
			IBinding binding13 = compiledBindingExtension11.ProvideValue(provider11);
			context.ProvideTargetProperty = null;
			image4.Bind(sourceProperty, binding13, null);
			image4.Width = 14.0;
			image4.Height = 14.0;
			image4.Stretch = Stretch.Uniform;
			image4.VerticalAlignment = VerticalAlignment.Center;
			image4.HorizontalAlignment = HorizontalAlignment.Center;
			RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
			AvaloniaProperty isVisibleProperty4 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.HasNetworkPillIcon!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider12 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding14 = compiledBindingExtension12.ProvideValue(provider12);
			context.ProvideTargetProperty = null;
			image4.Bind(isVisibleProperty4, binding14, null);
			image4.Margin = new Thickness(0.0, 0.0, 6.0, 0.0);
			context.PopParent();
			supportInitialize22.EndInit();
			AvaloniaList<Control> children12 = grid13.Children;
			TextBlock textBlock2;
			TextBlock textBlock = textBlock2 = new TextBlock();
			((ISupportInitialize)textBlock).BeginInit();
			children12.Add(textBlock);
			TextBlock textBlock3;
			ISupportInitialize supportInitialize23 = textBlock3 = textBlock2;
			context.PushParent(textBlock3);
			TextBlock textBlock4 = textBlock3;
			Grid.SetColumn(textBlock4, 1);
			textBlock4.FontSize = 12.5;
			StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider5 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj3 = staticResourceExtension3.ProvideValue(serviceProvider5);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock4, obj3);
			AvaloniaProperty textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillText!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider13 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding15 = compiledBindingExtension13.ProvideValue(provider13);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(textProperty, binding15, null);
			textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock4.VerticalAlignment = VerticalAlignment.Center;
			textBlock4.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock4.Opacity = 0.85;
			context.PopParent();
			supportInitialize23.EndInit();
			AvaloniaList<Control> children13 = grid13.Children;
			Viewbox viewbox12;
			Viewbox viewbox11 = viewbox12 = new Viewbox();
			((ISupportInitialize)viewbox11).BeginInit();
			children13.Add(viewbox11);
			ISupportInitialize supportInitialize24 = viewbox3 = viewbox12;
			context.PushParent(viewbox3);
			Viewbox viewbox13 = viewbox3;
			Grid.SetColumn(viewbox13, 2);
			viewbox13.HorizontalAlignment = HorizontalAlignment.Right;
			viewbox13.VerticalAlignment = VerticalAlignment.Center;
			viewbox13.Width = 7.0;
			viewbox13.Height = 4.0;
			viewbox13.Margin = new Thickness(6.0, 0.0, 0.0, 0.0);
			AvaloniaProperty isVisibleProperty5 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NetworkPillHasDropdown!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider14 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding16 = compiledBindingExtension14.ProvideValue(provider14);
			context.ProvideTargetProperty = null;
			viewbox13.Bind(isVisibleProperty5, binding16, null);
			Path path12;
			Path path11 = path12 = new Path();
			((ISupportInitialize)path11).BeginInit();
			viewbox13.Child = path11;
			ISupportInitialize supportInitialize25 = path3 = path12;
			context.PushParent(path3);
			Path path13 = path3;
			StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("PointDownFullArrow");
			IServiceProvider serviceProvider6 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj4 = staticResourceExtension4.ProvideValue(serviceProvider6);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_2(path13, obj4);
			path13.Stretch = Stretch.Uniform;
			path13.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			path13.Opacity = 0.4;
			context.PopParent();
			supportInitialize25.EndInit();
			context.PopParent();
			supportInitialize24.EndInit();
			context.PopParent();
			supportInitialize21.EndInit();
			context.PopParent();
			supportInitialize20.EndInit();
			context.PopParent();
			supportInitialize19.EndInit();
			AvaloniaList<Control> children14 = stackPanel10.Children;
			Grid grid15;
			Grid grid14 = grid15 = new Grid();
			((ISupportInitialize)grid14).BeginInit();
			children14.Add(grid14);
			ISupportInitialize supportInitialize26 = grid3 = grid15;
			context.PushParent(grid3);
			Grid grid16 = grid3;
			ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
			columnDefinitions2.Capacity = 2;
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid16.ColumnDefinitions = columnDefinitions2;
			grid16.HorizontalAlignment = HorizontalAlignment.Center;
			grid16.Margin = new Thickness(0.0, 0.0, 0.0, -5.0);
			AvaloniaList<Control> children15 = grid16.Children;
			TextBlock textBlock6;
			TextBlock textBlock5 = textBlock6 = new TextBlock();
			((ISupportInitialize)textBlock5).BeginInit();
			children15.Add(textBlock5);
			ISupportInitialize supportInitialize27 = textBlock3 = textBlock6;
			context.PushParent(textBlock3);
			TextBlock textBlock7 = textBlock3;
			Grid.SetColumn(textBlock7, 0);
			textBlock7.FontSize = 64.0;
			StaticResourceExtension staticResourceExtension5 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider7 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj5 = staticResourceExtension5.ProvideValue(serviceProvider7);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock7, obj5);
			textBlock7.FontWeight = FontWeight.Light;
			AvaloniaProperty textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.FormattedBalance!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider15 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding17 = compiledBindingExtension15.ProvideValue(provider15);
			context.ProvideTargetProperty = null;
			textBlock7.Bind(textProperty2, binding17, null);
			AvaloniaProperty foregroundProperty = TextBlock.ForegroundProperty;
			CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider16 = context;
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			IBinding binding18 = compiledBindingExtension16.ProvideValue(provider16);
			context.ProvideTargetProperty = null;
			textBlock7.Bind(foregroundProperty, binding18, null);
			textBlock7.Margin = new Thickness(0.0, 0.0, 2.0, 0.0);
			context.PopParent();
			supportInitialize27.EndInit();
			AvaloniaList<Control> children16 = grid16.Children;
			TextBlock textBlock9;
			TextBlock textBlock8 = textBlock9 = new TextBlock();
			((ISupportInitialize)textBlock8).BeginInit();
			children16.Add(textBlock8);
			ISupportInitialize supportInitialize28 = textBlock3 = textBlock9;
			context.PushParent(textBlock3);
			TextBlock textBlock10 = textBlock3;
			Grid.SetColumn(textBlock10, 1);
			textBlock10.FontSize = 32.0;
			textBlock10.Margin = new Thickness(0.0, -46.0, 0.0, 0.0);
			AvaloniaProperty foregroundProperty2 = TextBlock.ForegroundProperty;
			CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider17 = context;
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			IBinding binding19 = compiledBindingExtension17.ProvideValue(provider17);
			context.ProvideTargetProperty = null;
			textBlock10.Bind(foregroundProperty2, binding19, null);
			textBlock10.VerticalAlignment = VerticalAlignment.Bottom;
			StaticResourceExtension staticResourceExtension6 = new StaticResourceExtension("RobotoCondensedLight");
			IServiceProvider serviceProvider8 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj6 = staticResourceExtension6.ProvideValue(serviceProvider8);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock10, obj6);
			textBlock10.FontWeight = FontWeight.Thin;
			AvaloniaProperty textProperty3 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.MyCoin!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.Symbol!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider18 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding20 = compiledBindingExtension18.ProvideValue(provider18);
			context.ProvideTargetProperty = null;
			textBlock10.Bind(textProperty3, binding20, null);
			textBlock10.LetterSpacing = 1.0;
			context.PopParent();
			supportInitialize28.EndInit();
			context.PopParent();
			supportInitialize26.EndInit();
			AvaloniaList<Control> children17 = stackPanel10.Children;
			Grid grid18;
			Grid grid17 = grid18 = new Grid();
			((ISupportInitialize)grid17).BeginInit();
			children17.Add(grid17);
			ISupportInitialize supportInitialize29 = grid3 = grid18;
			context.PushParent(grid3);
			Grid grid19 = grid3;
			ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
			columnDefinitions3.Capacity = 2;
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid19.ColumnDefinitions = columnDefinitions3;
			grid19.HorizontalAlignment = HorizontalAlignment.Center;
			AvaloniaList<Control> children18 = grid19.Children;
			TextBlock textBlock12;
			TextBlock textBlock11 = textBlock12 = new TextBlock();
			((ISupportInitialize)textBlock11).BeginInit();
			children18.Add(textBlock11);
			ISupportInitialize supportInitialize30 = textBlock3 = textBlock12;
			context.PushParent(textBlock3);
			TextBlock textBlock13 = textBlock3;
			Grid.SetColumn(textBlock13, 0);
			textBlock13.FontSize = 18.2;
			StaticResourceExtension staticResourceExtension7 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider9 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj7 = staticResourceExtension7.ProvideValue(serviceProvider9);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock13, obj7);
			textBlock13.FontWeight = FontWeight.Light;
			textBlock13.Opacity = 0.5;
			textBlock13.Text = "$";
			textBlock13.VerticalAlignment = VerticalAlignment.Bottom;
			textBlock13.Margin = new Thickness(0.0, -24.0, 0.5, 0.0);
			context.PopParent();
			supportInitialize30.EndInit();
			AvaloniaList<Control> children19 = grid19.Children;
			TextBlock textBlock15;
			TextBlock textBlock14 = textBlock15 = new TextBlock();
			((ISupportInitialize)textBlock14).BeginInit();
			children19.Add(textBlock14);
			ISupportInitialize supportInitialize31 = textBlock3 = textBlock15;
			context.PushParent(textBlock3);
			TextBlock textBlock16 = textBlock3;
			Grid.SetColumn(textBlock16, 1);
			textBlock16.FontSize = 26.0;
			StaticResourceExtension staticResourceExtension8 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider10 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj8 = staticResourceExtension8.ProvideValue(serviceProvider10);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock16, obj8);
			textBlock16.FontWeight = FontWeight.Light;
			AvaloniaProperty textProperty4 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.BalanceInUsdString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider19 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding21 = compiledBindingExtension19.ProvideValue(provider19);
			context.ProvideTargetProperty = null;
			textBlock16.Bind(textProperty4, binding21, null);
			textBlock16.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			supportInitialize31.EndInit();
			context.PopParent();
			supportInitialize29.EndInit();
			context.PopParent();
			supportInitialize11.EndInit();
			context.PopParent();
			supportInitialize3.EndInit();
			AvaloniaList<Control> children20 = stackPanel4.Children;
			Grid grid21;
			Grid grid20 = grid21 = new Grid();
			((ISupportInitialize)grid20).BeginInit();
			children20.Add(grid20);
			ISupportInitialize supportInitialize32 = grid3 = grid21;
			context.PushParent(grid3);
			Grid grid22 = grid3;
			ColumnDefinitions columnDefinitions4 = new ColumnDefinitions();
			columnDefinitions4.Capacity = 2;
			columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions4.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid22.ColumnDefinitions = columnDefinitions4;
			grid22.HorizontalAlignment = HorizontalAlignment.Center;
			grid22.Margin = new Thickness(62.0, 3.0, 0.0, 0.0);
			AvaloniaList<Control> children21 = grid22.Children;
			Grid grid24;
			Grid grid23 = grid24 = new Grid();
			((ISupportInitialize)grid23).BeginInit();
			children21.Add(grid23);
			ISupportInitialize supportInitialize33 = grid3 = grid24;
			context.PushParent(grid3);
			Grid grid25 = grid3;
			Grid.SetColumn(grid25, 0);
			ColumnDefinitions columnDefinitions5 = new ColumnDefinitions();
			columnDefinitions5.Capacity = 2;
			columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid25.ColumnDefinitions = columnDefinitions5;
			AvaloniaList<Control> children22 = grid25.Children;
			Button button15;
			Button button14 = button15 = new Button();
			((ISupportInitialize)button14).BeginInit();
			children22.Add(button14);
			ISupportInitialize supportInitialize34 = button3 = button15;
			context.PushParent(button3);
			Button button16 = button3;
			Grid.SetColumn(button16, 0);
			button16.Background = new ImmutableSolidColorBrush(16777215U);
			Border border9;
			Border border8 = border9 = new Border();
			((ISupportInitialize)border8).BeginInit();
			button16.Content = border8;
			ISupportInitialize supportInitialize35 = border3 = border9;
			context.PushParent(border3);
			Border border10 = border3;
			border10.Height = 44.0;
			border10.Width = 237.0;
			border10.CornerRadius = new CornerRadius(30.0, 30.0, 30.0, 30.0);
			border10.BorderThickness = new Thickness(2.0, 2.0, 2.0, 2.0);
			AvaloniaProperty borderBrushProperty = Border.BorderBrushProperty;
			CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider20 = context;
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			IBinding binding22 = compiledBindingExtension20.ProvideValue(provider20);
			context.ProvideTargetProperty = null;
			border10.Bind(borderBrushProperty, binding22, null);
			TextBlock textBlock18;
			TextBlock textBlock17 = textBlock18 = new TextBlock();
			((ISupportInitialize)textBlock17).BeginInit();
			border10.Child = textBlock17;
			ISupportInitialize supportInitialize36 = textBlock3 = textBlock18;
			context.PushParent(textBlock3);
			TextBlock textBlock19 = textBlock3;
			textBlock19.FontSize = 16.0;
			StaticResourceExtension staticResourceExtension9 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider11 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj9 = staticResourceExtension9.ProvideValue(serviceProvider11);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock19, obj9);
			textBlock19.FontWeight = FontWeight.Normal;
			textBlock19.Text = "Send";
			textBlock19.VerticalAlignment = VerticalAlignment.Center;
			textBlock19.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize36.EndInit();
			context.PopParent();
			supportInitialize35.EndInit();
			context.PopParent();
			supportInitialize34.EndInit();
			AvaloniaList<Control> children23 = grid25.Children;
			Button button18;
			Button button17 = button18 = new Button();
			((ISupportInitialize)button17).BeginInit();
			children23.Add(button17);
			ISupportInitialize supportInitialize37 = button3 = button18;
			context.PushParent(button3);
			Button button19 = button3;
			Grid.SetColumn(button19, 1);
			button19.Background = new ImmutableSolidColorBrush(16777215U);
			AvaloniaProperty commandProperty2 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("ReceiveCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.CoinSpecificPartViewModel+ReceiveCommand_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider21 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding23 = compiledBindingExtension21.ProvideValue(provider21);
			context.ProvideTargetProperty = null;
			button19.Bind(commandProperty2, binding23, null);
			Border border12;
			Border border11 = border12 = new Border();
			((ISupportInitialize)border11).BeginInit();
			button19.Content = border11;
			ISupportInitialize supportInitialize38 = border3 = border12;
			context.PushParent(border3);
			Border border13 = border3;
			border13.Height = 44.0;
			border13.Width = 237.0;
			border13.CornerRadius = new CornerRadius(30.0, 30.0, 30.0, 30.0);
			border13.BorderThickness = new Thickness(2.0, 2.0, 2.0, 2.0);
			AvaloniaProperty borderBrushProperty2 = Border.BorderBrushProperty;
			CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider22 = context;
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			IBinding binding24 = compiledBindingExtension22.ProvideValue(provider22);
			context.ProvideTargetProperty = null;
			border13.Bind(borderBrushProperty2, binding24, null);
			TextBlock textBlock21;
			TextBlock textBlock20 = textBlock21 = new TextBlock();
			((ISupportInitialize)textBlock20).BeginInit();
			border13.Child = textBlock20;
			ISupportInitialize supportInitialize39 = textBlock3 = textBlock21;
			context.PushParent(textBlock3);
			TextBlock textBlock22 = textBlock3;
			textBlock22.FontSize = 16.0;
			StaticResourceExtension staticResourceExtension10 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider12 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj10 = staticResourceExtension10.ProvideValue(serviceProvider12);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock22, obj10);
			textBlock22.FontWeight = FontWeight.Normal;
			textBlock22.Text = "Receive";
			textBlock22.VerticalAlignment = VerticalAlignment.Center;
			textBlock22.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize39.EndInit();
			context.PopParent();
			supportInitialize38.EndInit();
			context.PopParent();
			supportInitialize37.EndInit();
			context.PopParent();
			supportInitialize33.EndInit();
			AvaloniaList<Control> children24 = grid22.Children;
			Button button21;
			Button button20 = button21 = new Button();
			((ISupportInitialize)button20).BeginInit();
			children24.Add(button20);
			ISupportInitialize supportInitialize40 = button3 = button21;
			context.PushParent(button3);
			Button button22 = button3;
			Grid.SetColumn(button22, 1);
			button22.Background = new ImmutableSolidColorBrush(16777215U);
			Border border15;
			Border border14 = border15 = new Border();
			((ISupportInitialize)border14).BeginInit();
			button22.Content = border14;
			ISupportInitialize supportInitialize41 = border3 = border15;
			context.PushParent(border3);
			Border border16 = border3;
			border16.Height = 48.0;
			border16.Width = 48.0;
			border16.CornerRadius = new CornerRadius(100.0, 100.0, 100.0, 100.0);
			AvaloniaProperty backgroundProperty2 = Border.BackgroundProperty;
			CompiledBindingExtension compiledBindingExtension23 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground2!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider23 = context;
			context.ProvideTargetProperty = Border.BackgroundProperty;
			IBinding binding25 = compiledBindingExtension23.ProvideValue(provider23);
			context.ProvideTargetProperty = null;
			border16.Bind(backgroundProperty2, binding25, null);
			Viewbox viewbox15;
			Viewbox viewbox14 = viewbox15 = new Viewbox();
			((ISupportInitialize)viewbox14).BeginInit();
			border16.Child = viewbox14;
			ISupportInitialize supportInitialize42 = viewbox3 = viewbox15;
			context.PushParent(viewbox3);
			Viewbox viewbox16 = viewbox3;
			viewbox16.Width = 20.0;
			viewbox16.HorizontalAlignment = HorizontalAlignment.Center;
			viewbox16.VerticalAlignment = VerticalAlignment.Center;
			Path path15;
			Path path14 = path15 = new Path();
			((ISupportInitialize)path14).BeginInit();
			viewbox16.Child = path14;
			ISupportInitialize supportInitialize43 = path3 = path15;
			context.PushParent(path3);
			Path path16 = path3;
			StaticResourceExtension staticResourceExtension11 = new StaticResourceExtension("Exchange");
			IServiceProvider serviceProvider13 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj11 = staticResourceExtension11.ProvideValue(serviceProvider13);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_2(path16, obj11);
			path16.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			path16.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize43.EndInit();
			context.PopParent();
			supportInitialize42.EndInit();
			context.PopParent();
			supportInitialize41.EndInit();
			context.PopParent();
			supportInitialize40.EndInit();
			context.PopParent();
			supportInitialize32.EndInit();
			AvaloniaList<Control> children25 = stackPanel4.Children;
			Grid grid27;
			Grid grid26 = grid27 = new Grid();
			((ISupportInitialize)grid26).BeginInit();
			children25.Add(grid26);
			ISupportInitialize supportInitialize44 = grid3 = grid27;
			context.PushParent(grid3);
			Grid grid28 = grid3;
			AvaloniaProperty isVisibleProperty6 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension24 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider24 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding26 = compiledBindingExtension24.ProvideValue(provider24);
			context.ProvideTargetProperty = null;
			grid28.Bind(isVisibleProperty6, binding26, null);
			AvaloniaList<Control> children26 = grid28.Children;
			Border border18;
			Border border17 = border18 = new Border();
			((ISupportInitialize)border17).BeginInit();
			children26.Add(border17);
			ISupportInitialize supportInitialize45 = border3 = border18;
			context.PushParent(border3);
			Border border19 = border3;
			border19.CornerRadius = new CornerRadius(0.0, 0.0, 12.0, 12.0);
			border19.HorizontalAlignment = HorizontalAlignment.Center;
			border19.Background = new ImmutableSolidColorBrush(4279046418U);
			border19.Width = 770.0;
			border19.Height = 108.0;
			border19.Margin = new Thickness(0.0, 18.0, 0.0, 10.0);
			AvaloniaProperty isVisibleProperty7 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension25 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsTherePendingTransaction!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider25 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding27 = compiledBindingExtension25.ProvideValue(provider25);
			context.ProvideTargetProperty = null;
			border19.Bind(isVisibleProperty7, binding27, null);
			Grid grid30;
			Grid grid29 = grid30 = new Grid();
			((ISupportInitialize)grid29).BeginInit();
			border19.Child = grid29;
			ISupportInitialize supportInitialize46 = grid3 = grid30;
			context.PushParent(grid3);
			Grid grid31 = grid3;
			RowDefinitions rowDefinitions = new RowDefinitions();
			rowDefinitions.Capacity = 2;
			rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid31.RowDefinitions = rowDefinitions;
			AvaloniaList<Control> children27 = grid31.Children;
			Border border21;
			Border border20 = border21 = new Border();
			((ISupportInitialize)border20).BeginInit();
			children27.Add(border20);
			Border border22 = border21;
			Grid.SetRow(border22, 0);
			border22.Height = 3.0;
			border22.HorizontalAlignment = HorizontalAlignment.Stretch;
			border22.Background = new LinearGradientBrush
			{
				StartPoint = new RelativePoint(0.0, 0.5, RelativeUnit.Relative),
				EndPoint = new RelativePoint(1.0, 0.5, RelativeUnit.Relative),
				GradientStops = 
				{
					new GradientStop
					{
						Color = Color.FromUInt32(4278239231U),
						Offset = 0.0
					},
					new GradientStop
					{
						Color = Color.FromUInt32(4284881407U),
						Offset = 1.0
					}
				}
			};
			((ISupportInitialize)border22).EndInit();
			AvaloniaList<Control> children28 = grid31.Children;
			Grid grid33;
			Grid grid32 = grid33 = new Grid();
			((ISupportInitialize)grid32).BeginInit();
			children28.Add(grid32);
			ISupportInitialize supportInitialize47 = grid3 = grid33;
			context.PushParent(grid3);
			Grid grid34 = grid3;
			Grid.SetRow(grid34, 1);
			grid34.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
			ColumnDefinitions columnDefinitions6 = new ColumnDefinitions();
			columnDefinitions6.Capacity = 3;
			columnDefinitions6.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions6.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions6.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid34.ColumnDefinitions = columnDefinitions6;
			AvaloniaList<Control> children29 = grid34.Children;
			Image image6;
			Image image5 = image6 = new Image();
			((ISupportInitialize)image5).BeginInit();
			children29.Add(image5);
			ISupportInitialize supportInitialize48 = image3 = image6;
			context.PushParent(image3);
			Image image7 = image3;
			Grid.SetColumn(image7, 0);
			image7.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/icon-graph.png");
			RenderOptions.SetBitmapInterpolationMode(image7, BitmapInterpolationMode.HighQuality);
			image7.Height = 80.0;
			image7.Stretch = Stretch.Uniform;
			image7.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			supportInitialize48.EndInit();
			AvaloniaList<Control> children30 = grid34.Children;
			WrapPanel wrapPanel2;
			WrapPanel wrapPanel = wrapPanel2 = new WrapPanel();
			((ISupportInitialize)wrapPanel).BeginInit();
			children30.Add(wrapPanel);
			WrapPanel wrapPanel3;
			ISupportInitialize supportInitialize49 = wrapPanel3 = wrapPanel2;
			context.PushParent(wrapPanel3);
			WrapPanel wrapPanel4 = wrapPanel3;
			Grid.SetColumn(wrapPanel4, 1);
			wrapPanel4.HorizontalAlignment = HorizontalAlignment.Stretch;
			wrapPanel4.VerticalAlignment = VerticalAlignment.Center;
			wrapPanel4.Margin = new Thickness(-4.0, 0.0, 0.0, 0.0);
			AvaloniaList<Control> children31 = wrapPanel4.Children;
			TextBlock textBlock24;
			TextBlock textBlock23 = textBlock24 = new TextBlock();
			((ISupportInitialize)textBlock23).BeginInit();
			children31.Add(textBlock23);
			ISupportInitialize supportInitialize50 = textBlock3 = textBlock24;
			context.PushParent(textBlock3);
			TextBlock textBlock25 = textBlock3;
			textBlock25.FontSize = 16.0;
			StaticResourceExtension staticResourceExtension12 = new StaticResourceExtension("RobotoCondensedSemiBold");
			IServiceProvider serviceProvider14 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj12 = staticResourceExtension12.ProvideValue(serviceProvider14);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock25, obj12);
			AvaloniaProperty textProperty5 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension26 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TotalInPending!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider26 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding28 = compiledBindingExtension26.ProvideValue(provider26);
			context.ProvideTargetProperty = null;
			textBlock25.Bind(textProperty5, binding28, null);
			textBlock25.VerticalAlignment = VerticalAlignment.Center;
			textBlock25.FontWeight = FontWeight.Normal;
			textBlock25.Margin = new Thickness(0.0, 0.0, 3.0, 0.0);
			textBlock25.HorizontalAlignment = HorizontalAlignment.Left;
			textBlock25.TextAlignment = TextAlignment.Left;
			context.PopParent();
			supportInitialize50.EndInit();
			AvaloniaList<Control> children32 = wrapPanel4.Children;
			TextBlock textBlock27;
			TextBlock textBlock26 = textBlock27 = new TextBlock();
			((ISupportInitialize)textBlock26).BeginInit();
			children32.Add(textBlock26);
			ISupportInitialize supportInitialize51 = textBlock3 = textBlock27;
			context.PushParent(textBlock3);
			TextBlock textBlock28 = textBlock3;
			textBlock28.FontSize = 14.0;
			StaticResourceExtension staticResourceExtension13 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider15 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj13 = staticResourceExtension13.ProvideValue(serviceProvider15);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock28, obj13);
			textBlock28.Text = "is pending confirmation and can't be sent.";
			textBlock28.VerticalAlignment = VerticalAlignment.Center;
			textBlock28.FontWeight = FontWeight.Light;
			textBlock28.HorizontalAlignment = HorizontalAlignment.Left;
			textBlock28.Opacity = 0.8;
			textBlock28.TextAlignment = TextAlignment.Left;
			context.PopParent();
			supportInitialize51.EndInit();
			context.PopParent();
			supportInitialize49.EndInit();
			AvaloniaList<Control> children33 = grid34.Children;
			Button button24;
			Button button23 = button24 = new Button();
			((ISupportInitialize)button23).BeginInit();
			children33.Add(button23);
			ISupportInitialize supportInitialize52 = button3 = button24;
			context.PushParent(button3);
			Button button25 = button3;
			Grid.SetColumn(button25, 2);
			button25.Background = new ImmutableSolidColorBrush(16777215U);
			button25.Margin = new Thickness(0.0, 0.0, 5.0, 0.0);
			Border border24;
			Border border23 = border24 = new Border();
			((ISupportInitialize)border23).BeginInit();
			button25.Content = border23;
			ISupportInitialize supportInitialize53 = border3 = border24;
			context.PushParent(border3);
			Border border25 = border3;
			border25.Height = 40.0;
			border25.Width = 150.0;
			border25.CornerRadius = new CornerRadius(23.0, 23.0, 23.0, 23.0);
			border25.Background = new LinearGradientBrush
			{
				StartPoint = new RelativePoint(0.0, 0.5, RelativeUnit.Relative),
				EndPoint = new RelativePoint(1.0, 0.5, RelativeUnit.Relative),
				GradientStops = 
				{
					new GradientStop
					{
						Color = Color.FromUInt32(4279967263U),
						Offset = 0.0
					},
					new GradientStop
					{
						Color = Color.FromUInt32(4280625193U),
						Offset = 1.0
					}
				}
			};
			TextBlock textBlock30;
			TextBlock textBlock29 = textBlock30 = new TextBlock();
			((ISupportInitialize)textBlock29).BeginInit();
			border25.Child = textBlock29;
			ISupportInitialize supportInitialize54 = textBlock3 = textBlock30;
			context.PushParent(textBlock3);
			TextBlock textBlock31 = textBlock3;
			textBlock31.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension14 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider16 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj14 = staticResourceExtension14.ProvideValue(serviceProvider16);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock31, obj14);
			textBlock31.Text = "LEARN MORE";
			textBlock31.VerticalAlignment = VerticalAlignment.Center;
			textBlock31.FontWeight = FontWeight.Normal;
			textBlock31.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock31.TextAlignment = TextAlignment.Center;
			context.PopParent();
			supportInitialize54.EndInit();
			context.PopParent();
			supportInitialize53.EndInit();
			context.PopParent();
			supportInitialize52.EndInit();
			context.PopParent();
			supportInitialize47.EndInit();
			context.PopParent();
			supportInitialize46.EndInit();
			context.PopParent();
			supportInitialize45.EndInit();
			context.PopParent();
			supportInitialize44.EndInit();
			AvaloniaList<Control> children34 = stackPanel4.Children;
			Grid grid36;
			Grid grid35 = grid36 = new Grid();
			((ISupportInitialize)grid35).BeginInit();
			children34.Add(grid35);
			ISupportInitialize supportInitialize55 = grid3 = grid36;
			context.PushParent(grid3);
			Grid grid37 = grid3;
			grid37.Height = 55.0;
			RowDefinitions rowDefinitions2 = new RowDefinitions();
			rowDefinitions2.Capacity = 2;
			rowDefinitions2.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid37.RowDefinitions = rowDefinitions2;
			grid37.Margin = new Thickness(18.0, 30.0, 18.0, 30.0);
			AvaloniaList<Control> children35 = grid37.Children;
			Grid grid39;
			Grid grid38 = grid39 = new Grid();
			((ISupportInitialize)grid38).BeginInit();
			children35.Add(grid38);
			ISupportInitialize supportInitialize56 = grid3 = grid39;
			context.PushParent(grid3);
			Grid grid40 = grid3;
			Grid.SetRow(grid40, 0);
			ColumnDefinitions columnDefinitions7 = new ColumnDefinitions();
			columnDefinitions7.Capacity = 2;
			columnDefinitions7.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions7.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid40.ColumnDefinitions = columnDefinitions7;
			grid40.Margin = new Thickness(7.0, 0.0, 7.0, 0.0);
			AvaloniaList<Control> children36 = grid40.Children;
			TextBlock textBlock33;
			TextBlock textBlock32 = textBlock33 = new TextBlock();
			((ISupportInitialize)textBlock32).BeginInit();
			children36.Add(textBlock32);
			ISupportInitialize supportInitialize57 = textBlock3 = textBlock33;
			context.PushParent(textBlock3);
			TextBlock textBlock34 = textBlock3;
			Grid.SetColumn(textBlock34, 0);
			textBlock34.FontSize = 14.0;
			textBlock34.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
			StaticResourceExtension staticResourceExtension15 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider17 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj15 = staticResourceExtension15.ProvideValue(serviceProvider17);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock34, obj15);
			textBlock34.Text = "PRICE CHART";
			textBlock34.VerticalAlignment = VerticalAlignment.Center;
			textBlock34.LetterSpacing = 2.3;
			textBlock34.HorizontalAlignment = HorizontalAlignment.Left;
			textBlock34.FontWeight = FontWeight.Light;
			textBlock34.TextAlignment = TextAlignment.Left;
			Styles styles = textBlock34.Styles;
			Style style = new Style();
			style.Selector = Selectors.OfType((Selector)null, typeof(TextBlock));
			style.Add(new Setter
			{
				Property = Visual.OpacityProperty,
				Value = 0.2
			});
			styles.Add(style);
			Styles styles2 = textBlock34.Styles;
			Style style2 = new Style();
			style2.Selector = Selectors.OfType((Selector)null, typeof(TextBlock)).Class(":pointerover");
			style2.Add(new Setter
			{
				Property = Visual.OpacityProperty,
				Value = 0.9
			});
			styles2.Add(style2);
			context.PopParent();
			supportInitialize57.EndInit();
			AvaloniaList<Control> children37 = grid40.Children;
			Button button27;
			Button button26 = button27 = new Button();
			((ISupportInitialize)button26).BeginInit();
			children37.Add(button26);
			ISupportInitialize supportInitialize58 = button3 = button27;
			context.PushParent(button3);
			Button button28 = button3;
			Grid.SetColumn(button28, 1);
			button28.Background = new ImmutableSolidColorBrush(16777215U);
			button28.VerticalAlignment = VerticalAlignment.Center;
			Viewbox viewbox18;
			Viewbox viewbox17 = viewbox18 = new Viewbox();
			((ISupportInitialize)viewbox17).BeginInit();
			button28.Content = viewbox17;
			ISupportInitialize supportInitialize59 = viewbox3 = viewbox18;
			context.PushParent(viewbox3);
			Viewbox viewbox19 = viewbox3;
			viewbox19.Width = 14.0;
			Path path18;
			Path path17 = path18 = new Path();
			((ISupportInitialize)path17).BeginInit();
			viewbox19.Child = path17;
			ISupportInitialize supportInitialize60 = path3 = path18;
			context.PushParent(path3);
			Path path19 = path3;
			StaticResourceExtension staticResourceExtension16 = new StaticResourceExtension("Expand");
			IServiceProvider serviceProvider18 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj16 = staticResourceExtension16.ProvideValue(serviceProvider18);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_2(path19, obj16);
			path19.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			path19.Opacity = 0.8;
			path19.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize60.EndInit();
			context.PopParent();
			supportInitialize59.EndInit();
			context.PopParent();
			supportInitialize58.EndInit();
			context.PopParent();
			supportInitialize56.EndInit();
			AvaloniaList<Control> children38 = grid37.Children;
			Border border27;
			Border border26 = border27 = new Border();
			((ISupportInitialize)border26).BeginInit();
			children38.Add(border26);
			Border border28 = border27;
			Grid.SetRow(border28, 1);
			border28.HorizontalAlignment = HorizontalAlignment.Stretch;
			border28.Height = 1.0;
			border28.Background = new ImmutableSolidColorBrush(uint.MaxValue);
			border28.CornerRadius = new CornerRadius(3.0, 3.0, 3.0, 3.0);
			border28.Opacity = 0.1;
			((ISupportInitialize)border28).EndInit();
			context.PopParent();
			supportInitialize55.EndInit();
			AvaloniaList<Control> children39 = stackPanel4.Children;
			Grid grid42;
			Grid grid41 = grid42 = new Grid();
			((ISupportInitialize)grid41).BeginInit();
			children39.Add(grid41);
			ISupportInitialize supportInitialize61 = grid3 = grid42;
			context.PushParent(grid3);
			Grid grid43 = grid3;
			grid43.HorizontalAlignment = HorizontalAlignment.Stretch;
			grid43.Margin = new Thickness(18.0, 0.0, 18.0, 12.0);
			RowDefinitions rowDefinitions3 = new RowDefinitions();
			rowDefinitions3.Capacity = 3;
			rowDefinitions3.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions3.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions3.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid43.RowDefinitions = rowDefinitions3;
			AvaloniaList<Control> children40 = grid43.Children;
			StackPanel stackPanel12;
			StackPanel stackPanel11 = stackPanel12 = new StackPanel();
			((ISupportInitialize)stackPanel11).BeginInit();
			children40.Add(stackPanel11);
			ISupportInitialize supportInitialize62 = stackPanel3 = stackPanel12;
			context.PushParent(stackPanel3);
			StackPanel stackPanel13 = stackPanel3;
			Grid.SetRow(stackPanel13, 0);
			stackPanel13.Margin = new Thickness(10.0, 0.0, 0.0, 10.0);
			stackPanel13.Orientation = Orientation.Horizontal;
			AvaloniaList<Control> children41 = stackPanel13.Children;
			Button button30;
			Button button29 = button30 = new Button();
			((ISupportInitialize)button29).BeginInit();
			children41.Add(button29);
			ISupportInitialize supportInitialize63 = button3 = button30;
			context.PushParent(button3);
			Button button31 = button3;
			button31.Margin = new Thickness(3.0, 0.0, 3.0, 0.0);
			button31.Background = new ImmutableSolidColorBrush(16777215U);
			TextBlock textBlock36;
			TextBlock textBlock35 = textBlock36 = new TextBlock();
			((ISupportInitialize)textBlock35).BeginInit();
			button31.Content = textBlock35;
			ISupportInitialize supportInitialize64 = textBlock3 = textBlock36;
			context.PushParent(textBlock3);
			TextBlock textBlock37 = textBlock3;
			textBlock37.FontSize = 14.0;
			StaticResourceExtension staticResourceExtension17 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider19 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj17 = staticResourceExtension17.ProvideValue(serviceProvider19);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock37, obj17);
			textBlock37.Text = "ACTIVITY";
			textBlock37.VerticalAlignment = VerticalAlignment.Center;
			textBlock37.LetterSpacing = 1.0;
			textBlock37.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock37.FontWeight = FontWeight.Medium;
			textBlock37.TextAlignment = TextAlignment.Center;
			context.PopParent();
			supportInitialize64.EndInit();
			context.PopParent();
			supportInitialize63.EndInit();
			AvaloniaList<Control> children42 = stackPanel13.Children;
			Button button33;
			Button button32 = button33 = new Button();
			((ISupportInitialize)button32).BeginInit();
			children42.Add(button32);
			ISupportInitialize supportInitialize65 = button3 = button33;
			context.PushParent(button3);
			Button button34 = button3;
			button34.Margin = new Thickness(3.0, 0.0, 3.0, 0.0);
			button34.Background = new ImmutableSolidColorBrush(16777215U);
			TextBlock textBlock39;
			TextBlock textBlock38 = textBlock39 = new TextBlock();
			((ISupportInitialize)textBlock38).BeginInit();
			button34.Content = textBlock38;
			ISupportInitialize supportInitialize66 = textBlock3 = textBlock39;
			context.PushParent(textBlock3);
			TextBlock textBlock40 = textBlock3;
			textBlock40.FontSize = 14.0;
			StaticResourceExtension staticResourceExtension18 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider20 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj18 = staticResourceExtension18.ProvideValue(serviceProvider20);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock40, obj18);
			textBlock40.Text = "ABOUT";
			textBlock40.VerticalAlignment = VerticalAlignment.Center;
			textBlock40.Opacity = 0.3;
			textBlock40.FontWeight = FontWeight.Medium;
			textBlock40.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock40.LetterSpacing = 1.0;
			textBlock40.TextAlignment = TextAlignment.Center;
			context.PopParent();
			supportInitialize66.EndInit();
			context.PopParent();
			supportInitialize65.EndInit();
			AvaloniaList<Control> children43 = stackPanel13.Children;
			Button button36;
			Button button35 = button36 = new Button();
			((ISupportInitialize)button35).BeginInit();
			children43.Add(button35);
			ISupportInitialize supportInitialize67 = button3 = button36;
			context.PushParent(button3);
			Button button37 = button3;
			button37.Margin = new Thickness(3.0, 0.0, 3.0, 0.0);
			button37.Background = new ImmutableSolidColorBrush(16777215U);
			TextBlock textBlock42;
			TextBlock textBlock41 = textBlock42 = new TextBlock();
			((ISupportInitialize)textBlock41).BeginInit();
			button37.Content = textBlock41;
			ISupportInitialize supportInitialize68 = textBlock3 = textBlock42;
			context.PushParent(textBlock3);
			TextBlock textBlock43 = textBlock3;
			textBlock43.FontSize = 14.0;
			StaticResourceExtension staticResourceExtension19 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider21 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj19 = staticResourceExtension19.ProvideValue(serviceProvider21);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock43, obj19);
			textBlock43.Text = "VIDEOS";
			textBlock43.VerticalAlignment = VerticalAlignment.Center;
			textBlock43.Opacity = 0.3;
			textBlock43.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock43.LetterSpacing = 1.0;
			textBlock43.FontWeight = FontWeight.Medium;
			textBlock43.TextAlignment = TextAlignment.Center;
			context.PopParent();
			supportInitialize68.EndInit();
			context.PopParent();
			supportInitialize67.EndInit();
			AvaloniaList<Control> children44 = stackPanel13.Children;
			Button button39;
			Button button38 = button39 = new Button();
			((ISupportInitialize)button38).BeginInit();
			children44.Add(button38);
			ISupportInitialize supportInitialize69 = button3 = button39;
			context.PushParent(button3);
			Button button40 = button3;
			button40.Margin = new Thickness(3.0, 0.0, 3.0, 0.0);
			button40.Background = new ImmutableSolidColorBrush(16777215U);
			TextBlock textBlock45;
			TextBlock textBlock44 = textBlock45 = new TextBlock();
			((ISupportInitialize)textBlock44).BeginInit();
			button40.Content = textBlock44;
			ISupportInitialize supportInitialize70 = textBlock3 = textBlock45;
			context.PushParent(textBlock3);
			TextBlock textBlock46 = textBlock3;
			textBlock46.FontSize = 14.0;
			StaticResourceExtension staticResourceExtension20 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider22 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj20 = staticResourceExtension20.ProvideValue(serviceProvider22);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock46, obj20);
			textBlock46.Text = "NEWS";
			textBlock46.VerticalAlignment = VerticalAlignment.Center;
			textBlock46.Opacity = 0.3;
			textBlock46.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock46.LetterSpacing = 1.0;
			textBlock46.FontWeight = FontWeight.Medium;
			textBlock46.TextAlignment = TextAlignment.Center;
			context.PopParent();
			supportInitialize70.EndInit();
			context.PopParent();
			supportInitialize69.EndInit();
			context.PopParent();
			supportInitialize62.EndInit();
			AvaloniaList<Control> children45 = grid43.Children;
			Border border30;
			Border border29 = border30 = new Border();
			((ISupportInitialize)border29).BeginInit();
			children45.Add(border29);
			Border border31 = border30;
			Grid.SetRow(border31, 1);
			border31.HorizontalAlignment = HorizontalAlignment.Stretch;
			border31.Height = 1.0;
			border31.Background = new ImmutableSolidColorBrush(uint.MaxValue);
			border31.CornerRadius = new CornerRadius(3.0, 3.0, 3.0, 3.0);
			border31.Opacity = 0.1;
			((ISupportInitialize)border31).EndInit();
			AvaloniaList<Control> children46 = grid43.Children;
			Border border33;
			Border border32 = border33 = new Border();
			((ISupportInitialize)border32).BeginInit();
			children46.Add(border32);
			Border border34 = border33;
			Grid.SetRow(border34, 1);
			border34.HorizontalAlignment = HorizontalAlignment.Left;
			border34.Height = 2.0;
			border34.Width = 60.0;
			border34.Background = new ImmutableSolidColorBrush(uint.MaxValue);
			border34.CornerRadius = new CornerRadius(3.0, 3.0, 3.0, 3.0);
			border34.Margin = new Thickness(20.0, 0.0, 0.0, 0.0);
			((ISupportInitialize)border34).EndInit();
			AvaloniaList<Control> children47 = grid43.Children;
			Grid grid45;
			Grid grid44 = grid45 = new Grid();
			((ISupportInitialize)grid44).BeginInit();
			children47.Add(grid44);
			ISupportInitialize supportInitialize71 = grid3 = grid45;
			context.PushParent(grid3);
			Grid grid46 = grid3;
			Grid.SetRow(grid46, 2);
			grid46.MinHeight = 250.0;
			RowDefinitions rowDefinitions4 = new RowDefinitions();
			rowDefinitions4.Capacity = 2;
			rowDefinitions4.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions4.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid46.RowDefinitions = rowDefinitions4;
			AvaloniaList<Control> children48 = grid46.Children;
			Grid grid48;
			Grid grid47 = grid48 = new Grid();
			((ISupportInitialize)grid47).BeginInit();
			children48.Add(grid47);
			ISupportInitialize supportInitialize72 = grid3 = grid48;
			context.PushParent(grid3);
			Grid grid49 = grid3;
			Grid.SetRow(grid49, 0);
			AvaloniaProperty isVisibleProperty8 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension27 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsShowGasWarning!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider27 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding29 = compiledBindingExtension27.ProvideValue(provider27);
			context.ProvideTargetProperty = null;
			grid49.Bind(isVisibleProperty8, binding29, null);
			AvaloniaList<Control> children49 = grid49.Children;
			Border border36;
			Border border35 = border36 = new Border();
			((ISupportInitialize)border35).BeginInit();
			children49.Add(border35);
			ISupportInitialize supportInitialize73 = border3 = border36;
			context.PushParent(border3);
			Border border37 = border3;
			border37.CornerRadius = new CornerRadius(12.0, 12.0, 12.0, 12.0);
			border37.HorizontalAlignment = HorizontalAlignment.Center;
			border37.Background = new ImmutableSolidColorBrush(4279046418U);
			border37.Width = 1090.0;
			border37.Height = 60.0;
			border37.Margin = new Thickness(0.0, 23.0, 0.0, 0.0);
			AvaloniaProperty isVisibleProperty9 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension28 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.MyCoin!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.IsEmpty!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider28 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding30 = compiledBindingExtension28.ProvideValue(provider28);
			context.ProvideTargetProperty = null;
			border37.Bind(isVisibleProperty9, binding30, null);
			Grid grid51;
			Grid grid50 = grid51 = new Grid();
			((ISupportInitialize)grid50).BeginInit();
			border37.Child = grid50;
			ISupportInitialize supportInitialize74 = grid3 = grid51;
			context.PushParent(grid3);
			Grid grid52 = grid3;
			ColumnDefinitions columnDefinitions8 = new ColumnDefinitions();
			columnDefinitions8.Capacity = 3;
			columnDefinitions8.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions8.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions8.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid52.ColumnDefinitions = columnDefinitions8;
			grid52.Margin = new Thickness(15.0, 0.0, 15.0, 0.0);
			AvaloniaList<Control> children50 = grid52.Children;
			Image image9;
			Image image8 = image9 = new Image();
			((ISupportInitialize)image8).BeginInit();
			children50.Add(image8);
			ISupportInitialize supportInitialize75 = image3 = image9;
			context.PushParent(image3);
			Image image10 = image3;
			Grid.SetColumn(image10, 0);
			image10.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/icon-low-gas.png");
			RenderOptions.SetBitmapInterpolationMode(image10, BitmapInterpolationMode.HighQuality);
			image10.Margin = new Thickness(5.0, 0.0, 0.0, 0.0);
			image10.Width = 36.0;
			image10.Stretch = Stretch.Uniform;
			image10.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			supportInitialize75.EndInit();
			AvaloniaList<Control> children51 = grid52.Children;
			TextBlock textBlock48;
			TextBlock textBlock47 = textBlock48 = new TextBlock();
			((ISupportInitialize)textBlock47).BeginInit();
			children51.Add(textBlock47);
			ISupportInitialize supportInitialize76 = textBlock3 = textBlock48;
			context.PushParent(textBlock3);
			TextBlock textBlock49 = textBlock3;
			Grid.SetColumn(textBlock49, 1);
			textBlock49.FontSize = 14.0;
			textBlock49.Margin = new Thickness(18.0, 0.0, 0.0, 0.0);
			StaticResourceExtension staticResourceExtension21 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider23 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj21 = staticResourceExtension21.ProvideValue(serviceProvider23);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock49, obj21);
			AvaloniaProperty textProperty6 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension29 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.GasWarningText!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider29 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding31 = compiledBindingExtension29.ProvideValue(provider29);
			context.ProvideTargetProperty = null;
			textBlock49.Bind(textProperty6, binding31, null);
			textBlock49.VerticalAlignment = VerticalAlignment.Center;
			textBlock49.FontWeight = FontWeight.Light;
			textBlock49.TextWrapping = TextWrapping.WrapWithOverflow;
			textBlock49.HorizontalAlignment = HorizontalAlignment.Left;
			textBlock49.Opacity = 0.8;
			textBlock49.TextAlignment = TextAlignment.Left;
			context.PopParent();
			supportInitialize76.EndInit();
			AvaloniaList<Control> children52 = grid52.Children;
			Button button42;
			Button button41 = button42 = new Button();
			((ISupportInitialize)button41).BeginInit();
			children52.Add(button41);
			ISupportInitialize supportInitialize77 = button3 = button42;
			context.PushParent(button3);
			Button button43 = button3;
			Grid.SetColumn(button43, 2);
			button43.Background = new ImmutableSolidColorBrush(16777215U);
			Border border39;
			Border border38 = border39 = new Border();
			((ISupportInitialize)border38).BeginInit();
			button43.Content = border38;
			ISupportInitialize supportInitialize78 = border3 = border39;
			context.PushParent(border3);
			Border border40 = border3;
			border40.Height = 40.0;
			border40.Width = 150.0;
			border40.CornerRadius = new CornerRadius(23.0, 23.0, 23.0, 23.0);
			border40.Background = new LinearGradientBrush
			{
				StartPoint = new RelativePoint(0.0, 0.5, RelativeUnit.Relative),
				EndPoint = new RelativePoint(1.0, 0.5, RelativeUnit.Relative),
				GradientStops = 
				{
					new GradientStop
					{
						Color = Color.FromUInt32(4279967263U),
						Offset = 0.0
					},
					new GradientStop
					{
						Color = Color.FromUInt32(4280625193U),
						Offset = 1.0
					}
				}
			};
			TextBlock textBlock51;
			TextBlock textBlock50 = textBlock51 = new TextBlock();
			((ISupportInitialize)textBlock50).BeginInit();
			border40.Child = textBlock50;
			ISupportInitialize supportInitialize79 = textBlock3 = textBlock51;
			context.PushParent(textBlock3);
			TextBlock textBlock52 = textBlock3;
			textBlock52.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension22 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider24 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj22 = staticResourceExtension22.ProvideValue(serviceProvider24);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock52, obj22);
			textBlock52.Text = "LEARN MORE";
			textBlock52.VerticalAlignment = VerticalAlignment.Center;
			textBlock52.FontWeight = FontWeight.Normal;
			textBlock52.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock52.TextAlignment = TextAlignment.Center;
			context.PopParent();
			supportInitialize79.EndInit();
			context.PopParent();
			supportInitialize78.EndInit();
			context.PopParent();
			supportInitialize77.EndInit();
			context.PopParent();
			supportInitialize74.EndInit();
			context.PopParent();
			supportInitialize73.EndInit();
			context.PopParent();
			supportInitialize72.EndInit();
			AvaloniaList<Control> children53 = grid46.Children;
			Grid grid54;
			Grid grid53 = grid54 = new Grid();
			((ISupportInitialize)grid53).BeginInit();
			children53.Add(grid53);
			ISupportInitialize supportInitialize80 = grid3 = grid54;
			context.PushParent(grid3);
			Grid grid55 = grid3;
			Grid.SetRow(grid55, 1);
			grid55.VerticalAlignment = VerticalAlignment.Center;
			AvaloniaList<Control> children54 = grid55.Children;
			TextBlock textBlock54;
			TextBlock textBlock53 = textBlock54 = new TextBlock();
			((ISupportInitialize)textBlock53).BeginInit();
			children54.Add(textBlock53);
			ISupportInitialize supportInitialize81 = textBlock3 = textBlock54;
			context.PushParent(textBlock3);
			TextBlock textBlock55 = textBlock3;
			AvaloniaProperty isVisibleProperty10 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension30 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereAnyTransaction!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider30 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding32 = compiledBindingExtension30.ProvideValue(provider30);
			context.ProvideTargetProperty = null;
			textBlock55.Bind(isVisibleProperty10, binding32, null);
			textBlock55.FontSize = 24.0;
			StaticResourceExtension staticResourceExtension23 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider25 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj23 = staticResourceExtension23.ProvideValue(serviceProvider25);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock55, obj23);
			AvaloniaProperty textProperty7 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension31 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.NoTransactionText!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider31 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding33 = compiledBindingExtension31.ProvideValue(provider31);
			context.ProvideTargetProperty = null;
			textBlock55.Bind(textProperty7, binding33, null);
			textBlock55.VerticalAlignment = VerticalAlignment.Center;
			textBlock55.Foreground = new ImmutableSolidColorBrush(4294638330U);
			textBlock55.Opacity = 0.2;
			textBlock55.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock55.FontWeight = FontWeight.Light;
			textBlock55.TextAlignment = TextAlignment.Center;
			context.PopParent();
			supportInitialize81.EndInit();
			context.PopParent();
			supportInitialize80.EndInit();
			AvaloniaList<Control> children55 = grid46.Children;
			StackPanel stackPanel15;
			StackPanel stackPanel14 = stackPanel15 = new StackPanel();
			((ISupportInitialize)stackPanel14).BeginInit();
			children55.Add(stackPanel14);
			ISupportInitialize supportInitialize82 = stackPanel3 = stackPanel15;
			context.PushParent(stackPanel3);
			StackPanel stackPanel16 = stackPanel3;
			Grid.SetRow(stackPanel16, 1);
			AvaloniaProperty isVisibleProperty11 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension32 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereAnyTransaction!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider32 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding34 = compiledBindingExtension32.ProvideValue(provider32);
			context.ProvideTargetProperty = null;
			stackPanel16.Bind(isVisibleProperty11, binding34, null);
			AvaloniaList<Control> children56 = stackPanel16.Children;
			StackPanel stackPanel18;
			StackPanel stackPanel17 = stackPanel18 = new StackPanel();
			((ISupportInitialize)stackPanel17).BeginInit();
			children56.Add(stackPanel17);
			ISupportInitialize supportInitialize83 = stackPanel3 = stackPanel18;
			context.PushParent(stackPanel3);
			StackPanel stackPanel19 = stackPanel3;
			AvaloniaProperty isVisibleProperty12 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension33 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsTherePendingTransaction!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider33 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding35 = compiledBindingExtension33.ProvideValue(provider33);
			context.ProvideTargetProperty = null;
			stackPanel19.Bind(isVisibleProperty12, binding35, null);
			stackPanel19.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
			AvaloniaList<Control> children57 = stackPanel19.Children;
			TextBlock textBlock57;
			TextBlock textBlock56 = textBlock57 = new TextBlock();
			((ISupportInitialize)textBlock56).BeginInit();
			children57.Add(textBlock56);
			ISupportInitialize supportInitialize84 = textBlock3 = textBlock57;
			context.PushParent(textBlock3);
			TextBlock textBlock58 = textBlock3;
			textBlock58.FontSize = 14.5;
			textBlock58.Margin = new Thickness(15.0, 40.0, 0.0, 4.0);
			StaticResourceExtension staticResourceExtension24 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider26 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj24 = staticResourceExtension24.ProvideValue(serviceProvider26);
			context.ProvideTargetProperty = null;
			CoinSpecificPartView.DynamicSetters_63.DynamicSetter_3(textBlock58, obj24);
			textBlock58.Text = "Pending";
			textBlock58.VerticalAlignment = VerticalAlignment.Center;
			textBlock58.Opacity = 0.25;
			textBlock58.FontWeight = FontWeight.Normal;
			context.PopParent();
			supportInitialize84.EndInit();
			AvaloniaList<Control> children58 = stackPanel19.Children;
			ItemsControl itemsControl2;
			ItemsControl itemsControl = itemsControl2 = new ItemsControl();
			((ISupportInitialize)itemsControl).BeginInit();
			children58.Add(itemsControl);
			ItemsControl itemsControl3;
			ISupportInitialize supportInitialize85 = itemsControl3 = itemsControl2;
			context.PushParent(itemsControl3);
			ItemsControl itemsControl4 = itemsControl3;
			AvaloniaProperty itemsSourceProperty = ItemsControl.ItemsSourceProperty;
			CompiledBindingExtension compiledBindingExtension34 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.PendingTransactions!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider34 = context;
			context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
			IBinding binding36 = compiledBindingExtension34.ProvideValue(provider34);
			context.ProvideTargetProperty = null;
			itemsControl4.Bind(itemsSourceProperty, binding36, null);
			itemsControl4.HorizontalAlignment = HorizontalAlignment.Stretch;
			itemsControl4.VerticalAlignment = VerticalAlignment.Top;
			AvaloniaProperty foregroundProperty3 = TemplatedControl.ForegroundProperty;
			CompiledBindingExtension compiledBindingExtension35 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider35 = context;
			context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
			IBinding binding37 = compiledBindingExtension35.ProvideValue(provider35);
			context.ProvideTargetProperty = null;
			itemsControl4.Bind(foregroundProperty3, binding37, null);
			itemsControl4.ItemsPanel = new ItemsPanelTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(CoinSpecificPartView.XamlClosure_64.Build), context)
			};
			DataTemplate dataTemplate;
			IDataTemplate itemTemplate = dataTemplate = new DataTemplate();
			context.PushParent(dataTemplate);
			dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(CoinSpecificPartView.XamlClosure_65.Build), context);
			context.PopParent();
			itemsControl4.ItemTemplate = itemTemplate;
			context.PopParent();
			supportInitialize85.EndInit();
			context.PopParent();
			supportInitialize83.EndInit();
			AvaloniaList<Control> children59 = stackPanel16.Children;
			ItemsControl itemsControl6;
			ItemsControl itemsControl5 = itemsControl6 = new ItemsControl();
			((ISupportInitialize)itemsControl5).BeginInit();
			children59.Add(itemsControl5);
			ISupportInitialize supportInitialize86 = itemsControl3 = itemsControl6;
			context.PushParent(itemsControl3);
			ItemsControl itemsControl7 = itemsControl3;
			AvaloniaProperty itemsSourceProperty2 = ItemsControl.ItemsSourceProperty;
			CompiledBindingExtension compiledBindingExtension36 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.TransactionsGroups!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider36 = context;
			context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
			IBinding binding38 = compiledBindingExtension36.ProvideValue(provider36);
			context.ProvideTargetProperty = null;
			itemsControl7.Bind(itemsSourceProperty2, binding38, null);
			AvaloniaProperty isVisibleProperty13 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension37 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsThereTransaction!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider37 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding39 = compiledBindingExtension37.ProvideValue(provider37);
			context.ProvideTargetProperty = null;
			itemsControl7.Bind(isVisibleProperty13, binding39, null);
			itemsControl7.HorizontalAlignment = HorizontalAlignment.Stretch;
			itemsControl7.VerticalAlignment = VerticalAlignment.Top;
			itemsControl7.Margin = new Thickness(0.0, 0.0, 0.0, 12.0);
			itemsControl7.ItemsPanel = new ItemsPanelTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(CoinSpecificPartView.XamlClosure_67.Build), context)
			};
			IDataTemplate itemTemplate2 = dataTemplate = new DataTemplate();
			context.PushParent(dataTemplate);
			dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(CoinSpecificPartView.XamlClosure_68.Build), context);
			context.PopParent();
			itemsControl7.ItemTemplate = itemTemplate2;
			context.PopParent();
			supportInitialize86.EndInit();
			context.PopParent();
			supportInitialize82.EndInit();
			context.PopParent();
			supportInitialize71.EndInit();
			context.PopParent();
			supportInitialize61.EndInit();
			context.PopParent();
			supportInitialize2.EndInit();
			context.PopParent();
			supportInitialize.EndInit();
			context.PopParent();
			((ISupportInitialize)A_1).EndInit();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x06000029 RID: 41 RVA: 0x0000D1B2 File Offset: 0x0000B3B2
		private static void !XamlIlPopulateTrampoline(CoinSpecificPartView A_0)
		{
			if (CoinSpecificPartView.!XamlIlPopulateOverride != null)
			{
				CoinSpecificPartView.!XamlIlPopulateOverride(A_0);
				return;
			}
			CoinSpecificPartView.!XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), A_0);
		}

		// Token: 0x04000008 RID: 8
		private static Action<object> !XamlIlPopulateOverride;

		// Token: 0x02000013 RID: 19
		private class DynamicSetters_63
		{
			// Token: 0x0600002A RID: 42 RVA: 0x0000D1D8 File Offset: 0x0000B3D8
			public static void DynamicSetter_1(StyledElement A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(StyledElement.ThemeProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(StyledElement.ThemeProperty, A_1, null);
					return;
				}
				if (A_1 is ControlTheme)
				{
					A_0.Theme = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.Theme = A_1;
					return;
				}
				throw new InvalidCastException();
			}

			// Token: 0x0600002B RID: 43 RVA: 0x0000D244 File Offset: 0x0000B444
			public static void DynamicSetter_2(Path A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(Path.DataProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(Path.DataProperty, A_1, null);
					return;
				}
				if (A_1 is Geometry)
				{
					A_0.Data = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.Data = A_1;
					return;
				}
				throw new InvalidCastException();
			}

			// Token: 0x0600002C RID: 44 RVA: 0x0000D2B0 File Offset: 0x0000B4B0
			public static void DynamicSetter_3(TextBlock A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
					return;
				}
				if (A_1 is FontFamily)
				{
					A_0.FontFamily = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.FontFamily = A_1;
					return;
				}
				throw new InvalidCastException();
			}
		}

		// Token: 0x02000014 RID: 20
		private class XamlClosure_64
		{
			// Token: 0x0600002D RID: 45 RVA: 0x0000D31C File Offset: 0x0000B51C
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<CoinSpecificPartView> context = new XamlIlContext.Context<CoinSpecificPartView>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.Singleton
				}, "avares://Exodus/Views/CoinSpecificPartView.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (CoinSpecificPartView)obj;
					}
				}
				context.IntermediateRoot = new StackPanel();
				object intermediateRoot = context.IntermediateRoot;
				((ISupportInitialize)intermediateRoot).BeginInit();
				intermediateRoot.Spacing = -5.0;
				((ISupportInitialize)intermediateRoot).EndInit();
				return intermediateRoot;
			}
		}

		// Token: 0x02000015 RID: 21
		private class XamlClosure_65
		{
			// Token: 0x0600002E RID: 46 RVA: 0x0000D3AC File Offset: 0x0000B5AC
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<CoinSpecificPartView> context = new XamlIlContext.Context<CoinSpecificPartView>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.Singleton
				}, "avares://Exodus/Views/CoinSpecificPartView.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (CoinSpecificPartView)obj;
					}
				}
				context.IntermediateRoot = new Grid();
				object intermediateRoot = context.IntermediateRoot;
				((ISupportInitialize)intermediateRoot).BeginInit();
				Grid grid = intermediateRoot;
				context.PushParent(grid);
				Grid grid2 = grid;
				RowDefinitions rowDefinitions = new RowDefinitions();
				rowDefinitions.Capacity = 3;
				rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
				rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
				grid2.RowDefinitions = rowDefinitions;
				grid2.Margin = new Thickness(0.0, 2.0, 25.0, 2.0);
				AvaloniaList<Control> children = grid2.Children;
				Border border2;
				Border border = border2 = new Border();
				((ISupportInitialize)border).BeginInit();
				children.Add(border);
				Border border3 = border2;
				Grid.SetRow(border3, 0);
				border3.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
				border3.Height = 1.0;
				border3.HorizontalAlignment = HorizontalAlignment.Stretch;
				border3.Background = new ImmutableSolidColorBrush(uint.MaxValue);
				border3.Opacity = 0.08;
				((ISupportInitialize)border3).EndInit();
				AvaloniaList<Control> children2 = grid2.Children;
				Border border5;
				Border border4 = border5 = new Border();
				((ISupportInitialize)border4).BeginInit();
				children2.Add(border4);
				Border border6;
				ISupportInitialize supportInitialize = border6 = border5;
				context.PushParent(border6);
				Border border7 = border6;
				Grid.SetRow(border7, 1);
				border7.HorizontalAlignment = HorizontalAlignment.Stretch;
				Grid grid4;
				Grid grid3 = grid4 = new Grid();
				((ISupportInitialize)grid3).BeginInit();
				border7.Child = grid3;
				ISupportInitialize supportInitialize2 = grid = grid4;
				context.PushParent(grid);
				Grid grid5 = grid;
				RowDefinitions rowDefinitions2 = new RowDefinitions();
				rowDefinitions2.Capacity = 2;
				rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
				rowDefinitions2.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid5.RowDefinitions = rowDefinitions2;
				grid5.HorizontalAlignment = HorizontalAlignment.Stretch;
				grid5.VerticalAlignment = VerticalAlignment.Top;
				AvaloniaList<Control> children3 = grid5.Children;
				Border border9;
				Border border8 = border9 = new Border();
				((ISupportInitialize)border8).BeginInit();
				children3.Add(border8);
				ISupportInitialize supportInitialize3 = border6 = border9;
				context.PushParent(border6);
				Border border10 = border6;
				Grid.SetRow(border10, 0);
				border10.HorizontalAlignment = HorizontalAlignment.Stretch;
				border10.Height = 46.0;
				Styles styles = border10.Styles;
				Style style;
				IStyle item = style = new Style();
				context.PushParent(style);
				Style style2 = style;
				style2.Selector = Selectors.OfType((Selector)null, typeof(Border));
				Setter setter2;
				SetterBase setter = setter2 = new Setter();
				context.PushParent(setter2);
				Setter setter3 = setter2;
				setter3.Property = Border.BackgroundProperty;
				CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.HeaderBackgroundColor!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider = context;
				context.ProvideTargetProperty = XamlIlHelpers.Avalonia.Styling.Setter,Avalonia.Base.Value!Property();
				object value = compiledBindingExtension.ProvideValue(provider);
				context.ProvideTargetProperty = null;
				setter3.Value = value;
				context.PopParent();
				style2.Add(setter);
				context.PopParent();
				styles.Add(item);
				Styles styles2 = border10.Styles;
				Style style3 = new Style();
				style3.Selector = Selectors.OfType((Selector)null, typeof(Border)).Class(":pointerover");
				style3.Add(new Setter
				{
					Property = Border.BackgroundProperty,
					Value = new ImmutableSolidColorBrush(637534208U)
				});
				styles2.Add(style3);
				Grid grid7;
				Grid grid6 = grid7 = new Grid();
				((ISupportInitialize)grid6).BeginInit();
				border10.Child = grid6;
				ISupportInitialize supportInitialize4 = grid = grid7;
				context.PushParent(grid);
				Grid grid8 = grid;
				ColumnDefinitions columnDefinitions = new ColumnDefinitions();
				columnDefinitions.Capacity = 3;
				columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				grid8.ColumnDefinitions = columnDefinitions;
				grid8.VerticalAlignment = VerticalAlignment.Stretch;
				grid8.HorizontalAlignment = HorizontalAlignment.Stretch;
				grid8.Margin = new Thickness(10.0, 0.0, 10.0, 0.0);
				AvaloniaList<Control> children4 = grid8.Children;
				StackPanel stackPanel2;
				StackPanel stackPanel = stackPanel2 = new StackPanel();
				((ISupportInitialize)stackPanel).BeginInit();
				children4.Add(stackPanel);
				StackPanel stackPanel3;
				ISupportInitialize supportInitialize5 = stackPanel3 = stackPanel2;
				context.PushParent(stackPanel3);
				StackPanel stackPanel4 = stackPanel3;
				Grid.SetColumn(stackPanel4, 0);
				stackPanel4.VerticalAlignment = VerticalAlignment.Center;
				stackPanel4.Orientation = Orientation.Horizontal;
				AvaloniaList<Control> children5 = stackPanel4.Children;
				ThreeDotAnimation threeDotAnimation2;
				ThreeDotAnimation threeDotAnimation = threeDotAnimation2 = new ThreeDotAnimation();
				((ISupportInitialize)threeDotAnimation).BeginInit();
				children5.Add(threeDotAnimation);
				ThreeDotAnimation threeDotAnimation3 = threeDotAnimation2;
				threeDotAnimation3.VerticalAlignment = VerticalAlignment.Center;
				threeDotAnimation3.Margin = new Thickness(0.0, 0.0, 10.0, 0.0);
				((ISupportInitialize)threeDotAnimation3).EndInit();
				AvaloniaList<Control> children6 = stackPanel4.Children;
				TextBlock textBlock2;
				TextBlock textBlock = textBlock2 = new TextBlock();
				((ISupportInitialize)textBlock).BeginInit();
				children6.Add(textBlock);
				TextBlock textBlock3;
				ISupportInitialize supportInitialize6 = textBlock3 = textBlock2;
				context.PushParent(textBlock3);
				TextBlock textBlock4 = textBlock3;
				textBlock4.FontSize = 15.0;
				StaticResourceExtension staticResourceExtension = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj2 = staticResourceExtension.ProvideValue(serviceProvider);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock4, obj2);
				textBlock4.Text = "Receiving...";
				textBlock4.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaProperty foregroundProperty = TextBlock.ForegroundProperty;
				CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(TemplatedControl.ForegroundProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).Build());
				IServiceProvider provider2 = context;
				context.ProvideTargetProperty = TextBlock.ForegroundProperty;
				IBinding binding = compiledBindingExtension2.ProvideValue(provider2);
				context.ProvideTargetProperty = null;
				textBlock4.Bind(foregroundProperty, binding, null);
				textBlock4.FontWeight = FontWeight.Light;
				context.PopParent();
				supportInitialize6.EndInit();
				context.PopParent();
				supportInitialize5.EndInit();
				AvaloniaList<Control> children7 = grid8.Children;
				Grid grid10;
				Grid grid9 = grid10 = new Grid();
				((ISupportInitialize)grid9).BeginInit();
				children7.Add(grid9);
				Grid grid11 = grid10;
				Grid.SetColumn(grid11, 1);
				grid11.HorizontalAlignment = HorizontalAlignment.Stretch;
				((ISupportInitialize)grid11).EndInit();
				AvaloniaList<Control> children8 = grid8.Children;
				Grid grid13;
				Grid grid12 = grid13 = new Grid();
				((ISupportInitialize)grid12).BeginInit();
				children8.Add(grid12);
				ISupportInitialize supportInitialize7 = grid = grid13;
				context.PushParent(grid);
				Grid grid14 = grid;
				Grid.SetColumn(grid14, 2);
				ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
				columnDefinitions2.Capacity = 2;
				columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				grid14.ColumnDefinitions = columnDefinitions2;
				AvaloniaList<Control> children9 = grid14.Children;
				StackPanel stackPanel6;
				StackPanel stackPanel5 = stackPanel6 = new StackPanel();
				((ISupportInitialize)stackPanel5).BeginInit();
				children9.Add(stackPanel5);
				ISupportInitialize supportInitialize8 = stackPanel3 = stackPanel6;
				context.PushParent(stackPanel3);
				StackPanel stackPanel7 = stackPanel3;
				Grid.SetColumn(stackPanel7, 0);
				stackPanel7.VerticalAlignment = VerticalAlignment.Center;
				stackPanel7.Orientation = Orientation.Horizontal;
				AvaloniaList<Control> children10 = stackPanel7.Children;
				Border border12;
				Border border11 = border12 = new Border();
				((ISupportInitialize)border11).BeginInit();
				children10.Add(border11);
				ISupportInitialize supportInitialize9 = border6 = border12;
				context.PushParent(border6);
				Border border13 = border6;
				border13.Margin = new Thickness(0.0, 5.0, 60.0, 5.0);
				border13.Background = new ImmutableSolidColorBrush(3858759680U);
				border13.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
				TextBlock textBlock6;
				TextBlock textBlock5 = textBlock6 = new TextBlock();
				((ISupportInitialize)textBlock5).BeginInit();
				border13.Child = textBlock5;
				ISupportInitialize supportInitialize10 = textBlock3 = textBlock6;
				context.PushParent(textBlock3);
				TextBlock textBlock7 = textBlock3;
				textBlock7.Margin = new Thickness(6.0, 3.0, 6.0, 3.0);
				textBlock7.FontSize = 12.0;
				StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("RobotoCondensedBold");
				IServiceProvider serviceProvider2 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj3 = staticResourceExtension2.ProvideValue(serviceProvider2);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock7, obj3);
				textBlock7.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock7.Text = "PENDING";
				textBlock7.VerticalAlignment = VerticalAlignment.Center;
				textBlock7.HorizontalAlignment = HorizontalAlignment.Center;
				textBlock7.TextAlignment = TextAlignment.Center;
				textBlock7.Opacity = 0.9;
				context.PopParent();
				supportInitialize10.EndInit();
				context.PopParent();
				supportInitialize9.EndInit();
				AvaloniaList<Control> children11 = stackPanel7.Children;
				Grid grid16;
				Grid grid15 = grid16 = new Grid();
				((ISupportInitialize)grid15).BeginInit();
				children11.Add(grid15);
				ISupportInitialize supportInitialize11 = grid = grid16;
				context.PushParent(grid);
				Grid grid17 = grid;
				ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
				columnDefinitions3.Capacity = 2;
				columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid17.ColumnDefinitions = columnDefinitions3;
				grid17.Margin = new Thickness(0.0, 0.0, 12.0, 0.0);
				AvaloniaList<Control> children12 = grid17.Children;
				TextBlock textBlock9;
				TextBlock textBlock8 = textBlock9 = new TextBlock();
				((ISupportInitialize)textBlock8).BeginInit();
				children12.Add(textBlock8);
				ISupportInitialize supportInitialize12 = textBlock3 = textBlock9;
				context.PushParent(textBlock3);
				TextBlock textBlock10 = textBlock3;
				Grid.SetColumn(textBlock10, 0);
				textBlock10.FontSize = 16.0;
				StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider3 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj4 = staticResourceExtension3.ProvideValue(serviceProvider3);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock10, obj4);
				textBlock10.Text = "+";
				textBlock10.VerticalAlignment = VerticalAlignment.Center;
				textBlock10.Margin = new Thickness(0.0, 0.0, 1.0, 0.0);
				AvaloniaProperty foregroundProperty2 = TextBlock.ForegroundProperty;
				CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(TemplatedControl.ForegroundProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).Build());
				IServiceProvider provider3 = context;
				context.ProvideTargetProperty = TextBlock.ForegroundProperty;
				IBinding binding2 = compiledBindingExtension3.ProvideValue(provider3);
				context.ProvideTargetProperty = null;
				textBlock10.Bind(foregroundProperty2, binding2, null);
				textBlock10.Opacity = 0.8;
				textBlock10.FontWeight = FontWeight.Normal;
				context.PopParent();
				supportInitialize12.EndInit();
				AvaloniaList<Control> children13 = grid17.Children;
				TextBlock textBlock12;
				TextBlock textBlock11 = textBlock12 = new TextBlock();
				((ISupportInitialize)textBlock11).BeginInit();
				children13.Add(textBlock11);
				ISupportInitialize supportInitialize13 = textBlock3 = textBlock12;
				context.PushParent(textBlock3);
				TextBlock textBlock13 = textBlock3;
				Grid.SetColumn(textBlock13, 1);
				textBlock13.FontSize = 16.0;
				StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider4 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj5 = staticResourceExtension4.ProvideValue(serviceProvider4);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock13, obj5);
				AvaloniaProperty textProperty = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.FormattedAmount!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider4 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding3 = compiledBindingExtension4.ProvideValue(provider4);
				context.ProvideTargetProperty = null;
				textBlock13.Bind(textProperty, binding3, null);
				textBlock13.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaProperty foregroundProperty3 = TextBlock.ForegroundProperty;
				CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(TemplatedControl.ForegroundProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).Build());
				IServiceProvider provider5 = context;
				context.ProvideTargetProperty = TextBlock.ForegroundProperty;
				IBinding binding4 = compiledBindingExtension5.ProvideValue(provider5);
				context.ProvideTargetProperty = null;
				textBlock13.Bind(foregroundProperty3, binding4, null);
				textBlock13.Opacity = 0.8;
				textBlock13.FontWeight = FontWeight.Normal;
				context.PopParent();
				supportInitialize13.EndInit();
				context.PopParent();
				supportInitialize11.EndInit();
				AvaloniaList<Control> children14 = stackPanel7.Children;
				Button button2;
				Button button = button2 = new Button();
				((ISupportInitialize)button).BeginInit();
				children14.Add(button);
				Button button3;
				ISupportInitialize supportInitialize14 = button3 = button2;
				context.PushParent(button3);
				Button button4 = button3;
				AvaloniaProperty commandProperty = Button.CommandProperty;
				CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("ExpandCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.Models.Transaction+ExpandCommand_0!CommandExecuteTrampoline), null, null).Build());
				IServiceProvider provider6 = context;
				context.ProvideTargetProperty = Button.CommandProperty;
				IBinding binding5 = compiledBindingExtension6.ProvideValue(provider6);
				context.ProvideTargetProperty = null;
				button4.Bind(commandProperty, binding5, null);
				button4.Background = new ImmutableSolidColorBrush(16777215U);
				button4.VerticalAlignment = VerticalAlignment.Center;
				Grid grid19;
				Grid grid18 = grid19 = new Grid();
				((ISupportInitialize)grid18).BeginInit();
				button4.Content = grid18;
				ISupportInitialize supportInitialize15 = grid = grid19;
				context.PushParent(grid);
				Grid grid20 = grid;
				AvaloniaList<Control> children15 = grid20.Children;
				Viewbox viewbox2;
				Viewbox viewbox = viewbox2 = new Viewbox();
				((ISupportInitialize)viewbox).BeginInit();
				children15.Add(viewbox);
				Viewbox viewbox3;
				ISupportInitialize supportInitialize16 = viewbox3 = viewbox2;
				context.PushParent(viewbox3);
				Viewbox viewbox4 = viewbox3;
				AvaloniaProperty isVisibleProperty = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider7 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding6 = compiledBindingExtension7.ProvideValue(provider7);
				context.ProvideTargetProperty = null;
				viewbox4.Bind(isVisibleProperty, binding6, null);
				viewbox4.Width = 14.0;
				Path path2;
				Path path = path2 = new Path();
				((ISupportInitialize)path).BeginInit();
				viewbox4.Child = path;
				Path path3;
				ISupportInitialize supportInitialize17 = path3 = path2;
				context.PushParent(path3);
				Path path4 = path3;
				StaticResourceExtension staticResourceExtension5 = new StaticResourceExtension("Collapse");
				IServiceProvider serviceProvider5 = context;
				context.ProvideTargetProperty = Path.DataProperty;
				object obj6 = staticResourceExtension5.ProvideValue(serviceProvider5);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_2(path4, obj6);
				path4.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
				path4.Opacity = 0.8;
				path4.Stretch = Stretch.Uniform;
				context.PopParent();
				supportInitialize17.EndInit();
				context.PopParent();
				supportInitialize16.EndInit();
				AvaloniaList<Control> children16 = grid20.Children;
				Viewbox viewbox6;
				Viewbox viewbox5 = viewbox6 = new Viewbox();
				((ISupportInitialize)viewbox5).BeginInit();
				children16.Add(viewbox5);
				ISupportInitialize supportInitialize18 = viewbox3 = viewbox6;
				context.PushParent(viewbox3);
				Viewbox viewbox7 = viewbox3;
				AvaloniaProperty isVisibleProperty2 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider8 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding7 = compiledBindingExtension8.ProvideValue(provider8);
				context.ProvideTargetProperty = null;
				viewbox7.Bind(isVisibleProperty2, binding7, null);
				viewbox7.Width = 14.0;
				Path path6;
				Path path5 = path6 = new Path();
				((ISupportInitialize)path5).BeginInit();
				viewbox7.Child = path5;
				ISupportInitialize supportInitialize19 = path3 = path6;
				context.PushParent(path3);
				Path path7 = path3;
				StaticResourceExtension staticResourceExtension6 = new StaticResourceExtension("Expand");
				IServiceProvider serviceProvider6 = context;
				context.ProvideTargetProperty = Path.DataProperty;
				object obj7 = staticResourceExtension6.ProvideValue(serviceProvider6);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_2(path7, obj7);
				path7.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
				path7.Opacity = 0.8;
				path7.Stretch = Stretch.Uniform;
				context.PopParent();
				supportInitialize19.EndInit();
				context.PopParent();
				supportInitialize18.EndInit();
				context.PopParent();
				supportInitialize15.EndInit();
				context.PopParent();
				supportInitialize14.EndInit();
				context.PopParent();
				supportInitialize8.EndInit();
				context.PopParent();
				supportInitialize7.EndInit();
				context.PopParent();
				supportInitialize4.EndInit();
				context.PopParent();
				supportInitialize3.EndInit();
				AvaloniaList<Control> children17 = grid5.Children;
				Grid grid22;
				Grid grid21 = grid22 = new Grid();
				((ISupportInitialize)grid21).BeginInit();
				children17.Add(grid21);
				ISupportInitialize supportInitialize20 = grid = grid22;
				context.PushParent(grid);
				Grid grid23 = grid;
				Grid.SetRow(grid23, 1);
				grid23.Background = new ImmutableSolidColorBrush(251658240U);
				grid23.Height = 175.0;
				grid23.HorizontalAlignment = HorizontalAlignment.Stretch;
				AvaloniaProperty isVisibleProperty3 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider9 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding8 = compiledBindingExtension9.ProvideValue(provider9);
				context.ProvideTargetProperty = null;
				grid23.Bind(isVisibleProperty3, binding8, null);
				AvaloniaList<Control> children18 = grid23.Children;
				Grid grid25;
				Grid grid24 = grid25 = new Grid();
				((ISupportInitialize)grid24).BeginInit();
				children18.Add(grid24);
				ISupportInitialize supportInitialize21 = grid = grid25;
				context.PushParent(grid);
				Grid grid26 = grid;
				grid26.HorizontalAlignment = HorizontalAlignment.Stretch;
				grid26.Margin = new Thickness(25.0, 10.0, 25.0, 10.0);
				RowDefinitions rowDefinitions3 = new RowDefinitions();
				rowDefinitions3.Capacity = 2;
				rowDefinitions3.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				rowDefinitions3.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
				grid26.RowDefinitions = rowDefinitions3;
				ColumnDefinitions columnDefinitions4 = new ColumnDefinitions();
				columnDefinitions4.Capacity = 3;
				columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid26.ColumnDefinitions = columnDefinitions4;
				AvaloniaList<Control> children19 = grid26.Children;
				Grid grid28;
				Grid grid27 = grid28 = new Grid();
				((ISupportInitialize)grid27).BeginInit();
				children19.Add(grid27);
				ISupportInitialize supportInitialize22 = grid = grid28;
				context.PushParent(grid);
				Grid grid29 = grid;
				Grid.SetColumn(grid29, 0);
				Grid.SetColumnSpan(grid29, 3);
				Grid.SetRow(grid29, 0);
				ColumnDefinitions columnDefinitions5 = new ColumnDefinitions();
				columnDefinitions5.Capacity = 3;
				columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid29.ColumnDefinitions = columnDefinitions5;
				AvaloniaList<Control> children20 = grid29.Children;
				Grid grid31;
				Grid grid30 = grid31 = new Grid();
				((ISupportInitialize)grid30).BeginInit();
				children20.Add(grid30);
				ISupportInitialize supportInitialize23 = grid = grid31;
				context.PushParent(grid);
				Grid grid32 = grid;
				Grid.SetColumn(grid32, 0);
				RowDefinitions rowDefinitions4 = new RowDefinitions();
				rowDefinitions4.Capacity = 2;
				rowDefinitions4.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				rowDefinitions4.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid32.RowDefinitions = rowDefinitions4;
				grid32.HorizontalAlignment = HorizontalAlignment.Stretch;
				grid32.VerticalAlignment = VerticalAlignment.Stretch;
				AvaloniaList<Control> children21 = grid32.Children;
				Grid grid34;
				Grid grid33 = grid34 = new Grid();
				((ISupportInitialize)grid33).BeginInit();
				children21.Add(grid33);
				ISupportInitialize supportInitialize24 = grid = grid34;
				context.PushParent(grid);
				Grid grid35 = grid;
				Grid.SetRow(grid35, 0);
				ColumnDefinitions columnDefinitions6 = new ColumnDefinitions();
				columnDefinitions6.Capacity = 2;
				columnDefinitions6.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				columnDefinitions6.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid35.ColumnDefinitions = columnDefinitions6;
				grid35.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children22 = grid35.Children;
				Border border15;
				Border border14 = border15 = new Border();
				((ISupportInitialize)border14).BeginInit();
				children22.Add(border14);
				Border border16 = border15;
				Grid.SetColumn(border16, 0);
				border16.Height = 26.0;
				border16.Width = 2.0;
				border16.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
				border16.Background = new ImmutableSolidColorBrush(872415231U);
				border16.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
				border16.VerticalAlignment = VerticalAlignment.Center;
				((ISupportInitialize)border16).EndInit();
				AvaloniaList<Control> children23 = grid35.Children;
				Grid grid37;
				Grid grid36 = grid37 = new Grid();
				((ISupportInitialize)grid36).BeginInit();
				children23.Add(grid36);
				ISupportInitialize supportInitialize25 = grid = grid37;
				context.PushParent(grid);
				Grid grid38 = grid;
				Grid.SetColumn(grid38, 1);
				RowDefinitions rowDefinitions5 = new RowDefinitions();
				rowDefinitions5.Capacity = 2;
				rowDefinitions5.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
				rowDefinitions5.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid38.RowDefinitions = rowDefinitions5;
				AvaloniaList<Control> children24 = grid38.Children;
				TextBlock textBlock15;
				TextBlock textBlock14 = textBlock15 = new TextBlock();
				((ISupportInitialize)textBlock14).BeginInit();
				children24.Add(textBlock14);
				ISupportInitialize supportInitialize26 = textBlock3 = textBlock15;
				context.PushParent(textBlock3);
				TextBlock textBlock16 = textBlock3;
				Grid.SetRow(textBlock16, 0);
				textBlock16.FontSize = 11.0;
				StaticResourceExtension staticResourceExtension7 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider7 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj8 = staticResourceExtension7.ProvideValue(serviceProvider7);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock16, obj8);
				textBlock16.Text = "Date";
				textBlock16.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock16.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
				textBlock16.Opacity = 0.5;
				textBlock16.FontWeight = FontWeight.Normal;
				context.PopParent();
				supportInitialize26.EndInit();
				AvaloniaList<Control> children25 = grid38.Children;
				TextBlock textBlock18;
				TextBlock textBlock17 = textBlock18 = new TextBlock();
				((ISupportInitialize)textBlock17).BeginInit();
				children25.Add(textBlock17);
				ISupportInitialize supportInitialize27 = textBlock3 = textBlock18;
				context.PushParent(textBlock3);
				TextBlock textBlock19 = textBlock3;
				Grid.SetRow(textBlock19, 1);
				textBlock19.FontSize = 14.0;
				StaticResourceExtension staticResourceExtension8 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider8 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj9 = staticResourceExtension8.ProvideValue(serviceProvider8);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock19, obj9);
				textBlock19.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				AvaloniaProperty textProperty2 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.TimeString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider10 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding9 = compiledBindingExtension10.ProvideValue(provider10);
				context.ProvideTargetProperty = null;
				textBlock19.Bind(textProperty2, binding9, null);
				textBlock19.Opacity = 0.9;
				textBlock19.FontWeight = FontWeight.Light;
				context.PopParent();
				supportInitialize27.EndInit();
				context.PopParent();
				supportInitialize25.EndInit();
				context.PopParent();
				supportInitialize24.EndInit();
				AvaloniaList<Control> children26 = grid32.Children;
				Grid grid40;
				Grid grid39 = grid40 = new Grid();
				((ISupportInitialize)grid39).BeginInit();
				children26.Add(grid39);
				ISupportInitialize supportInitialize28 = grid = grid40;
				context.PushParent(grid);
				Grid grid41 = grid;
				Grid.SetRow(grid41, 1);
				AvaloniaProperty isVisibleProperty4 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Ancestor(typeof(CoinSpecificPartView), 0).Property(StyledElement.DataContextProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).TypeCast<CoinSpecificPartViewModel>().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider11 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding10 = compiledBindingExtension11.ProvideValue(provider11);
				context.ProvideTargetProperty = null;
				grid41.Bind(isVisibleProperty4, binding10, null);
				ColumnDefinitions columnDefinitions7 = new ColumnDefinitions();
				columnDefinitions7.Capacity = 2;
				columnDefinitions7.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				columnDefinitions7.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid41.ColumnDefinitions = columnDefinitions7;
				grid41.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children27 = grid41.Children;
				Border border18;
				Border border17 = border18 = new Border();
				((ISupportInitialize)border17).BeginInit();
				children27.Add(border17);
				Border border19 = border18;
				Grid.SetColumn(border19, 0);
				border19.Height = 26.0;
				border19.Width = 2.0;
				border19.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
				border19.Background = new ImmutableSolidColorBrush(872415231U);
				border19.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
				border19.VerticalAlignment = VerticalAlignment.Center;
				((ISupportInitialize)border19).EndInit();
				AvaloniaList<Control> children28 = grid41.Children;
				Grid grid43;
				Grid grid42 = grid43 = new Grid();
				((ISupportInitialize)grid42).BeginInit();
				children28.Add(grid42);
				ISupportInitialize supportInitialize29 = grid = grid43;
				context.PushParent(grid);
				Grid grid44 = grid;
				Grid.SetColumn(grid44, 1);
				RowDefinitions rowDefinitions6 = new RowDefinitions();
				rowDefinitions6.Capacity = 2;
				rowDefinitions6.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
				rowDefinitions6.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid44.RowDefinitions = rowDefinitions6;
				AvaloniaList<Control> children29 = grid44.Children;
				TextBlock textBlock21;
				TextBlock textBlock20 = textBlock21 = new TextBlock();
				((ISupportInitialize)textBlock20).BeginInit();
				children29.Add(textBlock20);
				ISupportInitialize supportInitialize30 = textBlock3 = textBlock21;
				context.PushParent(textBlock3);
				TextBlock textBlock22 = textBlock3;
				Grid.SetRow(textBlock22, 0);
				textBlock22.FontSize = 11.0;
				StaticResourceExtension staticResourceExtension9 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider9 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj10 = staticResourceExtension9.ProvideValue(serviceProvider9);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock22, obj10);
				textBlock22.Text = "To";
				textBlock22.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock22.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
				textBlock22.Opacity = 0.5;
				textBlock22.FontWeight = FontWeight.Normal;
				context.PopParent();
				supportInitialize30.EndInit();
				AvaloniaList<Control> children30 = grid44.Children;
				TextBlock textBlock24;
				TextBlock textBlock23 = textBlock24 = new TextBlock();
				((ISupportInitialize)textBlock23).BeginInit();
				children30.Add(textBlock23);
				ISupportInitialize supportInitialize31 = textBlock3 = textBlock24;
				context.PushParent(textBlock3);
				TextBlock textBlock25 = textBlock3;
				Grid.SetRow(textBlock25, 1);
				textBlock25.FontSize = 14.0;
				StaticResourceExtension staticResourceExtension10 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider10 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj11 = staticResourceExtension10.ProvideValue(serviceProvider10);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock25, obj11);
				textBlock25.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				AvaloniaProperty textProperty3 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.To!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider12 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding11 = compiledBindingExtension12.ProvideValue(provider12);
				context.ProvideTargetProperty = null;
				textBlock25.Bind(textProperty3, binding11, null);
				textBlock25.Opacity = 0.9;
				textBlock25.FontWeight = FontWeight.Light;
				context.PopParent();
				supportInitialize31.EndInit();
				context.PopParent();
				supportInitialize29.EndInit();
				context.PopParent();
				supportInitialize28.EndInit();
				AvaloniaList<Control> children31 = grid32.Children;
				Grid grid46;
				Grid grid45 = grid46 = new Grid();
				((ISupportInitialize)grid45).BeginInit();
				children31.Add(grid45);
				ISupportInitialize supportInitialize32 = grid = grid46;
				context.PushParent(grid);
				Grid grid47 = grid;
				Grid.SetRow(grid47, 1);
				AvaloniaProperty isVisibleProperty5 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(CoinSpecificPartView), 0).Property(StyledElement.DataContextProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).TypeCast<CoinSpecificPartViewModel>().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider13 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding12 = compiledBindingExtension13.ProvideValue(provider13);
				context.ProvideTargetProperty = null;
				grid47.Bind(isVisibleProperty5, binding12, null);
				ColumnDefinitions columnDefinitions8 = new ColumnDefinitions();
				columnDefinitions8.Capacity = 2;
				columnDefinitions8.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				columnDefinitions8.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid47.ColumnDefinitions = columnDefinitions8;
				grid47.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children32 = grid47.Children;
				Border border21;
				Border border20 = border21 = new Border();
				((ISupportInitialize)border20).BeginInit();
				children32.Add(border20);
				Border border22 = border21;
				Grid.SetColumn(border22, 0);
				border22.Height = 26.0;
				border22.Width = 2.0;
				border22.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
				border22.Background = new ImmutableSolidColorBrush(872415231U);
				border22.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
				border22.VerticalAlignment = VerticalAlignment.Center;
				((ISupportInitialize)border22).EndInit();
				AvaloniaList<Control> children33 = grid47.Children;
				Grid grid49;
				Grid grid48 = grid49 = new Grid();
				((ISupportInitialize)grid48).BeginInit();
				children33.Add(grid48);
				ISupportInitialize supportInitialize33 = grid = grid49;
				context.PushParent(grid);
				Grid grid50 = grid;
				Grid.SetColumn(grid50, 1);
				RowDefinitions rowDefinitions7 = new RowDefinitions();
				rowDefinitions7.Capacity = 2;
				rowDefinitions7.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
				rowDefinitions7.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid50.RowDefinitions = rowDefinitions7;
				AvaloniaList<Control> children34 = grid50.Children;
				TextBlock textBlock27;
				TextBlock textBlock26 = textBlock27 = new TextBlock();
				((ISupportInitialize)textBlock26).BeginInit();
				children34.Add(textBlock26);
				ISupportInitialize supportInitialize34 = textBlock3 = textBlock27;
				context.PushParent(textBlock3);
				TextBlock textBlock28 = textBlock3;
				Grid.SetRow(textBlock28, 0);
				textBlock28.FontSize = 11.0;
				StaticResourceExtension staticResourceExtension11 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider11 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj12 = staticResourceExtension11.ProvideValue(serviceProvider11);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock28, obj12);
				textBlock28.Text = "Now";
				textBlock28.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock28.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
				textBlock28.Opacity = 0.5;
				textBlock28.FontWeight = FontWeight.Normal;
				context.PopParent();
				supportInitialize34.EndInit();
				AvaloniaList<Control> children35 = grid50.Children;
				TextBlock textBlock30;
				TextBlock textBlock29 = textBlock30 = new TextBlock();
				((ISupportInitialize)textBlock29).BeginInit();
				children35.Add(textBlock29);
				ISupportInitialize supportInitialize35 = textBlock3 = textBlock30;
				context.PushParent(textBlock3);
				TextBlock textBlock31 = textBlock3;
				Grid.SetRow(textBlock31, 1);
				textBlock31.FontSize = 14.0;
				StaticResourceExtension staticResourceExtension12 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider12 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj13 = staticResourceExtension12.ProvideValue(serviceProvider12);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock31, obj13);
				textBlock31.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				AvaloniaProperty textProperty4 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.PriceNowString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider14 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding13 = compiledBindingExtension14.ProvideValue(provider14);
				context.ProvideTargetProperty = null;
				textBlock31.Bind(textProperty4, binding13, null);
				textBlock31.Opacity = 0.9;
				textBlock31.FontWeight = FontWeight.Light;
				context.PopParent();
				supportInitialize35.EndInit();
				context.PopParent();
				supportInitialize33.EndInit();
				context.PopParent();
				supportInitialize32.EndInit();
				context.PopParent();
				supportInitialize23.EndInit();
				AvaloniaList<Control> children36 = grid29.Children;
				Grid grid52;
				Grid grid51 = grid52 = new Grid();
				((ISupportInitialize)grid51).BeginInit();
				children36.Add(grid51);
				ISupportInitialize supportInitialize36 = grid = grid52;
				context.PushParent(grid);
				Grid grid53 = grid;
				Grid.SetColumn(grid53, 1);
				RowDefinitions rowDefinitions8 = new RowDefinitions();
				rowDefinitions8.Capacity = 2;
				rowDefinitions8.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				rowDefinitions8.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid53.RowDefinitions = rowDefinitions8;
				AvaloniaList<Control> children37 = grid53.Children;
				Grid grid55;
				Grid grid54 = grid55 = new Grid();
				((ISupportInitialize)grid54).BeginInit();
				children37.Add(grid54);
				ISupportInitialize supportInitialize37 = grid = grid55;
				context.PushParent(grid);
				Grid grid56 = grid;
				Grid.SetRow(grid56, 0);
				ColumnDefinitions columnDefinitions9 = new ColumnDefinitions();
				columnDefinitions9.Capacity = 2;
				columnDefinitions9.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				columnDefinitions9.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid56.ColumnDefinitions = columnDefinitions9;
				grid56.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children38 = grid56.Children;
				Border border24;
				Border border23 = border24 = new Border();
				((ISupportInitialize)border23).BeginInit();
				children38.Add(border23);
				Border border25 = border24;
				Grid.SetColumn(border25, 0);
				border25.Height = 26.0;
				border25.Width = 2.0;
				border25.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
				border25.Background = new ImmutableSolidColorBrush(872415231U);
				border25.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
				border25.VerticalAlignment = VerticalAlignment.Center;
				((ISupportInitialize)border25).EndInit();
				AvaloniaList<Control> children39 = grid56.Children;
				Grid grid58;
				Grid grid57 = grid58 = new Grid();
				((ISupportInitialize)grid57).BeginInit();
				children39.Add(grid57);
				ISupportInitialize supportInitialize38 = grid = grid58;
				context.PushParent(grid);
				Grid grid59 = grid;
				Grid.SetColumn(grid59, 1);
				RowDefinitions rowDefinitions9 = new RowDefinitions();
				rowDefinitions9.Capacity = 2;
				rowDefinitions9.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
				rowDefinitions9.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid59.RowDefinitions = rowDefinitions9;
				AvaloniaList<Control> children40 = grid59.Children;
				TextBlock textBlock33;
				TextBlock textBlock32 = textBlock33 = new TextBlock();
				((ISupportInitialize)textBlock32).BeginInit();
				children40.Add(textBlock32);
				ISupportInitialize supportInitialize39 = textBlock3 = textBlock33;
				context.PushParent(textBlock3);
				TextBlock textBlock34 = textBlock3;
				Grid.SetRow(textBlock34, 0);
				textBlock34.FontSize = 11.0;
				StaticResourceExtension staticResourceExtension13 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider13 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj14 = staticResourceExtension13.ProvideValue(serviceProvider13);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock34, obj14);
				textBlock34.Text = "Transaction ID";
				textBlock34.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock34.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
				textBlock34.Opacity = 0.5;
				textBlock34.FontWeight = FontWeight.Normal;
				context.PopParent();
				supportInitialize39.EndInit();
				AvaloniaList<Control> children41 = grid59.Children;
				Button button6;
				Button button5 = button6 = new Button();
				((ISupportInitialize)button5).BeginInit();
				children41.Add(button5);
				ISupportInitialize supportInitialize40 = button3 = button6;
				context.PushParent(button3);
				Button button7 = button3;
				Grid.SetRow(button7, 1);
				button7.Margin = new Thickness(0.0, 0.0, 0.0, 0.0);
				button7.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
				button7.Background = new ImmutableSolidColorBrush(16777215U);
				AvaloniaProperty commandProperty2 = Button.CommandProperty;
				CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("OpenTransactionLook", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.Models.Transaction+OpenTransactionLook_0!CommandExecuteTrampoline), null, null).Build());
				IServiceProvider provider15 = context;
				context.ProvideTargetProperty = Button.CommandProperty;
				IBinding binding14 = compiledBindingExtension15.ProvideValue(provider15);
				context.ProvideTargetProperty = null;
				button7.Bind(commandProperty2, binding14, null);
				Styles styles3 = button7.Styles;
				IStyle item2 = style = new Style();
				context.PushParent(style);
				Style style4 = style;
				style4.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pointerover");
				style4.Add(new Setter
				{
					Property = TemplatedControl.BackgroundProperty,
					Value = new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue()
				});
				SetterBase setter4 = setter2 = new Setter();
				context.PushParent(setter2);
				Setter setter5 = setter2;
				setter5.Property = Visual.RenderTransformProperty;
				setter5.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(0.999)");
				context.PopParent();
				style4.Add(setter4);
				context.PopParent();
				styles3.Add(item2);
				Styles styles4 = button7.Styles;
				IStyle item3 = style = new Style();
				context.PushParent(style);
				Style style5 = style;
				style5.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pressed");
				style5.Add(new Setter
				{
					Property = TemplatedControl.BackgroundProperty,
					Value = new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue()
				});
				SetterBase setter6 = setter2 = new Setter();
				context.PushParent(setter2);
				Setter setter7 = setter2;
				setter7.Property = Visual.RenderTransformProperty;
				setter7.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(0.998)");
				context.PopParent();
				style5.Add(setter6);
				context.PopParent();
				styles4.Add(item3);
				Grid grid61;
				Grid grid60 = grid61 = new Grid();
				((ISupportInitialize)grid60).BeginInit();
				button7.Content = grid60;
				ISupportInitialize supportInitialize41 = grid = grid61;
				context.PushParent(grid);
				Grid grid62 = grid;
				grid62.Margin = new Thickness(0.0, 0.0, 5.0, 0.0);
				ColumnDefinitions columnDefinitions10 = new ColumnDefinitions();
				columnDefinitions10.Capacity = 2;
				columnDefinitions10.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				columnDefinitions10.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				grid62.ColumnDefinitions = columnDefinitions10;
				AvaloniaList<Control> children42 = grid62.Children;
				TextBlock textBlock36;
				TextBlock textBlock35 = textBlock36 = new TextBlock();
				((ISupportInitialize)textBlock35).BeginInit();
				children42.Add(textBlock35);
				ISupportInitialize supportInitialize42 = textBlock3 = textBlock36;
				context.PushParent(textBlock3);
				TextBlock textBlock37 = textBlock3;
				Grid.SetColumn(textBlock37, 0);
				textBlock37.FontSize = 14.0;
				StaticResourceExtension staticResourceExtension14 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider14 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj15 = staticResourceExtension14.ProvideValue(serviceProvider14);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock37, obj15);
				textBlock37.TextTrimming = TextTrimming.CharacterEllipsis;
				AvaloniaProperty textProperty5 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.TransactionId!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider16 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding15 = compiledBindingExtension16.ProvideValue(provider16);
				context.ProvideTargetProperty = null;
				textBlock37.Bind(textProperty5, binding15, null);
				textBlock37.TextDecorations = TextDecorations.Underline;
				AvaloniaProperty foregroundProperty4 = TextBlock.ForegroundProperty;
				CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(TemplatedControl.ForegroundProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).Build());
				IServiceProvider provider17 = context;
				context.ProvideTargetProperty = TextBlock.ForegroundProperty;
				IBinding binding16 = compiledBindingExtension17.ProvideValue(provider17);
				context.ProvideTargetProperty = null;
				textBlock37.Bind(foregroundProperty4, binding16, null);
				textBlock37.VerticalAlignment = VerticalAlignment.Center;
				textBlock37.HorizontalAlignment = HorizontalAlignment.Stretch;
				textBlock37.Opacity = 0.9;
				textBlock37.FontWeight = FontWeight.Light;
				context.PopParent();
				supportInitialize42.EndInit();
				AvaloniaList<Control> children43 = grid62.Children;
				Button button9;
				Button button8 = button9 = new Button();
				((ISupportInitialize)button8).BeginInit();
				children43.Add(button8);
				ISupportInitialize supportInitialize43 = button3 = button9;
				context.PushParent(button3);
				Button button10 = button3;
				Grid.SetColumn(button10, 1);
				button10.Background = new ImmutableSolidColorBrush(16777215U);
				button10.VerticalAlignment = VerticalAlignment.Center;
				button10.HorizontalAlignment = HorizontalAlignment.Left;
				Viewbox viewbox9;
				Viewbox viewbox8 = viewbox9 = new Viewbox();
				((ISupportInitialize)viewbox8).BeginInit();
				button10.Content = viewbox8;
				ISupportInitialize supportInitialize44 = viewbox3 = viewbox9;
				context.PushParent(viewbox3);
				Viewbox viewbox10 = viewbox3;
				viewbox10.Width = 10.0;
				Path path9;
				Path path8 = path9 = new Path();
				((ISupportInitialize)path8).BeginInit();
				viewbox10.Child = path8;
				ISupportInitialize supportInitialize45 = path3 = path9;
				context.PushParent(path3);
				Path path10 = path3;
				StaticResourceExtension staticResourceExtension15 = new StaticResourceExtension("Copy");
				IServiceProvider serviceProvider15 = context;
				context.ProvideTargetProperty = Path.DataProperty;
				object obj16 = staticResourceExtension15.ProvideValue(serviceProvider15);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_2(path10, obj16);
				path10.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
				path10.Opacity = 0.5;
				context.PopParent();
				supportInitialize45.EndInit();
				context.PopParent();
				supportInitialize44.EndInit();
				context.PopParent();
				supportInitialize43.EndInit();
				context.PopParent();
				supportInitialize41.EndInit();
				context.PopParent();
				supportInitialize40.EndInit();
				context.PopParent();
				supportInitialize38.EndInit();
				context.PopParent();
				supportInitialize37.EndInit();
				AvaloniaList<Control> children44 = grid53.Children;
				Grid grid64;
				Grid grid63 = grid64 = new Grid();
				((ISupportInitialize)grid63).BeginInit();
				children44.Add(grid63);
				ISupportInitialize supportInitialize46 = grid = grid64;
				context.PushParent(grid);
				Grid grid65 = grid;
				Grid.SetRow(grid65, 1);
				AvaloniaProperty isVisibleProperty6 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Ancestor(typeof(CoinSpecificPartView), 0).Property(StyledElement.DataContextProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).TypeCast<CoinSpecificPartViewModel>().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider18 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding17 = compiledBindingExtension18.ProvideValue(provider18);
				context.ProvideTargetProperty = null;
				grid65.Bind(isVisibleProperty6, binding17, null);
				ColumnDefinitions columnDefinitions11 = new ColumnDefinitions();
				columnDefinitions11.Capacity = 2;
				columnDefinitions11.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				columnDefinitions11.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid65.ColumnDefinitions = columnDefinitions11;
				grid65.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children45 = grid65.Children;
				Border border27;
				Border border26 = border27 = new Border();
				((ISupportInitialize)border26).BeginInit();
				children45.Add(border26);
				Border border28 = border27;
				Grid.SetColumn(border28, 0);
				border28.Height = 26.0;
				border28.Width = 2.0;
				border28.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
				border28.Background = new ImmutableSolidColorBrush(872415231U);
				border28.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
				border28.VerticalAlignment = VerticalAlignment.Center;
				((ISupportInitialize)border28).EndInit();
				AvaloniaList<Control> children46 = grid65.Children;
				Grid grid67;
				Grid grid66 = grid67 = new Grid();
				((ISupportInitialize)grid66).BeginInit();
				children46.Add(grid66);
				ISupportInitialize supportInitialize47 = grid = grid67;
				context.PushParent(grid);
				Grid grid68 = grid;
				Grid.SetColumn(grid68, 1);
				RowDefinitions rowDefinitions10 = new RowDefinitions();
				rowDefinitions10.Capacity = 2;
				rowDefinitions10.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
				rowDefinitions10.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid68.RowDefinitions = rowDefinitions10;
				AvaloniaList<Control> children47 = grid68.Children;
				TextBlock textBlock39;
				TextBlock textBlock38 = textBlock39 = new TextBlock();
				((ISupportInitialize)textBlock38).BeginInit();
				children47.Add(textBlock38);
				ISupportInitialize supportInitialize48 = textBlock3 = textBlock39;
				context.PushParent(textBlock3);
				TextBlock textBlock40 = textBlock3;
				Grid.SetRow(textBlock40, 0);
				textBlock40.FontSize = 11.0;
				StaticResourceExtension staticResourceExtension16 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider16 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj17 = staticResourceExtension16.ProvideValue(serviceProvider16);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock40, obj17);
				textBlock40.Text = "Now";
				textBlock40.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock40.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
				textBlock40.Opacity = 0.5;
				textBlock40.FontWeight = FontWeight.Normal;
				context.PopParent();
				supportInitialize48.EndInit();
				AvaloniaList<Control> children48 = grid68.Children;
				TextBlock textBlock42;
				TextBlock textBlock41 = textBlock42 = new TextBlock();
				((ISupportInitialize)textBlock41).BeginInit();
				children48.Add(textBlock41);
				ISupportInitialize supportInitialize49 = textBlock3 = textBlock42;
				context.PushParent(textBlock3);
				TextBlock textBlock43 = textBlock3;
				Grid.SetRow(textBlock43, 1);
				textBlock43.FontSize = 14.0;
				StaticResourceExtension staticResourceExtension17 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider17 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj18 = staticResourceExtension17.ProvideValue(serviceProvider17);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock43, obj18);
				textBlock43.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				AvaloniaProperty textProperty6 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.PriceNowString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider19 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding18 = compiledBindingExtension19.ProvideValue(provider19);
				context.ProvideTargetProperty = null;
				textBlock43.Bind(textProperty6, binding18, null);
				textBlock43.Opacity = 0.9;
				textBlock43.FontWeight = FontWeight.Light;
				context.PopParent();
				supportInitialize49.EndInit();
				context.PopParent();
				supportInitialize47.EndInit();
				context.PopParent();
				supportInitialize46.EndInit();
				context.PopParent();
				supportInitialize36.EndInit();
				AvaloniaList<Control> children49 = grid29.Children;
				Grid grid70;
				Grid grid69 = grid70 = new Grid();
				((ISupportInitialize)grid69).BeginInit();
				children49.Add(grid69);
				ISupportInitialize supportInitialize50 = grid = grid70;
				context.PushParent(grid);
				Grid grid71 = grid;
				Grid.SetColumn(grid71, 2);
				RowDefinitions rowDefinitions11 = new RowDefinitions();
				rowDefinitions11.Capacity = 2;
				rowDefinitions11.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				rowDefinitions11.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid71.RowDefinitions = rowDefinitions11;
				AvaloniaList<Control> children50 = grid71.Children;
				Grid grid73;
				Grid grid72 = grid73 = new Grid();
				((ISupportInitialize)grid72).BeginInit();
				children50.Add(grid72);
				ISupportInitialize supportInitialize51 = grid = grid73;
				context.PushParent(grid);
				Grid grid74 = grid;
				Grid.SetRow(grid74, 0);
				ColumnDefinitions columnDefinitions12 = new ColumnDefinitions();
				columnDefinitions12.Capacity = 2;
				columnDefinitions12.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				columnDefinitions12.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid74.ColumnDefinitions = columnDefinitions12;
				grid74.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children51 = grid74.Children;
				Border border30;
				Border border29 = border30 = new Border();
				((ISupportInitialize)border29).BeginInit();
				children51.Add(border29);
				Border border31 = border30;
				Grid.SetColumn(border31, 0);
				border31.Height = 26.0;
				border31.Width = 2.0;
				border31.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
				border31.Background = new ImmutableSolidColorBrush(872415231U);
				border31.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
				border31.VerticalAlignment = VerticalAlignment.Center;
				((ISupportInitialize)border31).EndInit();
				AvaloniaList<Control> children52 = grid74.Children;
				Grid grid76;
				Grid grid75 = grid76 = new Grid();
				((ISupportInitialize)grid75).BeginInit();
				children52.Add(grid75);
				ISupportInitialize supportInitialize52 = grid = grid76;
				context.PushParent(grid);
				Grid grid77 = grid;
				Grid.SetColumn(grid77, 1);
				RowDefinitions rowDefinitions12 = new RowDefinitions();
				rowDefinitions12.Capacity = 2;
				rowDefinitions12.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
				rowDefinitions12.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid77.RowDefinitions = rowDefinitions12;
				AvaloniaList<Control> children53 = grid77.Children;
				TextBlock textBlock45;
				TextBlock textBlock44 = textBlock45 = new TextBlock();
				((ISupportInitialize)textBlock44).BeginInit();
				children53.Add(textBlock44);
				ISupportInitialize supportInitialize53 = textBlock3 = textBlock45;
				context.PushParent(textBlock3);
				TextBlock textBlock46 = textBlock3;
				Grid.SetRow(textBlock46, 0);
				textBlock46.FontSize = 11.0;
				StaticResourceExtension staticResourceExtension18 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider18 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj19 = staticResourceExtension18.ProvideValue(serviceProvider18);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock46, obj19);
				textBlock46.Text = "From";
				textBlock46.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock46.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
				textBlock46.Opacity = 0.5;
				textBlock46.FontWeight = FontWeight.Normal;
				context.PopParent();
				supportInitialize53.EndInit();
				AvaloniaList<Control> children54 = grid77.Children;
				TextBlock textBlock48;
				TextBlock textBlock47 = textBlock48 = new TextBlock();
				((ISupportInitialize)textBlock47).BeginInit();
				children54.Add(textBlock47);
				ISupportInitialize supportInitialize54 = textBlock3 = textBlock48;
				context.PushParent(textBlock3);
				TextBlock textBlock49 = textBlock3;
				Grid.SetRow(textBlock49, 1);
				textBlock49.FontSize = 14.0;
				StaticResourceExtension staticResourceExtension19 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider19 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj20 = staticResourceExtension19.ProvideValue(serviceProvider19);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_1(textBlock49, obj20);
				AvaloniaProperty textProperty7 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.From!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider20 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding19 = compiledBindingExtension20.ProvideValue(provider20);
				context.ProvideTargetProperty = null;
				textBlock49.Bind(textProperty7, binding19, null);
				textBlock49.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock49.Opacity = 0.9;
				textBlock49.FontWeight = FontWeight.Light;
				context.PopParent();
				supportInitialize54.EndInit();
				context.PopParent();
				supportInitialize52.EndInit();
				context.PopParent();
				supportInitialize51.EndInit();
				AvaloniaList<Control> children55 = grid71.Children;
				Grid grid79;
				Grid grid78 = grid79 = new Grid();
				((ISupportInitialize)grid78).BeginInit();
				children55.Add(grid78);
				Grid grid80 = grid79;
				Grid.SetRow(grid80, 1);
				grid80.VerticalAlignment = VerticalAlignment.Stretch;
				((ISupportInitialize)grid80).EndInit();
				context.PopParent();
				supportInitialize50.EndInit();
				context.PopParent();
				supportInitialize22.EndInit();
				AvaloniaList<Control> children56 = grid26.Children;
				Grid grid82;
				Grid grid81 = grid82 = new Grid();
				((ISupportInitialize)grid81).BeginInit();
				children56.Add(grid81);
				ISupportInitialize supportInitialize55 = grid = grid82;
				context.PushParent(grid);
				Grid grid83 = grid;
				Grid.SetRow(grid83, 1);
				Grid.SetColumn(grid83, 0);
				Grid.SetColumnSpan(grid83, 2);
				grid83.HorizontalAlignment = HorizontalAlignment.Stretch;
				grid83.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
				AvaloniaList<Control> children57 = grid83.Children;
				Border border33;
				Border border32 = border33 = new Border();
				((ISupportInitialize)border32).BeginInit();
				children57.Add(border32);
				ISupportInitialize supportInitialize56 = border6 = border33;
				context.PushParent(border6);
				Border border34 = border6;
				border34.HorizontalAlignment = HorizontalAlignment.Stretch;
				border34.Height = 40.0;
				border34.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
				border34.Background = new ImmutableSolidColorBrush(4280230179U);
				Grid grid85;
				Grid grid84 = grid85 = new Grid();
				((ISupportInitialize)grid84).BeginInit();
				border34.Child = grid84;
				ISupportInitialize supportInitialize57 = grid = grid85;
				context.PushParent(grid);
				Grid grid86 = grid;
				ColumnDefinitions columnDefinitions13 = new ColumnDefinitions();
				columnDefinitions13.Capacity = 2;
				columnDefinitions13.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				columnDefinitions13.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				grid86.ColumnDefinitions = columnDefinitions13;
				grid86.Margin = new Thickness(5.0, 0.0, 5.0, 0.0);
				AvaloniaList<Control> children58 = grid86.Children;
				TextBox textBox2;
				TextBox textBox = textBox2 = new TextBox();
				((ISupportInitialize)textBox).BeginInit();
				children58.Add(textBox);
				TextBox textBox3;
				ISupportInitialize supportInitialize58 = textBox3 = textBox2;
				context.PushParent(textBox3);
				TextBox textBox4 = textBox3;
				Grid.SetColumn(textBox4, 0);
				textBox4.Background = new ImmutableSolidColorBrush(4280230179U);
				textBox4.BorderBrush = new ImmutableSolidColorBrush(4280230179U);
				textBox4.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
				textBox4.Watermark = "Personal note";
				textBox4.VerticalAlignment = VerticalAlignment.Center;
				textBox4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
				textBox4.VerticalContentAlignment = VerticalAlignment.Center;
				textBox4.HorizontalAlignment = HorizontalAlignment.Stretch;
				textBox4.HorizontalContentAlignment = HorizontalAlignment.Stretch;
				textBox4.FontSize = 14.0;
				StaticResourceExtension staticResourceExtension20 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider20 = context;
				context.ProvideTargetProperty = TemplatedControl.FontFamilyProperty;
				object obj21 = staticResourceExtension20.ProvideValue(serviceProvider20);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_3(textBox4, obj21);
				textBox4.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBox4.Opacity = 0.8;
				textBox4.Margin = new Thickness(0.0, 0.0, 7.0, 0.0);
				textBox4.FontWeight = FontWeight.Normal;
				context.PopParent();
				supportInitialize58.EndInit();
				AvaloniaList<Control> children59 = grid86.Children;
				Border border36;
				Border border35 = border36 = new Border();
				((ISupportInitialize)border35).BeginInit();
				children59.Add(border35);
				ISupportInitialize supportInitialize59 = border6 = border36;
				context.PushParent(border6);
				Border border37 = border6;
				Grid.SetColumn(border37, 1);
				border37.CornerRadius = new CornerRadius(120.0, 120.0, 120.0, 120.0);
				border37.VerticalAlignment = VerticalAlignment.Center;
				border37.Margin = new Thickness(0.0, 0.0, 6.0, 0.0);
				border37.Background = new ImmutableSolidColorBrush(4281217075U);
				border37.Width = 22.0;
				border37.Height = 22.0;
				Viewbox viewbox12;
				Viewbox viewbox11 = viewbox12 = new Viewbox();
				((ISupportInitialize)viewbox11).BeginInit();
				border37.Child = viewbox11;
				ISupportInitialize supportInitialize60 = viewbox3 = viewbox12;
				context.PushParent(viewbox3);
				Viewbox viewbox13 = viewbox3;
				viewbox13.VerticalAlignment = VerticalAlignment.Center;
				viewbox13.Width = 4.5;
				viewbox13.HorizontalAlignment = HorizontalAlignment.Center;
				Path path12;
				Path path11 = path12 = new Path();
				((ISupportInitialize)path11).BeginInit();
				viewbox13.Child = path11;
				ISupportInitialize supportInitialize61 = path3 = path12;
				context.PushParent(path3);
				Path path13 = path3;
				StaticResourceExtension staticResourceExtension21 = new StaticResourceExtension("IIcon");
				IServiceProvider serviceProvider21 = context;
				context.ProvideTargetProperty = Path.DataProperty;
				object obj22 = staticResourceExtension21.ProvideValue(serviceProvider21);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_65.DynamicSetters_66.DynamicSetter_2(path13, obj22);
				path13.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
				path13.Opacity = 0.5;
				path13.Stretch = Stretch.UniformToFill;
				context.PopParent();
				supportInitialize61.EndInit();
				context.PopParent();
				supportInitialize60.EndInit();
				context.PopParent();
				supportInitialize59.EndInit();
				context.PopParent();
				supportInitialize57.EndInit();
				context.PopParent();
				supportInitialize56.EndInit();
				context.PopParent();
				supportInitialize55.EndInit();
				context.PopParent();
				supportInitialize21.EndInit();
				context.PopParent();
				supportInitialize20.EndInit();
				context.PopParent();
				supportInitialize2.EndInit();
				context.PopParent();
				supportInitialize.EndInit();
				AvaloniaList<Control> children60 = grid2.Children;
				Border border39;
				Border border38 = border39 = new Border();
				((ISupportInitialize)border38).BeginInit();
				children60.Add(border38);
				Border border40 = border39;
				Grid.SetRow(border40, 2);
				border40.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
				border40.Height = 1.0;
				border40.HorizontalAlignment = HorizontalAlignment.Stretch;
				border40.Background = new ImmutableSolidColorBrush(uint.MaxValue);
				border40.Opacity = 0.08;
				((ISupportInitialize)border40).EndInit();
				context.PopParent();
				((ISupportInitialize)intermediateRoot).EndInit();
				return intermediateRoot;
			}

			// Token: 0x02000016 RID: 22
			private class DynamicSetters_66
			{
				// Token: 0x0600002F RID: 47 RVA: 0x00010618 File Offset: 0x0000E818
				public static void DynamicSetter_1(TextBlock A_0, object A_1)
				{
					if (A_1 is UnsetValueType)
					{
						A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
						return;
					}
					if (A_1 is IBinding)
					{
						A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
						return;
					}
					if (A_1 is FontFamily)
					{
						A_0.FontFamily = A_1;
						return;
					}
					if (A_1 == null)
					{
						A_0.FontFamily = A_1;
						return;
					}
					throw new InvalidCastException();
				}

				// Token: 0x06000030 RID: 48 RVA: 0x00010684 File Offset: 0x0000E884
				public static void DynamicSetter_2(Path A_0, object A_1)
				{
					if (A_1 is UnsetValueType)
					{
						A_0.SetValue(Path.DataProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
						return;
					}
					if (A_1 is IBinding)
					{
						A_0.Bind(Path.DataProperty, A_1, null);
						return;
					}
					if (A_1 is Geometry)
					{
						A_0.Data = A_1;
						return;
					}
					if (A_1 == null)
					{
						A_0.Data = A_1;
						return;
					}
					throw new InvalidCastException();
				}

				// Token: 0x06000031 RID: 49 RVA: 0x000106F0 File Offset: 0x0000E8F0
				public static void DynamicSetter_3(TemplatedControl A_0, object A_1)
				{
					if (A_1 is UnsetValueType)
					{
						A_0.SetValue(TemplatedControl.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
						return;
					}
					if (A_1 is IBinding)
					{
						A_0.Bind(TemplatedControl.FontFamilyProperty, A_1, null);
						return;
					}
					if (A_1 is FontFamily)
					{
						A_0.FontFamily = A_1;
						return;
					}
					if (A_1 == null)
					{
						A_0.FontFamily = A_1;
						return;
					}
					throw new InvalidCastException();
				}
			}
		}

		// Token: 0x02000017 RID: 23
		private class XamlClosure_67
		{
			// Token: 0x06000032 RID: 50 RVA: 0x0001075C File Offset: 0x0000E95C
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<CoinSpecificPartView> context = new XamlIlContext.Context<CoinSpecificPartView>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.Singleton
				}, "avares://Exodus/Views/CoinSpecificPartView.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (CoinSpecificPartView)obj;
					}
				}
				context.IntermediateRoot = new StackPanel();
				object intermediateRoot = context.IntermediateRoot;
				((ISupportInitialize)intermediateRoot).BeginInit();
				intermediateRoot.Spacing = -5.0;
				((ISupportInitialize)intermediateRoot).EndInit();
				return intermediateRoot;
			}
		}

		// Token: 0x02000018 RID: 24
		private class XamlClosure_68
		{
			// Token: 0x06000033 RID: 51 RVA: 0x000107EC File Offset: 0x0000E9EC
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<CoinSpecificPartView> context = new XamlIlContext.Context<CoinSpecificPartView>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.Singleton
				}, "avares://Exodus/Views/CoinSpecificPartView.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (CoinSpecificPartView)obj;
					}
				}
				context.IntermediateRoot = new Grid();
				object intermediateRoot = context.IntermediateRoot;
				((ISupportInitialize)intermediateRoot).BeginInit();
				Grid grid = intermediateRoot;
				context.PushParent(grid);
				Grid grid2 = grid;
				AvaloniaProperty isVisibleProperty = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.IsThereTransaction!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding = compiledBindingExtension.ProvideValue(provider);
				context.ProvideTargetProperty = null;
				grid2.Bind(isVisibleProperty, binding, null);
				RowDefinitions rowDefinitions = new RowDefinitions();
				rowDefinitions.Capacity = 2;
				rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
				rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid2.RowDefinitions = rowDefinitions;
				grid2.Margin = new Thickness(0.0, 40.0, 0.0, 0.0);
				AvaloniaList<Control> children = grid2.Children;
				TextBlock textBlock2;
				TextBlock textBlock = textBlock2 = new TextBlock();
				((ISupportInitialize)textBlock).BeginInit();
				children.Add(textBlock);
				TextBlock textBlock3;
				ISupportInitialize supportInitialize = textBlock3 = textBlock2;
				context.PushParent(textBlock3);
				TextBlock textBlock4 = textBlock3;
				Grid.SetRow(textBlock4, 0);
				textBlock4.FontSize = 15.0;
				textBlock4.Opacity = 0.25;
				textBlock4.Margin = new Thickness(15.0, 0.0, 0.0, 7.0);
				StaticResourceExtension staticResourceExtension = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj2 = staticResourceExtension.ProvideValue(serviceProvider);
				context.ProvideTargetProperty = null;
				CoinSpecificPartView.XamlClosure_68.DynamicSetters_69.DynamicSetter_1(textBlock4, obj2);
				AvaloniaProperty textProperty = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.DateTitle!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider2 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding2 = compiledBindingExtension2.ProvideValue(provider2);
				context.ProvideTargetProperty = null;
				textBlock4.Bind(textProperty, binding2, null);
				textBlock4.VerticalAlignment = VerticalAlignment.Center;
				textBlock4.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock4.FontWeight = FontWeight.Normal;
				context.PopParent();
				supportInitialize.EndInit();
				AvaloniaList<Control> children2 = grid2.Children;
				ItemsControl itemsControl2;
				ItemsControl itemsControl = itemsControl2 = new ItemsControl();
				((ISupportInitialize)itemsControl).BeginInit();
				children2.Add(itemsControl);
				ItemsControl itemsControl3;
				ISupportInitialize supportInitialize2 = itemsControl3 = itemsControl2;
				context.PushParent(itemsControl3);
				ItemsControl itemsControl4 = itemsControl3;
				Grid.SetRow(itemsControl4, 1);
				AvaloniaProperty itemsSourceProperty = ItemsControl.ItemsSourceProperty;
				CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.TransactionGroup,Exodus.Transactions!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider3 = context;
				context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
				IBinding binding3 = compiledBindingExtension3.ProvideValue(provider3);
				context.ProvideTargetProperty = null;
				itemsControl4.Bind(itemsSourceProperty, binding3, null);
				itemsControl4.HorizontalAlignment = HorizontalAlignment.Stretch;
				itemsControl4.VerticalAlignment = VerticalAlignment.Top;
				AvaloniaProperty foregroundProperty = TemplatedControl.ForegroundProperty;
				CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(StyledElement.DataContextProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).TypeCast<CoinSpecificPartViewModel>().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider4 = context;
				context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
				IBinding binding4 = compiledBindingExtension4.ProvideValue(provider4);
				context.ProvideTargetProperty = null;
				itemsControl4.Bind(foregroundProperty, binding4, null);
				itemsControl4.ItemsPanel = new ItemsPanelTemplate
				{
					Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(CoinSpecificPartView.XamlClosure_68.XamlClosure_70.Build), context)
				};
				DataTemplate dataTemplate;
				IDataTemplate itemTemplate = dataTemplate = new DataTemplate();
				context.PushParent(dataTemplate);
				dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(CoinSpecificPartView.XamlClosure_68.XamlClosure_71.Build), context);
				context.PopParent();
				itemsControl4.ItemTemplate = itemTemplate;
				context.PopParent();
				supportInitialize2.EndInit();
				context.PopParent();
				((ISupportInitialize)intermediateRoot).EndInit();
				return intermediateRoot;
			}

			// Token: 0x02000019 RID: 25
			private class DynamicSetters_69
			{
				// Token: 0x06000034 RID: 52 RVA: 0x00010BBC File Offset: 0x0000EDBC
				public static void DynamicSetter_1(TextBlock A_0, object A_1)
				{
					if (A_1 is UnsetValueType)
					{
						A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
						return;
					}
					if (A_1 is IBinding)
					{
						A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
						return;
					}
					if (A_1 is FontFamily)
					{
						A_0.FontFamily = A_1;
						return;
					}
					if (A_1 == null)
					{
						A_0.FontFamily = A_1;
						return;
					}
					throw new InvalidCastException();
				}
			}

			// Token: 0x0200001A RID: 26
			private class XamlClosure_70
			{
				// Token: 0x06000035 RID: 53 RVA: 0x00010C28 File Offset: 0x0000EE28
				public static object Build(IServiceProvider A_0)
				{
					XamlIlContext.Context<CoinSpecificPartView> context = new XamlIlContext.Context<CoinSpecificPartView>(A_0, new object[]
					{
						(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.Singleton
					}, "avares://Exodus/Views/CoinSpecificPartView.axaml");
					if (A_0 != null)
					{
						object obj = A_0.GetService(typeof(IRootObjectProvider));
						if (obj != null)
						{
							obj = ((IRootObjectProvider)obj).RootObject;
							context.RootObject = (CoinSpecificPartView)obj;
						}
					}
					context.IntermediateRoot = new StackPanel();
					object intermediateRoot = context.IntermediateRoot;
					((ISupportInitialize)intermediateRoot).BeginInit();
					intermediateRoot.Spacing = -5.0;
					((ISupportInitialize)intermediateRoot).EndInit();
					return intermediateRoot;
				}
			}

			// Token: 0x0200001B RID: 27
			private class XamlClosure_71
			{
				// Token: 0x06000036 RID: 54 RVA: 0x00010CB8 File Offset: 0x0000EEB8
				public static object Build(IServiceProvider A_0)
				{
					XamlIlContext.Context<CoinSpecificPartView> context = new XamlIlContext.Context<CoinSpecificPartView>(A_0, new object[]
					{
						(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/CoinSpecificPartView.axaml.Singleton
					}, "avares://Exodus/Views/CoinSpecificPartView.axaml");
					if (A_0 != null)
					{
						object obj = A_0.GetService(typeof(IRootObjectProvider));
						if (obj != null)
						{
							obj = ((IRootObjectProvider)obj).RootObject;
							context.RootObject = (CoinSpecificPartView)obj;
						}
					}
					context.IntermediateRoot = new Grid();
					object intermediateRoot = context.IntermediateRoot;
					((ISupportInitialize)intermediateRoot).BeginInit();
					Grid grid = intermediateRoot;
					context.PushParent(grid);
					Grid grid2 = grid;
					RowDefinitions rowDefinitions = new RowDefinitions();
					rowDefinitions.Capacity = 3;
					rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
					rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
					grid2.RowDefinitions = rowDefinitions;
					grid2.Margin = new Thickness(0.0, 2.0, 25.0, 2.0);
					AvaloniaList<Control> children = grid2.Children;
					Border border2;
					Border border = border2 = new Border();
					((ISupportInitialize)border).BeginInit();
					children.Add(border);
					Border border3 = border2;
					Grid.SetRow(border3, 0);
					border3.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
					border3.Height = 1.0;
					border3.HorizontalAlignment = HorizontalAlignment.Stretch;
					border3.Background = new ImmutableSolidColorBrush(uint.MaxValue);
					border3.Opacity = 0.08;
					((ISupportInitialize)border3).EndInit();
					AvaloniaList<Control> children2 = grid2.Children;
					Border border5;
					Border border4 = border5 = new Border();
					((ISupportInitialize)border4).BeginInit();
					children2.Add(border4);
					Border border6;
					ISupportInitialize supportInitialize = border6 = border5;
					context.PushParent(border6);
					Border border7 = border6;
					Grid.SetRow(border7, 1);
					border7.HorizontalAlignment = HorizontalAlignment.Stretch;
					Grid grid4;
					Grid grid3 = grid4 = new Grid();
					((ISupportInitialize)grid3).BeginInit();
					border7.Child = grid3;
					ISupportInitialize supportInitialize2 = grid = grid4;
					context.PushParent(grid);
					Grid grid5 = grid;
					RowDefinitions rowDefinitions2 = new RowDefinitions();
					rowDefinitions2.Capacity = 2;
					rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
					rowDefinitions2.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid5.RowDefinitions = rowDefinitions2;
					grid5.HorizontalAlignment = HorizontalAlignment.Stretch;
					grid5.VerticalAlignment = VerticalAlignment.Top;
					AvaloniaList<Control> children3 = grid5.Children;
					Border border9;
					Border border8 = border9 = new Border();
					((ISupportInitialize)border8).BeginInit();
					children3.Add(border8);
					ISupportInitialize supportInitialize3 = border6 = border9;
					context.PushParent(border6);
					Border border10 = border6;
					Grid.SetRow(border10, 0);
					border10.HorizontalAlignment = HorizontalAlignment.Stretch;
					border10.Height = 46.0;
					Styles styles = border10.Styles;
					Style style;
					IStyle item = style = new Style();
					context.PushParent(style);
					Style style2 = style;
					style2.Selector = Selectors.OfType((Selector)null, typeof(Border));
					Setter setter2;
					SetterBase setter = setter2 = new Setter();
					context.PushParent(setter2);
					Setter setter3 = setter2;
					setter3.Property = Border.BackgroundProperty;
					CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.HeaderBackgroundColor!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider = context;
					context.ProvideTargetProperty = XamlIlHelpers.Avalonia.Styling.Setter,Avalonia.Base.Value!Property();
					object value = compiledBindingExtension.ProvideValue(provider);
					context.ProvideTargetProperty = null;
					setter3.Value = value;
					context.PopParent();
					style2.Add(setter);
					context.PopParent();
					styles.Add(item);
					Styles styles2 = border10.Styles;
					Style style3 = new Style();
					style3.Selector = Selectors.OfType((Selector)null, typeof(Border)).Class(":pointerover");
					style3.Add(new Setter
					{
						Property = Border.BackgroundProperty,
						Value = new ImmutableSolidColorBrush(637534208U)
					});
					styles2.Add(style3);
					Grid grid7;
					Grid grid6 = grid7 = new Grid();
					((ISupportInitialize)grid6).BeginInit();
					border10.Child = grid6;
					ISupportInitialize supportInitialize4 = grid = grid7;
					context.PushParent(grid);
					Grid grid8 = grid;
					ColumnDefinitions columnDefinitions = new ColumnDefinitions();
					columnDefinitions.Capacity = 3;
					columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					grid8.ColumnDefinitions = columnDefinitions;
					grid8.VerticalAlignment = VerticalAlignment.Stretch;
					grid8.HorizontalAlignment = HorizontalAlignment.Stretch;
					grid8.Margin = new Thickness(10.0, 0.0, 10.0, 0.0);
					AvaloniaList<Control> children4 = grid8.Children;
					StackPanel stackPanel2;
					StackPanel stackPanel = stackPanel2 = new StackPanel();
					((ISupportInitialize)stackPanel).BeginInit();
					children4.Add(stackPanel);
					StackPanel stackPanel3;
					ISupportInitialize supportInitialize5 = stackPanel3 = stackPanel2;
					context.PushParent(stackPanel3);
					StackPanel stackPanel4 = stackPanel3;
					Grid.SetColumn(stackPanel4, 0);
					stackPanel4.VerticalAlignment = VerticalAlignment.Center;
					stackPanel4.Orientation = Orientation.Horizontal;
					AvaloniaList<Control> children5 = stackPanel4.Children;
					Viewbox viewbox2;
					Viewbox viewbox = viewbox2 = new Viewbox();
					((ISupportInitialize)viewbox).BeginInit();
					children5.Add(viewbox);
					Viewbox viewbox3;
					ISupportInitialize supportInitialize6 = viewbox3 = viewbox2;
					context.PushParent(viewbox3);
					Viewbox viewbox4 = viewbox3;
					viewbox4.Width = 14.0;
					viewbox4.VerticalAlignment = VerticalAlignment.Center;
					viewbox4.Margin = new Thickness(0.0, 0.0, 10.0, 0.0);
					Path path2;
					Path path = path2 = new Path();
					((ISupportInitialize)path).BeginInit();
					viewbox4.Child = path;
					Path path3;
					ISupportInitialize supportInitialize7 = path3 = path2;
					context.PushParent(path3);
					Path path4 = path3;
					StaticResourceExtension staticResourceExtension = new StaticResourceExtension("Received");
					IServiceProvider serviceProvider = context;
					context.ProvideTargetProperty = Path.DataProperty;
					object obj2 = staticResourceExtension.ProvideValue(serviceProvider);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_1(path4, obj2);
					AvaloniaProperty fillProperty = Shape.FillProperty;
					CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(TemplatedControl.ForegroundProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).Build());
					IServiceProvider provider2 = context;
					context.ProvideTargetProperty = Shape.FillProperty;
					IBinding binding = compiledBindingExtension2.ProvideValue(provider2);
					context.ProvideTargetProperty = null;
					path4.Bind(fillProperty, binding, null);
					path4.Opacity = 0.9;
					path4.Stretch = Stretch.Uniform;
					context.PopParent();
					supportInitialize7.EndInit();
					context.PopParent();
					supportInitialize6.EndInit();
					AvaloniaList<Control> children6 = stackPanel4.Children;
					TextBlock textBlock2;
					TextBlock textBlock = textBlock2 = new TextBlock();
					((ISupportInitialize)textBlock).BeginInit();
					children6.Add(textBlock);
					TextBlock textBlock3;
					ISupportInitialize supportInitialize8 = textBlock3 = textBlock2;
					context.PushParent(textBlock3);
					TextBlock textBlock4 = textBlock3;
					textBlock4.FontSize = 15.0;
					StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("RobotoCondensedRegular");
					IServiceProvider serviceProvider2 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj3 = staticResourceExtension2.ProvideValue(serviceProvider2);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock4, obj3);
					textBlock4.Text = "Received";
					textBlock4.VerticalAlignment = VerticalAlignment.Center;
					AvaloniaProperty foregroundProperty = TextBlock.ForegroundProperty;
					CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(TemplatedControl.ForegroundProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).Build());
					IServiceProvider provider3 = context;
					context.ProvideTargetProperty = TextBlock.ForegroundProperty;
					IBinding binding2 = compiledBindingExtension3.ProvideValue(provider3);
					context.ProvideTargetProperty = null;
					textBlock4.Bind(foregroundProperty, binding2, null);
					textBlock4.FontWeight = FontWeight.Light;
					context.PopParent();
					supportInitialize8.EndInit();
					AvaloniaList<Control> children7 = stackPanel4.Children;
					TextBlock textBlock6;
					TextBlock textBlock5 = textBlock6 = new TextBlock();
					((ISupportInitialize)textBlock5).BeginInit();
					children7.Add(textBlock5);
					ISupportInitialize supportInitialize9 = textBlock3 = textBlock6;
					context.PushParent(textBlock3);
					TextBlock textBlock7 = textBlock3;
					textBlock7.FontSize = 14.5;
					textBlock7.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
					StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("RobotoCondensedRegular");
					IServiceProvider serviceProvider3 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj4 = staticResourceExtension3.ProvideValue(serviceProvider3);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock7, obj4);
					AvaloniaProperty textProperty = TextBlock.TextProperty;
					CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.SentDurationsAgo!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider4 = context;
					context.ProvideTargetProperty = TextBlock.TextProperty;
					IBinding binding3 = compiledBindingExtension4.ProvideValue(provider4);
					context.ProvideTargetProperty = null;
					textBlock7.Bind(textProperty, binding3, null);
					textBlock7.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					textBlock7.VerticalAlignment = VerticalAlignment.Center;
					textBlock7.Opacity = 0.9;
					textBlock7.FontWeight = FontWeight.Normal;
					context.PopParent();
					supportInitialize9.EndInit();
					context.PopParent();
					supportInitialize5.EndInit();
					AvaloniaList<Control> children8 = grid8.Children;
					Grid grid10;
					Grid grid9 = grid10 = new Grid();
					((ISupportInitialize)grid9).BeginInit();
					children8.Add(grid9);
					Grid grid11 = grid10;
					Grid.SetColumn(grid11, 1);
					grid11.HorizontalAlignment = HorizontalAlignment.Stretch;
					((ISupportInitialize)grid11).EndInit();
					AvaloniaList<Control> children9 = grid8.Children;
					Grid grid13;
					Grid grid12 = grid13 = new Grid();
					((ISupportInitialize)grid12).BeginInit();
					children9.Add(grid12);
					ISupportInitialize supportInitialize10 = grid = grid13;
					context.PushParent(grid);
					Grid grid14 = grid;
					Grid.SetColumn(grid14, 2);
					ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
					columnDefinitions2.Capacity = 2;
					columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					grid14.ColumnDefinitions = columnDefinitions2;
					AvaloniaList<Control> children10 = grid14.Children;
					StackPanel stackPanel6;
					StackPanel stackPanel5 = stackPanel6 = new StackPanel();
					((ISupportInitialize)stackPanel5).BeginInit();
					children10.Add(stackPanel5);
					ISupportInitialize supportInitialize11 = stackPanel3 = stackPanel6;
					context.PushParent(stackPanel3);
					StackPanel stackPanel7 = stackPanel3;
					Grid.SetColumn(stackPanel7, 0);
					stackPanel7.VerticalAlignment = VerticalAlignment.Center;
					stackPanel7.Orientation = Orientation.Horizontal;
					AvaloniaList<Control> children11 = stackPanel7.Children;
					Grid grid16;
					Grid grid15 = grid16 = new Grid();
					((ISupportInitialize)grid15).BeginInit();
					children11.Add(grid15);
					ISupportInitialize supportInitialize12 = grid = grid16;
					context.PushParent(grid);
					Grid grid17 = grid;
					ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
					columnDefinitions3.Capacity = 2;
					columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid17.ColumnDefinitions = columnDefinitions3;
					grid17.Margin = new Thickness(0.0, 0.0, 12.0, 0.0);
					AvaloniaList<Control> children12 = grid17.Children;
					TextBlock textBlock9;
					TextBlock textBlock8 = textBlock9 = new TextBlock();
					((ISupportInitialize)textBlock8).BeginInit();
					children12.Add(textBlock8);
					ISupportInitialize supportInitialize13 = textBlock3 = textBlock9;
					context.PushParent(textBlock3);
					TextBlock textBlock10 = textBlock3;
					Grid.SetColumn(textBlock10, 0);
					textBlock10.FontSize = 16.0;
					StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("RobotoCondensedRegular");
					IServiceProvider serviceProvider4 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj5 = staticResourceExtension4.ProvideValue(serviceProvider4);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock10, obj5);
					textBlock10.Text = "+";
					textBlock10.VerticalAlignment = VerticalAlignment.Center;
					textBlock10.Margin = new Thickness(0.0, 0.0, 1.0, 0.0);
					AvaloniaProperty foregroundProperty2 = TextBlock.ForegroundProperty;
					CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(TemplatedControl.ForegroundProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).Build());
					IServiceProvider provider5 = context;
					context.ProvideTargetProperty = TextBlock.ForegroundProperty;
					IBinding binding4 = compiledBindingExtension5.ProvideValue(provider5);
					context.ProvideTargetProperty = null;
					textBlock10.Bind(foregroundProperty2, binding4, null);
					textBlock10.Opacity = 0.8;
					textBlock10.FontWeight = FontWeight.Normal;
					context.PopParent();
					supportInitialize13.EndInit();
					AvaloniaList<Control> children13 = grid17.Children;
					TextBlock textBlock12;
					TextBlock textBlock11 = textBlock12 = new TextBlock();
					((ISupportInitialize)textBlock11).BeginInit();
					children13.Add(textBlock11);
					ISupportInitialize supportInitialize14 = textBlock3 = textBlock12;
					context.PushParent(textBlock3);
					TextBlock textBlock13 = textBlock3;
					Grid.SetColumn(textBlock13, 1);
					textBlock13.FontSize = 16.0;
					StaticResourceExtension staticResourceExtension5 = new StaticResourceExtension("RobotoCondensedRegular");
					IServiceProvider serviceProvider5 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj6 = staticResourceExtension5.ProvideValue(serviceProvider5);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock13, obj6);
					AvaloniaProperty textProperty2 = TextBlock.TextProperty;
					CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.FormattedAmount!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider6 = context;
					context.ProvideTargetProperty = TextBlock.TextProperty;
					IBinding binding5 = compiledBindingExtension6.ProvideValue(provider6);
					context.ProvideTargetProperty = null;
					textBlock13.Bind(textProperty2, binding5, null);
					textBlock13.VerticalAlignment = VerticalAlignment.Center;
					AvaloniaProperty foregroundProperty3 = TextBlock.ForegroundProperty;
					CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(TemplatedControl.ForegroundProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).Build());
					IServiceProvider provider7 = context;
					context.ProvideTargetProperty = TextBlock.ForegroundProperty;
					IBinding binding6 = compiledBindingExtension7.ProvideValue(provider7);
					context.ProvideTargetProperty = null;
					textBlock13.Bind(foregroundProperty3, binding6, null);
					textBlock13.Opacity = 0.8;
					textBlock13.FontWeight = FontWeight.Normal;
					context.PopParent();
					supportInitialize14.EndInit();
					context.PopParent();
					supportInitialize12.EndInit();
					AvaloniaList<Control> children14 = stackPanel7.Children;
					Button button2;
					Button button = button2 = new Button();
					((ISupportInitialize)button).BeginInit();
					children14.Add(button);
					Button button3;
					ISupportInitialize supportInitialize15 = button3 = button2;
					context.PushParent(button3);
					Button button4 = button3;
					AvaloniaProperty commandProperty = Button.CommandProperty;
					CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("ExpandCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.Models.Transaction+ExpandCommand_0!CommandExecuteTrampoline), null, null).Build());
					IServiceProvider provider8 = context;
					context.ProvideTargetProperty = Button.CommandProperty;
					IBinding binding7 = compiledBindingExtension8.ProvideValue(provider8);
					context.ProvideTargetProperty = null;
					button4.Bind(commandProperty, binding7, null);
					button4.Background = new ImmutableSolidColorBrush(16777215U);
					button4.VerticalAlignment = VerticalAlignment.Center;
					Grid grid19;
					Grid grid18 = grid19 = new Grid();
					((ISupportInitialize)grid18).BeginInit();
					button4.Content = grid18;
					ISupportInitialize supportInitialize16 = grid = grid19;
					context.PushParent(grid);
					Grid grid20 = grid;
					AvaloniaList<Control> children15 = grid20.Children;
					Viewbox viewbox6;
					Viewbox viewbox5 = viewbox6 = new Viewbox();
					((ISupportInitialize)viewbox5).BeginInit();
					children15.Add(viewbox5);
					ISupportInitialize supportInitialize17 = viewbox3 = viewbox6;
					context.PushParent(viewbox3);
					Viewbox viewbox7 = viewbox3;
					AvaloniaProperty isVisibleProperty = Visual.IsVisibleProperty;
					CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider9 = context;
					context.ProvideTargetProperty = Visual.IsVisibleProperty;
					IBinding binding8 = compiledBindingExtension9.ProvideValue(provider9);
					context.ProvideTargetProperty = null;
					viewbox7.Bind(isVisibleProperty, binding8, null);
					viewbox7.Width = 14.0;
					Path path6;
					Path path5 = path6 = new Path();
					((ISupportInitialize)path5).BeginInit();
					viewbox7.Child = path5;
					ISupportInitialize supportInitialize18 = path3 = path6;
					context.PushParent(path3);
					Path path7 = path3;
					StaticResourceExtension staticResourceExtension6 = new StaticResourceExtension("Collapse");
					IServiceProvider serviceProvider6 = context;
					context.ProvideTargetProperty = Path.DataProperty;
					object obj7 = staticResourceExtension6.ProvideValue(serviceProvider6);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_1(path7, obj7);
					path7.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
					path7.Opacity = 0.8;
					path7.Stretch = Stretch.Uniform;
					context.PopParent();
					supportInitialize18.EndInit();
					context.PopParent();
					supportInitialize17.EndInit();
					AvaloniaList<Control> children16 = grid20.Children;
					Viewbox viewbox9;
					Viewbox viewbox8 = viewbox9 = new Viewbox();
					((ISupportInitialize)viewbox8).BeginInit();
					children16.Add(viewbox8);
					ISupportInitialize supportInitialize19 = viewbox3 = viewbox9;
					context.PushParent(viewbox3);
					Viewbox viewbox10 = viewbox3;
					AvaloniaProperty isVisibleProperty2 = Visual.IsVisibleProperty;
					CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider10 = context;
					context.ProvideTargetProperty = Visual.IsVisibleProperty;
					IBinding binding9 = compiledBindingExtension10.ProvideValue(provider10);
					context.ProvideTargetProperty = null;
					viewbox10.Bind(isVisibleProperty2, binding9, null);
					viewbox10.Width = 14.0;
					Path path9;
					Path path8 = path9 = new Path();
					((ISupportInitialize)path8).BeginInit();
					viewbox10.Child = path8;
					ISupportInitialize supportInitialize20 = path3 = path9;
					context.PushParent(path3);
					Path path10 = path3;
					StaticResourceExtension staticResourceExtension7 = new StaticResourceExtension("Expand");
					IServiceProvider serviceProvider7 = context;
					context.ProvideTargetProperty = Path.DataProperty;
					object obj8 = staticResourceExtension7.ProvideValue(serviceProvider7);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_1(path10, obj8);
					path10.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
					path10.Opacity = 0.8;
					path10.Stretch = Stretch.Uniform;
					context.PopParent();
					supportInitialize20.EndInit();
					context.PopParent();
					supportInitialize19.EndInit();
					context.PopParent();
					supportInitialize16.EndInit();
					context.PopParent();
					supportInitialize15.EndInit();
					context.PopParent();
					supportInitialize11.EndInit();
					context.PopParent();
					supportInitialize10.EndInit();
					context.PopParent();
					supportInitialize4.EndInit();
					context.PopParent();
					supportInitialize3.EndInit();
					AvaloniaList<Control> children17 = grid5.Children;
					Grid grid22;
					Grid grid21 = grid22 = new Grid();
					((ISupportInitialize)grid21).BeginInit();
					children17.Add(grid21);
					ISupportInitialize supportInitialize21 = grid = grid22;
					context.PushParent(grid);
					Grid grid23 = grid;
					Grid.SetRow(grid23, 1);
					grid23.Background = new ImmutableSolidColorBrush(251658240U);
					grid23.Height = 175.0;
					grid23.HorizontalAlignment = HorizontalAlignment.Stretch;
					AvaloniaProperty isVisibleProperty3 = Visual.IsVisibleProperty;
					CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.IsExpanded!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider11 = context;
					context.ProvideTargetProperty = Visual.IsVisibleProperty;
					IBinding binding10 = compiledBindingExtension11.ProvideValue(provider11);
					context.ProvideTargetProperty = null;
					grid23.Bind(isVisibleProperty3, binding10, null);
					AvaloniaList<Control> children18 = grid23.Children;
					Grid grid25;
					Grid grid24 = grid25 = new Grid();
					((ISupportInitialize)grid24).BeginInit();
					children18.Add(grid24);
					ISupportInitialize supportInitialize22 = grid = grid25;
					context.PushParent(grid);
					Grid grid26 = grid;
					grid26.HorizontalAlignment = HorizontalAlignment.Stretch;
					grid26.Margin = new Thickness(25.0, 10.0, 25.0, 10.0);
					RowDefinitions rowDefinitions3 = new RowDefinitions();
					rowDefinitions3.Capacity = 2;
					rowDefinitions3.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					rowDefinitions3.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
					grid26.RowDefinitions = rowDefinitions3;
					ColumnDefinitions columnDefinitions4 = new ColumnDefinitions();
					columnDefinitions4.Capacity = 3;
					columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid26.ColumnDefinitions = columnDefinitions4;
					AvaloniaList<Control> children19 = grid26.Children;
					Grid grid28;
					Grid grid27 = grid28 = new Grid();
					((ISupportInitialize)grid27).BeginInit();
					children19.Add(grid27);
					ISupportInitialize supportInitialize23 = grid = grid28;
					context.PushParent(grid);
					Grid grid29 = grid;
					Grid.SetColumn(grid29, 0);
					Grid.SetColumnSpan(grid29, 3);
					Grid.SetRow(grid29, 0);
					ColumnDefinitions columnDefinitions5 = new ColumnDefinitions();
					columnDefinitions5.Capacity = 3;
					columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid29.ColumnDefinitions = columnDefinitions5;
					AvaloniaList<Control> children20 = grid29.Children;
					Grid grid31;
					Grid grid30 = grid31 = new Grid();
					((ISupportInitialize)grid30).BeginInit();
					children20.Add(grid30);
					ISupportInitialize supportInitialize24 = grid = grid31;
					context.PushParent(grid);
					Grid grid32 = grid;
					Grid.SetColumn(grid32, 0);
					RowDefinitions rowDefinitions4 = new RowDefinitions();
					rowDefinitions4.Capacity = 2;
					rowDefinitions4.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					rowDefinitions4.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid32.RowDefinitions = rowDefinitions4;
					grid32.HorizontalAlignment = HorizontalAlignment.Stretch;
					grid32.VerticalAlignment = VerticalAlignment.Stretch;
					AvaloniaList<Control> children21 = grid32.Children;
					Grid grid34;
					Grid grid33 = grid34 = new Grid();
					((ISupportInitialize)grid33).BeginInit();
					children21.Add(grid33);
					ISupportInitialize supportInitialize25 = grid = grid34;
					context.PushParent(grid);
					Grid grid35 = grid;
					Grid.SetRow(grid35, 0);
					ColumnDefinitions columnDefinitions6 = new ColumnDefinitions();
					columnDefinitions6.Capacity = 2;
					columnDefinitions6.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					columnDefinitions6.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid35.ColumnDefinitions = columnDefinitions6;
					grid35.VerticalAlignment = VerticalAlignment.Center;
					AvaloniaList<Control> children22 = grid35.Children;
					Border border12;
					Border border11 = border12 = new Border();
					((ISupportInitialize)border11).BeginInit();
					children22.Add(border11);
					Border border13 = border12;
					Grid.SetColumn(border13, 0);
					border13.Height = 26.0;
					border13.Width = 2.0;
					border13.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
					border13.Background = new ImmutableSolidColorBrush(872415231U);
					border13.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
					border13.VerticalAlignment = VerticalAlignment.Center;
					((ISupportInitialize)border13).EndInit();
					AvaloniaList<Control> children23 = grid35.Children;
					Grid grid37;
					Grid grid36 = grid37 = new Grid();
					((ISupportInitialize)grid36).BeginInit();
					children23.Add(grid36);
					ISupportInitialize supportInitialize26 = grid = grid37;
					context.PushParent(grid);
					Grid grid38 = grid;
					Grid.SetColumn(grid38, 1);
					RowDefinitions rowDefinitions5 = new RowDefinitions();
					rowDefinitions5.Capacity = 2;
					rowDefinitions5.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
					rowDefinitions5.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid38.RowDefinitions = rowDefinitions5;
					AvaloniaList<Control> children24 = grid38.Children;
					TextBlock textBlock15;
					TextBlock textBlock14 = textBlock15 = new TextBlock();
					((ISupportInitialize)textBlock14).BeginInit();
					children24.Add(textBlock14);
					ISupportInitialize supportInitialize27 = textBlock3 = textBlock15;
					context.PushParent(textBlock3);
					TextBlock textBlock16 = textBlock3;
					Grid.SetRow(textBlock16, 0);
					textBlock16.FontSize = 11.0;
					StaticResourceExtension staticResourceExtension8 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider8 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj9 = staticResourceExtension8.ProvideValue(serviceProvider8);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock16, obj9);
					textBlock16.Text = "Date";
					textBlock16.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					textBlock16.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
					textBlock16.Opacity = 0.5;
					textBlock16.FontWeight = FontWeight.Normal;
					context.PopParent();
					supportInitialize27.EndInit();
					AvaloniaList<Control> children25 = grid38.Children;
					TextBlock textBlock18;
					TextBlock textBlock17 = textBlock18 = new TextBlock();
					((ISupportInitialize)textBlock17).BeginInit();
					children25.Add(textBlock17);
					ISupportInitialize supportInitialize28 = textBlock3 = textBlock18;
					context.PushParent(textBlock3);
					TextBlock textBlock19 = textBlock3;
					Grid.SetRow(textBlock19, 1);
					textBlock19.FontSize = 14.0;
					StaticResourceExtension staticResourceExtension9 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider9 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj10 = staticResourceExtension9.ProvideValue(serviceProvider9);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock19, obj10);
					textBlock19.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					AvaloniaProperty textProperty3 = TextBlock.TextProperty;
					CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.TimeString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider12 = context;
					context.ProvideTargetProperty = TextBlock.TextProperty;
					IBinding binding11 = compiledBindingExtension12.ProvideValue(provider12);
					context.ProvideTargetProperty = null;
					textBlock19.Bind(textProperty3, binding11, null);
					textBlock19.Opacity = 0.9;
					textBlock19.FontWeight = FontWeight.Light;
					context.PopParent();
					supportInitialize28.EndInit();
					context.PopParent();
					supportInitialize26.EndInit();
					context.PopParent();
					supportInitialize25.EndInit();
					AvaloniaList<Control> children26 = grid32.Children;
					Grid grid40;
					Grid grid39 = grid40 = new Grid();
					((ISupportInitialize)grid39).BeginInit();
					children26.Add(grid39);
					ISupportInitialize supportInitialize29 = grid = grid40;
					context.PushParent(grid);
					Grid grid41 = grid;
					Grid.SetRow(grid41, 1);
					AvaloniaProperty isVisibleProperty4 = Visual.IsVisibleProperty;
					CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Ancestor(typeof(CoinSpecificPartView), 0).Property(StyledElement.DataContextProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).TypeCast<CoinSpecificPartViewModel>().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider13 = context;
					context.ProvideTargetProperty = Visual.IsVisibleProperty;
					IBinding binding12 = compiledBindingExtension13.ProvideValue(provider13);
					context.ProvideTargetProperty = null;
					grid41.Bind(isVisibleProperty4, binding12, null);
					ColumnDefinitions columnDefinitions7 = new ColumnDefinitions();
					columnDefinitions7.Capacity = 2;
					columnDefinitions7.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					columnDefinitions7.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid41.ColumnDefinitions = columnDefinitions7;
					grid41.VerticalAlignment = VerticalAlignment.Center;
					AvaloniaList<Control> children27 = grid41.Children;
					Border border15;
					Border border14 = border15 = new Border();
					((ISupportInitialize)border14).BeginInit();
					children27.Add(border14);
					Border border16 = border15;
					Grid.SetColumn(border16, 0);
					border16.Height = 26.0;
					border16.Width = 2.0;
					border16.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
					border16.Background = new ImmutableSolidColorBrush(872415231U);
					border16.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
					border16.VerticalAlignment = VerticalAlignment.Center;
					((ISupportInitialize)border16).EndInit();
					AvaloniaList<Control> children28 = grid41.Children;
					Grid grid43;
					Grid grid42 = grid43 = new Grid();
					((ISupportInitialize)grid42).BeginInit();
					children28.Add(grid42);
					ISupportInitialize supportInitialize30 = grid = grid43;
					context.PushParent(grid);
					Grid grid44 = grid;
					Grid.SetColumn(grid44, 1);
					RowDefinitions rowDefinitions6 = new RowDefinitions();
					rowDefinitions6.Capacity = 2;
					rowDefinitions6.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
					rowDefinitions6.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid44.RowDefinitions = rowDefinitions6;
					AvaloniaList<Control> children29 = grid44.Children;
					TextBlock textBlock21;
					TextBlock textBlock20 = textBlock21 = new TextBlock();
					((ISupportInitialize)textBlock20).BeginInit();
					children29.Add(textBlock20);
					ISupportInitialize supportInitialize31 = textBlock3 = textBlock21;
					context.PushParent(textBlock3);
					TextBlock textBlock22 = textBlock3;
					Grid.SetRow(textBlock22, 0);
					textBlock22.FontSize = 11.0;
					StaticResourceExtension staticResourceExtension10 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider10 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj11 = staticResourceExtension10.ProvideValue(serviceProvider10);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock22, obj11);
					textBlock22.Text = "To";
					textBlock22.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					textBlock22.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
					textBlock22.Opacity = 0.5;
					textBlock22.FontWeight = FontWeight.Normal;
					context.PopParent();
					supportInitialize31.EndInit();
					AvaloniaList<Control> children30 = grid44.Children;
					TextBlock textBlock24;
					TextBlock textBlock23 = textBlock24 = new TextBlock();
					((ISupportInitialize)textBlock23).BeginInit();
					children30.Add(textBlock23);
					ISupportInitialize supportInitialize32 = textBlock3 = textBlock24;
					context.PushParent(textBlock3);
					TextBlock textBlock25 = textBlock3;
					Grid.SetRow(textBlock25, 1);
					textBlock25.FontSize = 14.0;
					StaticResourceExtension staticResourceExtension11 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider11 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj12 = staticResourceExtension11.ProvideValue(serviceProvider11);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock25, obj12);
					textBlock25.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					AvaloniaProperty textProperty4 = TextBlock.TextProperty;
					CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.To!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider14 = context;
					context.ProvideTargetProperty = TextBlock.TextProperty;
					IBinding binding13 = compiledBindingExtension14.ProvideValue(provider14);
					context.ProvideTargetProperty = null;
					textBlock25.Bind(textProperty4, binding13, null);
					textBlock25.Opacity = 0.9;
					textBlock25.FontWeight = FontWeight.Light;
					context.PopParent();
					supportInitialize32.EndInit();
					context.PopParent();
					supportInitialize30.EndInit();
					context.PopParent();
					supportInitialize29.EndInit();
					AvaloniaList<Control> children31 = grid32.Children;
					Grid grid46;
					Grid grid45 = grid46 = new Grid();
					((ISupportInitialize)grid45).BeginInit();
					children31.Add(grid45);
					ISupportInitialize supportInitialize33 = grid = grid46;
					context.PushParent(grid);
					Grid grid47 = grid;
					Grid.SetRow(grid47, 1);
					AvaloniaProperty isVisibleProperty5 = Visual.IsVisibleProperty;
					CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(CoinSpecificPartView), 0).Property(StyledElement.DataContextProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).TypeCast<CoinSpecificPartViewModel>().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider15 = context;
					context.ProvideTargetProperty = Visual.IsVisibleProperty;
					IBinding binding14 = compiledBindingExtension15.ProvideValue(provider15);
					context.ProvideTargetProperty = null;
					grid47.Bind(isVisibleProperty5, binding14, null);
					ColumnDefinitions columnDefinitions8 = new ColumnDefinitions();
					columnDefinitions8.Capacity = 2;
					columnDefinitions8.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					columnDefinitions8.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid47.ColumnDefinitions = columnDefinitions8;
					grid47.VerticalAlignment = VerticalAlignment.Center;
					AvaloniaList<Control> children32 = grid47.Children;
					Border border18;
					Border border17 = border18 = new Border();
					((ISupportInitialize)border17).BeginInit();
					children32.Add(border17);
					Border border19 = border18;
					Grid.SetColumn(border19, 0);
					border19.Height = 26.0;
					border19.Width = 2.0;
					border19.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
					border19.Background = new ImmutableSolidColorBrush(872415231U);
					border19.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
					border19.VerticalAlignment = VerticalAlignment.Center;
					((ISupportInitialize)border19).EndInit();
					AvaloniaList<Control> children33 = grid47.Children;
					Grid grid49;
					Grid grid48 = grid49 = new Grid();
					((ISupportInitialize)grid48).BeginInit();
					children33.Add(grid48);
					ISupportInitialize supportInitialize34 = grid = grid49;
					context.PushParent(grid);
					Grid grid50 = grid;
					Grid.SetColumn(grid50, 1);
					RowDefinitions rowDefinitions7 = new RowDefinitions();
					rowDefinitions7.Capacity = 2;
					rowDefinitions7.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
					rowDefinitions7.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid50.RowDefinitions = rowDefinitions7;
					AvaloniaList<Control> children34 = grid50.Children;
					TextBlock textBlock27;
					TextBlock textBlock26 = textBlock27 = new TextBlock();
					((ISupportInitialize)textBlock26).BeginInit();
					children34.Add(textBlock26);
					ISupportInitialize supportInitialize35 = textBlock3 = textBlock27;
					context.PushParent(textBlock3);
					TextBlock textBlock28 = textBlock3;
					Grid.SetRow(textBlock28, 0);
					textBlock28.FontSize = 11.0;
					StaticResourceExtension staticResourceExtension12 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider12 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj13 = staticResourceExtension12.ProvideValue(serviceProvider12);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock28, obj13);
					textBlock28.Text = "Now";
					textBlock28.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					textBlock28.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
					textBlock28.Opacity = 0.5;
					textBlock28.FontWeight = FontWeight.Normal;
					context.PopParent();
					supportInitialize35.EndInit();
					AvaloniaList<Control> children35 = grid50.Children;
					TextBlock textBlock30;
					TextBlock textBlock29 = textBlock30 = new TextBlock();
					((ISupportInitialize)textBlock29).BeginInit();
					children35.Add(textBlock29);
					ISupportInitialize supportInitialize36 = textBlock3 = textBlock30;
					context.PushParent(textBlock3);
					TextBlock textBlock31 = textBlock3;
					Grid.SetRow(textBlock31, 1);
					textBlock31.FontSize = 14.0;
					StaticResourceExtension staticResourceExtension13 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider13 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj14 = staticResourceExtension13.ProvideValue(serviceProvider13);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock31, obj14);
					textBlock31.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					AvaloniaProperty textProperty5 = TextBlock.TextProperty;
					CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.PriceNowString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider16 = context;
					context.ProvideTargetProperty = TextBlock.TextProperty;
					IBinding binding15 = compiledBindingExtension16.ProvideValue(provider16);
					context.ProvideTargetProperty = null;
					textBlock31.Bind(textProperty5, binding15, null);
					textBlock31.Opacity = 0.9;
					textBlock31.FontWeight = FontWeight.Light;
					context.PopParent();
					supportInitialize36.EndInit();
					context.PopParent();
					supportInitialize34.EndInit();
					context.PopParent();
					supportInitialize33.EndInit();
					context.PopParent();
					supportInitialize24.EndInit();
					AvaloniaList<Control> children36 = grid29.Children;
					Grid grid52;
					Grid grid51 = grid52 = new Grid();
					((ISupportInitialize)grid51).BeginInit();
					children36.Add(grid51);
					ISupportInitialize supportInitialize37 = grid = grid52;
					context.PushParent(grid);
					Grid grid53 = grid;
					Grid.SetColumn(grid53, 1);
					RowDefinitions rowDefinitions8 = new RowDefinitions();
					rowDefinitions8.Capacity = 2;
					rowDefinitions8.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					rowDefinitions8.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid53.RowDefinitions = rowDefinitions8;
					AvaloniaList<Control> children37 = grid53.Children;
					Grid grid55;
					Grid grid54 = grid55 = new Grid();
					((ISupportInitialize)grid54).BeginInit();
					children37.Add(grid54);
					ISupportInitialize supportInitialize38 = grid = grid55;
					context.PushParent(grid);
					Grid grid56 = grid;
					Grid.SetRow(grid56, 0);
					ColumnDefinitions columnDefinitions9 = new ColumnDefinitions();
					columnDefinitions9.Capacity = 2;
					columnDefinitions9.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					columnDefinitions9.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid56.ColumnDefinitions = columnDefinitions9;
					grid56.VerticalAlignment = VerticalAlignment.Center;
					AvaloniaList<Control> children38 = grid56.Children;
					Border border21;
					Border border20 = border21 = new Border();
					((ISupportInitialize)border20).BeginInit();
					children38.Add(border20);
					Border border22 = border21;
					Grid.SetColumn(border22, 0);
					border22.Height = 26.0;
					border22.Width = 2.0;
					border22.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
					border22.Background = new ImmutableSolidColorBrush(872415231U);
					border22.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
					border22.VerticalAlignment = VerticalAlignment.Center;
					((ISupportInitialize)border22).EndInit();
					AvaloniaList<Control> children39 = grid56.Children;
					Grid grid58;
					Grid grid57 = grid58 = new Grid();
					((ISupportInitialize)grid57).BeginInit();
					children39.Add(grid57);
					ISupportInitialize supportInitialize39 = grid = grid58;
					context.PushParent(grid);
					Grid grid59 = grid;
					Grid.SetColumn(grid59, 1);
					RowDefinitions rowDefinitions9 = new RowDefinitions();
					rowDefinitions9.Capacity = 2;
					rowDefinitions9.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
					rowDefinitions9.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid59.RowDefinitions = rowDefinitions9;
					AvaloniaList<Control> children40 = grid59.Children;
					TextBlock textBlock33;
					TextBlock textBlock32 = textBlock33 = new TextBlock();
					((ISupportInitialize)textBlock32).BeginInit();
					children40.Add(textBlock32);
					ISupportInitialize supportInitialize40 = textBlock3 = textBlock33;
					context.PushParent(textBlock3);
					TextBlock textBlock34 = textBlock3;
					Grid.SetRow(textBlock34, 0);
					textBlock34.FontSize = 11.0;
					StaticResourceExtension staticResourceExtension14 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider14 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj15 = staticResourceExtension14.ProvideValue(serviceProvider14);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock34, obj15);
					textBlock34.Text = "Transaction ID";
					textBlock34.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					textBlock34.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
					textBlock34.Opacity = 0.5;
					textBlock34.FontWeight = FontWeight.Normal;
					context.PopParent();
					supportInitialize40.EndInit();
					AvaloniaList<Control> children41 = grid59.Children;
					Button button6;
					Button button5 = button6 = new Button();
					((ISupportInitialize)button5).BeginInit();
					children41.Add(button5);
					ISupportInitialize supportInitialize41 = button3 = button6;
					context.PushParent(button3);
					Button button7 = button3;
					Grid.SetRow(button7, 1);
					button7.Margin = new Thickness(0.0, 0.0, 0.0, 0.0);
					button7.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
					button7.Background = new ImmutableSolidColorBrush(16777215U);
					AvaloniaProperty commandProperty2 = Button.CommandProperty;
					CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("OpenTransactionLook", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.Models.Transaction+OpenTransactionLook_0!CommandExecuteTrampoline), null, null).Build());
					IServiceProvider provider17 = context;
					context.ProvideTargetProperty = Button.CommandProperty;
					IBinding binding16 = compiledBindingExtension17.ProvideValue(provider17);
					context.ProvideTargetProperty = null;
					button7.Bind(commandProperty2, binding16, null);
					Styles styles3 = button7.Styles;
					IStyle item2 = style = new Style();
					context.PushParent(style);
					Style style4 = style;
					style4.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pointerover");
					style4.Add(new Setter
					{
						Property = TemplatedControl.BackgroundProperty,
						Value = new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue()
					});
					SetterBase setter4 = setter2 = new Setter();
					context.PushParent(setter2);
					Setter setter5 = setter2;
					setter5.Property = Visual.RenderTransformProperty;
					setter5.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(0.999)");
					context.PopParent();
					style4.Add(setter4);
					context.PopParent();
					styles3.Add(item2);
					Styles styles4 = button7.Styles;
					IStyle item3 = style = new Style();
					context.PushParent(style);
					Style style5 = style;
					style5.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pressed");
					style5.Add(new Setter
					{
						Property = TemplatedControl.BackgroundProperty,
						Value = new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue()
					});
					SetterBase setter6 = setter2 = new Setter();
					context.PushParent(setter2);
					Setter setter7 = setter2;
					setter7.Property = Visual.RenderTransformProperty;
					setter7.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(0.998)");
					context.PopParent();
					style5.Add(setter6);
					context.PopParent();
					styles4.Add(item3);
					Grid grid61;
					Grid grid60 = grid61 = new Grid();
					((ISupportInitialize)grid60).BeginInit();
					button7.Content = grid60;
					ISupportInitialize supportInitialize42 = grid = grid61;
					context.PushParent(grid);
					Grid grid62 = grid;
					grid62.Margin = new Thickness(0.0, 0.0, 5.0, 0.0);
					ColumnDefinitions columnDefinitions10 = new ColumnDefinitions();
					columnDefinitions10.Capacity = 2;
					columnDefinitions10.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					columnDefinitions10.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					grid62.ColumnDefinitions = columnDefinitions10;
					AvaloniaList<Control> children42 = grid62.Children;
					TextBlock textBlock36;
					TextBlock textBlock35 = textBlock36 = new TextBlock();
					((ISupportInitialize)textBlock35).BeginInit();
					children42.Add(textBlock35);
					ISupportInitialize supportInitialize43 = textBlock3 = textBlock36;
					context.PushParent(textBlock3);
					TextBlock textBlock37 = textBlock3;
					Grid.SetColumn(textBlock37, 0);
					textBlock37.FontSize = 14.0;
					StaticResourceExtension staticResourceExtension15 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider15 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj16 = staticResourceExtension15.ProvideValue(serviceProvider15);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock37, obj16);
					textBlock37.TextTrimming = TextTrimming.CharacterEllipsis;
					AvaloniaProperty textProperty6 = TextBlock.TextProperty;
					CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.TransactionId!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider18 = context;
					context.ProvideTargetProperty = TextBlock.TextProperty;
					IBinding binding17 = compiledBindingExtension18.ProvideValue(provider18);
					context.ProvideTargetProperty = null;
					textBlock37.Bind(textProperty6, binding17, null);
					textBlock37.TextDecorations = TextDecorations.Underline;
					AvaloniaProperty foregroundProperty4 = TextBlock.ForegroundProperty;
					CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(TemplatedControl.ForegroundProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).Build());
					IServiceProvider provider19 = context;
					context.ProvideTargetProperty = TextBlock.ForegroundProperty;
					IBinding binding18 = compiledBindingExtension19.ProvideValue(provider19);
					context.ProvideTargetProperty = null;
					textBlock37.Bind(foregroundProperty4, binding18, null);
					textBlock37.VerticalAlignment = VerticalAlignment.Center;
					textBlock37.HorizontalAlignment = HorizontalAlignment.Stretch;
					textBlock37.Opacity = 0.9;
					textBlock37.FontWeight = FontWeight.Light;
					context.PopParent();
					supportInitialize43.EndInit();
					AvaloniaList<Control> children43 = grid62.Children;
					Button button9;
					Button button8 = button9 = new Button();
					((ISupportInitialize)button8).BeginInit();
					children43.Add(button8);
					ISupportInitialize supportInitialize44 = button3 = button9;
					context.PushParent(button3);
					Button button10 = button3;
					Grid.SetColumn(button10, 1);
					button10.Background = new ImmutableSolidColorBrush(16777215U);
					button10.VerticalAlignment = VerticalAlignment.Center;
					button10.HorizontalAlignment = HorizontalAlignment.Left;
					Viewbox viewbox12;
					Viewbox viewbox11 = viewbox12 = new Viewbox();
					((ISupportInitialize)viewbox11).BeginInit();
					button10.Content = viewbox11;
					ISupportInitialize supportInitialize45 = viewbox3 = viewbox12;
					context.PushParent(viewbox3);
					Viewbox viewbox13 = viewbox3;
					viewbox13.Width = 10.0;
					Path path12;
					Path path11 = path12 = new Path();
					((ISupportInitialize)path11).BeginInit();
					viewbox13.Child = path11;
					ISupportInitialize supportInitialize46 = path3 = path12;
					context.PushParent(path3);
					Path path13 = path3;
					StaticResourceExtension staticResourceExtension16 = new StaticResourceExtension("Copy");
					IServiceProvider serviceProvider16 = context;
					context.ProvideTargetProperty = Path.DataProperty;
					object obj17 = staticResourceExtension16.ProvideValue(serviceProvider16);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_1(path13, obj17);
					path13.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
					path13.Opacity = 0.5;
					context.PopParent();
					supportInitialize46.EndInit();
					context.PopParent();
					supportInitialize45.EndInit();
					context.PopParent();
					supportInitialize44.EndInit();
					context.PopParent();
					supportInitialize42.EndInit();
					context.PopParent();
					supportInitialize41.EndInit();
					context.PopParent();
					supportInitialize39.EndInit();
					context.PopParent();
					supportInitialize38.EndInit();
					AvaloniaList<Control> children44 = grid53.Children;
					Grid grid64;
					Grid grid63 = grid64 = new Grid();
					((ISupportInitialize)grid63).BeginInit();
					children44.Add(grid63);
					ISupportInitialize supportInitialize47 = grid = grid64;
					context.PushParent(grid);
					Grid grid65 = grid;
					Grid.SetRow(grid65, 1);
					AvaloniaProperty isVisibleProperty6 = Visual.IsVisibleProperty;
					CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Ancestor(typeof(CoinSpecificPartView), 0).Property(StyledElement.DataContextProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).TypeCast<CoinSpecificPartViewModel>().Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.IsEthereum!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider20 = context;
					context.ProvideTargetProperty = Visual.IsVisibleProperty;
					IBinding binding19 = compiledBindingExtension20.ProvideValue(provider20);
					context.ProvideTargetProperty = null;
					grid65.Bind(isVisibleProperty6, binding19, null);
					ColumnDefinitions columnDefinitions11 = new ColumnDefinitions();
					columnDefinitions11.Capacity = 2;
					columnDefinitions11.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					columnDefinitions11.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid65.ColumnDefinitions = columnDefinitions11;
					grid65.VerticalAlignment = VerticalAlignment.Center;
					AvaloniaList<Control> children45 = grid65.Children;
					Border border24;
					Border border23 = border24 = new Border();
					((ISupportInitialize)border23).BeginInit();
					children45.Add(border23);
					Border border25 = border24;
					Grid.SetColumn(border25, 0);
					border25.Height = 26.0;
					border25.Width = 2.0;
					border25.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
					border25.Background = new ImmutableSolidColorBrush(872415231U);
					border25.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
					border25.VerticalAlignment = VerticalAlignment.Center;
					((ISupportInitialize)border25).EndInit();
					AvaloniaList<Control> children46 = grid65.Children;
					Grid grid67;
					Grid grid66 = grid67 = new Grid();
					((ISupportInitialize)grid66).BeginInit();
					children46.Add(grid66);
					ISupportInitialize supportInitialize48 = grid = grid67;
					context.PushParent(grid);
					Grid grid68 = grid;
					Grid.SetColumn(grid68, 1);
					RowDefinitions rowDefinitions10 = new RowDefinitions();
					rowDefinitions10.Capacity = 2;
					rowDefinitions10.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
					rowDefinitions10.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid68.RowDefinitions = rowDefinitions10;
					AvaloniaList<Control> children47 = grid68.Children;
					TextBlock textBlock39;
					TextBlock textBlock38 = textBlock39 = new TextBlock();
					((ISupportInitialize)textBlock38).BeginInit();
					children47.Add(textBlock38);
					ISupportInitialize supportInitialize49 = textBlock3 = textBlock39;
					context.PushParent(textBlock3);
					TextBlock textBlock40 = textBlock3;
					Grid.SetRow(textBlock40, 0);
					textBlock40.FontSize = 11.0;
					StaticResourceExtension staticResourceExtension17 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider17 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj18 = staticResourceExtension17.ProvideValue(serviceProvider17);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock40, obj18);
					textBlock40.Text = "Now";
					textBlock40.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					textBlock40.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
					textBlock40.Opacity = 0.5;
					textBlock40.FontWeight = FontWeight.Normal;
					context.PopParent();
					supportInitialize49.EndInit();
					AvaloniaList<Control> children48 = grid68.Children;
					TextBlock textBlock42;
					TextBlock textBlock41 = textBlock42 = new TextBlock();
					((ISupportInitialize)textBlock41).BeginInit();
					children48.Add(textBlock41);
					ISupportInitialize supportInitialize50 = textBlock3 = textBlock42;
					context.PushParent(textBlock3);
					TextBlock textBlock43 = textBlock3;
					Grid.SetRow(textBlock43, 1);
					textBlock43.FontSize = 14.0;
					StaticResourceExtension staticResourceExtension18 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider18 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj19 = staticResourceExtension18.ProvideValue(serviceProvider18);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock43, obj19);
					AvaloniaProperty textProperty7 = TextBlock.TextProperty;
					CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.PriceNowString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider21 = context;
					context.ProvideTargetProperty = TextBlock.TextProperty;
					IBinding binding20 = compiledBindingExtension21.ProvideValue(provider21);
					context.ProvideTargetProperty = null;
					textBlock43.Bind(textProperty7, binding20, null);
					textBlock43.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					textBlock43.Opacity = 0.9;
					textBlock43.FontWeight = FontWeight.Light;
					context.PopParent();
					supportInitialize50.EndInit();
					context.PopParent();
					supportInitialize48.EndInit();
					context.PopParent();
					supportInitialize47.EndInit();
					context.PopParent();
					supportInitialize37.EndInit();
					AvaloniaList<Control> children49 = grid29.Children;
					Grid grid70;
					Grid grid69 = grid70 = new Grid();
					((ISupportInitialize)grid69).BeginInit();
					children49.Add(grid69);
					ISupportInitialize supportInitialize51 = grid = grid70;
					context.PushParent(grid);
					Grid grid71 = grid;
					Grid.SetColumn(grid71, 2);
					RowDefinitions rowDefinitions11 = new RowDefinitions();
					rowDefinitions11.Capacity = 2;
					rowDefinitions11.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					rowDefinitions11.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid71.RowDefinitions = rowDefinitions11;
					AvaloniaList<Control> children50 = grid71.Children;
					Grid grid73;
					Grid grid72 = grid73 = new Grid();
					((ISupportInitialize)grid72).BeginInit();
					children50.Add(grid72);
					ISupportInitialize supportInitialize52 = grid = grid73;
					context.PushParent(grid);
					Grid grid74 = grid;
					Grid.SetRow(grid74, 0);
					ColumnDefinitions columnDefinitions12 = new ColumnDefinitions();
					columnDefinitions12.Capacity = 2;
					columnDefinitions12.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					columnDefinitions12.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid74.ColumnDefinitions = columnDefinitions12;
					grid74.VerticalAlignment = VerticalAlignment.Center;
					AvaloniaList<Control> children51 = grid74.Children;
					Border border27;
					Border border26 = border27 = new Border();
					((ISupportInitialize)border26).BeginInit();
					children51.Add(border26);
					Border border28 = border27;
					Grid.SetColumn(border28, 0);
					border28.Height = 26.0;
					border28.Width = 2.0;
					border28.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
					border28.Background = new ImmutableSolidColorBrush(872415231U);
					border28.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
					border28.VerticalAlignment = VerticalAlignment.Center;
					((ISupportInitialize)border28).EndInit();
					AvaloniaList<Control> children52 = grid74.Children;
					Grid grid76;
					Grid grid75 = grid76 = new Grid();
					((ISupportInitialize)grid75).BeginInit();
					children52.Add(grid75);
					ISupportInitialize supportInitialize53 = grid = grid76;
					context.PushParent(grid);
					Grid grid77 = grid;
					Grid.SetColumn(grid77, 1);
					RowDefinitions rowDefinitions12 = new RowDefinitions();
					rowDefinitions12.Capacity = 2;
					rowDefinitions12.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
					rowDefinitions12.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
					grid77.RowDefinitions = rowDefinitions12;
					AvaloniaList<Control> children53 = grid77.Children;
					TextBlock textBlock45;
					TextBlock textBlock44 = textBlock45 = new TextBlock();
					((ISupportInitialize)textBlock44).BeginInit();
					children53.Add(textBlock44);
					ISupportInitialize supportInitialize54 = textBlock3 = textBlock45;
					context.PushParent(textBlock3);
					TextBlock textBlock46 = textBlock3;
					Grid.SetRow(textBlock46, 0);
					textBlock46.FontSize = 11.0;
					StaticResourceExtension staticResourceExtension19 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider19 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj20 = staticResourceExtension19.ProvideValue(serviceProvider19);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock46, obj20);
					textBlock46.Text = "From";
					textBlock46.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					textBlock46.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
					textBlock46.Opacity = 0.5;
					textBlock46.FontWeight = FontWeight.Normal;
					context.PopParent();
					supportInitialize54.EndInit();
					AvaloniaList<Control> children54 = grid77.Children;
					TextBlock textBlock48;
					TextBlock textBlock47 = textBlock48 = new TextBlock();
					((ISupportInitialize)textBlock47).BeginInit();
					children54.Add(textBlock47);
					ISupportInitialize supportInitialize55 = textBlock3 = textBlock48;
					context.PushParent(textBlock3);
					TextBlock textBlock49 = textBlock3;
					Grid.SetRow(textBlock49, 1);
					textBlock49.FontSize = 14.0;
					StaticResourceExtension staticResourceExtension20 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider20 = context;
					context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
					object obj21 = staticResourceExtension20.ProvideValue(serviceProvider20);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_2(textBlock49, obj21);
					AvaloniaProperty textProperty8 = TextBlock.TextProperty;
					CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.Transaction,Exodus.From!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
					IServiceProvider provider22 = context;
					context.ProvideTargetProperty = TextBlock.TextProperty;
					IBinding binding21 = compiledBindingExtension22.ProvideValue(provider22);
					context.ProvideTargetProperty = null;
					textBlock49.Bind(textProperty8, binding21, null);
					textBlock49.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					textBlock49.Opacity = 0.9;
					textBlock49.FontWeight = FontWeight.Light;
					context.PopParent();
					supportInitialize55.EndInit();
					context.PopParent();
					supportInitialize53.EndInit();
					context.PopParent();
					supportInitialize52.EndInit();
					AvaloniaList<Control> children55 = grid71.Children;
					Grid grid79;
					Grid grid78 = grid79 = new Grid();
					((ISupportInitialize)grid78).BeginInit();
					children55.Add(grid78);
					Grid grid80 = grid79;
					Grid.SetRow(grid80, 1);
					grid80.VerticalAlignment = VerticalAlignment.Stretch;
					((ISupportInitialize)grid80).EndInit();
					context.PopParent();
					supportInitialize51.EndInit();
					context.PopParent();
					supportInitialize23.EndInit();
					AvaloniaList<Control> children56 = grid26.Children;
					Grid grid82;
					Grid grid81 = grid82 = new Grid();
					((ISupportInitialize)grid81).BeginInit();
					children56.Add(grid81);
					ISupportInitialize supportInitialize56 = grid = grid82;
					context.PushParent(grid);
					Grid grid83 = grid;
					Grid.SetRow(grid83, 1);
					Grid.SetColumn(grid83, 0);
					Grid.SetColumnSpan(grid83, 2);
					grid83.HorizontalAlignment = HorizontalAlignment.Stretch;
					grid83.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
					AvaloniaList<Control> children57 = grid83.Children;
					Border border30;
					Border border29 = border30 = new Border();
					((ISupportInitialize)border29).BeginInit();
					children57.Add(border29);
					ISupportInitialize supportInitialize57 = border6 = border30;
					context.PushParent(border6);
					Border border31 = border6;
					border31.HorizontalAlignment = HorizontalAlignment.Stretch;
					border31.Height = 40.0;
					border31.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
					border31.Background = new ImmutableSolidColorBrush(4280230179U);
					Grid grid85;
					Grid grid84 = grid85 = new Grid();
					((ISupportInitialize)grid84).BeginInit();
					border31.Child = grid84;
					ISupportInitialize supportInitialize58 = grid = grid85;
					context.PushParent(grid);
					Grid grid86 = grid;
					ColumnDefinitions columnDefinitions13 = new ColumnDefinitions();
					columnDefinitions13.Capacity = 2;
					columnDefinitions13.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
					columnDefinitions13.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
					grid86.ColumnDefinitions = columnDefinitions13;
					grid86.Margin = new Thickness(5.0, 0.0, 5.0, 0.0);
					AvaloniaList<Control> children58 = grid86.Children;
					TextBox textBox2;
					TextBox textBox = textBox2 = new TextBox();
					((ISupportInitialize)textBox).BeginInit();
					children58.Add(textBox);
					TextBox textBox3;
					ISupportInitialize supportInitialize59 = textBox3 = textBox2;
					context.PushParent(textBox3);
					TextBox textBox4 = textBox3;
					Grid.SetColumn(textBox4, 0);
					textBox4.Background = new ImmutableSolidColorBrush(4280230179U);
					textBox4.BorderBrush = new ImmutableSolidColorBrush(4280230179U);
					textBox4.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
					textBox4.Watermark = "Personal note";
					textBox4.VerticalAlignment = VerticalAlignment.Center;
					textBox4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
					textBox4.VerticalContentAlignment = VerticalAlignment.Center;
					textBox4.HorizontalAlignment = HorizontalAlignment.Stretch;
					textBox4.HorizontalContentAlignment = HorizontalAlignment.Stretch;
					textBox4.FontSize = 14.0;
					StaticResourceExtension staticResourceExtension21 = new StaticResourceExtension("RobotoRegular");
					IServiceProvider serviceProvider21 = context;
					context.ProvideTargetProperty = TemplatedControl.FontFamilyProperty;
					object obj22 = staticResourceExtension21.ProvideValue(serviceProvider21);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_3(textBox4, obj22);
					textBox4.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
					textBox4.Opacity = 0.8;
					textBox4.Margin = new Thickness(0.0, 0.0, 7.0, 0.0);
					textBox4.FontWeight = FontWeight.Normal;
					context.PopParent();
					supportInitialize59.EndInit();
					AvaloniaList<Control> children59 = grid86.Children;
					Border border33;
					Border border32 = border33 = new Border();
					((ISupportInitialize)border32).BeginInit();
					children59.Add(border32);
					ISupportInitialize supportInitialize60 = border6 = border33;
					context.PushParent(border6);
					Border border34 = border6;
					Grid.SetColumn(border34, 1);
					border34.CornerRadius = new CornerRadius(120.0, 120.0, 120.0, 120.0);
					border34.VerticalAlignment = VerticalAlignment.Center;
					border34.Margin = new Thickness(0.0, 0.0, 6.0, 0.0);
					border34.Background = new ImmutableSolidColorBrush(4281217075U);
					border34.Width = 22.0;
					border34.Height = 22.0;
					Viewbox viewbox15;
					Viewbox viewbox14 = viewbox15 = new Viewbox();
					((ISupportInitialize)viewbox14).BeginInit();
					border34.Child = viewbox14;
					ISupportInitialize supportInitialize61 = viewbox3 = viewbox15;
					context.PushParent(viewbox3);
					Viewbox viewbox16 = viewbox3;
					viewbox16.VerticalAlignment = VerticalAlignment.Center;
					viewbox16.Width = 4.5;
					viewbox16.HorizontalAlignment = HorizontalAlignment.Center;
					Path path15;
					Path path14 = path15 = new Path();
					((ISupportInitialize)path14).BeginInit();
					viewbox16.Child = path14;
					ISupportInitialize supportInitialize62 = path3 = path15;
					context.PushParent(path3);
					Path path16 = path3;
					StaticResourceExtension staticResourceExtension22 = new StaticResourceExtension("IIcon");
					IServiceProvider serviceProvider22 = context;
					context.ProvideTargetProperty = Path.DataProperty;
					object obj23 = staticResourceExtension22.ProvideValue(serviceProvider22);
					context.ProvideTargetProperty = null;
					CoinSpecificPartView.XamlClosure_68.XamlClosure_71.DynamicSetters_72.DynamicSetter_1(path16, obj23);
					path16.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
					path16.Opacity = 0.5;
					path16.Stretch = Stretch.UniformToFill;
					context.PopParent();
					supportInitialize62.EndInit();
					context.PopParent();
					supportInitialize61.EndInit();
					context.PopParent();
					supportInitialize60.EndInit();
					context.PopParent();
					supportInitialize58.EndInit();
					context.PopParent();
					supportInitialize57.EndInit();
					context.PopParent();
					supportInitialize56.EndInit();
					context.PopParent();
					supportInitialize22.EndInit();
					context.PopParent();
					supportInitialize21.EndInit();
					context.PopParent();
					supportInitialize2.EndInit();
					context.PopParent();
					supportInitialize.EndInit();
					AvaloniaList<Control> children60 = grid2.Children;
					Border border36;
					Border border35 = border36 = new Border();
					((ISupportInitialize)border35).BeginInit();
					children60.Add(border35);
					Border border37 = border36;
					Grid.SetRow(border37, 2);
					border37.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
					border37.Height = 1.0;
					border37.HorizontalAlignment = HorizontalAlignment.Stretch;
					border37.Background = new ImmutableSolidColorBrush(uint.MaxValue);
					border37.Opacity = 0.08;
					((ISupportInitialize)border37).EndInit();
					context.PopParent();
					((ISupportInitialize)intermediateRoot).EndInit();
					return intermediateRoot;
				}

				// Token: 0x0200001C RID: 28
				private class DynamicSetters_72
				{
					// Token: 0x06000037 RID: 55 RVA: 0x00013FB0 File Offset: 0x000121B0
					public static void DynamicSetter_1(Path A_0, object A_1)
					{
						if (A_1 is UnsetValueType)
						{
							A_0.SetValue(Path.DataProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
							return;
						}
						if (A_1 is IBinding)
						{
							A_0.Bind(Path.DataProperty, A_1, null);
							return;
						}
						if (A_1 is Geometry)
						{
							A_0.Data = A_1;
							return;
						}
						if (A_1 == null)
						{
							A_0.Data = A_1;
							return;
						}
						throw new InvalidCastException();
					}

					// Token: 0x06000038 RID: 56 RVA: 0x0001401C File Offset: 0x0001221C
					public static void DynamicSetter_2(TextBlock A_0, object A_1)
					{
						if (A_1 is UnsetValueType)
						{
							A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
							return;
						}
						if (A_1 is IBinding)
						{
							A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
							return;
						}
						if (A_1 is FontFamily)
						{
							A_0.FontFamily = A_1;
							return;
						}
						if (A_1 == null)
						{
							A_0.FontFamily = A_1;
							return;
						}
						throw new InvalidCastException();
					}

					// Token: 0x06000039 RID: 57 RVA: 0x00014088 File Offset: 0x00012288
					public static void DynamicSetter_3(TemplatedControl A_0, object A_1)
					{
						if (A_1 is UnsetValueType)
						{
							A_0.SetValue(TemplatedControl.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
							return;
						}
						if (A_1 is IBinding)
						{
							A_0.Bind(TemplatedControl.FontFamilyProperty, A_1, null);
							return;
						}
						if (A_1 is FontFamily)
						{
							A_0.FontFamily = A_1;
							return;
						}
						if (A_1 == null)
						{
							A_0.FontFamily = A_1;
							return;
						}
						throw new InvalidCastException();
					}
				}
			}
		}
	}
}
