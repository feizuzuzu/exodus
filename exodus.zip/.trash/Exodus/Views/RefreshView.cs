﻿using System;
using System.ComponentModel;
using System.Globalization;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Animation.Easings;
using Avalonia.Collections;
using Avalonia.Controls;
using Avalonia.Controls.Documents;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Data.Core;
using Avalonia.Data.Core.Plugins;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;

namespace Exodus.Views
{
	// Token: 0x0200002E RID: 46
	public class RefreshView : Border
	{
		// Token: 0x06000066 RID: 102 RVA: 0x00020055 File Offset: 0x0001E255
		public RefreshView()
		{
			this.InitializeComponent(true);
		}

		// Token: 0x06000067 RID: 103 RVA: 0x00020064 File Offset: 0x0001E264
		public void InitializeComponent(bool loadXaml = true)
		{
			if (loadXaml)
			{
				RefreshView.!XamlIlPopulateTrampoline(this);
			}
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00020070 File Offset: 0x0001E270
		static void !XamlIlPopulate(IServiceProvider A_0, RefreshView A_1)
		{
			XamlIlContext.Context<RefreshView> context = new XamlIlContext.Context<RefreshView>(A_0, new object[]
			{
				(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/RefreshView.axaml.Singleton
			}, "avares://Exodus/Views/RefreshView.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			((ISupportInitialize)A_1).BeginInit();
			context.PushParent(A_1);
			A_1.Background = new ImmutableSolidColorBrush(4279901215U);
			AvaloniaProperty opacityProperty = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.Opacity!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider = context;
			context.ProvideTargetProperty = Visual.OpacityProperty;
			IBinding binding = compiledBindingExtension.ProvideValue(provider);
			context.ProvideTargetProperty = null;
			A_1.Bind(opacityProperty, binding, null);
			A_1.Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = Visual.OpacityProperty,
					Duration = TimeSpan.FromTicks(3500000L)
				}
			};
			Grid grid2;
			Grid grid = grid2 = new Grid();
			((ISupportInitialize)grid).BeginInit();
			A_1.Child = grid;
			Grid grid3;
			ISupportInitialize supportInitialize = grid3 = grid2;
			context.PushParent(grid3);
			AvaloniaList<Control> children = grid3.Children;
			Grid grid5;
			Grid grid4 = grid5 = new Grid();
			((ISupportInitialize)grid4).BeginInit();
			children.Add(grid4);
			ISupportInitialize supportInitialize2 = grid3 = grid5;
			context.PushParent(grid3);
			Grid grid6 = grid3;
			grid6.VerticalAlignment = VerticalAlignment.Stretch;
			grid6.HorizontalAlignment = HorizontalAlignment.Stretch;
			RowDefinitions rowDefinitions = new RowDefinitions();
			rowDefinitions.Capacity = 2;
			rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid6.RowDefinitions = rowDefinitions;
			grid6.Margin = new Thickness(25.0, 32.0, 25.0, 32.0);
			AvaloniaList<Control> children2 = grid6.Children;
			Button button2;
			Button button = button2 = new Button();
			((ISupportInitialize)button).BeginInit();
			children2.Add(button);
			Button button3;
			ISupportInitialize supportInitialize3 = button3 = button2;
			context.PushParent(button3);
			Button button4 = button3;
			Grid.SetRow(button4, 0);
			button4.Background = new ImmutableSolidColorBrush(16777215U);
			AvaloniaProperty commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("CloseCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.RefreshViewModel+CloseCommand_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider2 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding2 = compiledBindingExtension2.ProvideValue(provider2);
			context.ProvideTargetProperty = null;
			button4.Bind(commandProperty, binding2, null);
			button4.HorizontalAlignment = HorizontalAlignment.Right;
			AvaloniaProperty opacityProperty2 = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.SolidOpacity!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider3 = context;
			context.ProvideTargetProperty = Visual.OpacityProperty;
			IBinding binding3 = compiledBindingExtension3.ProvideValue(provider3);
			context.ProvideTargetProperty = null;
			button4.Bind(opacityProperty2, binding3, null);
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShow!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider4 = context;
			context.ProvideTargetProperty = "class:IsShow";
			IBinding binding4 = compiledBindingExtension4.ProvideValue(provider4);
			context.ProvideTargetProperty = null;
			IBinding source = binding4;
			button4.BindClass("IsShow", source, null);
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShow!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider5 = context;
			context.ProvideTargetProperty = "class:NotIsShow";
			IBinding binding5 = compiledBindingExtension5.ProvideValue(provider5);
			context.ProvideTargetProperty = null;
			source = binding5;
			button4.BindClass("NotIsShow", source, null);
			button4.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Button)).Class("IsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(3600000L),
						Easing = Easing.Parse("SineEaseOut"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 100.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							}
						}
					}
				}
			});
			button4.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Button)).Class("NotIsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(3600000L),
						Easing = Easing.Parse("SineEaseIn"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 100.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							}
						}
					}
				}
			});
			button4.Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = Visual.OpacityProperty,
					Duration = TimeSpan.FromTicks(3100000L)
				}
			};
			Border border2;
			Border border = border2 = new Border();
			((ISupportInitialize)border).BeginInit();
			button4.Content = border;
			Border border3;
			ISupportInitialize supportInitialize4 = border3 = border2;
			context.PushParent(border3);
			Border border4 = border3;
			border4.Height = 38.0;
			border4.Width = 38.0;
			border4.Background = new ImmutableSolidColorBrush(4281019696U);
			border4.CornerRadius = new CornerRadius(100.0, 100.0, 100.0, 100.0);
			Viewbox viewbox2;
			Viewbox viewbox = viewbox2 = new Viewbox();
			((ISupportInitialize)viewbox).BeginInit();
			border4.Child = viewbox;
			Viewbox viewbox3;
			ISupportInitialize supportInitialize5 = viewbox3 = viewbox2;
			context.PushParent(viewbox3);
			Viewbox viewbox4 = viewbox3;
			viewbox4.Height = 14.0;
			viewbox4.VerticalAlignment = VerticalAlignment.Center;
			viewbox4.HorizontalAlignment = HorizontalAlignment.Center;
			Path path2;
			Path path = path2 = new Path();
			((ISupportInitialize)path).BeginInit();
			viewbox4.Child = path;
			Path path3;
			ISupportInitialize supportInitialize6 = path3 = path2;
			context.PushParent(path3);
			Path path4 = path3;
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("Close");
			IServiceProvider serviceProvider = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj = staticResourceExtension.ProvideValue(serviceProvider);
			context.ProvideTargetProperty = null;
			RefreshView.DynamicSetters_84.DynamicSetter_1(path4, obj);
			path4.Fill = new ImmutableSolidColorBrush(1560281087U);
			path4.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize6.EndInit();
			context.PopParent();
			supportInitialize5.EndInit();
			context.PopParent();
			supportInitialize4.EndInit();
			context.PopParent();
			supportInitialize3.EndInit();
			AvaloniaList<Control> children3 = grid6.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = stackPanel2 = new StackPanel();
			((ISupportInitialize)stackPanel).BeginInit();
			children3.Add(stackPanel);
			StackPanel stackPanel3;
			ISupportInitialize supportInitialize7 = stackPanel3 = stackPanel2;
			context.PushParent(stackPanel3);
			StackPanel stackPanel4 = stackPanel3;
			Grid.SetRow(stackPanel4, 1);
			stackPanel4.Margin = new Thickness(0.0, -45.0, 0.0, 0.0);
			AvaloniaProperty opacityProperty3 = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.SolidOpacity!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider6 = context;
			context.ProvideTargetProperty = Visual.OpacityProperty;
			IBinding binding6 = compiledBindingExtension6.ProvideValue(provider6);
			context.ProvideTargetProperty = null;
			stackPanel4.Bind(opacityProperty3, binding6, null);
			stackPanel4.VerticalAlignment = VerticalAlignment.Center;
			stackPanel4.HorizontalAlignment = HorizontalAlignment.Center;
			stackPanel4.Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = Visual.OpacityProperty,
					Delay = TimeSpan.FromTicks(3900000L),
					Duration = TimeSpan.FromTicks(4000000L)
				}
			};
			AvaloniaList<Control> children4 = stackPanel4.Children;
			StackPanel stackPanel6;
			StackPanel stackPanel5 = stackPanel6 = new StackPanel();
			((ISupportInitialize)stackPanel5).BeginInit();
			children4.Add(stackPanel5);
			ISupportInitialize supportInitialize8 = stackPanel3 = stackPanel6;
			context.PushParent(stackPanel3);
			StackPanel stackPanel7 = stackPanel3;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShow!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider7 = context;
			context.ProvideTargetProperty = "class:IsShow";
			IBinding binding7 = compiledBindingExtension7.ProvideValue(provider7);
			context.ProvideTargetProperty = null;
			source = binding7;
			stackPanel7.BindClass("IsShow", source, null);
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShow!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider8 = context;
			context.ProvideTargetProperty = "class:NotIsShow";
			IBinding binding8 = compiledBindingExtension8.ProvideValue(provider8);
			context.ProvideTargetProperty = null;
			source = binding8;
			stackPanel7.BindClass("NotIsShow", source, null);
			stackPanel7.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(StackPanel)).Class("IsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(9000000L),
						Delay = TimeSpan.FromTicks(3000000L),
						Easing = Easing.Parse("QuadraticEaseOut"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = -55.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("60%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 8.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							}
						}
					}
				}
			});
			stackPanel7.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(StackPanel)).Class("NotIsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(5000000L),
						Easing = Easing.Parse("QuadraticEaseIn"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = -55.0
									}
								}
							}
						}
					}
				}
			});
			AvaloniaList<Control> children5 = stackPanel7.Children;
			Image image2;
			Image image = image2 = new Image();
			((ISupportInitialize)image).BeginInit();
			children5.Add(image);
			Image image3;
			ISupportInitialize supportInitialize9 = image3 = image2;
			context.PushParent(image3);
			Image image4 = image3;
			image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/icon-warning-colors.png");
			image4.Width = 140.0;
			image4.Stretch = Stretch.Uniform;
			RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
			image4.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize9.EndInit();
			AvaloniaList<Control> children6 = stackPanel7.Children;
			TextBlock textBlock2;
			TextBlock textBlock = textBlock2 = new TextBlock();
			((ISupportInitialize)textBlock).BeginInit();
			children6.Add(textBlock);
			TextBlock textBlock3;
			ISupportInitialize supportInitialize10 = textBlock3 = textBlock2;
			context.PushParent(textBlock3);
			TextBlock textBlock4 = textBlock3;
			textBlock4.FontSize = 36.0;
			StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("RobotoCondensedLight");
			IServiceProvider serviceProvider2 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj2 = staticResourceExtension2.ProvideValue(serviceProvider2);
			context.ProvideTargetProperty = null;
			RefreshView.DynamicSetters_84.DynamicSetter_2(textBlock4, obj2);
			textBlock4.Text = "Refresh Blockchain?";
			textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock4.TextAlignment = TextAlignment.Center;
			textBlock4.Margin = new Thickness(0.0, 6.0, 0.0, 8.0);
			context.PopParent();
			supportInitialize10.EndInit();
			AvaloniaList<Control> children7 = stackPanel7.Children;
			TextBlock textBlock6;
			TextBlock textBlock5 = textBlock6 = new TextBlock();
			((ISupportInitialize)textBlock5).BeginInit();
			children7.Add(textBlock5);
			ISupportInitialize supportInitialize11 = textBlock3 = textBlock6;
			context.PushParent(textBlock3);
			TextBlock textBlock7 = textBlock3;
			textBlock7.FontSize = 14.0;
			StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider3 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj3 = staticResourceExtension3.ProvideValue(serviceProvider3);
			context.ProvideTargetProperty = null;
			RefreshView.DynamicSetters_84.DynamicSetter_2(textBlock7, obj3);
			textBlock7.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock7.TextAlignment = TextAlignment.Center;
			textBlock7.Foreground = new ImmutableSolidColorBrush(4286283908U);
			AvaloniaProperty textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.RefreshText!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider9 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding9 = compiledBindingExtension9.ProvideValue(provider9);
			context.ProvideTargetProperty = null;
			textBlock7.Bind(textProperty, binding9, null);
			textBlock7.Margin = new Thickness(0.0, 0.0, 0.0, 1.0);
			context.PopParent();
			supportInitialize11.EndInit();
			AvaloniaList<Control> children8 = stackPanel7.Children;
			TextBlock textBlock9;
			TextBlock textBlock8 = textBlock9 = new TextBlock();
			((ISupportInitialize)textBlock8).BeginInit();
			children8.Add(textBlock8);
			ISupportInitialize supportInitialize12 = textBlock3 = textBlock9;
			context.PushParent(textBlock3);
			TextBlock textBlock10 = textBlock3;
			textBlock10.FontSize = 14.0;
			StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider4 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj4 = staticResourceExtension4.ProvideValue(serviceProvider4);
			context.ProvideTargetProperty = null;
			RefreshView.DynamicSetters_84.DynamicSetter_2(textBlock10, obj4);
			textBlock10.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock10.TextAlignment = TextAlignment.Center;
			textBlock10.Foreground = new ImmutableSolidColorBrush(4286283908U);
			textBlock10.Inlines.Add("This may take ");
			InlineCollection inlines = textBlock10.Inlines;
			Italic italic = new Italic();
			((ISupportInitialize)italic).BeginInit();
			Italic italic2 = italic;
			context.PushParent(italic2);
			Italic italic3 = italic2;
			italic3.Foreground = new ImmutableSolidColorBrush(3650251775U);
			StaticResourceExtension staticResourceExtension5 = new StaticResourceExtension("RobotoLightItalic");
			IServiceProvider serviceProvider5 = context;
			context.ProvideTargetProperty = TextElement.FontFamilyProperty;
			object obj5 = staticResourceExtension5.ProvideValue(serviceProvider5);
			context.ProvideTargetProperty = null;
			RefreshView.DynamicSetters_84.DynamicSetter_3(italic3, obj5);
			italic3.Inlines.Add("5 to 10 minutes.");
			context.PopParent();
			((ISupportInitialize)italic).EndInit();
			inlines.Add(italic);
			context.PopParent();
			supportInitialize12.EndInit();
			context.PopParent();
			supportInitialize8.EndInit();
			AvaloniaList<Control> children9 = stackPanel4.Children;
			StackPanel stackPanel9;
			StackPanel stackPanel8 = stackPanel9 = new StackPanel();
			((ISupportInitialize)stackPanel8).BeginInit();
			children9.Add(stackPanel8);
			ISupportInitialize supportInitialize13 = stackPanel3 = stackPanel9;
			context.PushParent(stackPanel3);
			StackPanel stackPanel10 = stackPanel3;
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShowButtons!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider10 = context;
			context.ProvideTargetProperty = "class:IsShow";
			IBinding binding10 = compiledBindingExtension10.ProvideValue(provider10);
			context.ProvideTargetProperty = null;
			source = binding10;
			stackPanel10.BindClass("IsShow", source, null);
			CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.IsShowButtons!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider11 = context;
			context.ProvideTargetProperty = "class:NotIsShow";
			IBinding binding11 = compiledBindingExtension11.ProvideValue(provider11);
			context.ProvideTargetProperty = null;
			source = binding11;
			stackPanel10.BindClass("NotIsShow", source, null);
			AvaloniaProperty opacityProperty4 = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.RefreshViewModel,Exodus.ButtonsOpacity!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider12 = context;
			context.ProvideTargetProperty = Visual.OpacityProperty;
			IBinding binding12 = compiledBindingExtension12.ProvideValue(provider12);
			context.ProvideTargetProperty = null;
			stackPanel10.Bind(opacityProperty4, binding12, null);
			stackPanel10.Orientation = Orientation.Horizontal;
			stackPanel10.HorizontalAlignment = HorizontalAlignment.Center;
			stackPanel10.Margin = new Thickness(0.0, 32.0, 0.0, 0.0);
			stackPanel10.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(StackPanel)).Class("IsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(9000000L),
						Easing = Easing.Parse("QuadraticEaseOut"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 25.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("60%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = -4.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							}
						}
					}
				}
			});
			stackPanel10.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(StackPanel)).Class("NotIsShow"),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(5000000L),
						Easing = Easing.Parse("QuadraticEaseIn"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 0.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = TranslateTransform.XProperty,
										Value = 0.0
									},
									new Setter
									{
										Property = TranslateTransform.YProperty,
										Value = 25.0
									}
								}
							}
						}
					}
				}
			});
			Styles styles = stackPanel10.Styles;
			Style style;
			IStyle item = style = new Style();
			context.PushParent(style);
			Style style2 = style;
			style2.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pointerover");
			Setter setter2;
			SetterBase setter = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter3 = setter2;
			setter3.Property = Visual.RenderTransformProperty;
			setter3.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(1)");
			context.PopParent();
			style2.Add(setter);
			context.PopParent();
			styles.Add(item);
			Styles styles2 = stackPanel10.Styles;
			IStyle item2 = style = new Style();
			context.PushParent(style);
			Style style3 = style;
			style3.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pressed");
			SetterBase setter4 = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter5 = setter2;
			setter5.Property = Visual.RenderTransformProperty;
			setter5.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "scale(1)");
			context.PopParent();
			style3.Add(setter4);
			context.PopParent();
			styles2.Add(item2);
			stackPanel10.Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = Visual.OpacityProperty,
					Duration = TimeSpan.FromTicks(3000000L)
				}
			};
			AvaloniaList<Control> children10 = stackPanel10.Children;
			Button button6;
			Button button5 = button6 = new Button();
			((ISupportInitialize)button5).BeginInit();
			children10.Add(button5);
			ISupportInitialize supportInitialize14 = button3 = button6;
			context.PushParent(button3);
			Button button7 = button3;
			button7.Background = new ImmutableSolidColorBrush(16777215U);
			AvaloniaProperty commandProperty2 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("CloseCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.RefreshViewModel+CloseCommand_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider13 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding13 = compiledBindingExtension13.ProvideValue(provider13);
			context.ProvideTargetProperty = null;
			button7.Bind(commandProperty2, binding13, null);
			button7.Margin = new Thickness(2.0, 0.0, 2.0, 0.0);
			Border border6;
			Border border5 = border6 = new Border();
			((ISupportInitialize)border5).BeginInit();
			button7.Content = border5;
			ISupportInitialize supportInitialize15 = border3 = border6;
			context.PushParent(border3);
			Border border7 = border3;
			border7.Height = 45.0;
			border7.Width = 240.0;
			border7.CornerRadius = new CornerRadius(30.0, 30.0, 30.0, 30.0);
			border7.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			border7.BorderBrush = new ImmutableSolidColorBrush(16777215U);
			border7.Transitions = new Transitions
			{
				new BrushTransition
				{
					Property = Border.BackgroundProperty,
					Duration = TimeSpan.FromTicks(1200000L)
				}
			};
			Styles styles3 = border7.Styles;
			Style style4 = new Style();
			style4.Selector = Selectors.OfType((Selector)null, typeof(Border));
			style4.Add(new Setter
			{
				Property = Border.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(4280164130U)
			});
			styles3.Add(style4);
			Styles styles4 = border7.Styles;
			Style style5 = new Style();
			style5.Selector = Selectors.OfType((Selector)null, typeof(Border)).Class(":pointerover");
			style5.Add(new Setter
			{
				Property = Border.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(4280888110U)
			});
			styles4.Add(style5);
			TextBlock textBlock12;
			TextBlock textBlock11 = textBlock12 = new TextBlock();
			((ISupportInitialize)textBlock11).BeginInit();
			border7.Child = textBlock11;
			ISupportInitialize supportInitialize16 = textBlock3 = textBlock12;
			context.PushParent(textBlock3);
			TextBlock textBlock13 = textBlock3;
			textBlock13.FontSize = 12.0;
			StaticResourceExtension staticResourceExtension6 = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider6 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj6 = staticResourceExtension6.ProvideValue(serviceProvider6);
			context.ProvideTargetProperty = null;
			RefreshView.DynamicSetters_84.DynamicSetter_2(textBlock13, obj6);
			textBlock13.FontWeight = FontWeight.Medium;
			textBlock13.Text = "CANCEL";
			textBlock13.Opacity = 0.4;
			textBlock13.VerticalAlignment = VerticalAlignment.Center;
			textBlock13.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize16.EndInit();
			context.PopParent();
			supportInitialize15.EndInit();
			context.PopParent();
			supportInitialize14.EndInit();
			AvaloniaList<Control> children11 = stackPanel10.Children;
			Button button9;
			Button button8 = button9 = new Button();
			((ISupportInitialize)button8).BeginInit();
			children11.Add(button8);
			ISupportInitialize supportInitialize17 = button3 = button9;
			context.PushParent(button3);
			Button button10 = button3;
			button10.Background = new ImmutableSolidColorBrush(16777215U);
			AvaloniaProperty commandProperty3 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("YesRefreshCommand", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.RefreshViewModel+YesRefreshCommand_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider14 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding14 = compiledBindingExtension14.ProvideValue(provider14);
			context.ProvideTargetProperty = null;
			button10.Bind(commandProperty3, binding14, null);
			button10.Margin = new Thickness(2.0, 0.0, 2.0, 0.0);
			Border border9;
			Border border8 = border9 = new Border();
			((ISupportInitialize)border8).BeginInit();
			button10.Content = border8;
			ISupportInitialize supportInitialize18 = border3 = border9;
			context.PushParent(border3);
			Border border10 = border3;
			border10.Height = 45.0;
			border10.Width = 240.0;
			border10.CornerRadius = new CornerRadius(30.0, 30.0, 30.0, 30.0);
			border10.BorderThickness = new Thickness(2.0, 2.0, 2.0, 2.0);
			border10.Transitions = new Transitions
			{
				new BrushTransition
				{
					Property = Border.BackgroundProperty,
					Duration = TimeSpan.FromTicks(1200000L)
				},
				new BrushTransition
				{
					Property = Border.BorderBrushProperty,
					Duration = TimeSpan.FromTicks(1200000L)
				}
			};
			Styles styles5 = border10.Styles;
			Style style6 = new Style();
			style6.Selector = Selectors.OfType((Selector)null, typeof(Border));
			style6.Add(new Setter
			{
				Property = Border.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(218103808U)
			});
			style6.Add(new Setter
			{
				Property = Border.BorderBrushProperty,
				Value = new LinearGradientBrush
				{
					StartPoint = new RelativePoint(0.0, 0.5, RelativeUnit.Relative),
					EndPoint = new RelativePoint(1.0, 0.5, RelativeUnit.Relative),
					GradientStops = 
					{
						new GradientStop
						{
							Color = Color.FromUInt32(2785067007U),
							Offset = 0.0
						},
						new GradientStop
						{
							Color = Color.FromUInt32(2791709183U),
							Offset = 1.0
						}
					}
				}
			});
			styles5.Add(style6);
			Styles styles6 = border10.Styles;
			Style style7 = new Style();
			style7.Selector = Selectors.OfType((Selector)null, typeof(Border)).Class(":pointerover");
			style7.Add(new Setter
			{
				Property = Border.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(1073741824U)
			});
			style7.Add(new Setter
			{
				Property = Border.BorderBrushProperty,
				Value = new LinearGradientBrush
				{
					StartPoint = new RelativePoint(0.0, 0.5, RelativeUnit.Relative),
					EndPoint = new RelativePoint(1.0, 0.5, RelativeUnit.Relative),
					GradientStops = 
					{
						new GradientStop
						{
							Color = Color.FromUInt32(4278239231U),
							Offset = 0.0
						},
						new GradientStop
						{
							Color = Color.FromUInt32(4284881407U),
							Offset = 1.0
						}
					}
				}
			});
			styles6.Add(style7);
			TextBlock textBlock15;
			TextBlock textBlock14 = textBlock15 = new TextBlock();
			((ISupportInitialize)textBlock14).BeginInit();
			border10.Child = textBlock14;
			ISupportInitialize supportInitialize19 = textBlock3 = textBlock15;
			context.PushParent(textBlock3);
			TextBlock textBlock16 = textBlock3;
			textBlock16.FontSize = 12.0;
			StaticResourceExtension staticResourceExtension7 = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider7 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj7 = staticResourceExtension7.ProvideValue(serviceProvider7);
			context.ProvideTargetProperty = null;
			RefreshView.DynamicSetters_84.DynamicSetter_2(textBlock16, obj7);
			textBlock16.FontWeight = FontWeight.Medium;
			textBlock16.Text = "RESCAN";
			textBlock16.VerticalAlignment = VerticalAlignment.Center;
			textBlock16.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize19.EndInit();
			context.PopParent();
			supportInitialize18.EndInit();
			context.PopParent();
			supportInitialize17.EndInit();
			context.PopParent();
			supportInitialize13.EndInit();
			context.PopParent();
			supportInitialize7.EndInit();
			context.PopParent();
			supportInitialize2.EndInit();
			context.PopParent();
			supportInitialize.EndInit();
			context.PopParent();
			((ISupportInitialize)A_1).EndInit();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x06000069 RID: 105 RVA: 0x00021E40 File Offset: 0x00020040
		private static void !XamlIlPopulateTrampoline(RefreshView A_0)
		{
			if (RefreshView.!XamlIlPopulateOverride != null)
			{
				RefreshView.!XamlIlPopulateOverride(A_0);
				return;
			}
			RefreshView.!XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), A_0);
		}

		// Token: 0x04000015 RID: 21
		private static Action<object> !XamlIlPopulateOverride;

		// Token: 0x0200002F RID: 47
		private class DynamicSetters_84
		{
			// Token: 0x0600006A RID: 106 RVA: 0x00021E68 File Offset: 0x00020068
			public static void DynamicSetter_1(Path A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(Path.DataProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(Path.DataProperty, A_1, null);
					return;
				}
				if (A_1 is Geometry)
				{
					A_0.Data = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.Data = A_1;
					return;
				}
				throw new InvalidCastException();
			}

			// Token: 0x0600006B RID: 107 RVA: 0x00021ED4 File Offset: 0x000200D4
			public static void DynamicSetter_2(TextBlock A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
					return;
				}
				if (A_1 is FontFamily)
				{
					A_0.FontFamily = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.FontFamily = A_1;
					return;
				}
				throw new InvalidCastException();
			}

			// Token: 0x0600006C RID: 108 RVA: 0x00021F40 File Offset: 0x00020140
			public static void DynamicSetter_3(TextElement A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(TextElement.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(TextElement.FontFamilyProperty, A_1, null);
					return;
				}
				if (A_1 is FontFamily)
				{
					A_0.FontFamily = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.FontFamily = A_1;
					return;
				}
				throw new InvalidCastException();
			}
		}
	}
}
