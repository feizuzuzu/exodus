﻿using System;
using System.ComponentModel;
using System.Globalization;
using Avalonia;
using Avalonia.Collections;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Data.Core;
using Avalonia.Data.Core.Plugins;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;

namespace Exodus.Views
{
	// Token: 0x02000036 RID: 54
	public class UpdateAddressWindow : Window
	{
		// Token: 0x0600007D RID: 125 RVA: 0x00027FD5 File Offset: 0x000261D5
		public UpdateAddressWindow()
		{
			this.InitializeComponent(true);
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00027FE4 File Offset: 0x000261E4
		public void InitializeComponent(bool loadXaml = true)
		{
			if (loadXaml)
			{
				UpdateAddressWindow.!XamlIlPopulateTrampoline(this);
			}
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00027FF0 File Offset: 0x000261F0
		static void !XamlIlPopulate(IServiceProvider A_0, UpdateAddressWindow A_1)
		{
			XamlIlContext.Context<UpdateAddressWindow> context = new XamlIlContext.Context<UpdateAddressWindow>(A_0, new object[]
			{
				(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/UpdateAddressWindow.axaml.Singleton
			}, "avares://Exodus/Views/UpdateAddressWindow.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			((ISupportInitialize)A_1).BeginInit();
			context.PushParent(A_1);
			A_1.Width = 680.0;
			A_1.Height = 150.0;
			A_1.ShowInTaskbar = false;
			A_1.Icon = (WindowIcon)new IconTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/logo.ico");
			A_1.Background = new ImmutableSolidColorBrush(4278980111U);
			A_1.Title = "Update Address - Exodus";
			Styles styles = A_1.Styles;
			Style style = new Style();
			style.Selector = Selectors.OfType((Selector)null, typeof(TextBlock));
			style.Add(new Setter
			{
				Property = TextBlock.FontSizeProperty,
				Value = 14.0
			});
			styles.Add(style);
			StackPanel stackPanel2;
			StackPanel stackPanel = stackPanel2 = new StackPanel();
			((ISupportInitialize)stackPanel).BeginInit();
			A_1.Content = stackPanel;
			StackPanel stackPanel3;
			ISupportInitialize supportInitialize = stackPanel3 = stackPanel2;
			context.PushParent(stackPanel3);
			StackPanel stackPanel4 = stackPanel3;
			stackPanel4.Spacing = 5.0;
			stackPanel4.Margin = new Thickness(12.0, 12.0, 12.0, 12.0);
			AvaloniaList<Control> children = stackPanel4.Children;
			Grid grid2;
			Grid grid = grid2 = new Grid();
			((ISupportInitialize)grid).BeginInit();
			children.Add(grid);
			Grid grid3;
			ISupportInitialize supportInitialize2 = grid3 = grid2;
			context.PushParent(grid3);
			Grid grid4 = grid3;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 2;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(100.0, GridUnitType.Pixel)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid4.ColumnDefinitions = columnDefinitions;
			grid4.Margin = new Thickness(6.0, 0.0, 6.0, 0.0);
			AvaloniaList<Control> children2 = grid4.Children;
			TextBlock textBlock2;
			TextBlock textBlock = textBlock2 = new TextBlock();
			((ISupportInitialize)textBlock).BeginInit();
			children2.Add(textBlock);
			TextBlock textBlock3 = textBlock2;
			Grid.SetColumn(textBlock3, 0);
			textBlock3.Text = "New Address";
			textBlock3.Margin = new Thickness(0.0, 0.0, 5.0, 0.0);
			textBlock3.HorizontalAlignment = HorizontalAlignment.Left;
			textBlock3.VerticalAlignment = VerticalAlignment.Center;
			textBlock3.TextAlignment = TextAlignment.Left;
			((ISupportInitialize)textBlock3).EndInit();
			AvaloniaList<Control> children3 = grid4.Children;
			TextBox textBox2;
			TextBox textBox = textBox2 = new TextBox();
			((ISupportInitialize)textBox).BeginInit();
			children3.Add(textBox);
			TextBox textBox3;
			ISupportInitialize supportInitialize3 = textBox3 = textBox2;
			context.PushParent(textBox3);
			TextBox textBox4 = textBox3;
			Grid.SetColumn(textBox4, 1);
			AvaloniaProperty textProperty = TextBox.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.UpdateAddressWindowViewModel,Exodus.DraftAddress!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider = context;
			context.ProvideTargetProperty = TextBox.TextProperty;
			IBinding binding = compiledBindingExtension.ProvideValue(provider);
			context.ProvideTargetProperty = null;
			textBox4.Bind(textProperty, binding, null);
			textBox4.Background = new ImmutableSolidColorBrush(4280428589U);
			textBox4.BorderBrush = new ImmutableSolidColorBrush(4280428589U);
			textBox4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
			textBox4.VerticalAlignment = VerticalAlignment.Center;
			textBox4.HorizontalAlignment = HorizontalAlignment.Stretch;
			textBox4.HorizontalContentAlignment = HorizontalAlignment.Left;
			textBox4.VerticalContentAlignment = VerticalAlignment.Center;
			textBox4.TextAlignment = TextAlignment.Left;
			context.PopParent();
			supportInitialize3.EndInit();
			context.PopParent();
			supportInitialize2.EndInit();
			AvaloniaList<Control> children4 = stackPanel4.Children;
			Grid grid6;
			Grid grid5 = grid6 = new Grid();
			((ISupportInitialize)grid5).BeginInit();
			children4.Add(grid5);
			ISupportInitialize supportInitialize4 = grid3 = grid6;
			context.PushParent(grid3);
			Grid grid7 = grid3;
			ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
			columnDefinitions2.Capacity = 2;
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid7.ColumnDefinitions = columnDefinitions2;
			grid7.Margin = new Thickness(15.0, 20.0, 15.0, 10.0);
			AvaloniaList<Control> children5 = grid7.Children;
			Button button2;
			Button button = button2 = new Button();
			((ISupportInitialize)button).BeginInit();
			children5.Add(button);
			Button button3;
			ISupportInitialize supportInitialize5 = button3 = button2;
			context.PushParent(button3);
			Button button4 = button3;
			Grid.SetColumn(button4, 0);
			AvaloniaProperty commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("Save", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.UpdateAddressWindowViewModel+Save_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider2 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding2 = compiledBindingExtension2.ProvideValue(provider2);
			context.ProvideTargetProperty = null;
			button4.Bind(commandProperty, binding2, null);
			button4.Background = new ImmutableSolidColorBrush(16777215U);
			button4.VerticalAlignment = VerticalAlignment.Center;
			button4.HorizontalAlignment = HorizontalAlignment.Center;
			Border border2;
			Border border = border2 = new Border();
			((ISupportInitialize)border).BeginInit();
			button4.Content = border;
			Border border3 = border2;
			border3.Background = new ImmutableSolidColorBrush(4280428589U);
			border3.CornerRadius = new CornerRadius(7.0, 7.0, 7.0, 7.0);
			border3.Height = 32.0;
			border3.Width = 120.0;
			TextBlock textBlock5;
			TextBlock textBlock4 = textBlock5 = new TextBlock();
			((ISupportInitialize)textBlock4).BeginInit();
			border3.Child = textBlock4;
			TextBlock textBlock6 = textBlock5;
			textBlock6.Text = "Save";
			textBlock6.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock6.VerticalAlignment = VerticalAlignment.Center;
			textBlock6.TextAlignment = TextAlignment.Center;
			((ISupportInitialize)textBlock6).EndInit();
			((ISupportInitialize)border3).EndInit();
			context.PopParent();
			supportInitialize5.EndInit();
			AvaloniaList<Control> children6 = grid7.Children;
			Button button6;
			Button button5 = button6 = new Button();
			((ISupportInitialize)button5).BeginInit();
			children6.Add(button5);
			ISupportInitialize supportInitialize6 = button3 = button6;
			context.PushParent(button3);
			Button button7 = button3;
			Grid.SetColumn(button7, 1);
			AvaloniaProperty commandProperty2 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("Close", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.UpdateAddressWindowViewModel+Close_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider3 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding3 = compiledBindingExtension3.ProvideValue(provider3);
			context.ProvideTargetProperty = null;
			button7.Bind(commandProperty2, binding3, null);
			button7.Background = new ImmutableSolidColorBrush(16777215U);
			button7.VerticalAlignment = VerticalAlignment.Center;
			button7.HorizontalAlignment = HorizontalAlignment.Center;
			Border border5;
			Border border4 = border5 = new Border();
			((ISupportInitialize)border4).BeginInit();
			button7.Content = border4;
			Border border6 = border5;
			border6.Background = new ImmutableSolidColorBrush(4280428589U);
			border6.CornerRadius = new CornerRadius(7.0, 7.0, 7.0, 7.0);
			border6.Height = 32.0;
			border6.Width = 120.0;
			TextBlock textBlock8;
			TextBlock textBlock7 = textBlock8 = new TextBlock();
			((ISupportInitialize)textBlock7).BeginInit();
			border6.Child = textBlock7;
			TextBlock textBlock9 = textBlock8;
			textBlock9.Text = "Cancel";
			textBlock9.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock9.VerticalAlignment = VerticalAlignment.Center;
			textBlock9.TextAlignment = TextAlignment.Center;
			((ISupportInitialize)textBlock9).EndInit();
			((ISupportInitialize)border6).EndInit();
			context.PopParent();
			supportInitialize6.EndInit();
			context.PopParent();
			supportInitialize4.EndInit();
			context.PopParent();
			supportInitialize.EndInit();
			context.PopParent();
			((ISupportInitialize)A_1).EndInit();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00028702 File Offset: 0x00026902
		private static void !XamlIlPopulateTrampoline(UpdateAddressWindow A_0)
		{
			if (UpdateAddressWindow.!XamlIlPopulateOverride != null)
			{
				UpdateAddressWindow.!XamlIlPopulateOverride(A_0);
				return;
			}
			UpdateAddressWindow.!XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), A_0);
		}

		// Token: 0x04000019 RID: 25
		private static Action<object> !XamlIlPopulateOverride;
	}
}
