﻿using System;
using System.ComponentModel;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Collections;
using Avalonia.Controls;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Data.Core;
using Avalonia.Data.Core.Plugins;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;

namespace Exodus.Views
{
	// Token: 0x02000024 RID: 36
	public class NotificationView : UserControl
	{
		// Token: 0x0600004E RID: 78 RVA: 0x00018895 File Offset: 0x00016A95
		public NotificationView()
		{
			this.InitializeComponent(true);
		}

		// Token: 0x0600004F RID: 79 RVA: 0x000188A4 File Offset: 0x00016AA4
		public void InitializeComponent(bool loadXaml = true)
		{
			if (loadXaml)
			{
				NotificationView.!XamlIlPopulateTrampoline(this);
			}
		}

		// Token: 0x06000050 RID: 80 RVA: 0x000188B0 File Offset: 0x00016AB0
		static void !XamlIlPopulate(IServiceProvider A_0, NotificationView A_1)
		{
			XamlIlContext.Context<NotificationView> context = new XamlIlContext.Context<NotificationView>(A_0, new object[]
			{
				(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/NotificationView.axaml.Singleton
			}, "avares://Exodus/Views/NotificationView.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			((ISupportInitialize)A_1).BeginInit();
			context.PushParent(A_1);
			A_1.Background = new ImmutableSolidColorBrush(4279243799U);
			A_1.CornerRadius = new CornerRadius(0.0, 0.0, 0.0, 0.0);
			A_1.Width = 360.0;
			A_1.Height = 55.0;
			Grid grid2;
			Grid grid = grid2 = new Grid();
			((ISupportInitialize)grid).BeginInit();
			A_1.Content = grid;
			Grid grid3;
			ISupportInitialize supportInitialize = grid3 = grid2;
			context.PushParent(grid3);
			Grid grid4 = grid3;
			RowDefinitions rowDefinitions = new RowDefinitions();
			rowDefinitions.Capacity = 2;
			rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid4.RowDefinitions = rowDefinitions;
			AvaloniaList<Control> children = grid4.Children;
			Grid grid6;
			Grid grid5 = grid6 = new Grid();
			((ISupportInitialize)grid5).BeginInit();
			children.Add(grid5);
			ISupportInitialize supportInitialize2 = grid3 = grid6;
			context.PushParent(grid3);
			Grid grid7 = grid3;
			Grid.SetRow(grid7, 0);
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 6;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid7.ColumnDefinitions = columnDefinitions;
			grid7.VerticalAlignment = VerticalAlignment.Stretch;
			AvaloniaList<Control> children2 = grid7.Children;
			Image image2;
			Image image = image2 = new Image();
			((ISupportInitialize)image).BeginInit();
			children2.Add(image);
			Image image3;
			ISupportInitialize supportInitialize3 = image3 = image2;
			context.PushParent(image3);
			Image image4 = image3;
			Grid.SetColumn(image4, 0);
			AvaloniaProperty sourceProperty = Image.SourceProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.Logo!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider = context;
			context.ProvideTargetProperty = Image.SourceProperty;
			IBinding binding = compiledBindingExtension.ProvideValue(provider);
			context.ProvideTargetProperty = null;
			image4.Bind(sourceProperty, binding, null);
			image4.Height = 32.0;
			image4.Stretch = Stretch.Uniform;
			RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
			image4.VerticalAlignment = VerticalAlignment.Center;
			image4.Margin = new Thickness(15.0, 0.0, 10.0, 0.0);
			context.PopParent();
			supportInitialize3.EndInit();
			AvaloniaList<Control> children3 = grid7.Children;
			TextBlock textBlock2;
			TextBlock textBlock = textBlock2 = new TextBlock();
			((ISupportInitialize)textBlock).BeginInit();
			children3.Add(textBlock);
			TextBlock textBlock3;
			ISupportInitialize supportInitialize4 = textBlock3 = textBlock2;
			context.PushParent(textBlock3);
			TextBlock textBlock4 = textBlock3;
			Grid.SetColumn(textBlock4, 1);
			textBlock4.FontSize = 14.5;
			textBlock4.VerticalAlignment = VerticalAlignment.Center;
			textBlock4.HorizontalAlignment = HorizontalAlignment.Left;
			textBlock4.TextAlignment = TextAlignment.Left;
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj = staticResourceExtension.ProvideValue(serviceProvider);
			context.ProvideTargetProperty = null;
			NotificationView.DynamicSetters_77.DynamicSetter_1(textBlock4, obj);
			textBlock4.FontWeight = FontWeight.Normal;
			textBlock4.Text = "Receiving...";
			textBlock4.Opacity = 0.9;
			context.PopParent();
			supportInitialize4.EndInit();
			AvaloniaList<Control> children4 = grid7.Children;
			TextBlock textBlock6;
			TextBlock textBlock5 = textBlock6 = new TextBlock();
			((ISupportInitialize)textBlock5).BeginInit();
			children4.Add(textBlock5);
			ISupportInitialize supportInitialize5 = textBlock3 = textBlock6;
			context.PushParent(textBlock3);
			TextBlock textBlock7 = textBlock3;
			Grid.SetColumn(textBlock7, 2);
			textBlock7.FontSize = 14.5;
			textBlock7.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
			textBlock7.VerticalAlignment = VerticalAlignment.Center;
			textBlock7.HorizontalAlignment = HorizontalAlignment.Right;
			textBlock7.TextAlignment = TextAlignment.Right;
			StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("RobotoCondensedMedium");
			IServiceProvider serviceProvider2 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj2 = staticResourceExtension2.ProvideValue(serviceProvider2);
			context.ProvideTargetProperty = null;
			NotificationView.DynamicSetters_77.DynamicSetter_1(textBlock7, obj2);
			AvaloniaProperty foregroundProperty = TextBlock.ForegroundProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.ViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider2 = context;
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			IBinding binding2 = compiledBindingExtension2.ProvideValue(provider2);
			context.ProvideTargetProperty = null;
			textBlock7.Bind(foregroundProperty, binding2, null);
			textBlock7.FontWeight = FontWeight.DemiBold;
			AvaloniaProperty textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CurrentlyAdded!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider3 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding3 = compiledBindingExtension3.ProvideValue(provider3);
			context.ProvideTargetProperty = null;
			textBlock7.Bind(textProperty, binding3, null);
			textBlock7.Opacity = 0.75;
			context.PopParent();
			supportInitialize5.EndInit();
			AvaloniaList<Control> children5 = grid7.Children;
			TextBlock textBlock9;
			TextBlock textBlock8 = textBlock9 = new TextBlock();
			((ISupportInitialize)textBlock8).BeginInit();
			children5.Add(textBlock8);
			ISupportInitialize supportInitialize6 = textBlock3 = textBlock9;
			context.PushParent(textBlock3);
			TextBlock textBlock10 = textBlock3;
			Grid.SetColumn(textBlock10, 3);
			textBlock10.FontSize = 14.5;
			textBlock10.VerticalAlignment = VerticalAlignment.Center;
			textBlock10.HorizontalAlignment = HorizontalAlignment.Right;
			textBlock10.TextAlignment = TextAlignment.Right;
			StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("RobotoCondensedMedium");
			IServiceProvider serviceProvider3 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj3 = staticResourceExtension3.ProvideValue(serviceProvider3);
			context.ProvideTargetProperty = null;
			NotificationView.DynamicSetters_77.DynamicSetter_1(textBlock10, obj3);
			AvaloniaProperty foregroundProperty2 = TextBlock.ForegroundProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.ViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.Foreground1!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider4 = context;
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			IBinding binding4 = compiledBindingExtension4.ProvideValue(provider4);
			context.ProvideTargetProperty = null;
			textBlock10.Bind(foregroundProperty2, binding4, null);
			textBlock10.FontWeight = FontWeight.DemiBold;
			AvaloniaProperty textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.ViewPart!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.ViewModels.CoinSpecificPartViewModel,Exodus.MyCoin!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.Models.Coin,Exodus.Symbol!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider5 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding5 = compiledBindingExtension5.ProvideValue(provider5);
			context.ProvideTargetProperty = null;
			textBlock10.Bind(textProperty2, binding5, null);
			textBlock10.Opacity = 0.75;
			context.PopParent();
			supportInitialize6.EndInit();
			AvaloniaList<Control> children6 = grid7.Children;
			Rectangle rectangle2;
			Rectangle rectangle = rectangle2 = new Rectangle();
			((ISupportInitialize)rectangle).BeginInit();
			children6.Add(rectangle);
			Rectangle rectangle3 = rectangle2;
			Grid.SetColumn(rectangle3, 4);
			rectangle3.Width = 1.0;
			rectangle3.VerticalAlignment = VerticalAlignment.Stretch;
			rectangle3.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			rectangle3.Opacity = 0.2;
			rectangle3.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
			((ISupportInitialize)rectangle3).EndInit();
			AvaloniaList<Control> children7 = grid7.Children;
			Button button2;
			Button button = button2 = new Button();
			((ISupportInitialize)button).BeginInit();
			children7.Add(button);
			Button button3;
			ISupportInitialize supportInitialize7 = button3 = button2;
			context.PushParent(button3);
			Button button4 = button3;
			Grid.SetColumn(button4, 5);
			button4.Margin = new Thickness(8.0, 0.0, 8.0, 0.0);
			AvaloniaProperty commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.CloseNotification!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider6 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding6 = compiledBindingExtension6.ProvideValue(provider6);
			context.ProvideTargetProperty = null;
			button4.Bind(commandProperty, binding6, null);
			button4.Background = new ImmutableSolidColorBrush(16777215U);
			button4.VerticalAlignment = VerticalAlignment.Center;
			Viewbox viewbox2;
			Viewbox viewbox = viewbox2 = new Viewbox();
			((ISupportInitialize)viewbox).BeginInit();
			button4.Content = viewbox;
			Viewbox viewbox3;
			ISupportInitialize supportInitialize8 = viewbox3 = viewbox2;
			context.PushParent(viewbox3);
			Viewbox viewbox4 = viewbox3;
			viewbox4.Height = 12.0;
			viewbox4.VerticalAlignment = VerticalAlignment.Center;
			Path path2;
			Path path = path2 = new Path();
			((ISupportInitialize)path).BeginInit();
			viewbox4.Child = path;
			Path path3;
			ISupportInitialize supportInitialize9 = path3 = path2;
			context.PushParent(path3);
			Path path4 = path3;
			StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("Close");
			IServiceProvider serviceProvider4 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj4 = staticResourceExtension4.ProvideValue(serviceProvider4);
			context.ProvideTargetProperty = null;
			NotificationView.DynamicSetters_77.DynamicSetter_2(path4, obj4);
			path4.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			path4.Opacity = 0.9;
			path4.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize9.EndInit();
			context.PopParent();
			supportInitialize8.EndInit();
			context.PopParent();
			supportInitialize7.EndInit();
			context.PopParent();
			supportInitialize2.EndInit();
			AvaloniaList<Control> children8 = grid4.Children;
			Rectangle rectangle5;
			Rectangle rectangle4 = rectangle5 = new Rectangle();
			((ISupportInitialize)rectangle4).BeginInit();
			children8.Add(rectangle4);
			Rectangle rectangle6;
			ISupportInitialize supportInitialize10 = rectangle6 = rectangle5;
			context.PushParent(rectangle6);
			Rectangle rectangle7 = rectangle6;
			Grid.SetRow(rectangle7, 1);
			rectangle7.Height = 1.5;
			rectangle7.HorizontalAlignment = HorizontalAlignment.Left;
			rectangle7.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			rectangle7.Opacity = 0.2;
			AvaloniaProperty widthProperty = Layoutable.WidthProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.NotificationViewModel,Exodus.NotificationStripeWidth!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider7 = context;
			context.ProvideTargetProperty = Layoutable.WidthProperty;
			IBinding binding7 = compiledBindingExtension7.ProvideValue(provider7);
			context.ProvideTargetProperty = null;
			rectangle7.Bind(widthProperty, binding7, null);
			rectangle7.Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = Layoutable.WidthProperty,
					Duration = TimeSpan.FromTicks(36500000L)
				}
			};
			context.PopParent();
			supportInitialize10.EndInit();
			context.PopParent();
			supportInitialize.EndInit();
			context.PopParent();
			((ISupportInitialize)A_1).EndInit();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x06000051 RID: 81 RVA: 0x0001926D File Offset: 0x0001746D
		private static void !XamlIlPopulateTrampoline(NotificationView A_0)
		{
			if (NotificationView.!XamlIlPopulateOverride != null)
			{
				NotificationView.!XamlIlPopulateOverride(A_0);
				return;
			}
			NotificationView.!XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), A_0);
		}

		// Token: 0x04000012 RID: 18
		private static Action<object> !XamlIlPopulateOverride;

		// Token: 0x02000025 RID: 37
		private class DynamicSetters_77
		{
			// Token: 0x06000052 RID: 82 RVA: 0x00019294 File Offset: 0x00017494
			public static void DynamicSetter_1(TextBlock A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
					return;
				}
				if (A_1 is FontFamily)
				{
					A_0.FontFamily = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.FontFamily = A_1;
					return;
				}
				throw new InvalidCastException();
			}

			// Token: 0x06000053 RID: 83 RVA: 0x00019300 File Offset: 0x00017500
			public static void DynamicSetter_2(Path A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(Path.DataProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(Path.DataProperty, A_1, null);
					return;
				}
				if (A_1 is Geometry)
				{
					A_0.Data = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.Data = A_1;
					return;
				}
				throw new InvalidCastException();
			}
		}
	}
}
