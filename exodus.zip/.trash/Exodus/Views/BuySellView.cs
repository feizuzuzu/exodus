﻿using System;
using System.ComponentModel;
using Avalonia;
using Avalonia.Collections;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Controls.Templates;
using Avalonia.Data;
using Avalonia.Data.Core;
using Avalonia.Data.Core.Plugins;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using Exodus.Models;
using Exodus.ViewModels;

namespace Exodus.Views
{
	// Token: 0x0200000C RID: 12
	public class BuySellView : UserControl
	{
		// Token: 0x06000017 RID: 23 RVA: 0x00004655 File Offset: 0x00002855
		public BuySellView()
		{
			this.InitializeComponent(true);
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00004664 File Offset: 0x00002864
		public void InitializeComponent(bool loadXaml = true)
		{
			if (loadXaml)
			{
				BuySellView.!XamlIlPopulateTrampoline(this);
			}
			INameScope nameScope = this.FindNameScope();
			this.BuyScroll = ((nameScope != null) ? nameScope.Find("BuyScroll") : null);
		}

		// Token: 0x06000019 RID: 25 RVA: 0x0000468C File Offset: 0x0000288C
		static void !XamlIlPopulate(IServiceProvider A_0, BuySellView A_1)
		{
			XamlIlContext.Context<BuySellView> context = new XamlIlContext.Context<BuySellView>(A_0, new object[]
			{
				(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.Singleton
			}, "avares://Exodus/Views/BuySellView.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			((ISupportInitialize)A_1).BeginInit();
			context.PushParent(A_1);
			Grid grid2;
			Grid grid = grid2 = new Grid();
			((ISupportInitialize)grid).BeginInit();
			A_1.Content = grid;
			Grid grid3;
			ISupportInitialize supportInitialize = grid3 = grid2;
			context.PushParent(grid3);
			Grid grid4 = grid3;
			AvaloniaList<Control> children = grid4.Children;
			Border border2;
			Border border = border2 = new Border();
			((ISupportInitialize)border).BeginInit();
			children.Add(border);
			Border border3;
			ISupportInitialize supportInitialize2 = border3 = border2;
			context.PushParent(border3);
			Border border4 = border3;
			border4.CornerRadius = new CornerRadius(26.0, 26.0, 0.0, 0.0);
			border4.HorizontalAlignment = HorizontalAlignment.Stretch;
			border4.VerticalAlignment = VerticalAlignment.Stretch;
			border4.Background = new LinearGradientBrush
			{
				StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative),
				EndPoint = new RelativePoint(1.0, 1.0, RelativeUnit.Relative),
				GradientStops = 
				{
					new GradientStop
					{
						Color = Color.FromUInt32(4278848532U),
						Offset = 0.0
					},
					new GradientStop
					{
						Color = Color.FromUInt32(4279375403U),
						Offset = 0.45
					},
					new GradientStop
					{
						Color = Color.FromUInt32(4280226360U),
						Offset = 1.0
					}
				}
			};
			Grid grid6;
			Grid grid5 = grid6 = new Grid();
			((ISupportInitialize)grid5).BeginInit();
			border4.Child = grid5;
			ISupportInitialize supportInitialize3 = grid3 = grid6;
			context.PushParent(grid3);
			Grid grid7 = grid3;
			RowDefinitions rowDefinitions = new RowDefinitions();
			rowDefinitions.Capacity = 2;
			rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid7.RowDefinitions = rowDefinitions;
			AvaloniaList<Control> children2 = grid7.Children;
			Grid grid9;
			Grid grid8 = grid9 = new Grid();
			((ISupportInitialize)grid8).BeginInit();
			children2.Add(grid8);
			ISupportInitialize supportInitialize4 = grid3 = grid9;
			context.PushParent(grid3);
			Grid grid10 = grid3;
			Grid.SetRow(grid10, 0);
			grid10.Margin = new Thickness(24.0, 16.0, 24.0, 0.0);
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 3;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid10.ColumnDefinitions = columnDefinitions;
			AvaloniaList<Control> children3 = grid10.Children;
			Button button2;
			Button button = button2 = new Button();
			((ISupportInitialize)button).BeginInit();
			children3.Add(button);
			Button button3;
			ISupportInitialize supportInitialize5 = button3 = button2;
			context.PushParent(button3);
			Button button4 = button3;
			Grid.SetColumn(button4, 0);
			AvaloniaProperty commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("BackToWallet", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.BuySellViewModel+BackToWallet_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding = compiledBindingExtension.ProvideValue(provider);
			context.ProvideTargetProperty = null;
			button4.Bind(commandProperty, binding, null);
			button4.Background = new ImmutableSolidColorBrush(16777215U);
			button4.Cursor = new Cursor(StandardCursorType.Hand);
			button4.Padding = new Thickness(8.0, 4.0, 8.0, 4.0);
			button4.VerticalAlignment = VerticalAlignment.Center;
			StackPanel stackPanel2;
			StackPanel stackPanel = stackPanel2 = new StackPanel();
			((ISupportInitialize)stackPanel).BeginInit();
			button4.Content = stackPanel;
			StackPanel stackPanel3;
			ISupportInitialize supportInitialize6 = stackPanel3 = stackPanel2;
			context.PushParent(stackPanel3);
			StackPanel stackPanel4 = stackPanel3;
			stackPanel4.Orientation = Orientation.Horizontal;
			stackPanel4.Spacing = 6.0;
			AvaloniaList<Control> children4 = stackPanel4.Children;
			Viewbox viewbox2;
			Viewbox viewbox = viewbox2 = new Viewbox();
			((ISupportInitialize)viewbox).BeginInit();
			children4.Add(viewbox);
			Viewbox viewbox3 = viewbox2;
			viewbox3.Width = 12.0;
			viewbox3.Height = 12.0;
			viewbox3.VerticalAlignment = VerticalAlignment.Center;
			Path path2;
			Path path = path2 = new Path();
			((ISupportInitialize)path).BeginInit();
			viewbox3.Child = path;
			Path path3 = path2;
			path3.Data = Geometry.Parse("M 10 1 L 2 9 L 10 17");
			path3.Stroke = new ImmutableSolidColorBrush(4287469228U);
			path3.StrokeThickness = 2.5;
			path3.StrokeLineCap = PenLineCap.Round;
			path3.StrokeJoin = PenLineJoin.Round;
			((ISupportInitialize)path3).EndInit();
			((ISupportInitialize)viewbox3).EndInit();
			AvaloniaList<Control> children5 = stackPanel4.Children;
			TextBlock textBlock2;
			TextBlock textBlock = textBlock2 = new TextBlock();
			((ISupportInitialize)textBlock).BeginInit();
			children5.Add(textBlock);
			TextBlock textBlock3;
			ISupportInitialize supportInitialize7 = textBlock3 = textBlock2;
			context.PushParent(textBlock3);
			TextBlock textBlock4 = textBlock3;
			textBlock4.Text = "Wallet";
			textBlock4.FontSize = 13.5;
			textBlock4.Foreground = new ImmutableSolidColorBrush(4287469228U);
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj = staticResourceExtension.ProvideValue(serviceProvider);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock4, obj);
			textBlock4.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			supportInitialize7.EndInit();
			context.PopParent();
			supportInitialize6.EndInit();
			context.PopParent();
			supportInitialize5.EndInit();
			AvaloniaList<Control> children6 = grid10.Children;
			StackPanel stackPanel6;
			StackPanel stackPanel5 = stackPanel6 = new StackPanel();
			((ISupportInitialize)stackPanel5).BeginInit();
			children6.Add(stackPanel5);
			ISupportInitialize supportInitialize8 = stackPanel3 = stackPanel6;
			context.PushParent(stackPanel3);
			StackPanel stackPanel7 = stackPanel3;
			Grid.SetColumn(stackPanel7, 1);
			stackPanel7.Orientation = Orientation.Horizontal;
			stackPanel7.HorizontalAlignment = HorizontalAlignment.Center;
			stackPanel7.Spacing = 28.0;
			AvaloniaList<Control> children7 = stackPanel7.Children;
			StackPanel stackPanel9;
			StackPanel stackPanel8 = stackPanel9 = new StackPanel();
			((ISupportInitialize)stackPanel8).BeginInit();
			children7.Add(stackPanel8);
			ISupportInitialize supportInitialize9 = stackPanel3 = stackPanel9;
			context.PushParent(stackPanel3);
			StackPanel stackPanel10 = stackPanel3;
			stackPanel10.Spacing = 6.0;
			stackPanel10.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaList<Control> children8 = stackPanel10.Children;
			TextBlock textBlock6;
			TextBlock textBlock5 = textBlock6 = new TextBlock();
			((ISupportInitialize)textBlock5).BeginInit();
			children8.Add(textBlock5);
			ISupportInitialize supportInitialize10 = textBlock3 = textBlock6;
			context.PushParent(textBlock3);
			TextBlock textBlock7 = textBlock3;
			textBlock7.Text = "Buy Crypto";
			textBlock7.FontSize = 14.5;
			textBlock7.FontWeight = FontWeight.Bold;
			textBlock7.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider2 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj2 = staticResourceExtension2.ProvideValue(serviceProvider2);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock7, obj2);
			context.PopParent();
			supportInitialize10.EndInit();
			AvaloniaList<Control> children9 = stackPanel10.Children;
			Border border6;
			Border border5 = border6 = new Border();
			((ISupportInitialize)border5).BeginInit();
			children9.Add(border5);
			Border border7 = border6;
			border7.Width = 32.0;
			border7.Height = 2.5;
			border7.Background = new ImmutableSolidColorBrush(4283016900U);
			border7.CornerRadius = new CornerRadius(1.5, 1.5, 1.5, 1.5);
			border7.HorizontalAlignment = HorizontalAlignment.Center;
			((ISupportInitialize)border7).EndInit();
			context.PopParent();
			supportInitialize9.EndInit();
			AvaloniaList<Control> children10 = stackPanel7.Children;
			StackPanel stackPanel12;
			StackPanel stackPanel11 = stackPanel12 = new StackPanel();
			((ISupportInitialize)stackPanel11).BeginInit();
			children10.Add(stackPanel11);
			ISupportInitialize supportInitialize11 = stackPanel3 = stackPanel12;
			context.PushParent(stackPanel3);
			StackPanel stackPanel13 = stackPanel3;
			stackPanel13.Spacing = 6.0;
			stackPanel13.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaList<Control> children11 = stackPanel13.Children;
			TextBlock textBlock9;
			TextBlock textBlock8 = textBlock9 = new TextBlock();
			((ISupportInitialize)textBlock8).BeginInit();
			children11.Add(textBlock8);
			ISupportInitialize supportInitialize12 = textBlock3 = textBlock9;
			context.PushParent(textBlock3);
			TextBlock textBlock10 = textBlock3;
			textBlock10.Text = "History";
			textBlock10.FontSize = 14.5;
			textBlock10.FontWeight = FontWeight.Normal;
			textBlock10.Foreground = new ImmutableSolidColorBrush(4285298318U);
			StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider3 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj3 = staticResourceExtension3.ProvideValue(serviceProvider3);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock10, obj3);
			context.PopParent();
			supportInitialize12.EndInit();
			context.PopParent();
			supportInitialize11.EndInit();
			context.PopParent();
			supportInitialize8.EndInit();
			context.PopParent();
			supportInitialize4.EndInit();
			AvaloniaList<Control> children12 = grid7.Children;
			ScrollViewer scrollViewer2;
			ScrollViewer scrollViewer = scrollViewer2 = new ScrollViewer();
			((ISupportInitialize)scrollViewer).BeginInit();
			children12.Add(scrollViewer);
			ScrollViewer scrollViewer3;
			ISupportInitialize supportInitialize13 = scrollViewer3 = scrollViewer2;
			context.PushParent(scrollViewer3);
			ScrollViewer scrollViewer4 = scrollViewer3;
			scrollViewer4.Name = "BuyScroll";
			object element = scrollViewer4;
			context.AvaloniaNameScope.Register("BuyScroll", element);
			Grid.SetRow(scrollViewer4, 1);
			scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
			scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			Grid grid12;
			Grid grid11 = grid12 = new Grid();
			((ISupportInitialize)grid11).BeginInit();
			scrollViewer4.Content = grid11;
			ISupportInitialize supportInitialize14 = grid3 = grid12;
			context.PushParent(grid3);
			Grid grid13 = grid3;
			grid13.HorizontalAlignment = HorizontalAlignment.Stretch;
			grid13.VerticalAlignment = VerticalAlignment.Stretch;
			AvaloniaProperty minHeightProperty = Layoutable.MinHeightProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "BuyScroll").Property(Visual.BoundsProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).Property(XamlIlHelpers.Avalonia.Rect,Avalonia.Base.Height!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider2 = context;
			context.ProvideTargetProperty = Layoutable.MinHeightProperty;
			IBinding binding2 = compiledBindingExtension2.ProvideValue(provider2);
			context.ProvideTargetProperty = null;
			grid13.Bind(minHeightProperty, binding2, null);
			AvaloniaList<Control> children13 = grid13.Children;
			Grid grid15;
			Grid grid14 = grid15 = new Grid();
			((ISupportInitialize)grid14).BeginInit();
			children13.Add(grid14);
			ISupportInitialize supportInitialize15 = grid3 = grid15;
			context.PushParent(grid3);
			Grid grid16 = grid3;
			grid16.HorizontalAlignment = HorizontalAlignment.Center;
			grid16.VerticalAlignment = VerticalAlignment.Center;
			grid16.Margin = new Thickness(20.0, 30.0, 20.0, 30.0);
			grid16.Width = 490.0;
			AvaloniaList<Control> children14 = grid16.Children;
			Border border9;
			Border border8 = border9 = new Border();
			((ISupportInitialize)border8).BeginInit();
			children14.Add(border8);
			ISupportInitialize supportInitialize16 = border3 = border9;
			context.PushParent(border3);
			Border border10 = border3;
			border10.Background = new ImmutableSolidColorBrush(4279638311U);
			border10.CornerRadius = new CornerRadius(20.0, 20.0, 20.0, 20.0);
			border10.BorderBrush = new ImmutableSolidColorBrush(4280626242U);
			border10.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			border10.Padding = new Thickness(22.0, 22.0, 22.0, 22.0);
			border10.BoxShadow = BoxShadows.Parse("0 14 36 0 #40000000");
			StackPanel stackPanel15;
			StackPanel stackPanel14 = stackPanel15 = new StackPanel();
			((ISupportInitialize)stackPanel14).BeginInit();
			border10.Child = stackPanel14;
			ISupportInitialize supportInitialize17 = stackPanel3 = stackPanel15;
			context.PushParent(stackPanel3);
			StackPanel stackPanel16 = stackPanel3;
			stackPanel16.Spacing = 16.0;
			AvaloniaList<Control> children15 = stackPanel16.Children;
			Border border12;
			Border border11 = border12 = new Border();
			((ISupportInitialize)border11).BeginInit();
			children15.Add(border11);
			ISupportInitialize supportInitialize18 = border3 = border12;
			context.PushParent(border3);
			Border border13 = border3;
			border13.Background = new ImmutableSolidColorBrush(4279243292U);
			border13.CornerRadius = new CornerRadius(14.0, 14.0, 14.0, 14.0);
			border13.BorderBrush = new ImmutableSolidColorBrush(4280230966U);
			border13.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			border13.Padding = new Thickness(16.0, 14.0, 16.0, 14.0);
			StackPanel stackPanel18;
			StackPanel stackPanel17 = stackPanel18 = new StackPanel();
			((ISupportInitialize)stackPanel17).BeginInit();
			border13.Child = stackPanel17;
			ISupportInitialize supportInitialize19 = stackPanel3 = stackPanel18;
			context.PushParent(stackPanel3);
			StackPanel stackPanel19 = stackPanel3;
			stackPanel19.Spacing = 8.0;
			AvaloniaList<Control> children16 = stackPanel19.Children;
			TextBlock textBlock12;
			TextBlock textBlock11 = textBlock12 = new TextBlock();
			((ISupportInitialize)textBlock11).BeginInit();
			children16.Add(textBlock11);
			ISupportInitialize supportInitialize20 = textBlock3 = textBlock12;
			context.PushParent(textBlock3);
			TextBlock textBlock13 = textBlock3;
			textBlock13.Text = "You pay";
			textBlock13.FontSize = 12.5;
			textBlock13.Foreground = new ImmutableSolidColorBrush(4286482334U);
			StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider4 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj4 = staticResourceExtension4.ProvideValue(serviceProvider4);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock13, obj4);
			context.PopParent();
			supportInitialize20.EndInit();
			AvaloniaList<Control> children17 = stackPanel19.Children;
			Grid grid18;
			Grid grid17 = grid18 = new Grid();
			((ISupportInitialize)grid17).BeginInit();
			children17.Add(grid17);
			ISupportInitialize supportInitialize21 = grid3 = grid18;
			context.PushParent(grid3);
			Grid grid19 = grid3;
			ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
			columnDefinitions2.Capacity = 2;
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid19.ColumnDefinitions = columnDefinitions2;
			AvaloniaList<Control> children18 = grid19.Children;
			Button button6;
			Button button5 = button6 = new Button();
			((ISupportInitialize)button5).BeginInit();
			children18.Add(button5);
			ISupportInitialize supportInitialize22 = button3 = button6;
			context.PushParent(button3);
			Button button7 = button3;
			Grid.SetColumn(button7, 0);
			button7.Background = new ImmutableSolidColorBrush(4280165174U);
			button7.CornerRadius = new CornerRadius(10.0, 10.0, 10.0, 10.0);
			button7.Padding = new Thickness(10.0, 6.0, 12.0, 6.0);
			button7.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaProperty commandProperty2 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("OpenFiatPicker", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.BuySellViewModel+OpenFiatPicker_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider3 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding3 = compiledBindingExtension3.ProvideValue(provider3);
			context.ProvideTargetProperty = null;
			button7.Bind(commandProperty2, binding3, null);
			button7.VerticalAlignment = VerticalAlignment.Center;
			StackPanel stackPanel21;
			StackPanel stackPanel20 = stackPanel21 = new StackPanel();
			((ISupportInitialize)stackPanel20).BeginInit();
			button7.Content = stackPanel20;
			ISupportInitialize supportInitialize23 = stackPanel3 = stackPanel21;
			context.PushParent(stackPanel3);
			StackPanel stackPanel22 = stackPanel3;
			stackPanel22.Orientation = Orientation.Horizontal;
			stackPanel22.Spacing = 8.0;
			stackPanel22.VerticalAlignment = VerticalAlignment.Center;
			AvaloniaList<Control> children19 = stackPanel22.Children;
			TextBlock textBlock15;
			TextBlock textBlock14 = textBlock15 = new TextBlock();
			((ISupportInitialize)textBlock14).BeginInit();
			children19.Add(textBlock14);
			ISupportInitialize supportInitialize24 = textBlock3 = textBlock15;
			context.PushParent(textBlock3);
			TextBlock textBlock16 = textBlock3;
			AvaloniaProperty textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedFiat!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.Models.FiatItem,Exodus.FlagEmoji!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider4 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding4 = compiledBindingExtension4.ProvideValue(provider4);
			context.ProvideTargetProperty = null;
			textBlock16.Bind(textProperty, binding4, null);
			textBlock16.FontSize = 18.0;
			textBlock16.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			supportInitialize24.EndInit();
			AvaloniaList<Control> children20 = stackPanel22.Children;
			TextBlock textBlock18;
			TextBlock textBlock17 = textBlock18 = new TextBlock();
			((ISupportInitialize)textBlock17).BeginInit();
			children20.Add(textBlock17);
			ISupportInitialize supportInitialize25 = textBlock3 = textBlock18;
			context.PushParent(textBlock3);
			TextBlock textBlock19 = textBlock3;
			AvaloniaProperty textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedFiat!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Code!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider5 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding5 = compiledBindingExtension5.ProvideValue(provider5);
			context.ProvideTargetProperty = null;
			textBlock19.Bind(textProperty2, binding5, null);
			textBlock19.FontSize = 16.0;
			textBlock19.FontWeight = FontWeight.Bold;
			textBlock19.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock19.VerticalAlignment = VerticalAlignment.Center;
			StaticResourceExtension staticResourceExtension5 = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider5 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj5 = staticResourceExtension5.ProvideValue(serviceProvider5);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock19, obj5);
			context.PopParent();
			supportInitialize25.EndInit();
			AvaloniaList<Control> children21 = stackPanel22.Children;
			Viewbox viewbox5;
			Viewbox viewbox4 = viewbox5 = new Viewbox();
			((ISupportInitialize)viewbox4).BeginInit();
			children21.Add(viewbox4);
			Viewbox viewbox6;
			ISupportInitialize supportInitialize26 = viewbox6 = viewbox5;
			context.PushParent(viewbox6);
			Viewbox viewbox7 = viewbox6;
			viewbox7.Width = 8.0;
			viewbox7.Height = 8.0;
			viewbox7.VerticalAlignment = VerticalAlignment.Center;
			viewbox7.Margin = new Thickness(2.0, 0.0, 0.0, 0.0);
			Path path5;
			Path path4 = path5 = new Path();
			((ISupportInitialize)path4).BeginInit();
			viewbox7.Child = path4;
			Path path6;
			ISupportInitialize supportInitialize27 = path6 = path5;
			context.PushParent(path6);
			Path path7 = path6;
			StaticResourceExtension staticResourceExtension6 = new StaticResourceExtension("PointDownFullArrow");
			IServiceProvider serviceProvider6 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj6 = staticResourceExtension6.ProvideValue(serviceProvider6);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_2(path7, obj6);
			path7.Fill = new ImmutableSolidColorBrush(4286482334U);
			path7.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize27.EndInit();
			context.PopParent();
			supportInitialize26.EndInit();
			context.PopParent();
			supportInitialize23.EndInit();
			context.PopParent();
			supportInitialize22.EndInit();
			AvaloniaList<Control> children22 = grid19.Children;
			TextBox textBox2;
			TextBox textBox = textBox2 = new TextBox();
			((ISupportInitialize)textBox).BeginInit();
			children22.Add(textBox);
			TextBox textBox3;
			ISupportInitialize supportInitialize28 = textBox3 = textBox2;
			context.PushParent(textBox3);
			TextBox textBox4 = textBox3;
			Grid.SetColumn(textBox4, 1);
			AvaloniaProperty textProperty3 = TextBox.TextProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.PayAmountString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider6 = context;
			context.ProvideTargetProperty = TextBox.TextProperty;
			IBinding binding6 = compiledBindingExtension6.ProvideValue(provider6);
			context.ProvideTargetProperty = null;
			textBox4.Bind(textProperty3, binding6, null);
			textBox4.FontSize = 24.0;
			textBox4.FontWeight = FontWeight.Bold;
			textBox4.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBox4.HorizontalContentAlignment = HorizontalAlignment.Right;
			textBox4.Background = new ImmutableSolidColorBrush(16777215U);
			textBox4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
			StaticResourceExtension staticResourceExtension7 = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider7 = context;
			context.ProvideTargetProperty = TemplatedControl.FontFamilyProperty;
			object obj7 = staticResourceExtension7.ProvideValue(serviceProvider7);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_3(textBox4, obj7);
			textBox4.VerticalAlignment = VerticalAlignment.Center;
			textBox4.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			context.PopParent();
			supportInitialize28.EndInit();
			context.PopParent();
			supportInitialize21.EndInit();
			context.PopParent();
			supportInitialize19.EndInit();
			context.PopParent();
			supportInitialize18.EndInit();
			AvaloniaList<Control> children23 = stackPanel16.Children;
			Border border15;
			Border border14 = border15 = new Border();
			((ISupportInitialize)border14).BeginInit();
			children23.Add(border14);
			ISupportInitialize supportInitialize29 = border3 = border15;
			context.PushParent(border3);
			Border border16 = border3;
			border16.Background = new ImmutableSolidColorBrush(4279243292U);
			border16.CornerRadius = new CornerRadius(14.0, 14.0, 14.0, 14.0);
			border16.BorderBrush = new ImmutableSolidColorBrush(4280230966U);
			border16.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			border16.Padding = new Thickness(16.0, 14.0, 16.0, 14.0);
			StackPanel stackPanel24;
			StackPanel stackPanel23 = stackPanel24 = new StackPanel();
			((ISupportInitialize)stackPanel23).BeginInit();
			border16.Child = stackPanel23;
			ISupportInitialize supportInitialize30 = stackPanel3 = stackPanel24;
			context.PushParent(stackPanel3);
			StackPanel stackPanel25 = stackPanel3;
			stackPanel25.Spacing = 8.0;
			AvaloniaList<Control> children24 = stackPanel25.Children;
			TextBlock textBlock21;
			TextBlock textBlock20 = textBlock21 = new TextBlock();
			((ISupportInitialize)textBlock20).BeginInit();
			children24.Add(textBlock20);
			ISupportInitialize supportInitialize31 = textBlock3 = textBlock21;
			context.PushParent(textBlock3);
			TextBlock textBlock22 = textBlock3;
			textBlock22.Text = "You receive";
			textBlock22.FontSize = 12.5;
			textBlock22.Foreground = new ImmutableSolidColorBrush(4286482334U);
			StaticResourceExtension staticResourceExtension8 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider8 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj8 = staticResourceExtension8.ProvideValue(serviceProvider8);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock22, obj8);
			context.PopParent();
			supportInitialize31.EndInit();
			AvaloniaList<Control> children25 = stackPanel25.Children;
			Grid grid21;
			Grid grid20 = grid21 = new Grid();
			((ISupportInitialize)grid20).BeginInit();
			children25.Add(grid20);
			ISupportInitialize supportInitialize32 = grid3 = grid21;
			context.PushParent(grid3);
			Grid grid22 = grid3;
			ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
			columnDefinitions3.Capacity = 2;
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid22.ColumnDefinitions = columnDefinitions3;
			AvaloniaList<Control> children26 = grid22.Children;
			Button button9;
			Button button8 = button9 = new Button();
			((ISupportInitialize)button8).BeginInit();
			children26.Add(button8);
			ISupportInitialize supportInitialize33 = button3 = button9;
			context.PushParent(button3);
			Button button10 = button3;
			Grid.SetColumn(button10, 0);
			button10.Background = new ImmutableSolidColorBrush(4280165174U);
			button10.CornerRadius = new CornerRadius(10.0, 10.0, 10.0, 10.0);
			button10.Padding = new Thickness(8.0, 6.0, 12.0, 6.0);
			button10.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaProperty commandProperty3 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("OpenCryptoPicker", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.BuySellViewModel+OpenCryptoPicker_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider7 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding7 = compiledBindingExtension7.ProvideValue(provider7);
			context.ProvideTargetProperty = null;
			button10.Bind(commandProperty3, binding7, null);
			button10.VerticalAlignment = VerticalAlignment.Center;
			StackPanel stackPanel27;
			StackPanel stackPanel26 = stackPanel27 = new StackPanel();
			((ISupportInitialize)stackPanel26).BeginInit();
			button10.Content = stackPanel26;
			ISupportInitialize supportInitialize34 = stackPanel3 = stackPanel27;
			context.PushParent(stackPanel3);
			StackPanel stackPanel28 = stackPanel3;
			stackPanel28.Orientation = Orientation.Horizontal;
			stackPanel28.Spacing = 10.0;
			stackPanel28.VerticalAlignment = VerticalAlignment.Center;
			AvaloniaList<Control> children27 = stackPanel28.Children;
			Border border18;
			Border border17 = border18 = new Border();
			((ISupportInitialize)border17).BeginInit();
			children27.Add(border17);
			ISupportInitialize supportInitialize35 = border3 = border18;
			context.PushParent(border3);
			Border border19 = border3;
			border19.Width = 28.0;
			border19.Height = 28.0;
			border19.CornerRadius = new CornerRadius(14.0, 14.0, 14.0, 14.0);
			border19.ClipToBounds = true;
			Image image2;
			Image image = image2 = new Image();
			((ISupportInitialize)image).BeginInit();
			border19.Child = image;
			Image image3;
			ISupportInitialize supportInitialize36 = image3 = image2;
			context.PushParent(image3);
			Image image4 = image3;
			AvaloniaProperty sourceProperty = Image.SourceProperty;
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedCrypto!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Icon!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider8 = context;
			context.ProvideTargetProperty = Image.SourceProperty;
			IBinding binding8 = compiledBindingExtension8.ProvideValue(provider8);
			context.ProvideTargetProperty = null;
			image4.Bind(sourceProperty, binding8, null);
			image4.Stretch = Stretch.Uniform;
			RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
			context.PopParent();
			supportInitialize36.EndInit();
			context.PopParent();
			supportInitialize35.EndInit();
			AvaloniaList<Control> children28 = stackPanel28.Children;
			TextBlock textBlock24;
			TextBlock textBlock23 = textBlock24 = new TextBlock();
			((ISupportInitialize)textBlock23).BeginInit();
			children28.Add(textBlock23);
			ISupportInitialize supportInitialize37 = textBlock3 = textBlock24;
			context.PushParent(textBlock3);
			TextBlock textBlock25 = textBlock3;
			AvaloniaProperty textProperty4 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SelectedCrypto!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Property(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Symbol!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider9 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding9 = compiledBindingExtension9.ProvideValue(provider9);
			context.ProvideTargetProperty = null;
			textBlock25.Bind(textProperty4, binding9, null);
			textBlock25.FontSize = 16.0;
			textBlock25.FontWeight = FontWeight.Bold;
			textBlock25.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock25.VerticalAlignment = VerticalAlignment.Center;
			StaticResourceExtension staticResourceExtension9 = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider9 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj9 = staticResourceExtension9.ProvideValue(serviceProvider9);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock25, obj9);
			context.PopParent();
			supportInitialize37.EndInit();
			AvaloniaList<Control> children29 = stackPanel28.Children;
			Viewbox viewbox9;
			Viewbox viewbox8 = viewbox9 = new Viewbox();
			((ISupportInitialize)viewbox8).BeginInit();
			children29.Add(viewbox8);
			ISupportInitialize supportInitialize38 = viewbox6 = viewbox9;
			context.PushParent(viewbox6);
			Viewbox viewbox10 = viewbox6;
			viewbox10.Width = 8.0;
			viewbox10.Height = 8.0;
			viewbox10.VerticalAlignment = VerticalAlignment.Center;
			viewbox10.Margin = new Thickness(2.0, 0.0, 0.0, 0.0);
			Path path9;
			Path path8 = path9 = new Path();
			((ISupportInitialize)path8).BeginInit();
			viewbox10.Child = path8;
			ISupportInitialize supportInitialize39 = path6 = path9;
			context.PushParent(path6);
			Path path10 = path6;
			StaticResourceExtension staticResourceExtension10 = new StaticResourceExtension("PointDownFullArrow");
			IServiceProvider serviceProvider10 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj10 = staticResourceExtension10.ProvideValue(serviceProvider10);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_2(path10, obj10);
			path10.Fill = new ImmutableSolidColorBrush(4286482334U);
			path10.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize39.EndInit();
			context.PopParent();
			supportInitialize38.EndInit();
			context.PopParent();
			supportInitialize34.EndInit();
			context.PopParent();
			supportInitialize33.EndInit();
			AvaloniaList<Control> children30 = grid22.Children;
			TextBlock textBlock27;
			TextBlock textBlock26 = textBlock27 = new TextBlock();
			((ISupportInitialize)textBlock26).BeginInit();
			children30.Add(textBlock26);
			ISupportInitialize supportInitialize40 = textBlock3 = textBlock27;
			context.PushParent(textBlock3);
			TextBlock textBlock28 = textBlock3;
			Grid.SetColumn(textBlock28, 1);
			AvaloniaProperty textProperty5 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ReceiveCryptoString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider10 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding10 = compiledBindingExtension10.ProvideValue(provider10);
			context.ProvideTargetProperty = null;
			textBlock28.Bind(textProperty5, binding10, null);
			textBlock28.FontSize = 24.0;
			textBlock28.FontWeight = FontWeight.Bold;
			textBlock28.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock28.HorizontalAlignment = HorizontalAlignment.Right;
			textBlock28.VerticalAlignment = VerticalAlignment.Center;
			StaticResourceExtension staticResourceExtension11 = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider11 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj11 = staticResourceExtension11.ProvideValue(serviceProvider11);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock28, obj11);
			context.PopParent();
			supportInitialize40.EndInit();
			context.PopParent();
			supportInitialize32.EndInit();
			context.PopParent();
			supportInitialize30.EndInit();
			context.PopParent();
			supportInitialize29.EndInit();
			AvaloniaList<Control> children31 = stackPanel16.Children;
			StackPanel stackPanel30;
			StackPanel stackPanel29 = stackPanel30 = new StackPanel();
			((ISupportInitialize)stackPanel29).BeginInit();
			children31.Add(stackPanel29);
			ISupportInitialize supportInitialize41 = stackPanel3 = stackPanel30;
			context.PushParent(stackPanel3);
			StackPanel stackPanel31 = stackPanel3;
			stackPanel31.Spacing = 4.0;
			stackPanel31.Margin = new Thickness(0.0, 2.0, 0.0, 0.0);
			AvaloniaList<Control> children32 = stackPanel31.Children;
			TextBlock textBlock30;
			TextBlock textBlock29 = textBlock30 = new TextBlock();
			((ISupportInitialize)textBlock29).BeginInit();
			children32.Add(textBlock29);
			ISupportInitialize supportInitialize42 = textBlock3 = textBlock30;
			context.PushParent(textBlock3);
			TextBlock textBlock31 = textBlock3;
			AvaloniaProperty textProperty6 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.RateInfoText!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider11 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding11 = compiledBindingExtension11.ProvideValue(provider11);
			context.ProvideTargetProperty = null;
			textBlock31.Bind(textProperty6, binding11, null);
			textBlock31.FontSize = 12.5;
			textBlock31.Foreground = new ImmutableSolidColorBrush(4287272111U);
			textBlock31.HorizontalAlignment = HorizontalAlignment.Center;
			StaticResourceExtension staticResourceExtension12 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider12 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj12 = staticResourceExtension12.ProvideValue(serviceProvider12);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock31, obj12);
			context.PopParent();
			supportInitialize42.EndInit();
			AvaloniaList<Control> children33 = stackPanel31.Children;
			TextBlock textBlock33;
			TextBlock textBlock32 = textBlock33 = new TextBlock();
			((ISupportInitialize)textBlock32).BeginInit();
			children33.Add(textBlock32);
			ISupportInitialize supportInitialize43 = textBlock3 = textBlock33;
			context.PushParent(textBlock3);
			TextBlock textBlock34 = textBlock3;
			textBlock34.Text = "Debit Card with MoonPay";
			textBlock34.FontSize = 11.5;
			textBlock34.Foreground = new ImmutableSolidColorBrush(4284179578U);
			textBlock34.HorizontalAlignment = HorizontalAlignment.Center;
			StaticResourceExtension staticResourceExtension13 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider13 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj13 = staticResourceExtension13.ProvideValue(serviceProvider13);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock34, obj13);
			context.PopParent();
			supportInitialize43.EndInit();
			context.PopParent();
			supportInitialize41.EndInit();
			AvaloniaList<Control> children34 = stackPanel16.Children;
			Grid grid24;
			Grid grid23 = grid24 = new Grid();
			((ISupportInitialize)grid23).BeginInit();
			children34.Add(grid23);
			ISupportInitialize supportInitialize44 = grid3 = grid24;
			context.PushParent(grid3);
			Grid grid25 = grid3;
			ColumnDefinitions columnDefinitions4 = new ColumnDefinitions();
			columnDefinitions4.Capacity = 3;
			columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid25.ColumnDefinitions = columnDefinitions4;
			grid25.Margin = new Thickness(0.0, 4.0, 0.0, 0.0);
			AvaloniaList<Control> children35 = grid25.Children;
			Button button12;
			Button button11 = button12 = new Button();
			((ISupportInitialize)button11).BeginInit();
			children35.Add(button11);
			ISupportInitialize supportInitialize45 = button3 = button12;
			context.PushParent(button3);
			Button button13 = button3;
			Grid.SetColumn(button13, 0);
			button13.Content = "$100";
			AvaloniaProperty commandProperty4 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("SetPresetAmount", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.BuySellViewModel+SetPresetAmount_1!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider12 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding12 = compiledBindingExtension12.ProvideValue(provider12);
			context.ProvideTargetProperty = null;
			button13.Bind(commandProperty4, binding12, null);
			button13.CommandParameter = "100";
			button13.Height = 34.0;
			button13.Margin = new Thickness(0.0, 0.0, 6.0, 0.0);
			button13.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
			button13.Background = new ImmutableSolidColorBrush(4279967535U);
			button13.Foreground = new ImmutableSolidColorBrush(4287469228U);
			button13.FontSize = 12.5;
			button13.FontWeight = FontWeight.DemiBold;
			button13.HorizontalAlignment = HorizontalAlignment.Stretch;
			button13.HorizontalContentAlignment = HorizontalAlignment.Center;
			button13.Cursor = new Cursor(StandardCursorType.Hand);
			context.PopParent();
			supportInitialize45.EndInit();
			AvaloniaList<Control> children36 = grid25.Children;
			Button button15;
			Button button14 = button15 = new Button();
			((ISupportInitialize)button14).BeginInit();
			children36.Add(button14);
			ISupportInitialize supportInitialize46 = button3 = button15;
			context.PushParent(button3);
			Button button16 = button3;
			Grid.SetColumn(button16, 1);
			button16.Content = "$500";
			AvaloniaProperty commandProperty5 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("SetPresetAmount", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.BuySellViewModel+SetPresetAmount_1!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider13 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding13 = compiledBindingExtension13.ProvideValue(provider13);
			context.ProvideTargetProperty = null;
			button16.Bind(commandProperty5, binding13, null);
			button16.CommandParameter = "500";
			button16.Height = 34.0;
			button16.Margin = new Thickness(3.0, 0.0, 3.0, 0.0);
			button16.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
			button16.Background = new ImmutableSolidColorBrush(4279967535U);
			button16.Foreground = new ImmutableSolidColorBrush(4287469228U);
			button16.FontSize = 12.5;
			button16.FontWeight = FontWeight.DemiBold;
			button16.HorizontalAlignment = HorizontalAlignment.Stretch;
			button16.HorizontalContentAlignment = HorizontalAlignment.Center;
			button16.Cursor = new Cursor(StandardCursorType.Hand);
			context.PopParent();
			supportInitialize46.EndInit();
			AvaloniaList<Control> children37 = grid25.Children;
			Button button18;
			Button button17 = button18 = new Button();
			((ISupportInitialize)button17).BeginInit();
			children37.Add(button17);
			ISupportInitialize supportInitialize47 = button3 = button18;
			context.PushParent(button3);
			Button button19 = button3;
			Grid.SetColumn(button19, 2);
			button19.Content = "MAX";
			AvaloniaProperty commandProperty6 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("SetPresetAmount", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.BuySellViewModel+SetPresetAmount_1!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider14 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding14 = compiledBindingExtension14.ProvideValue(provider14);
			context.ProvideTargetProperty = null;
			button19.Bind(commandProperty6, binding14, null);
			button19.CommandParameter = "2000";
			button19.Height = 34.0;
			button19.Margin = new Thickness(6.0, 0.0, 0.0, 0.0);
			button19.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
			button19.Background = new ImmutableSolidColorBrush(4279967535U);
			button19.Foreground = new ImmutableSolidColorBrush(4287469228U);
			button19.FontSize = 12.5;
			button19.FontWeight = FontWeight.DemiBold;
			button19.HorizontalAlignment = HorizontalAlignment.Stretch;
			button19.HorizontalContentAlignment = HorizontalAlignment.Center;
			button19.Cursor = new Cursor(StandardCursorType.Hand);
			context.PopParent();
			supportInitialize47.EndInit();
			context.PopParent();
			supportInitialize44.EndInit();
			AvaloniaList<Control> children38 = stackPanel16.Children;
			Button button21;
			Button button20 = button21 = new Button();
			((ISupportInitialize)button20).BeginInit();
			children38.Add(button20);
			ISupportInitialize supportInitialize48 = button3 = button21;
			context.PushParent(button3);
			Button button22 = button3;
			button22.Height = 48.0;
			button22.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
			button22.CornerRadius = new CornerRadius(12.0, 12.0, 12.0, 12.0);
			button22.HorizontalAlignment = HorizontalAlignment.Stretch;
			button22.HorizontalContentAlignment = HorizontalAlignment.Center;
			button22.Cursor = new Cursor(StandardCursorType.Hand);
			AvaloniaProperty commandProperty7 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("ExecuteContinue", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.BuySellViewModel+ExecuteContinue_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider15 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding15 = compiledBindingExtension15.ProvideValue(provider15);
			context.ProvideTargetProperty = null;
			button22.Bind(commandProperty7, binding15, null);
			button22.Background = new LinearGradientBrush
			{
				StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative),
				EndPoint = new RelativePoint(1.0, 1.0, RelativeUnit.Relative),
				GradientStops = 
				{
					new GradientStop
					{
						Color = Color.FromUInt32(4285281758U),
						Offset = 0.0
					},
					new GradientStop
					{
						Color = Color.FromUInt32(4287837162U),
						Offset = 1.0
					}
				}
			};
			TextBlock textBlock36;
			TextBlock textBlock35 = textBlock36 = new TextBlock();
			((ISupportInitialize)textBlock35).BeginInit();
			button22.Content = textBlock35;
			ISupportInitialize supportInitialize49 = textBlock3 = textBlock36;
			context.PushParent(textBlock3);
			TextBlock textBlock37 = textBlock3;
			textBlock37.Text = "CONTINUE";
			textBlock37.FontSize = 14.5;
			textBlock37.FontWeight = FontWeight.Bold;
			textBlock37.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock37.LetterSpacing = 1.0;
			StaticResourceExtension staticResourceExtension14 = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider14 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj14 = staticResourceExtension14.ProvideValue(serviceProvider14);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock37, obj14);
			textBlock37.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			supportInitialize49.EndInit();
			context.PopParent();
			supportInitialize48.EndInit();
			context.PopParent();
			supportInitialize17.EndInit();
			context.PopParent();
			supportInitialize16.EndInit();
			context.PopParent();
			supportInitialize15.EndInit();
			context.PopParent();
			supportInitialize14.EndInit();
			context.PopParent();
			supportInitialize13.EndInit();
			context.PopParent();
			supportInitialize3.EndInit();
			context.PopParent();
			supportInitialize2.EndInit();
			AvaloniaList<Control> children39 = grid4.Children;
			Grid grid27;
			Grid grid26 = grid27 = new Grid();
			((ISupportInitialize)grid26).BeginInit();
			children39.Add(grid26);
			ISupportInitialize supportInitialize50 = grid3 = grid27;
			context.PushParent(grid3);
			Grid grid28 = grid3;
			AvaloniaProperty isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsCryptoPickerOpen!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider16 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding16 = compiledBindingExtension16.ProvideValue(provider16);
			context.ProvideTargetProperty = null;
			grid28.Bind(isVisibleProperty, binding16, null);
			grid28.ZIndex = 500;
			grid28.Background = new ImmutableSolidColorBrush(2415919104U);
			AvaloniaList<Control> children40 = grid28.Children;
			Border border21;
			Border border20 = border21 = new Border();
			((ISupportInitialize)border20).BeginInit();
			children40.Add(border20);
			ISupportInitialize supportInitialize51 = border3 = border21;
			context.PushParent(border3);
			Border border22 = border3;
			border22.Background = new ImmutableSolidColorBrush(4279769894U);
			border22.Width = 440.0;
			border22.Height = 530.0;
			border22.CornerRadius = new CornerRadius(18.0, 18.0, 18.0, 18.0);
			border22.BorderBrush = new ImmutableSolidColorBrush(4281284172U);
			border22.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			border22.HorizontalAlignment = HorizontalAlignment.Center;
			border22.VerticalAlignment = VerticalAlignment.Center;
			border22.BoxShadow = BoxShadows.Parse("0 16 40 0 #50000000");
			border22.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			Grid grid30;
			Grid grid29 = grid30 = new Grid();
			((ISupportInitialize)grid29).BeginInit();
			border22.Child = grid29;
			ISupportInitialize supportInitialize52 = grid3 = grid30;
			context.PushParent(grid3);
			Grid grid31 = grid3;
			RowDefinitions rowDefinitions2 = new RowDefinitions();
			rowDefinitions2.Capacity = 3;
			rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions2.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid31.RowDefinitions = rowDefinitions2;
			AvaloniaList<Control> children41 = grid31.Children;
			Grid grid33;
			Grid grid32 = grid33 = new Grid();
			((ISupportInitialize)grid32).BeginInit();
			children41.Add(grid32);
			ISupportInitialize supportInitialize53 = grid3 = grid33;
			context.PushParent(grid3);
			Grid grid34 = grid3;
			Grid.SetRow(grid34, 0);
			ColumnDefinitions columnDefinitions5 = new ColumnDefinitions();
			columnDefinitions5.Capacity = 2;
			columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions5.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid34.ColumnDefinitions = columnDefinitions5;
			grid34.Margin = new Thickness(22.0, 18.0, 20.0, 14.0);
			AvaloniaList<Control> children42 = grid34.Children;
			TextBlock textBlock39;
			TextBlock textBlock38 = textBlock39 = new TextBlock();
			((ISupportInitialize)textBlock38).BeginInit();
			children42.Add(textBlock38);
			ISupportInitialize supportInitialize54 = textBlock3 = textBlock39;
			context.PushParent(textBlock3);
			TextBlock textBlock40 = textBlock3;
			Grid.SetColumn(textBlock40, 0);
			textBlock40.Text = "Available to Buy:";
			textBlock40.FontSize = 17.0;
			textBlock40.FontWeight = FontWeight.Bold;
			textBlock40.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock40.VerticalAlignment = VerticalAlignment.Center;
			StaticResourceExtension staticResourceExtension15 = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider15 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj15 = staticResourceExtension15.ProvideValue(serviceProvider15);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock40, obj15);
			context.PopParent();
			supportInitialize54.EndInit();
			AvaloniaList<Control> children43 = grid34.Children;
			Button button24;
			Button button23 = button24 = new Button();
			((ISupportInitialize)button23).BeginInit();
			children43.Add(button23);
			ISupportInitialize supportInitialize55 = button3 = button24;
			context.PushParent(button3);
			Button button25 = button3;
			Grid.SetColumn(button25, 1);
			AvaloniaProperty commandProperty8 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("CloseCryptoPicker", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.BuySellViewModel+CloseCryptoPicker_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider17 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding17 = compiledBindingExtension17.ProvideValue(provider17);
			context.ProvideTargetProperty = null;
			button25.Bind(commandProperty8, binding17, null);
			button25.Background = new ImmutableSolidColorBrush(4280428086U);
			button25.Width = 30.0;
			button25.Height = 30.0;
			button25.CornerRadius = new CornerRadius(15.0, 15.0, 15.0, 15.0);
			button25.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			button25.Cursor = new Cursor(StandardCursorType.Hand);
			Viewbox viewbox12;
			Viewbox viewbox11 = viewbox12 = new Viewbox();
			((ISupportInitialize)viewbox11).BeginInit();
			button25.Content = viewbox11;
			ISupportInitialize supportInitialize56 = viewbox6 = viewbox12;
			context.PushParent(viewbox6);
			Viewbox viewbox13 = viewbox6;
			viewbox13.Width = 10.0;
			viewbox13.Height = 10.0;
			viewbox13.HorizontalAlignment = HorizontalAlignment.Center;
			viewbox13.VerticalAlignment = VerticalAlignment.Center;
			Path path12;
			Path path11 = path12 = new Path();
			((ISupportInitialize)path11).BeginInit();
			viewbox13.Child = path11;
			ISupportInitialize supportInitialize57 = path6 = path12;
			context.PushParent(path6);
			Path path13 = path6;
			StaticResourceExtension staticResourceExtension16 = new StaticResourceExtension("Close");
			IServiceProvider serviceProvider16 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj16 = staticResourceExtension16.ProvideValue(serviceProvider16);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_2(path13, obj16);
			path13.Fill = new ImmutableSolidColorBrush(4287272111U);
			path13.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize57.EndInit();
			context.PopParent();
			supportInitialize56.EndInit();
			context.PopParent();
			supportInitialize55.EndInit();
			context.PopParent();
			supportInitialize53.EndInit();
			AvaloniaList<Control> children44 = grid31.Children;
			Border border24;
			Border border23 = border24 = new Border();
			((ISupportInitialize)border23).BeginInit();
			children44.Add(border23);
			ISupportInitialize supportInitialize58 = border3 = border24;
			context.PushParent(border3);
			Border border25 = border3;
			Grid.SetRow(border25, 1);
			border25.Margin = new Thickness(20.0, 0.0, 20.0, 12.0);
			border25.Background = new ImmutableSolidColorBrush(4279374877U);
			border25.CornerRadius = new CornerRadius(10.0, 10.0, 10.0, 10.0);
			border25.BorderBrush = new ImmutableSolidColorBrush(4280625723U);
			border25.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			border25.Height = 40.0;
			border25.Padding = new Thickness(10.0, 0.0, 10.0, 0.0);
			Grid grid36;
			Grid grid35 = grid36 = new Grid();
			((ISupportInitialize)grid35).BeginInit();
			border25.Child = grid35;
			ISupportInitialize supportInitialize59 = grid3 = grid36;
			context.PushParent(grid3);
			Grid grid37 = grid3;
			ColumnDefinitions columnDefinitions6 = new ColumnDefinitions();
			columnDefinitions6.Capacity = 2;
			columnDefinitions6.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions6.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid37.ColumnDefinitions = columnDefinitions6;
			AvaloniaList<Control> children45 = grid37.Children;
			Viewbox viewbox15;
			Viewbox viewbox14 = viewbox15 = new Viewbox();
			((ISupportInitialize)viewbox14).BeginInit();
			children45.Add(viewbox14);
			Viewbox viewbox16 = viewbox15;
			Grid.SetColumn(viewbox16, 0);
			viewbox16.Width = 14.0;
			viewbox16.Height = 14.0;
			viewbox16.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
			viewbox16.VerticalAlignment = VerticalAlignment.Center;
			Path path15;
			Path path14 = path15 = new Path();
			((ISupportInitialize)path14).BeginInit();
			viewbox16.Child = path14;
			Path path16 = path15;
			path16.Data = Geometry.Parse("M 10 10 A 5 5 0 1 0 5 10 A 5 5 0 0 0 10 10 M 8.5 8.5 L 13 13");
			path16.Stroke = new ImmutableSolidColorBrush(4284773515U);
			path16.StrokeThickness = 1.5;
			path16.StrokeLineCap = PenLineCap.Round;
			path16.Stretch = Stretch.Uniform;
			((ISupportInitialize)path16).EndInit();
			((ISupportInitialize)viewbox16).EndInit();
			AvaloniaList<Control> children46 = grid37.Children;
			TextBox textBox6;
			TextBox textBox5 = textBox6 = new TextBox();
			((ISupportInitialize)textBox5).BeginInit();
			children46.Add(textBox5);
			ISupportInitialize supportInitialize60 = textBox3 = textBox6;
			context.PushParent(textBox3);
			TextBox textBox7 = textBox3;
			Grid.SetColumn(textBox7, 1);
			AvaloniaProperty textProperty7 = TextBox.TextProperty;
			CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.SearchQuery!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider18 = context;
			context.ProvideTargetProperty = TextBox.TextProperty;
			IBinding binding18 = compiledBindingExtension18.ProvideValue(provider18);
			context.ProvideTargetProperty = null;
			textBox7.Bind(textProperty7, binding18, null);
			textBox7.Watermark = "Search...";
			textBox7.Background = new ImmutableSolidColorBrush(16777215U);
			textBox7.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
			textBox7.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBox7.FontSize = 13.0;
			textBox7.VerticalContentAlignment = VerticalAlignment.Center;
			StaticResourceExtension staticResourceExtension17 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider17 = context;
			context.ProvideTargetProperty = TemplatedControl.FontFamilyProperty;
			object obj17 = staticResourceExtension17.ProvideValue(serviceProvider17);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_3(textBox7, obj17);
			context.PopParent();
			supportInitialize60.EndInit();
			context.PopParent();
			supportInitialize59.EndInit();
			context.PopParent();
			supportInitialize58.EndInit();
			AvaloniaList<Control> children47 = grid31.Children;
			ScrollViewer scrollViewer6;
			ScrollViewer scrollViewer5 = scrollViewer6 = new ScrollViewer();
			((ISupportInitialize)scrollViewer5).BeginInit();
			children47.Add(scrollViewer5);
			ISupportInitialize supportInitialize61 = scrollViewer3 = scrollViewer6;
			context.PushParent(scrollViewer3);
			ScrollViewer scrollViewer7 = scrollViewer3;
			Grid.SetRow(scrollViewer7, 2);
			scrollViewer7.Margin = new Thickness(8.0, 0.0, 8.0, 12.0);
			ItemsControl itemsControl2;
			ItemsControl itemsControl = itemsControl2 = new ItemsControl();
			((ISupportInitialize)itemsControl).BeginInit();
			scrollViewer7.Content = itemsControl;
			ItemsControl itemsControl3;
			ISupportInitialize supportInitialize62 = itemsControl3 = itemsControl2;
			context.PushParent(itemsControl3);
			ItemsControl itemsControl4 = itemsControl3;
			AvaloniaProperty itemsSourceProperty = ItemsControl.ItemsSourceProperty;
			CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FilteredCryptoCoins!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider19 = context;
			context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
			IBinding binding19 = compiledBindingExtension19.ProvideValue(provider19);
			context.ProvideTargetProperty = null;
			itemsControl4.Bind(itemsSourceProperty, binding19, null);
			DataTemplate dataTemplate;
			IDataTemplate itemTemplate = dataTemplate = new DataTemplate();
			context.PushParent(dataTemplate);
			DataTemplate dataTemplate2 = dataTemplate;
			dataTemplate2.DataType = typeof(SwapCoinItem);
			dataTemplate2.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(BuySellView.XamlClosure_59.Build), context);
			context.PopParent();
			itemsControl4.ItemTemplate = itemTemplate;
			context.PopParent();
			supportInitialize62.EndInit();
			context.PopParent();
			supportInitialize61.EndInit();
			context.PopParent();
			supportInitialize52.EndInit();
			context.PopParent();
			supportInitialize51.EndInit();
			context.PopParent();
			supportInitialize50.EndInit();
			AvaloniaList<Control> children48 = grid4.Children;
			Grid grid39;
			Grid grid38 = grid39 = new Grid();
			((ISupportInitialize)grid38).BeginInit();
			children48.Add(grid38);
			ISupportInitialize supportInitialize63 = grid3 = grid39;
			context.PushParent(grid3);
			Grid grid40 = grid3;
			AvaloniaProperty isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsFiatPickerOpen!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider20 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding20 = compiledBindingExtension20.ProvideValue(provider20);
			context.ProvideTargetProperty = null;
			grid40.Bind(isVisibleProperty2, binding20, null);
			grid40.ZIndex = 500;
			grid40.Background = new ImmutableSolidColorBrush(2415919104U);
			AvaloniaList<Control> children49 = grid40.Children;
			Border border27;
			Border border26 = border27 = new Border();
			((ISupportInitialize)border26).BeginInit();
			children49.Add(border26);
			ISupportInitialize supportInitialize64 = border3 = border27;
			context.PushParent(border3);
			Border border28 = border3;
			border28.Background = new ImmutableSolidColorBrush(4279769894U);
			border28.Width = 400.0;
			border28.Height = 460.0;
			border28.CornerRadius = new CornerRadius(18.0, 18.0, 18.0, 18.0);
			border28.BorderBrush = new ImmutableSolidColorBrush(4281284172U);
			border28.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			border28.HorizontalAlignment = HorizontalAlignment.Center;
			border28.VerticalAlignment = VerticalAlignment.Center;
			border28.BoxShadow = BoxShadows.Parse("0 16 40 0 #50000000");
			border28.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			Grid grid42;
			Grid grid41 = grid42 = new Grid();
			((ISupportInitialize)grid41).BeginInit();
			border28.Child = grid41;
			ISupportInitialize supportInitialize65 = grid3 = grid42;
			context.PushParent(grid3);
			Grid grid43 = grid3;
			RowDefinitions rowDefinitions3 = new RowDefinitions();
			rowDefinitions3.Capacity = 2;
			rowDefinitions3.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions3.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid43.RowDefinitions = rowDefinitions3;
			AvaloniaList<Control> children50 = grid43.Children;
			Grid grid45;
			Grid grid44 = grid45 = new Grid();
			((ISupportInitialize)grid44).BeginInit();
			children50.Add(grid44);
			ISupportInitialize supportInitialize66 = grid3 = grid45;
			context.PushParent(grid3);
			Grid grid46 = grid3;
			Grid.SetRow(grid46, 0);
			ColumnDefinitions columnDefinitions7 = new ColumnDefinitions();
			columnDefinitions7.Capacity = 2;
			columnDefinitions7.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions7.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid46.ColumnDefinitions = columnDefinitions7;
			grid46.Margin = new Thickness(22.0, 18.0, 20.0, 14.0);
			AvaloniaList<Control> children51 = grid46.Children;
			TextBlock textBlock42;
			TextBlock textBlock41 = textBlock42 = new TextBlock();
			((ISupportInitialize)textBlock41).BeginInit();
			children51.Add(textBlock41);
			ISupportInitialize supportInitialize67 = textBlock3 = textBlock42;
			context.PushParent(textBlock3);
			TextBlock textBlock43 = textBlock3;
			Grid.SetColumn(textBlock43, 0);
			textBlock43.Text = "Choose your currency:";
			textBlock43.FontSize = 17.0;
			textBlock43.FontWeight = FontWeight.Bold;
			textBlock43.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock43.VerticalAlignment = VerticalAlignment.Center;
			StaticResourceExtension staticResourceExtension18 = new StaticResourceExtension("RobotoMedium");
			IServiceProvider serviceProvider18 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj18 = staticResourceExtension18.ProvideValue(serviceProvider18);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock43, obj18);
			context.PopParent();
			supportInitialize67.EndInit();
			AvaloniaList<Control> children52 = grid46.Children;
			Button button27;
			Button button26 = button27 = new Button();
			((ISupportInitialize)button26).BeginInit();
			children52.Add(button26);
			ISupportInitialize supportInitialize68 = button3 = button27;
			context.PushParent(button3);
			Button button28 = button3;
			Grid.SetColumn(button28, 1);
			AvaloniaProperty commandProperty9 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Command("CloseFiatPicker", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.BuySellViewModel+CloseFiatPicker_0!CommandExecuteTrampoline), null, null).Build());
			IServiceProvider provider21 = context;
			context.ProvideTargetProperty = Button.CommandProperty;
			IBinding binding21 = compiledBindingExtension21.ProvideValue(provider21);
			context.ProvideTargetProperty = null;
			button28.Bind(commandProperty9, binding21, null);
			button28.Background = new ImmutableSolidColorBrush(4280428086U);
			button28.Width = 30.0;
			button28.Height = 30.0;
			button28.CornerRadius = new CornerRadius(15.0, 15.0, 15.0, 15.0);
			button28.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			button28.Cursor = new Cursor(StandardCursorType.Hand);
			Viewbox viewbox18;
			Viewbox viewbox17 = viewbox18 = new Viewbox();
			((ISupportInitialize)viewbox17).BeginInit();
			button28.Content = viewbox17;
			ISupportInitialize supportInitialize69 = viewbox6 = viewbox18;
			context.PushParent(viewbox6);
			Viewbox viewbox19 = viewbox6;
			viewbox19.Width = 10.0;
			viewbox19.Height = 10.0;
			viewbox19.HorizontalAlignment = HorizontalAlignment.Center;
			viewbox19.VerticalAlignment = VerticalAlignment.Center;
			Path path18;
			Path path17 = path18 = new Path();
			((ISupportInitialize)path17).BeginInit();
			viewbox19.Child = path17;
			ISupportInitialize supportInitialize70 = path6 = path18;
			context.PushParent(path6);
			Path path19 = path6;
			StaticResourceExtension staticResourceExtension19 = new StaticResourceExtension("Close");
			IServiceProvider serviceProvider19 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj19 = staticResourceExtension19.ProvideValue(serviceProvider19);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_2(path19, obj19);
			path19.Fill = new ImmutableSolidColorBrush(4287272111U);
			path19.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize70.EndInit();
			context.PopParent();
			supportInitialize69.EndInit();
			context.PopParent();
			supportInitialize68.EndInit();
			context.PopParent();
			supportInitialize66.EndInit();
			AvaloniaList<Control> children53 = grid43.Children;
			ScrollViewer scrollViewer9;
			ScrollViewer scrollViewer8 = scrollViewer9 = new ScrollViewer();
			((ISupportInitialize)scrollViewer8).BeginInit();
			children53.Add(scrollViewer8);
			ISupportInitialize supportInitialize71 = scrollViewer3 = scrollViewer9;
			context.PushParent(scrollViewer3);
			ScrollViewer scrollViewer10 = scrollViewer3;
			Grid.SetRow(scrollViewer10, 1);
			scrollViewer10.Margin = new Thickness(8.0, 0.0, 8.0, 12.0);
			ItemsControl itemsControl6;
			ItemsControl itemsControl5 = itemsControl6 = new ItemsControl();
			((ISupportInitialize)itemsControl5).BeginInit();
			scrollViewer10.Content = itemsControl5;
			ISupportInitialize supportInitialize72 = itemsControl3 = itemsControl6;
			context.PushParent(itemsControl3);
			ItemsControl itemsControl7 = itemsControl3;
			AvaloniaProperty itemsSourceProperty2 = ItemsControl.ItemsSourceProperty;
			CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.FiatCurrencies!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider22 = context;
			context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
			IBinding binding22 = compiledBindingExtension22.ProvideValue(provider22);
			context.ProvideTargetProperty = null;
			itemsControl7.Bind(itemsSourceProperty2, binding22, null);
			IDataTemplate itemTemplate2 = dataTemplate = new DataTemplate();
			context.PushParent(dataTemplate);
			DataTemplate dataTemplate3 = dataTemplate;
			dataTemplate3.DataType = typeof(FiatItem);
			dataTemplate3.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(BuySellView.XamlClosure_61.Build), context);
			context.PopParent();
			itemsControl7.ItemTemplate = itemTemplate2;
			context.PopParent();
			supportInitialize72.EndInit();
			context.PopParent();
			supportInitialize71.EndInit();
			context.PopParent();
			supportInitialize65.EndInit();
			context.PopParent();
			supportInitialize64.EndInit();
			context.PopParent();
			supportInitialize63.EndInit();
			AvaloniaList<Control> children54 = grid4.Children;
			Border border30;
			Border border29 = border30 = new Border();
			((ISupportInitialize)border29).BeginInit();
			children54.Add(border29);
			ISupportInitialize supportInitialize73 = border3 = border30;
			context.PushParent(border3);
			Border border31 = border3;
			AvaloniaProperty isVisibleProperty3 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension23 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.IsToastVisible!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider23 = context;
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			IBinding binding23 = compiledBindingExtension23.ProvideValue(provider23);
			context.ProvideTargetProperty = null;
			border31.Bind(isVisibleProperty3, binding23, null);
			border31.Background = new ImmutableSolidColorBrush(4280232247U);
			border31.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
			border31.BorderBrush = new ImmutableSolidColorBrush(4282090230U);
			border31.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			border31.Padding = new Thickness(16.0, 10.0, 16.0, 10.0);
			border31.HorizontalAlignment = HorizontalAlignment.Center;
			border31.VerticalAlignment = VerticalAlignment.Bottom;
			border31.Margin = new Thickness(0.0, 0.0, 0.0, 30.0);
			border31.BoxShadow = BoxShadows.Parse("0 8 20 0 #50000000");
			border31.ZIndex = 999;
			StackPanel stackPanel33;
			StackPanel stackPanel32 = stackPanel33 = new StackPanel();
			((ISupportInitialize)stackPanel32).BeginInit();
			border31.Child = stackPanel32;
			ISupportInitialize supportInitialize74 = stackPanel3 = stackPanel33;
			context.PushParent(stackPanel3);
			StackPanel stackPanel34 = stackPanel3;
			stackPanel34.Orientation = Orientation.Horizontal;
			stackPanel34.Spacing = 8.0;
			stackPanel34.VerticalAlignment = VerticalAlignment.Center;
			AvaloniaList<Control> children55 = stackPanel34.Children;
			TextBlock textBlock45;
			TextBlock textBlock44 = textBlock45 = new TextBlock();
			((ISupportInitialize)textBlock44).BeginInit();
			children55.Add(textBlock44);
			TextBlock textBlock46 = textBlock45;
			textBlock46.Text = "ℹ";
			textBlock46.FontSize = 14.0;
			textBlock46.Foreground = new ImmutableSolidColorBrush(4284524026U);
			textBlock46.FontWeight = FontWeight.Bold;
			((ISupportInitialize)textBlock46).EndInit();
			AvaloniaList<Control> children56 = stackPanel34.Children;
			TextBlock textBlock48;
			TextBlock textBlock47 = textBlock48 = new TextBlock();
			((ISupportInitialize)textBlock47).BeginInit();
			children56.Add(textBlock47);
			ISupportInitialize supportInitialize75 = textBlock3 = textBlock48;
			context.PushParent(textBlock3);
			TextBlock textBlock49 = textBlock3;
			AvaloniaProperty textProperty8 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension24 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.BuySellViewModel,Exodus.ToastMessage!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider24 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding24 = compiledBindingExtension24.ProvideValue(provider24);
			context.ProvideTargetProperty = null;
			textBlock49.Bind(textProperty8, binding24, null);
			textBlock49.FontSize = 13.0;
			textBlock49.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			StaticResourceExtension staticResourceExtension20 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider20 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj20 = staticResourceExtension20.ProvideValue(serviceProvider20);
			context.ProvideTargetProperty = null;
			BuySellView.DynamicSetters_58.DynamicSetter_1(textBlock49, obj20);
			context.PopParent();
			supportInitialize75.EndInit();
			context.PopParent();
			supportInitialize74.EndInit();
			context.PopParent();
			supportInitialize73.EndInit();
			context.PopParent();
			supportInitialize.EndInit();
			context.PopParent();
			((ISupportInitialize)A_1).EndInit();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00007CCA File Offset: 0x00005ECA
		private static void !XamlIlPopulateTrampoline(BuySellView A_0)
		{
			if (BuySellView.!XamlIlPopulateOverride != null)
			{
				BuySellView.!XamlIlPopulateOverride(A_0);
				return;
			}
			BuySellView.!XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), A_0);
		}

		// Token: 0x04000006 RID: 6
		internal ScrollViewer BuyScroll;

		// Token: 0x04000007 RID: 7
		private static Action<object> !XamlIlPopulateOverride;

		// Token: 0x0200000D RID: 13
		private class DynamicSetters_58
		{
			// Token: 0x0600001B RID: 27 RVA: 0x00007CF0 File Offset: 0x00005EF0
			public static void DynamicSetter_1(TextBlock A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
					return;
				}
				if (A_1 is FontFamily)
				{
					A_0.FontFamily = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.FontFamily = A_1;
					return;
				}
				throw new InvalidCastException();
			}

			// Token: 0x0600001C RID: 28 RVA: 0x00007D5C File Offset: 0x00005F5C
			public static void DynamicSetter_2(Path A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(Path.DataProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(Path.DataProperty, A_1, null);
					return;
				}
				if (A_1 is Geometry)
				{
					A_0.Data = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.Data = A_1;
					return;
				}
				throw new InvalidCastException();
			}

			// Token: 0x0600001D RID: 29 RVA: 0x00007DC8 File Offset: 0x00005FC8
			public static void DynamicSetter_3(TemplatedControl A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(TemplatedControl.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(TemplatedControl.FontFamilyProperty, A_1, null);
					return;
				}
				if (A_1 is FontFamily)
				{
					A_0.FontFamily = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.FontFamily = A_1;
					return;
				}
				throw new InvalidCastException();
			}
		}

		// Token: 0x0200000E RID: 14
		private class XamlClosure_59
		{
			// Token: 0x0600001E RID: 30 RVA: 0x00007E34 File Offset: 0x00006034
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<BuySellView> context = new XamlIlContext.Context<BuySellView>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.Singleton
				}, "avares://Exodus/Views/BuySellView.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (BuySellView)obj;
					}
				}
				context.IntermediateRoot = new Button();
				object intermediateRoot = context.IntermediateRoot;
				((ISupportInitialize)intermediateRoot).BeginInit();
				Button button = intermediateRoot;
				context.PushParent(button);
				Button button2 = button;
				button2.Background = new ImmutableSolidColorBrush(16777215U);
				button2.HorizontalAlignment = HorizontalAlignment.Stretch;
				button2.HorizontalContentAlignment = HorizontalAlignment.Stretch;
				button2.Padding = new Thickness(14.0, 9.0, 14.0, 9.0);
				button2.CornerRadius = new CornerRadius(10.0, 10.0, 10.0, 10.0);
				button2.Cursor = new Cursor(StandardCursorType.Hand);
				AvaloniaProperty commandProperty = Button.CommandProperty;
				CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(BuySellView), 0).Property(StyledElement.DataContextProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).TypeCast<BuySellViewModel>().Command("SelectCrypto", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.BuySellViewModel+SelectCrypto_1!CommandExecuteTrampoline), null, null).Build());
				IServiceProvider provider = context;
				context.ProvideTargetProperty = Button.CommandProperty;
				IBinding binding = compiledBindingExtension.ProvideValue(provider);
				context.ProvideTargetProperty = null;
				button2.Bind(commandProperty, binding, null);
				CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension();
				IServiceProvider provider2 = context;
				context.ProvideTargetProperty = Button.CommandParameterProperty;
				CompiledBindingExtension compiledBindingExtension3 = compiledBindingExtension2.ProvideValue(provider2);
				context.ProvideTargetProperty = null;
				BuySellView.XamlClosure_59.DynamicSetters_60.DynamicSetter_1(button2, compiledBindingExtension3);
				Grid grid2;
				Grid grid = grid2 = new Grid();
				((ISupportInitialize)grid).BeginInit();
				button2.Content = grid;
				Grid grid3;
				ISupportInitialize supportInitialize = grid3 = grid2;
				context.PushParent(grid3);
				Grid grid4 = grid3;
				ColumnDefinitions columnDefinitions = new ColumnDefinitions();
				columnDefinitions.Capacity = 3;
				columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				grid4.ColumnDefinitions = columnDefinitions;
				AvaloniaList<Control> children = grid4.Children;
				Border border2;
				Border border = border2 = new Border();
				((ISupportInitialize)border).BeginInit();
				children.Add(border);
				Border border3;
				ISupportInitialize supportInitialize2 = border3 = border2;
				context.PushParent(border3);
				Border border4 = border3;
				Grid.SetColumn(border4, 0);
				border4.Width = 36.0;
				border4.Height = 36.0;
				border4.CornerRadius = new CornerRadius(18.0, 18.0, 18.0, 18.0);
				border4.ClipToBounds = true;
				border4.Margin = new Thickness(0.0, 0.0, 12.0, 0.0);
				border4.VerticalAlignment = VerticalAlignment.Center;
				Image image2;
				Image image = image2 = new Image();
				((ISupportInitialize)image).BeginInit();
				border4.Child = image;
				Image image3;
				ISupportInitialize supportInitialize3 = image3 = image2;
				context.PushParent(image3);
				Image image4 = image3;
				AvaloniaProperty sourceProperty = Image.SourceProperty;
				CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Icon!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider3 = context;
				context.ProvideTargetProperty = Image.SourceProperty;
				IBinding binding2 = compiledBindingExtension4.ProvideValue(provider3);
				context.ProvideTargetProperty = null;
				image4.Bind(sourceProperty, binding2, null);
				image4.Stretch = Stretch.Uniform;
				RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
				context.PopParent();
				supportInitialize3.EndInit();
				context.PopParent();
				supportInitialize2.EndInit();
				AvaloniaList<Control> children2 = grid4.Children;
				StackPanel stackPanel2;
				StackPanel stackPanel = stackPanel2 = new StackPanel();
				((ISupportInitialize)stackPanel).BeginInit();
				children2.Add(stackPanel);
				StackPanel stackPanel3;
				ISupportInitialize supportInitialize4 = stackPanel3 = stackPanel2;
				context.PushParent(stackPanel3);
				StackPanel stackPanel4 = stackPanel3;
				Grid.SetColumn(stackPanel4, 1);
				stackPanel4.VerticalAlignment = VerticalAlignment.Center;
				stackPanel4.Spacing = 2.0;
				AvaloniaList<Control> children3 = stackPanel4.Children;
				StackPanel stackPanel6;
				StackPanel stackPanel5 = stackPanel6 = new StackPanel();
				((ISupportInitialize)stackPanel5).BeginInit();
				children3.Add(stackPanel5);
				ISupportInitialize supportInitialize5 = stackPanel3 = stackPanel6;
				context.PushParent(stackPanel3);
				StackPanel stackPanel7 = stackPanel3;
				stackPanel7.Orientation = Orientation.Horizontal;
				stackPanel7.Spacing = 6.0;
				AvaloniaList<Control> children4 = stackPanel7.Children;
				TextBlock textBlock2;
				TextBlock textBlock = textBlock2 = new TextBlock();
				((ISupportInitialize)textBlock).BeginInit();
				children4.Add(textBlock);
				TextBlock textBlock3;
				ISupportInitialize supportInitialize6 = textBlock3 = textBlock2;
				context.PushParent(textBlock3);
				TextBlock textBlock4 = textBlock3;
				AvaloniaProperty textProperty = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Symbol!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider4 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding3 = compiledBindingExtension5.ProvideValue(provider4);
				context.ProvideTargetProperty = null;
				textBlock4.Bind(textProperty, binding3, null);
				textBlock4.FontSize = 14.5;
				textBlock4.FontWeight = FontWeight.Bold;
				textBlock4.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				StaticResourceExtension staticResourceExtension = new StaticResourceExtension("RobotoMedium");
				IServiceProvider serviceProvider = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj2 = staticResourceExtension.ProvideValue(serviceProvider);
				context.ProvideTargetProperty = null;
				BuySellView.XamlClosure_59.DynamicSetters_60.DynamicSetter_2(textBlock4, obj2);
				context.PopParent();
				supportInitialize6.EndInit();
				AvaloniaList<Control> children5 = stackPanel7.Children;
				Border border6;
				Border border5 = border6 = new Border();
				((ISupportInitialize)border5).BeginInit();
				children5.Add(border5);
				ISupportInitialize supportInitialize7 = border3 = border6;
				context.PushParent(border3);
				Border border7 = border3;
				border7.Background = new ImmutableSolidColorBrush(4280362552U);
				border7.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
				border7.Padding = new Thickness(4.0, 1.0, 4.0, 1.0);
				border7.VerticalAlignment = VerticalAlignment.Center;
				TextBlock textBlock6;
				TextBlock textBlock5 = textBlock6 = new TextBlock();
				((ISupportInitialize)textBlock5).BeginInit();
				border7.Child = textBlock5;
				ISupportInitialize supportInitialize8 = textBlock3 = textBlock6;
				context.PushParent(textBlock3);
				TextBlock textBlock7 = textBlock3;
				AvaloniaProperty textProperty2 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.SubNetwork!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider5 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding4 = compiledBindingExtension6.ProvideValue(provider5);
				context.ProvideTargetProperty = null;
				textBlock7.Bind(textProperty2, binding4, null);
				textBlock7.FontSize = 9.5;
				textBlock7.Foreground = new ImmutableSolidColorBrush(4287469228U);
				textBlock7.FontWeight = FontWeight.DemiBold;
				context.PopParent();
				supportInitialize8.EndInit();
				context.PopParent();
				supportInitialize7.EndInit();
				context.PopParent();
				supportInitialize5.EndInit();
				AvaloniaList<Control> children6 = stackPanel4.Children;
				TextBlock textBlock9;
				TextBlock textBlock8 = textBlock9 = new TextBlock();
				((ISupportInitialize)textBlock8).BeginInit();
				children6.Add(textBlock8);
				ISupportInitialize supportInitialize9 = textBlock3 = textBlock9;
				context.PushParent(textBlock3);
				TextBlock textBlock10 = textBlock3;
				AvaloniaProperty textProperty3 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.Name!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider6 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding5 = compiledBindingExtension7.ProvideValue(provider6);
				context.ProvideTargetProperty = null;
				textBlock10.Bind(textProperty3, binding5, null);
				textBlock10.FontSize = 12.0;
				textBlock10.Foreground = new ImmutableSolidColorBrush(4285298318U);
				StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider2 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj3 = staticResourceExtension2.ProvideValue(serviceProvider2);
				context.ProvideTargetProperty = null;
				BuySellView.XamlClosure_59.DynamicSetters_60.DynamicSetter_2(textBlock10, obj3);
				context.PopParent();
				supportInitialize9.EndInit();
				context.PopParent();
				supportInitialize4.EndInit();
				AvaloniaList<Control> children7 = grid4.Children;
				StackPanel stackPanel9;
				StackPanel stackPanel8 = stackPanel9 = new StackPanel();
				((ISupportInitialize)stackPanel8).BeginInit();
				children7.Add(stackPanel8);
				ISupportInitialize supportInitialize10 = stackPanel3 = stackPanel9;
				context.PushParent(stackPanel3);
				StackPanel stackPanel10 = stackPanel3;
				Grid.SetColumn(stackPanel10, 2);
				stackPanel10.HorizontalAlignment = HorizontalAlignment.Right;
				stackPanel10.VerticalAlignment = VerticalAlignment.Center;
				stackPanel10.Spacing = 2.0;
				AvaloniaList<Control> children8 = stackPanel10.Children;
				TextBlock textBlock12;
				TextBlock textBlock11 = textBlock12 = new TextBlock();
				((ISupportInitialize)textBlock11).BeginInit();
				children8.Add(textBlock11);
				ISupportInitialize supportInitialize11 = textBlock3 = textBlock12;
				context.PushParent(textBlock3);
				TextBlock textBlock13 = textBlock3;
				AvaloniaProperty textProperty4 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.DisplaySubtitle!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider7 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding6 = compiledBindingExtension8.ProvideValue(provider7);
				context.ProvideTargetProperty = null;
				textBlock13.Bind(textProperty4, binding6, null);
				textBlock13.FontSize = 14.0;
				textBlock13.FontWeight = FontWeight.Bold;
				textBlock13.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock13.HorizontalAlignment = HorizontalAlignment.Right;
				StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("RobotoMedium");
				IServiceProvider serviceProvider3 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj4 = staticResourceExtension3.ProvideValue(serviceProvider3);
				context.ProvideTargetProperty = null;
				BuySellView.XamlClosure_59.DynamicSetters_60.DynamicSetter_2(textBlock13, obj4);
				context.PopParent();
				supportInitialize11.EndInit();
				AvaloniaList<Control> children9 = stackPanel10.Children;
				TextBlock textBlock15;
				TextBlock textBlock14 = textBlock15 = new TextBlock();
				((ISupportInitialize)textBlock14).BeginInit();
				children9.Add(textBlock14);
				ISupportInitialize supportInitialize12 = textBlock3 = textBlock15;
				context.PushParent(textBlock3);
				TextBlock textBlock16 = textBlock3;
				AvaloniaProperty textProperty5 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.SwapCoinItem,Exodus.ValueInUsdString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider8 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding7 = compiledBindingExtension9.ProvideValue(provider8);
				context.ProvideTargetProperty = null;
				textBlock16.Bind(textProperty5, binding7, null);
				textBlock16.FontSize = 12.0;
				textBlock16.Foreground = new ImmutableSolidColorBrush(4285298318U);
				textBlock16.HorizontalAlignment = HorizontalAlignment.Right;
				StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider4 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj5 = staticResourceExtension4.ProvideValue(serviceProvider4);
				context.ProvideTargetProperty = null;
				BuySellView.XamlClosure_59.DynamicSetters_60.DynamicSetter_2(textBlock16, obj5);
				context.PopParent();
				supportInitialize12.EndInit();
				context.PopParent();
				supportInitialize10.EndInit();
				context.PopParent();
				supportInitialize.EndInit();
				context.PopParent();
				((ISupportInitialize)intermediateRoot).EndInit();
				return intermediateRoot;
			}

			// Token: 0x0200000F RID: 15
			private class DynamicSetters_60
			{
				// Token: 0x0600001F RID: 31 RVA: 0x00008744 File Offset: 0x00006944
				public static void DynamicSetter_1(Button A_0, CompiledBindingExtension A_1)
				{
					if (A_1 != null)
					{
						A_0.Bind(Button.CommandParameterProperty, A_1, null);
						return;
					}
					A_0.CommandParameter = A_1;
				}

				// Token: 0x06000020 RID: 32 RVA: 0x00008770 File Offset: 0x00006970
				public static void DynamicSetter_2(TextBlock A_0, object A_1)
				{
					if (A_1 is UnsetValueType)
					{
						A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
						return;
					}
					if (A_1 is IBinding)
					{
						A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
						return;
					}
					if (A_1 is FontFamily)
					{
						A_0.FontFamily = A_1;
						return;
					}
					if (A_1 == null)
					{
						A_0.FontFamily = A_1;
						return;
					}
					throw new InvalidCastException();
				}
			}
		}

		// Token: 0x02000010 RID: 16
		private class XamlClosure_61
		{
			// Token: 0x06000021 RID: 33 RVA: 0x000087DC File Offset: 0x000069DC
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<BuySellView> context = new XamlIlContext.Context<BuySellView>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/BuySellView.axaml.Singleton
				}, "avares://Exodus/Views/BuySellView.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (BuySellView)obj;
					}
				}
				context.IntermediateRoot = new Button();
				object intermediateRoot = context.IntermediateRoot;
				((ISupportInitialize)intermediateRoot).BeginInit();
				Button button = intermediateRoot;
				context.PushParent(button);
				Button button2 = button;
				button2.Background = new ImmutableSolidColorBrush(16777215U);
				button2.HorizontalAlignment = HorizontalAlignment.Stretch;
				button2.HorizontalContentAlignment = HorizontalAlignment.Stretch;
				button2.Padding = new Thickness(14.0, 10.0, 14.0, 10.0);
				button2.CornerRadius = new CornerRadius(10.0, 10.0, 10.0, 10.0);
				button2.Cursor = new Cursor(StandardCursorType.Hand);
				AvaloniaProperty commandProperty = Button.CommandProperty;
				CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(BuySellView), 0).Property(StyledElement.DataContextProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).TypeCast<BuySellViewModel>().Command("SelectFiat", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.BuySellViewModel+SelectFiat_1!CommandExecuteTrampoline), null, null).Build());
				IServiceProvider provider = context;
				context.ProvideTargetProperty = Button.CommandProperty;
				IBinding binding = compiledBindingExtension.ProvideValue(provider);
				context.ProvideTargetProperty = null;
				button2.Bind(commandProperty, binding, null);
				CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension();
				IServiceProvider provider2 = context;
				context.ProvideTargetProperty = Button.CommandParameterProperty;
				CompiledBindingExtension compiledBindingExtension3 = compiledBindingExtension2.ProvideValue(provider2);
				context.ProvideTargetProperty = null;
				BuySellView.XamlClosure_61.DynamicSetters_62.DynamicSetter_1(button2, compiledBindingExtension3);
				Grid grid2;
				Grid grid = grid2 = new Grid();
				((ISupportInitialize)grid).BeginInit();
				button2.Content = grid;
				Grid grid3;
				ISupportInitialize supportInitialize = grid3 = grid2;
				context.PushParent(grid3);
				Grid grid4 = grid3;
				ColumnDefinitions columnDefinitions = new ColumnDefinitions();
				columnDefinitions.Capacity = 2;
				columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
				grid4.ColumnDefinitions = columnDefinitions;
				AvaloniaList<Control> children = grid4.Children;
				TextBlock textBlock2;
				TextBlock textBlock = textBlock2 = new TextBlock();
				((ISupportInitialize)textBlock).BeginInit();
				children.Add(textBlock);
				TextBlock textBlock3;
				ISupportInitialize supportInitialize2 = textBlock3 = textBlock2;
				context.PushParent(textBlock3);
				TextBlock textBlock4 = textBlock3;
				Grid.SetColumn(textBlock4, 0);
				AvaloniaProperty textProperty = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.FiatItem,Exodus.FlagEmoji!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider3 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding2 = compiledBindingExtension4.ProvideValue(provider3);
				context.ProvideTargetProperty = null;
				textBlock4.Bind(textProperty, binding2, null);
				textBlock4.FontSize = 22.0;
				textBlock4.VerticalAlignment = VerticalAlignment.Center;
				textBlock4.Margin = new Thickness(0.0, 0.0, 14.0, 0.0);
				context.PopParent();
				supportInitialize2.EndInit();
				AvaloniaList<Control> children2 = grid4.Children;
				StackPanel stackPanel2;
				StackPanel stackPanel = stackPanel2 = new StackPanel();
				((ISupportInitialize)stackPanel).BeginInit();
				children2.Add(stackPanel);
				StackPanel stackPanel3;
				ISupportInitialize supportInitialize3 = stackPanel3 = stackPanel2;
				context.PushParent(stackPanel3);
				StackPanel stackPanel4 = stackPanel3;
				Grid.SetColumn(stackPanel4, 1);
				stackPanel4.VerticalAlignment = VerticalAlignment.Center;
				stackPanel4.Spacing = 2.0;
				AvaloniaList<Control> children3 = stackPanel4.Children;
				TextBlock textBlock6;
				TextBlock textBlock5 = textBlock6 = new TextBlock();
				((ISupportInitialize)textBlock5).BeginInit();
				children3.Add(textBlock5);
				ISupportInitialize supportInitialize4 = textBlock3 = textBlock6;
				context.PushParent(textBlock3);
				TextBlock textBlock7 = textBlock3;
				AvaloniaProperty textProperty2 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Code!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider4 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding3 = compiledBindingExtension5.ProvideValue(provider4);
				context.ProvideTargetProperty = null;
				textBlock7.Bind(textProperty2, binding3, null);
				textBlock7.FontSize = 15.0;
				textBlock7.FontWeight = FontWeight.Bold;
				textBlock7.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				StaticResourceExtension staticResourceExtension = new StaticResourceExtension("RobotoMedium");
				IServiceProvider serviceProvider = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj2 = staticResourceExtension.ProvideValue(serviceProvider);
				context.ProvideTargetProperty = null;
				BuySellView.XamlClosure_61.DynamicSetters_62.DynamicSetter_2(textBlock7, obj2);
				context.PopParent();
				supportInitialize4.EndInit();
				AvaloniaList<Control> children4 = stackPanel4.Children;
				TextBlock textBlock9;
				TextBlock textBlock8 = textBlock9 = new TextBlock();
				((ISupportInitialize)textBlock8).BeginInit();
				children4.Add(textBlock8);
				ISupportInitialize supportInitialize5 = textBlock3 = textBlock9;
				context.PushParent(textBlock3);
				TextBlock textBlock10 = textBlock3;
				AvaloniaProperty textProperty3 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.FiatItem,Exodus.Name!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider5 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding4 = compiledBindingExtension6.ProvideValue(provider5);
				context.ProvideTargetProperty = null;
				textBlock10.Bind(textProperty3, binding4, null);
				textBlock10.FontSize = 12.0;
				textBlock10.Foreground = new ImmutableSolidColorBrush(4285298318U);
				StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider2 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj3 = staticResourceExtension2.ProvideValue(serviceProvider2);
				context.ProvideTargetProperty = null;
				BuySellView.XamlClosure_61.DynamicSetters_62.DynamicSetter_2(textBlock10, obj3);
				context.PopParent();
				supportInitialize5.EndInit();
				context.PopParent();
				supportInitialize3.EndInit();
				context.PopParent();
				supportInitialize.EndInit();
				context.PopParent();
				((ISupportInitialize)intermediateRoot).EndInit();
				return intermediateRoot;
			}

			// Token: 0x02000011 RID: 17
			private class DynamicSetters_62
			{
				// Token: 0x06000022 RID: 34 RVA: 0x00008CBC File Offset: 0x00006EBC
				public static void DynamicSetter_1(Button A_0, CompiledBindingExtension A_1)
				{
					if (A_1 != null)
					{
						A_0.Bind(Button.CommandParameterProperty, A_1, null);
						return;
					}
					A_0.CommandParameter = A_1;
				}

				// Token: 0x06000023 RID: 35 RVA: 0x00008CE8 File Offset: 0x00006EE8
				public static void DynamicSetter_2(TextBlock A_0, object A_1)
				{
					if (A_1 is UnsetValueType)
					{
						A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
						return;
					}
					if (A_1 is IBinding)
					{
						A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
						return;
					}
					if (A_1 is FontFamily)
					{
						A_0.FontFamily = A_1;
						return;
					}
					if (A_1 == null)
					{
						A_0.FontFamily = A_1;
						return;
					}
					throw new InvalidCastException();
				}
			}
		}
	}
}
