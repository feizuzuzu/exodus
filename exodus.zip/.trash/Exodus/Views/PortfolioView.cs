﻿using System;
using System.ComponentModel;
using System.Globalization;
using Avalonia;
using Avalonia.Collections;
using Avalonia.Controls;
using Avalonia.Controls.Presenters;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Controls.Templates;
using Avalonia.Data;
using Avalonia.Data.Core;
using Avalonia.Data.Core.Plugins;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using Exodus.Models;
using Exodus.ViewModels;

namespace Exodus.Views
{
	// Token: 0x02000026 RID: 38
	public class PortfolioView : UserControl
	{
		// Token: 0x06000054 RID: 84 RVA: 0x00019369 File Offset: 0x00017569
		public PortfolioView()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00019377 File Offset: 0x00017577
		private void InitializeComponent()
		{
			PortfolioView.!XamlIlPopulateTrampoline(this);
		}

		// Token: 0x06000056 RID: 86 RVA: 0x0001937F File Offset: 0x0001757F
		public void InitializeComponent(bool loadXaml = true)
		{
			if (loadXaml)
			{
				PortfolioView.!XamlIlPopulateTrampoline(this);
			}
		}

		// Token: 0x06000057 RID: 87 RVA: 0x0001938C File Offset: 0x0001758C
		static void !XamlIlPopulate(IServiceProvider A_0, PortfolioView A_1)
		{
			XamlIlContext.Context<PortfolioView> context = new XamlIlContext.Context<PortfolioView>(A_0, new object[]
			{
				(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.Singleton
			}, "avares://Exodus/Views/PortfolioView.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			((ISupportInitialize)A_1).BeginInit();
			context.PushParent(A_1);
			Styles styles = A_1.Styles;
			Style style = new Style();
			style.Selector = Selectors.OfType((Selector)null, typeof(Button));
			style.Add(new Setter
			{
				Property = TemplatedControl.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(16777215U)
			});
			style.Add(new Setter
			{
				Property = TemplatedControl.BorderThicknessProperty,
				Value = new Thickness(0.0, 0.0, 0.0, 0.0)
			});
			style.Add(new Setter
			{
				Property = TemplatedControl.PaddingProperty,
				Value = new Thickness(0.0, 0.0, 0.0, 0.0)
			});
			style.Add(new Setter
			{
				Property = Layoutable.MarginProperty,
				Value = new Thickness(0.0, 0.0, 0.0, 0.0)
			});
			styles.Add(style);
			Styles styles2 = A_1.Styles;
			Style style2 = new Style();
			style2.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class(":pointerover").Template().OfType(typeof(ContentPresenter));
			style2.Add(new Setter
			{
				Property = ContentPresenter.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(16777215U)
			});
			styles2.Add(style2);
			Styles styles3 = A_1.Styles;
			Style style3 = new Style();
			style3.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class("assetRow");
			style3.Add(new Setter
			{
				Property = InputElement.CursorProperty,
				Value = new Cursor(StandardCursorType.Hand)
			});
			style3.Add(new Setter
			{
				Property = TemplatedControl.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(16777215U)
			});
			styles3.Add(style3);
			Styles styles4 = A_1.Styles;
			Style style4 = new Style();
			style4.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class("assetRow").Class(":pointerover").Child().OfType(typeof(Border));
			style4.Add(new Setter
			{
				Property = Border.BackgroundProperty,
				Value = new ImmutableSolidColorBrush(318767103U)
			});
			styles4.Add(style4);
			Styles styles5 = A_1.Styles;
			Style style5;
			IStyle item = style5 = new Style();
			context.PushParent(style5);
			Style style6 = style5;
			style6.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class("timeBtn");
			style6.Add(new Setter
			{
				Property = InputElement.CursorProperty,
				Value = new Cursor(StandardCursorType.Hand)
			});
			style6.Add(new Setter
			{
				Property = Visual.OpacityProperty,
				Value = 0.45
			});
			style6.Add(new Setter
			{
				Property = TemplatedControl.ForegroundProperty,
				Value = new ImmutableSolidColorBrush(uint.MaxValue)
			});
			Setter setter2;
			SetterBase setter = setter2 = new Setter();
			context.PushParent(setter2);
			Setter setter3 = setter2;
			setter3.Property = TemplatedControl.FontFamilyProperty;
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider = context;
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia.Styling.Setter,Avalonia.Base.Value!Property();
			object value = staticResourceExtension.ProvideValue(serviceProvider);
			context.ProvideTargetProperty = null;
			setter3.Value = value;
			context.PopParent();
			style6.Add(setter);
			style6.Add(new Setter
			{
				Property = TemplatedControl.FontSizeProperty,
				Value = 13.0
			});
			context.PopParent();
			styles5.Add(item);
			Styles styles6 = A_1.Styles;
			Style style7 = new Style();
			style7.Selector = Selectors.OfType((Selector)null, typeof(Button)).Class("timeBtn").Class(":pointerover");
			style7.Add(new Setter
			{
				Property = Visual.OpacityProperty,
				Value = 0.85
			});
			styles6.Add(style7);
			Border border2;
			Border border = border2 = new Border();
			((ISupportInitialize)border).BeginInit();
			A_1.Content = border;
			Border border3;
			ISupportInitialize supportInitialize = border3 = border2;
			context.PushParent(border3);
			Border border4 = border3;
			border4.Background = new ImmutableSolidColorBrush(4279440664U);
			border4.CornerRadius = new CornerRadius(26.0, 26.0, 0.0, 0.0);
			ScrollViewer scrollViewer2;
			ScrollViewer scrollViewer = scrollViewer2 = new ScrollViewer();
			((ISupportInitialize)scrollViewer).BeginInit();
			border4.Child = scrollViewer;
			ScrollViewer scrollViewer3;
			ISupportInitialize supportInitialize2 = scrollViewer3 = scrollViewer2;
			context.PushParent(scrollViewer3);
			ScrollViewer scrollViewer4 = scrollViewer3;
			scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
			scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			StackPanel stackPanel2;
			StackPanel stackPanel = stackPanel2 = new StackPanel();
			((ISupportInitialize)stackPanel).BeginInit();
			scrollViewer4.Content = stackPanel;
			StackPanel stackPanel3;
			ISupportInitialize supportInitialize3 = stackPanel3 = stackPanel2;
			context.PushParent(stackPanel3);
			StackPanel stackPanel4 = stackPanel3;
			stackPanel4.Margin = new Thickness(0.0, 20.0, 0.0, 40.0);
			AvaloniaList<Control> children = stackPanel4.Children;
			Grid grid2;
			Grid grid = grid2 = new Grid();
			((ISupportInitialize)grid).BeginInit();
			children.Add(grid);
			Grid grid3;
			ISupportInitialize supportInitialize4 = grid3 = grid2;
			context.PushParent(grid3);
			Grid grid4 = grid3;
			grid4.Width = 420.0;
			grid4.Height = 420.0;
			grid4.HorizontalAlignment = HorizontalAlignment.Center;
			grid4.Margin = new Thickness(0.0, 15.0, 0.0, 0.0);
			AvaloniaList<Control> children2 = grid4.Children;
			Ellipse ellipse2;
			Ellipse ellipse = ellipse2 = new Ellipse();
			((ISupportInitialize)ellipse).BeginInit();
			children2.Add(ellipse);
			Ellipse ellipse3 = ellipse2;
			ellipse3.Width = 360.0;
			ellipse3.Height = 360.0;
			ellipse3.Stroke = new ImmutableSolidColorBrush(4280099368U);
			ellipse3.StrokeThickness = 9.0;
			ellipse3.HorizontalAlignment = HorizontalAlignment.Center;
			ellipse3.VerticalAlignment = VerticalAlignment.Center;
			((ISupportInitialize)ellipse3).EndInit();
			AvaloniaList<Control> children3 = grid4.Children;
			ItemsControl itemsControl2;
			ItemsControl itemsControl = itemsControl2 = new ItemsControl();
			((ISupportInitialize)itemsControl).BeginInit();
			children3.Add(itemsControl);
			ItemsControl itemsControl3;
			ISupportInitialize supportInitialize5 = itemsControl3 = itemsControl2;
			context.PushParent(itemsControl3);
			ItemsControl itemsControl4 = itemsControl3;
			AvaloniaProperty itemsSourceProperty = ItemsControl.ItemsSourceProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DonutSegments!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider = context;
			context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
			IBinding binding = compiledBindingExtension.ProvideValue(provider);
			context.ProvideTargetProperty = null;
			itemsControl4.Bind(itemsSourceProperty, binding, null);
			itemsControl4.Width = 420.0;
			itemsControl4.Height = 420.0;
			itemsControl4.HorizontalAlignment = HorizontalAlignment.Center;
			itemsControl4.VerticalAlignment = VerticalAlignment.Center;
			itemsControl4.ItemsPanel = new ItemsPanelTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(PortfolioView.XamlClosure_78.Build), context)
			};
			DataTemplate dataTemplate;
			IDataTemplate itemTemplate = dataTemplate = new DataTemplate();
			context.PushParent(dataTemplate);
			DataTemplate dataTemplate2 = dataTemplate;
			dataTemplate2.DataType = typeof(DonutSegment);
			dataTemplate2.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(PortfolioView.XamlClosure_79.Build), context);
			context.PopParent();
			itemsControl4.ItemTemplate = itemTemplate;
			context.PopParent();
			supportInitialize5.EndInit();
			AvaloniaList<Control> children4 = grid4.Children;
			StackPanel stackPanel6;
			StackPanel stackPanel5 = stackPanel6 = new StackPanel();
			((ISupportInitialize)stackPanel5).BeginInit();
			children4.Add(stackPanel5);
			ISupportInitialize supportInitialize6 = stackPanel3 = stackPanel6;
			context.PushParent(stackPanel3);
			StackPanel stackPanel7 = stackPanel3;
			stackPanel7.VerticalAlignment = VerticalAlignment.Center;
			stackPanel7.HorizontalAlignment = HorizontalAlignment.Center;
			stackPanel7.Spacing = 4.0;
			AvaloniaList<Control> children5 = stackPanel7.Children;
			TextBlock textBlock2;
			TextBlock textBlock = textBlock2 = new TextBlock();
			((ISupportInitialize)textBlock).BeginInit();
			children5.Add(textBlock);
			TextBlock textBlock3;
			ISupportInitialize supportInitialize7 = textBlock3 = textBlock2;
			context.PushParent(textBlock3);
			TextBlock textBlock4 = textBlock3;
			AvaloniaProperty textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.TotalBalanceString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider2 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding2 = compiledBindingExtension2.ProvideValue(provider2);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(textProperty, binding2, null);
			textBlock4.FontSize = 42.0;
			StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("RobotoLight");
			IServiceProvider serviceProvider2 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj = staticResourceExtension2.ProvideValue(serviceProvider2);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock4, obj);
			textBlock4.FontWeight = FontWeight.Light;
			textBlock4.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize7.EndInit();
			AvaloniaList<Control> children6 = stackPanel7.Children;
			TextBlock textBlock6;
			TextBlock textBlock5 = textBlock6 = new TextBlock();
			((ISupportInitialize)textBlock5).BeginInit();
			children6.Add(textBlock5);
			ISupportInitialize supportInitialize8 = textBlock3 = textBlock6;
			context.PushParent(textBlock3);
			TextBlock textBlock7 = textBlock3;
			AvaloniaProperty textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.AssetCountText!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider3 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding3 = compiledBindingExtension3.ProvideValue(provider3);
			context.ProvideTargetProperty = null;
			textBlock7.Bind(textProperty2, binding3, null);
			textBlock7.FontSize = 16.0;
			StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider3 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj2 = staticResourceExtension3.ProvideValue(serviceProvider3);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock7, obj2);
			textBlock7.Foreground = new ImmutableSolidColorBrush(4286284427U);
			textBlock7.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock7.Margin = new Thickness(0.0, 2.0, 0.0, 0.0);
			context.PopParent();
			supportInitialize8.EndInit();
			context.PopParent();
			supportInitialize6.EndInit();
			context.PopParent();
			supportInitialize4.EndInit();
			AvaloniaList<Control> children7 = stackPanel4.Children;
			StackPanel stackPanel9;
			StackPanel stackPanel8 = stackPanel9 = new StackPanel();
			((ISupportInitialize)stackPanel8).BeginInit();
			children7.Add(stackPanel8);
			ISupportInitialize supportInitialize9 = stackPanel3 = stackPanel9;
			context.PushParent(stackPanel3);
			StackPanel stackPanel10 = stackPanel3;
			stackPanel10.Orientation = Orientation.Horizontal;
			stackPanel10.HorizontalAlignment = HorizontalAlignment.Center;
			stackPanel10.Spacing = 28.0;
			stackPanel10.Margin = new Thickness(0.0, 18.0, 0.0, 25.0);
			AvaloniaList<Control> children8 = stackPanel10.Children;
			StackPanel stackPanel12;
			StackPanel stackPanel11 = stackPanel12 = new StackPanel();
			((ISupportInitialize)stackPanel11).BeginInit();
			children8.Add(stackPanel11);
			ISupportInitialize supportInitialize10 = stackPanel3 = stackPanel12;
			context.PushParent(stackPanel3);
			StackPanel stackPanel13 = stackPanel3;
			stackPanel13.Orientation = Orientation.Vertical;
			stackPanel13.HorizontalAlignment = HorizontalAlignment.Center;
			stackPanel13.Spacing = 4.0;
			AvaloniaList<Control> children9 = stackPanel13.Children;
			Border border6;
			Border border5 = border6 = new Border();
			((ISupportInitialize)border5).BeginInit();
			children9.Add(border5);
			Border border7 = border6;
			border7.Width = 7.0;
			border7.Height = 7.0;
			border7.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
			border7.BorderThickness = new Thickness(1.5, 1.5, 1.5, 1.5);
			border7.BorderBrush = new ImmutableSolidColorBrush(uint.MaxValue);
			border7.Background = new ImmutableSolidColorBrush(16777215U);
			border7.HorizontalAlignment = HorizontalAlignment.Center;
			((ISupportInitialize)border7).EndInit();
			AvaloniaList<Control> children10 = stackPanel13.Children;
			TextBlock textBlock9;
			TextBlock textBlock8 = textBlock9 = new TextBlock();
			((ISupportInitialize)textBlock8).BeginInit();
			children10.Add(textBlock8);
			ISupportInitialize supportInitialize11 = textBlock3 = textBlock9;
			context.PushParent(textBlock3);
			TextBlock textBlock10 = textBlock3;
			textBlock10.Text = "NOW";
			textBlock10.FontSize = 13.0;
			StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("RobotoCondensedBold");
			IServiceProvider serviceProvider4 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj3 = staticResourceExtension4.ProvideValue(serviceProvider4);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock10, obj3);
			textBlock10.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock10.FontWeight = FontWeight.DemiBold;
			context.PopParent();
			supportInitialize11.EndInit();
			context.PopParent();
			supportInitialize10.EndInit();
			AvaloniaList<Control> children11 = stackPanel10.Children;
			Button button2;
			Button button = button2 = new Button();
			((ISupportInitialize)button).BeginInit();
			children11.Add(button);
			Button button3 = button2;
			button3.Classes.Add("timeBtn");
			button3.Content = "1M";
			button3.VerticalAlignment = VerticalAlignment.Bottom;
			button3.Margin = new Thickness(0.0, 0.0, 0.0, 1.0);
			((ISupportInitialize)button3).EndInit();
			AvaloniaList<Control> children12 = stackPanel10.Children;
			Button button5;
			Button button4 = button5 = new Button();
			((ISupportInitialize)button4).BeginInit();
			children12.Add(button4);
			Button button6 = button5;
			button6.Classes.Add("timeBtn");
			button6.Content = "6M";
			button6.VerticalAlignment = VerticalAlignment.Bottom;
			button6.Margin = new Thickness(0.0, 0.0, 0.0, 1.0);
			((ISupportInitialize)button6).EndInit();
			AvaloniaList<Control> children13 = stackPanel10.Children;
			Button button8;
			Button button7 = button8 = new Button();
			((ISupportInitialize)button7).BeginInit();
			children13.Add(button7);
			Button button9 = button8;
			button9.Classes.Add("timeBtn");
			button9.Content = "1Y";
			button9.VerticalAlignment = VerticalAlignment.Bottom;
			button9.Margin = new Thickness(0.0, 0.0, 0.0, 1.0);
			((ISupportInitialize)button9).EndInit();
			AvaloniaList<Control> children14 = stackPanel10.Children;
			Button button11;
			Button button10 = button11 = new Button();
			((ISupportInitialize)button10).BeginInit();
			children14.Add(button10);
			Button button12 = button11;
			button12.Classes.Add("timeBtn");
			button12.Content = "ALL";
			button12.VerticalAlignment = VerticalAlignment.Bottom;
			button12.Margin = new Thickness(0.0, 0.0, 0.0, 1.0);
			((ISupportInitialize)button12).EndInit();
			context.PopParent();
			supportInitialize9.EndInit();
			AvaloniaList<Control> children15 = stackPanel4.Children;
			Border border9;
			Border border8 = border9 = new Border();
			((ISupportInitialize)border8).BeginInit();
			children15.Add(border8);
			ISupportInitialize supportInitialize12 = border3 = border9;
			context.PushParent(border3);
			Border border10 = border3;
			border10.Margin = new Thickness(40.0, 0.0, 40.0, 25.0);
			border10.Background = new ImmutableSolidColorBrush(4279704094U);
			border10.CornerRadius = new CornerRadius(12.0, 12.0, 12.0, 12.0);
			border10.Padding = new Thickness(25.0, 18.0, 25.0, 18.0);
			border10.HorizontalAlignment = HorizontalAlignment.Stretch;
			Grid grid6;
			Grid grid5 = grid6 = new Grid();
			((ISupportInitialize)grid5).BeginInit();
			border10.Child = grid5;
			ISupportInitialize supportInitialize13 = grid3 = grid6;
			context.PushParent(grid3);
			Grid grid7 = grid3;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 9;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid7.ColumnDefinitions = columnDefinitions;
			AvaloniaList<Control> children16 = grid7.Children;
			StackPanel stackPanel15;
			StackPanel stackPanel14 = stackPanel15 = new StackPanel();
			((ISupportInitialize)stackPanel14).BeginInit();
			children16.Add(stackPanel14);
			ISupportInitialize supportInitialize14 = stackPanel3 = stackPanel15;
			context.PushParent(stackPanel3);
			StackPanel stackPanel16 = stackPanel3;
			Grid.SetColumn(stackPanel16, 0);
			stackPanel16.Spacing = 6.0;
			stackPanel16.HorizontalAlignment = HorizontalAlignment.Center;
			AvaloniaList<Control> children17 = stackPanel16.Children;
			TextBlock textBlock12;
			TextBlock textBlock11 = textBlock12 = new TextBlock();
			((ISupportInitialize)textBlock11).BeginInit();
			children17.Add(textBlock11);
			ISupportInitialize supportInitialize15 = textBlock3 = textBlock12;
			context.PushParent(textBlock3);
			TextBlock textBlock13 = textBlock3;
			textBlock13.Text = "24H Change";
			textBlock13.FontSize = 12.5;
			StaticResourceExtension staticResourceExtension5 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider5 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj4 = staticResourceExtension5.ProvideValue(serviceProvider5);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock13, obj4);
			textBlock13.Foreground = new ImmutableSolidColorBrush(4287139478U);
			textBlock13.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize15.EndInit();
			AvaloniaList<Control> children18 = stackPanel16.Children;
			TextBlock textBlock15;
			TextBlock textBlock14 = textBlock15 = new TextBlock();
			((ISupportInitialize)textBlock14).BeginInit();
			children18.Add(textBlock14);
			ISupportInitialize supportInitialize16 = textBlock3 = textBlock15;
			context.PushParent(textBlock3);
			TextBlock textBlock16 = textBlock3;
			AvaloniaProperty textProperty3 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider4 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding4 = compiledBindingExtension4.ProvideValue(provider4);
			context.ProvideTargetProperty = null;
			textBlock16.Bind(textProperty3, binding4, null);
			textBlock16.FontSize = 15.0;
			StaticResourceExtension staticResourceExtension6 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider6 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj5 = staticResourceExtension6.ProvideValue(serviceProvider6);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock16, obj5);
			AvaloniaProperty foregroundProperty = TextBlock.ForegroundProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Change24HBrush!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider5 = context;
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			IBinding binding5 = compiledBindingExtension5.ProvideValue(provider5);
			context.ProvideTargetProperty = null;
			textBlock16.Bind(foregroundProperty, binding5, null);
			textBlock16.FontWeight = FontWeight.Medium;
			textBlock16.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize16.EndInit();
			context.PopParent();
			supportInitialize14.EndInit();
			AvaloniaList<Control> children19 = grid7.Children;
			Rectangle rectangle2;
			Rectangle rectangle = rectangle2 = new Rectangle();
			((ISupportInitialize)rectangle).BeginInit();
			children19.Add(rectangle);
			Rectangle rectangle3 = rectangle2;
			Grid.SetColumn(rectangle3, 1);
			rectangle3.Width = 1.0;
			rectangle3.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			rectangle3.Opacity = 0.1;
			rectangle3.VerticalAlignment = VerticalAlignment.Stretch;
			rectangle3.Margin = new Thickness(10.0, 2.0, 10.0, 2.0);
			((ISupportInitialize)rectangle3).EndInit();
			AvaloniaList<Control> children20 = grid7.Children;
			StackPanel stackPanel18;
			StackPanel stackPanel17 = stackPanel18 = new StackPanel();
			((ISupportInitialize)stackPanel17).BeginInit();
			children20.Add(stackPanel17);
			ISupportInitialize supportInitialize17 = stackPanel3 = stackPanel18;
			context.PushParent(stackPanel3);
			StackPanel stackPanel19 = stackPanel3;
			Grid.SetColumn(stackPanel19, 2);
			stackPanel19.Spacing = 6.0;
			stackPanel19.HorizontalAlignment = HorizontalAlignment.Center;
			AvaloniaList<Control> children21 = stackPanel19.Children;
			StackPanel stackPanel21;
			StackPanel stackPanel20 = stackPanel21 = new StackPanel();
			((ISupportInitialize)stackPanel20).BeginInit();
			children21.Add(stackPanel20);
			ISupportInitialize supportInitialize18 = stackPanel3 = stackPanel21;
			context.PushParent(stackPanel3);
			StackPanel stackPanel22 = stackPanel3;
			stackPanel22.Orientation = Orientation.Horizontal;
			stackPanel22.HorizontalAlignment = HorizontalAlignment.Center;
			stackPanel22.Spacing = 4.0;
			AvaloniaList<Control> children22 = stackPanel22.Children;
			TextBlock textBlock18;
			TextBlock textBlock17 = textBlock18 = new TextBlock();
			((ISupportInitialize)textBlock17).BeginInit();
			children22.Add(textBlock17);
			ISupportInitialize supportInitialize19 = textBlock3 = textBlock18;
			context.PushParent(textBlock3);
			TextBlock textBlock19 = textBlock3;
			textBlock19.Text = "Highest Balance";
			textBlock19.FontSize = 12.5;
			StaticResourceExtension staticResourceExtension7 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider7 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj6 = staticResourceExtension7.ProvideValue(serviceProvider7);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock19, obj6);
			textBlock19.Foreground = new ImmutableSolidColorBrush(4287139478U);
			context.PopParent();
			supportInitialize19.EndInit();
			AvaloniaList<Control> children23 = stackPanel22.Children;
			TextBlock textBlock21;
			TextBlock textBlock20 = textBlock21 = new TextBlock();
			((ISupportInitialize)textBlock20).BeginInit();
			children23.Add(textBlock20);
			TextBlock textBlock22 = textBlock21;
			textBlock22.Text = "ⓘ";
			textBlock22.FontSize = 11.0;
			textBlock22.Foreground = new ImmutableSolidColorBrush(4287139478U);
			textBlock22.VerticalAlignment = VerticalAlignment.Center;
			((ISupportInitialize)textBlock22).EndInit();
			context.PopParent();
			supportInitialize18.EndInit();
			AvaloniaList<Control> children24 = stackPanel19.Children;
			TextBlock textBlock24;
			TextBlock textBlock23 = textBlock24 = new TextBlock();
			((ISupportInitialize)textBlock23).BeginInit();
			children24.Add(textBlock23);
			ISupportInitialize supportInitialize20 = textBlock3 = textBlock24;
			context.PushParent(textBlock3);
			TextBlock textBlock25 = textBlock3;
			AvaloniaProperty textProperty4 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.HighestBalanceText!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider6 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding6 = compiledBindingExtension6.ProvideValue(provider6);
			context.ProvideTargetProperty = null;
			textBlock25.Bind(textProperty4, binding6, null);
			textBlock25.FontSize = 15.0;
			StaticResourceExtension staticResourceExtension8 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider8 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj7 = staticResourceExtension8.ProvideValue(serviceProvider8);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock25, obj7);
			textBlock25.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock25.FontWeight = FontWeight.Medium;
			textBlock25.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize20.EndInit();
			context.PopParent();
			supportInitialize17.EndInit();
			AvaloniaList<Control> children25 = grid7.Children;
			Rectangle rectangle5;
			Rectangle rectangle4 = rectangle5 = new Rectangle();
			((ISupportInitialize)rectangle4).BeginInit();
			children25.Add(rectangle4);
			Rectangle rectangle6 = rectangle5;
			Grid.SetColumn(rectangle6, 3);
			rectangle6.Width = 1.0;
			rectangle6.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			rectangle6.Opacity = 0.1;
			rectangle6.VerticalAlignment = VerticalAlignment.Stretch;
			rectangle6.Margin = new Thickness(10.0, 2.0, 10.0, 2.0);
			((ISupportInitialize)rectangle6).EndInit();
			AvaloniaList<Control> children26 = grid7.Children;
			StackPanel stackPanel24;
			StackPanel stackPanel23 = stackPanel24 = new StackPanel();
			((ISupportInitialize)stackPanel23).BeginInit();
			children26.Add(stackPanel23);
			ISupportInitialize supportInitialize21 = stackPanel3 = stackPanel24;
			context.PushParent(stackPanel3);
			StackPanel stackPanel25 = stackPanel3;
			Grid.SetColumn(stackPanel25, 4);
			stackPanel25.Spacing = 6.0;
			stackPanel25.HorizontalAlignment = HorizontalAlignment.Center;
			AvaloniaList<Control> children27 = stackPanel25.Children;
			TextBlock textBlock27;
			TextBlock textBlock26 = textBlock27 = new TextBlock();
			((ISupportInitialize)textBlock26).BeginInit();
			children27.Add(textBlock26);
			ISupportInitialize supportInitialize22 = textBlock3 = textBlock27;
			context.PushParent(textBlock3);
			TextBlock textBlock28 = textBlock3;
			textBlock28.Text = "Portfolio Age";
			textBlock28.FontSize = 12.5;
			StaticResourceExtension staticResourceExtension9 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider9 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj8 = staticResourceExtension9.ProvideValue(serviceProvider9);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock28, obj8);
			textBlock28.Foreground = new ImmutableSolidColorBrush(4287139478U);
			textBlock28.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize22.EndInit();
			AvaloniaList<Control> children28 = stackPanel25.Children;
			TextBlock textBlock30;
			TextBlock textBlock29 = textBlock30 = new TextBlock();
			((ISupportInitialize)textBlock29).BeginInit();
			children28.Add(textBlock29);
			ISupportInitialize supportInitialize23 = textBlock3 = textBlock30;
			context.PushParent(textBlock3);
			TextBlock textBlock31 = textBlock3;
			AvaloniaProperty textProperty5 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.PortfolioAgeText!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider7 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding7 = compiledBindingExtension7.ProvideValue(provider7);
			context.ProvideTargetProperty = null;
			textBlock31.Bind(textProperty5, binding7, null);
			textBlock31.FontSize = 15.0;
			StaticResourceExtension staticResourceExtension10 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider10 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj9 = staticResourceExtension10.ProvideValue(serviceProvider10);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock31, obj9);
			textBlock31.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock31.FontWeight = FontWeight.Medium;
			textBlock31.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize23.EndInit();
			context.PopParent();
			supportInitialize21.EndInit();
			AvaloniaList<Control> children29 = grid7.Children;
			Rectangle rectangle8;
			Rectangle rectangle7 = rectangle8 = new Rectangle();
			((ISupportInitialize)rectangle7).BeginInit();
			children29.Add(rectangle7);
			Rectangle rectangle9 = rectangle8;
			Grid.SetColumn(rectangle9, 5);
			rectangle9.Width = 1.0;
			rectangle9.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			rectangle9.Opacity = 0.1;
			rectangle9.VerticalAlignment = VerticalAlignment.Stretch;
			rectangle9.Margin = new Thickness(10.0, 2.0, 10.0, 2.0);
			((ISupportInitialize)rectangle9).EndInit();
			AvaloniaList<Control> children30 = grid7.Children;
			StackPanel stackPanel27;
			StackPanel stackPanel26 = stackPanel27 = new StackPanel();
			((ISupportInitialize)stackPanel26).BeginInit();
			children30.Add(stackPanel26);
			ISupportInitialize supportInitialize24 = stackPanel3 = stackPanel27;
			context.PushParent(stackPanel3);
			StackPanel stackPanel28 = stackPanel3;
			Grid.SetColumn(stackPanel28, 6);
			stackPanel28.Spacing = 6.0;
			stackPanel28.HorizontalAlignment = HorizontalAlignment.Center;
			AvaloniaList<Control> children31 = stackPanel28.Children;
			TextBlock textBlock33;
			TextBlock textBlock32 = textBlock33 = new TextBlock();
			((ISupportInitialize)textBlock32).BeginInit();
			children31.Add(textBlock32);
			ISupportInitialize supportInitialize25 = textBlock3 = textBlock33;
			context.PushParent(textBlock3);
			TextBlock textBlock34 = textBlock3;
			textBlock34.Text = "Best 24H Asset";
			textBlock34.FontSize = 12.5;
			StaticResourceExtension staticResourceExtension11 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider11 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj10 = staticResourceExtension11.ProvideValue(serviceProvider11);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock34, obj10);
			textBlock34.Foreground = new ImmutableSolidColorBrush(4287139478U);
			textBlock34.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize25.EndInit();
			AvaloniaList<Control> children32 = stackPanel28.Children;
			TextBlock textBlock36;
			TextBlock textBlock35 = textBlock36 = new TextBlock();
			((ISupportInitialize)textBlock35).BeginInit();
			children32.Add(textBlock35);
			ISupportInitialize supportInitialize26 = textBlock3 = textBlock36;
			context.PushParent(textBlock3);
			TextBlock textBlock37 = textBlock3;
			AvaloniaProperty textProperty6 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Best24HAsset!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider8 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding8 = compiledBindingExtension8.ProvideValue(provider8);
			context.ProvideTargetProperty = null;
			textBlock37.Bind(textProperty6, binding8, null);
			textBlock37.FontSize = 15.0;
			StaticResourceExtension staticResourceExtension12 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider12 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj11 = staticResourceExtension12.ProvideValue(serviceProvider12);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock37, obj11);
			textBlock37.Foreground = new ImmutableSolidColorBrush(4278249078U);
			textBlock37.FontWeight = FontWeight.Medium;
			textBlock37.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize26.EndInit();
			context.PopParent();
			supportInitialize24.EndInit();
			AvaloniaList<Control> children33 = grid7.Children;
			Rectangle rectangle11;
			Rectangle rectangle10 = rectangle11 = new Rectangle();
			((ISupportInitialize)rectangle10).BeginInit();
			children33.Add(rectangle10);
			Rectangle rectangle12 = rectangle11;
			Grid.SetColumn(rectangle12, 7);
			rectangle12.Width = 1.0;
			rectangle12.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			rectangle12.Opacity = 0.1;
			rectangle12.VerticalAlignment = VerticalAlignment.Stretch;
			rectangle12.Margin = new Thickness(10.0, 2.0, 10.0, 2.0);
			((ISupportInitialize)rectangle12).EndInit();
			AvaloniaList<Control> children34 = grid7.Children;
			StackPanel stackPanel30;
			StackPanel stackPanel29 = stackPanel30 = new StackPanel();
			((ISupportInitialize)stackPanel29).BeginInit();
			children34.Add(stackPanel29);
			ISupportInitialize supportInitialize27 = stackPanel3 = stackPanel30;
			context.PushParent(stackPanel3);
			StackPanel stackPanel31 = stackPanel3;
			Grid.SetColumn(stackPanel31, 8);
			stackPanel31.Spacing = 6.0;
			stackPanel31.HorizontalAlignment = HorizontalAlignment.Center;
			AvaloniaList<Control> children35 = stackPanel31.Children;
			TextBlock textBlock39;
			TextBlock textBlock38 = textBlock39 = new TextBlock();
			((ISupportInitialize)textBlock38).BeginInit();
			children35.Add(textBlock38);
			ISupportInitialize supportInitialize28 = textBlock3 = textBlock39;
			context.PushParent(textBlock3);
			TextBlock textBlock40 = textBlock3;
			textBlock40.Text = "Worst 24H Asset";
			textBlock40.FontSize = 12.5;
			StaticResourceExtension staticResourceExtension13 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider13 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj12 = staticResourceExtension13.ProvideValue(serviceProvider13);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock40, obj12);
			textBlock40.Foreground = new ImmutableSolidColorBrush(4287139478U);
			textBlock40.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize28.EndInit();
			AvaloniaList<Control> children36 = stackPanel31.Children;
			TextBlock textBlock42;
			TextBlock textBlock41 = textBlock42 = new TextBlock();
			((ISupportInitialize)textBlock41).BeginInit();
			children36.Add(textBlock41);
			ISupportInitialize supportInitialize29 = textBlock3 = textBlock42;
			context.PushParent(textBlock3);
			TextBlock textBlock43 = textBlock3;
			AvaloniaProperty textProperty7 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.Worst24HAsset!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider9 = context;
			context.ProvideTargetProperty = TextBlock.TextProperty;
			IBinding binding9 = compiledBindingExtension9.ProvideValue(provider9);
			context.ProvideTargetProperty = null;
			textBlock43.Bind(textProperty7, binding9, null);
			textBlock43.FontSize = 15.0;
			StaticResourceExtension staticResourceExtension14 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider14 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj13 = staticResourceExtension14.ProvideValue(serviceProvider14);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock43, obj13);
			textBlock43.Foreground = new ImmutableSolidColorBrush(4294922834U);
			textBlock43.FontWeight = FontWeight.Medium;
			textBlock43.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			supportInitialize29.EndInit();
			context.PopParent();
			supportInitialize27.EndInit();
			context.PopParent();
			supportInitialize13.EndInit();
			context.PopParent();
			supportInitialize12.EndInit();
			AvaloniaList<Control> children37 = stackPanel4.Children;
			Grid grid9;
			Grid grid8 = grid9 = new Grid();
			((ISupportInitialize)grid8).BeginInit();
			children37.Add(grid8);
			ISupportInitialize supportInitialize30 = grid3 = grid9;
			context.PushParent(grid3);
			Grid grid10 = grid3;
			grid10.Margin = new Thickness(45.0, 10.0, 45.0, 10.0);
			ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
			columnDefinitions2.Capacity = 3;
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid10.ColumnDefinitions = columnDefinitions2;
			AvaloniaList<Control> children38 = grid10.Children;
			StackPanel stackPanel33;
			StackPanel stackPanel32 = stackPanel33 = new StackPanel();
			((ISupportInitialize)stackPanel32).BeginInit();
			children38.Add(stackPanel32);
			ISupportInitialize supportInitialize31 = stackPanel3 = stackPanel33;
			context.PushParent(stackPanel3);
			StackPanel stackPanel34 = stackPanel3;
			Grid.SetColumn(stackPanel34, 0);
			stackPanel34.Orientation = Orientation.Horizontal;
			stackPanel34.Spacing = 24.0;
			AvaloniaList<Control> children39 = stackPanel34.Children;
			StackPanel stackPanel36;
			StackPanel stackPanel35 = stackPanel36 = new StackPanel();
			((ISupportInitialize)stackPanel35).BeginInit();
			children39.Add(stackPanel35);
			ISupportInitialize supportInitialize32 = stackPanel3 = stackPanel36;
			context.PushParent(stackPanel3);
			StackPanel stackPanel37 = stackPanel3;
			stackPanel37.Orientation = Orientation.Vertical;
			stackPanel37.Spacing = 4.0;
			AvaloniaList<Control> children40 = stackPanel37.Children;
			TextBlock textBlock45;
			TextBlock textBlock44 = textBlock45 = new TextBlock();
			((ISupportInitialize)textBlock44).BeginInit();
			children40.Add(textBlock44);
			ISupportInitialize supportInitialize33 = textBlock3 = textBlock45;
			context.PushParent(textBlock3);
			TextBlock textBlock46 = textBlock3;
			textBlock46.Text = "OVERVIEW";
			textBlock46.FontSize = 13.0;
			StaticResourceExtension staticResourceExtension15 = new StaticResourceExtension("RobotoCondensedBold");
			IServiceProvider serviceProvider15 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj14 = staticResourceExtension15.ProvideValue(serviceProvider15);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock46, obj14);
			textBlock46.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock46.FontWeight = FontWeight.DemiBold;
			textBlock46.LetterSpacing = 0.5;
			context.PopParent();
			supportInitialize33.EndInit();
			AvaloniaList<Control> children41 = stackPanel37.Children;
			Border border12;
			Border border11 = border12 = new Border();
			((ISupportInitialize)border11).BeginInit();
			children41.Add(border11);
			Border border13 = border12;
			border13.Height = 2.0;
			border13.Background = new ImmutableSolidColorBrush(4283016900U);
			border13.CornerRadius = new CornerRadius(1.0, 1.0, 1.0, 1.0);
			border13.Margin = new Thickness(0.0, 2.0, 0.0, 0.0);
			((ISupportInitialize)border13).EndInit();
			context.PopParent();
			supportInitialize32.EndInit();
			AvaloniaList<Control> children42 = stackPanel34.Children;
			Button button14;
			Button button13 = button14 = new Button();
			((ISupportInitialize)button13).BeginInit();
			children42.Add(button13);
			Button button15;
			ISupportInitialize supportInitialize34 = button15 = button14;
			context.PushParent(button15);
			Button button16 = button15;
			button16.Background = new ImmutableSolidColorBrush(16777215U);
			TextBlock textBlock48;
			TextBlock textBlock47 = textBlock48 = new TextBlock();
			((ISupportInitialize)textBlock47).BeginInit();
			button16.Content = textBlock47;
			ISupportInitialize supportInitialize35 = textBlock3 = textBlock48;
			context.PushParent(textBlock3);
			TextBlock textBlock49 = textBlock3;
			textBlock49.Text = "PRICE ACTION";
			textBlock49.FontSize = 13.0;
			StaticResourceExtension staticResourceExtension16 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider16 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj15 = staticResourceExtension16.ProvideValue(serviceProvider16);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock49, obj15);
			textBlock49.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock49.Opacity = 0.35;
			textBlock49.FontWeight = FontWeight.Medium;
			textBlock49.LetterSpacing = 0.5;
			context.PopParent();
			supportInitialize35.EndInit();
			context.PopParent();
			supportInitialize34.EndInit();
			AvaloniaList<Control> children43 = stackPanel34.Children;
			Button button18;
			Button button17 = button18 = new Button();
			((ISupportInitialize)button17).BeginInit();
			children43.Add(button17);
			ISupportInitialize supportInitialize36 = button15 = button18;
			context.PushParent(button15);
			Button button19 = button15;
			button19.Background = new ImmutableSolidColorBrush(16777215U);
			TextBlock textBlock51;
			TextBlock textBlock50 = textBlock51 = new TextBlock();
			((ISupportInitialize)textBlock50).BeginInit();
			button19.Content = textBlock50;
			ISupportInitialize supportInitialize37 = textBlock3 = textBlock51;
			context.PushParent(textBlock3);
			TextBlock textBlock52 = textBlock3;
			textBlock52.Text = "PORTFOLIO";
			textBlock52.FontSize = 13.0;
			StaticResourceExtension staticResourceExtension17 = new StaticResourceExtension("RobotoCondensedRegular");
			IServiceProvider serviceProvider17 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj16 = staticResourceExtension17.ProvideValue(serviceProvider17);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock52, obj16);
			textBlock52.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
			textBlock52.Opacity = 0.35;
			textBlock52.FontWeight = FontWeight.Medium;
			textBlock52.LetterSpacing = 0.5;
			context.PopParent();
			supportInitialize37.EndInit();
			context.PopParent();
			supportInitialize36.EndInit();
			context.PopParent();
			supportInitialize31.EndInit();
			AvaloniaList<Control> children44 = grid10.Children;
			StackPanel stackPanel39;
			StackPanel stackPanel38 = stackPanel39 = new StackPanel();
			((ISupportInitialize)stackPanel38).BeginInit();
			children44.Add(stackPanel38);
			ISupportInitialize supportInitialize38 = stackPanel3 = stackPanel39;
			context.PushParent(stackPanel3);
			StackPanel stackPanel40 = stackPanel3;
			Grid.SetColumn(stackPanel40, 2);
			stackPanel40.Orientation = Orientation.Horizontal;
			stackPanel40.Spacing = 20.0;
			stackPanel40.VerticalAlignment = VerticalAlignment.Center;
			AvaloniaList<Control> children45 = stackPanel40.Children;
			CheckBox checkBox2;
			CheckBox checkBox = checkBox2 = new CheckBox();
			((ISupportInitialize)checkBox).BeginInit();
			children45.Add(checkBox);
			CheckBox checkBox3;
			ISupportInitialize supportInitialize39 = checkBox3 = checkBox2;
			context.PushParent(checkBox3);
			CheckBox checkBox4 = checkBox3;
			AvaloniaProperty isCheckedProperty = ToggleButton.IsCheckedProperty;
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterWithBalance!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider10 = context;
			context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
			IBinding binding10 = compiledBindingExtension10.ProvideValue(provider10);
			context.ProvideTargetProperty = null;
			checkBox4.Bind(isCheckedProperty, binding10, null);
			checkBox4.Foreground = new ImmutableSolidColorBrush(4287139478U);
			checkBox4.FontSize = 13.0;
			TextBlock textBlock54;
			TextBlock textBlock53 = textBlock54 = new TextBlock();
			((ISupportInitialize)textBlock53).BeginInit();
			checkBox4.Content = textBlock53;
			ISupportInitialize supportInitialize40 = textBlock3 = textBlock54;
			context.PushParent(textBlock3);
			TextBlock textBlock55 = textBlock3;
			textBlock55.Text = "With Balance";
			textBlock55.Foreground = new ImmutableSolidColorBrush(4287139478U);
			textBlock55.FontSize = 13.0;
			StaticResourceExtension staticResourceExtension18 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider18 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj17 = staticResourceExtension18.ProvideValue(serviceProvider18);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock55, obj17);
			context.PopParent();
			supportInitialize40.EndInit();
			context.PopParent();
			supportInitialize39.EndInit();
			AvaloniaList<Control> children46 = stackPanel40.Children;
			CheckBox checkBox6;
			CheckBox checkBox5 = checkBox6 = new CheckBox();
			((ISupportInitialize)checkBox5).BeginInit();
			children46.Add(checkBox5);
			ISupportInitialize supportInitialize41 = checkBox3 = checkBox6;
			context.PushParent(checkBox3);
			CheckBox checkBox7 = checkBox3;
			AvaloniaProperty isCheckedProperty2 = ToggleButton.IsCheckedProperty;
			CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.FilterFavorite!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider11 = context;
			context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
			IBinding binding11 = compiledBindingExtension11.ProvideValue(provider11);
			context.ProvideTargetProperty = null;
			checkBox7.Bind(isCheckedProperty2, binding11, null);
			checkBox7.Foreground = new ImmutableSolidColorBrush(4287139478U);
			checkBox7.FontSize = 13.0;
			TextBlock textBlock57;
			TextBlock textBlock56 = textBlock57 = new TextBlock();
			((ISupportInitialize)textBlock56).BeginInit();
			checkBox7.Content = textBlock56;
			ISupportInitialize supportInitialize42 = textBlock3 = textBlock57;
			context.PushParent(textBlock3);
			TextBlock textBlock58 = textBlock3;
			textBlock58.Text = "Favorite";
			textBlock58.Foreground = new ImmutableSolidColorBrush(4287139478U);
			textBlock58.FontSize = 13.0;
			StaticResourceExtension staticResourceExtension19 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider19 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj18 = staticResourceExtension19.ProvideValue(serviceProvider19);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock58, obj18);
			context.PopParent();
			supportInitialize42.EndInit();
			context.PopParent();
			supportInitialize41.EndInit();
			context.PopParent();
			supportInitialize38.EndInit();
			context.PopParent();
			supportInitialize30.EndInit();
			AvaloniaList<Control> children47 = stackPanel4.Children;
			Border border15;
			Border border14 = border15 = new Border();
			((ISupportInitialize)border14).BeginInit();
			children47.Add(border14);
			ISupportInitialize supportInitialize43 = border3 = border15;
			context.PushParent(border3);
			Border border16 = border3;
			border16.Margin = new Thickness(40.0, 5.0, 40.0, 30.0);
			border16.Background = new ImmutableSolidColorBrush(4279309078U);
			border16.CornerRadius = new CornerRadius(14.0, 14.0, 14.0, 14.0);
			border16.Padding = new Thickness(15.0, 10.0, 15.0, 10.0);
			StackPanel stackPanel42;
			StackPanel stackPanel41 = stackPanel42 = new StackPanel();
			((ISupportInitialize)stackPanel41).BeginInit();
			border16.Child = stackPanel41;
			ISupportInitialize supportInitialize44 = stackPanel3 = stackPanel42;
			context.PushParent(stackPanel3);
			StackPanel stackPanel43 = stackPanel3;
			AvaloniaList<Control> children48 = stackPanel43.Children;
			Border border18;
			Border border17 = border18 = new Border();
			((ISupportInitialize)border17).BeginInit();
			children48.Add(border17);
			ISupportInitialize supportInitialize45 = border3 = border18;
			context.PushParent(border3);
			Border border19 = border3;
			border19.BorderThickness = new Thickness(0.0, 0.0, 0.0, 1.0);
			border19.BorderBrush = new ImmutableSolidColorBrush(452984831U);
			border19.Padding = new Thickness(10.0, 8.0, 10.0, 12.0);
			Grid grid12;
			Grid grid11 = grid12 = new Grid();
			((ISupportInitialize)grid11).BeginInit();
			border19.Child = grid11;
			ISupportInitialize supportInitialize46 = grid3 = grid12;
			context.PushParent(grid3);
			Grid grid13 = grid3;
			ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
			columnDefinitions3.Capacity = 10;
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(220.0, GridUnitType.Pixel)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(95.0, GridUnitType.Pixel)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(115.0, GridUnitType.Pixel)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(105.0, GridUnitType.Pixel)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(105.0, GridUnitType.Pixel)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(105.0, GridUnitType.Pixel)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(125.0, GridUnitType.Pixel)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(150.0, GridUnitType.Pixel)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(120.0, GridUnitType.Pixel)));
			columnDefinitions3.Add(new ColumnDefinition(new GridLength(80.0, GridUnitType.Pixel)));
			grid13.ColumnDefinitions = columnDefinitions3;
			AvaloniaList<Control> children49 = grid13.Children;
			TextBlock textBlock60;
			TextBlock textBlock59 = textBlock60 = new TextBlock();
			((ISupportInitialize)textBlock59).BeginInit();
			children49.Add(textBlock59);
			ISupportInitialize supportInitialize47 = textBlock3 = textBlock60;
			context.PushParent(textBlock3);
			TextBlock textBlock61 = textBlock3;
			Grid.SetColumn(textBlock61, 0);
			textBlock61.Text = "ASSET NAME ⬍";
			textBlock61.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension20 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider20 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj19 = staticResourceExtension20.ProvideValue(serviceProvider20);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock61, obj19);
			textBlock61.Foreground = new ImmutableSolidColorBrush(4284902775U);
			textBlock61.FontWeight = FontWeight.Medium;
			context.PopParent();
			supportInitialize47.EndInit();
			AvaloniaList<Control> children50 = grid13.Children;
			TextBlock textBlock63;
			TextBlock textBlock62 = textBlock63 = new TextBlock();
			((ISupportInitialize)textBlock62).BeginInit();
			children50.Add(textBlock62);
			ISupportInitialize supportInitialize48 = textBlock3 = textBlock63;
			context.PushParent(textBlock3);
			TextBlock textBlock64 = textBlock3;
			Grid.SetColumn(textBlock64, 1);
			textBlock64.Text = "APY REWARDS ⬍";
			textBlock64.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension21 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider21 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj20 = staticResourceExtension21.ProvideValue(serviceProvider21);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock64, obj20);
			textBlock64.Foreground = new ImmutableSolidColorBrush(4284902775U);
			textBlock64.FontWeight = FontWeight.Medium;
			context.PopParent();
			supportInitialize48.EndInit();
			AvaloniaList<Control> children51 = grid13.Children;
			TextBlock textBlock66;
			TextBlock textBlock65 = textBlock66 = new TextBlock();
			((ISupportInitialize)textBlock65).BeginInit();
			children51.Add(textBlock65);
			ISupportInitialize supportInitialize49 = textBlock3 = textBlock66;
			context.PushParent(textBlock3);
			TextBlock textBlock67 = textBlock3;
			Grid.SetColumn(textBlock67, 2);
			textBlock67.Text = "PRICE ⬍";
			textBlock67.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension22 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider22 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj21 = staticResourceExtension22.ProvideValue(serviceProvider22);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock67, obj21);
			textBlock67.Foreground = new ImmutableSolidColorBrush(4284902775U);
			textBlock67.FontWeight = FontWeight.Medium;
			context.PopParent();
			supportInitialize49.EndInit();
			AvaloniaList<Control> children52 = grid13.Children;
			TextBlock textBlock69;
			TextBlock textBlock68 = textBlock69 = new TextBlock();
			((ISupportInitialize)textBlock68).BeginInit();
			children52.Add(textBlock68);
			ISupportInitialize supportInitialize50 = textBlock3 = textBlock69;
			context.PushParent(textBlock3);
			TextBlock textBlock70 = textBlock3;
			Grid.SetColumn(textBlock70, 3);
			textBlock70.Text = "24H CHANGE ⬍";
			textBlock70.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension23 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider23 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj22 = staticResourceExtension23.ProvideValue(serviceProvider23);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock70, obj22);
			textBlock70.Foreground = new ImmutableSolidColorBrush(4284902775U);
			textBlock70.FontWeight = FontWeight.Medium;
			context.PopParent();
			supportInitialize50.EndInit();
			AvaloniaList<Control> children53 = grid13.Children;
			TextBlock textBlock72;
			TextBlock textBlock71 = textBlock72 = new TextBlock();
			((ISupportInitialize)textBlock71).BeginInit();
			children53.Add(textBlock71);
			ISupportInitialize supportInitialize51 = textBlock3 = textBlock72;
			context.PushParent(textBlock3);
			TextBlock textBlock73 = textBlock3;
			Grid.SetColumn(textBlock73, 4);
			textBlock73.Text = "MARKET CAP ⬍";
			textBlock73.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension24 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider24 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj23 = staticResourceExtension24.ProvideValue(serviceProvider24);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock73, obj23);
			textBlock73.Foreground = new ImmutableSolidColorBrush(4284902775U);
			textBlock73.FontWeight = FontWeight.Medium;
			context.PopParent();
			supportInitialize51.EndInit();
			AvaloniaList<Control> children54 = grid13.Children;
			TextBlock textBlock75;
			TextBlock textBlock74 = textBlock75 = new TextBlock();
			((ISupportInitialize)textBlock74).BeginInit();
			children54.Add(textBlock74);
			ISupportInitialize supportInitialize52 = textBlock3 = textBlock75;
			context.PushParent(textBlock3);
			TextBlock textBlock76 = textBlock3;
			Grid.SetColumn(textBlock76, 5);
			textBlock76.Text = "24H VOL ⬍";
			textBlock76.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension25 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider25 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj24 = staticResourceExtension25.ProvideValue(serviceProvider25);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock76, obj24);
			textBlock76.Foreground = new ImmutableSolidColorBrush(4284902775U);
			textBlock76.FontWeight = FontWeight.Medium;
			context.PopParent();
			supportInitialize52.EndInit();
			AvaloniaList<Control> children55 = grid13.Children;
			TextBlock textBlock78;
			TextBlock textBlock77 = textBlock78 = new TextBlock();
			((ISupportInitialize)textBlock77).BeginInit();
			children55.Add(textBlock77);
			ISupportInitialize supportInitialize53 = textBlock3 = textBlock78;
			context.PushParent(textBlock3);
			TextBlock textBlock79 = textBlock3;
			Grid.SetColumn(textBlock79, 6);
			textBlock79.Text = "30 DAY TREND";
			textBlock79.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension26 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider26 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj25 = staticResourceExtension26.ProvideValue(serviceProvider26);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock79, obj25);
			textBlock79.Foreground = new ImmutableSolidColorBrush(4284902775U);
			textBlock79.FontWeight = FontWeight.Medium;
			context.PopParent();
			supportInitialize53.EndInit();
			AvaloniaList<Control> children56 = grid13.Children;
			TextBlock textBlock81;
			TextBlock textBlock80 = textBlock81 = new TextBlock();
			((ISupportInitialize)textBlock80).BeginInit();
			children56.Add(textBlock80);
			ISupportInitialize supportInitialize54 = textBlock3 = textBlock81;
			context.PushParent(textBlock3);
			TextBlock textBlock82 = textBlock3;
			Grid.SetColumn(textBlock82, 7);
			textBlock82.Text = "BALANCE ⬍";
			textBlock82.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension27 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider27 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj26 = staticResourceExtension27.ProvideValue(serviceProvider27);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock82, obj26);
			textBlock82.Foreground = new ImmutableSolidColorBrush(4284902775U);
			textBlock82.FontWeight = FontWeight.Medium;
			context.PopParent();
			supportInitialize54.EndInit();
			AvaloniaList<Control> children57 = grid13.Children;
			TextBlock textBlock84;
			TextBlock textBlock83 = textBlock84 = new TextBlock();
			((ISupportInitialize)textBlock83).BeginInit();
			children57.Add(textBlock83);
			ISupportInitialize supportInitialize55 = textBlock3 = textBlock84;
			context.PushParent(textBlock3);
			TextBlock textBlock85 = textBlock3;
			Grid.SetColumn(textBlock85, 8);
			textBlock85.Text = "VALUE ▼";
			textBlock85.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension28 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider28 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj27 = staticResourceExtension28.ProvideValue(serviceProvider28);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock85, obj27);
			textBlock85.Foreground = new ImmutableSolidColorBrush(4291876060U);
			textBlock85.FontWeight = FontWeight.DemiBold;
			context.PopParent();
			supportInitialize55.EndInit();
			AvaloniaList<Control> children58 = grid13.Children;
			TextBlock textBlock87;
			TextBlock textBlock86 = textBlock87 = new TextBlock();
			((ISupportInitialize)textBlock86).BeginInit();
			children58.Add(textBlock86);
			ISupportInitialize supportInitialize56 = textBlock3 = textBlock87;
			context.PushParent(textBlock3);
			TextBlock textBlock88 = textBlock3;
			Grid.SetColumn(textBlock88, 9);
			textBlock88.Text = "PORTFOLIO % ⬍";
			textBlock88.FontSize = 11.0;
			StaticResourceExtension staticResourceExtension29 = new StaticResourceExtension("RobotoRegular");
			IServiceProvider serviceProvider29 = context;
			context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
			object obj28 = staticResourceExtension29.ProvideValue(serviceProvider29);
			context.ProvideTargetProperty = null;
			PortfolioView.DynamicSetters_80.DynamicSetter_1(textBlock88, obj28);
			textBlock88.Foreground = new ImmutableSolidColorBrush(4284902775U);
			textBlock88.FontWeight = FontWeight.Medium;
			context.PopParent();
			supportInitialize56.EndInit();
			context.PopParent();
			supportInitialize46.EndInit();
			context.PopParent();
			supportInitialize45.EndInit();
			AvaloniaList<Control> children59 = stackPanel43.Children;
			ItemsControl itemsControl6;
			ItemsControl itemsControl5 = itemsControl6 = new ItemsControl();
			((ISupportInitialize)itemsControl5).BeginInit();
			children59.Add(itemsControl5);
			ISupportInitialize supportInitialize57 = itemsControl3 = itemsControl6;
			context.PushParent(itemsControl3);
			ItemsControl itemsControl7 = itemsControl3;
			AvaloniaProperty itemsSourceProperty2 = ItemsControl.ItemsSourceProperty;
			CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.ViewModels.PortfolioViewModel,Exodus.DisplayItems!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
			IServiceProvider provider12 = context;
			context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
			IBinding binding12 = compiledBindingExtension12.ProvideValue(provider12);
			context.ProvideTargetProperty = null;
			itemsControl7.Bind(itemsSourceProperty2, binding12, null);
			IDataTemplate itemTemplate2 = dataTemplate = new DataTemplate();
			context.PushParent(dataTemplate);
			DataTemplate dataTemplate3 = dataTemplate;
			dataTemplate3.DataType = typeof(PortfolioCoinItem);
			dataTemplate3.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV2<Control>(new Func<IServiceProvider, object>(PortfolioView.XamlClosure_81.Build), context);
			context.PopParent();
			itemsControl7.ItemTemplate = itemTemplate2;
			context.PopParent();
			supportInitialize57.EndInit();
			context.PopParent();
			supportInitialize44.EndInit();
			context.PopParent();
			supportInitialize43.EndInit();
			context.PopParent();
			supportInitialize3.EndInit();
			context.PopParent();
			supportInitialize2.EndInit();
			context.PopParent();
			supportInitialize.EndInit();
			context.PopParent();
			((ISupportInitialize)A_1).EndInit();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x06000058 RID: 88 RVA: 0x0001BF9E File Offset: 0x0001A19E
		private static void !XamlIlPopulateTrampoline(PortfolioView A_0)
		{
			if (PortfolioView.!XamlIlPopulateOverride != null)
			{
				PortfolioView.!XamlIlPopulateOverride(A_0);
				return;
			}
			PortfolioView.!XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), A_0);
		}

		// Token: 0x04000013 RID: 19
		private static Action<object> !XamlIlPopulateOverride;

		// Token: 0x02000027 RID: 39
		private class XamlClosure_78
		{
			// Token: 0x06000059 RID: 89 RVA: 0x0001BFC4 File Offset: 0x0001A1C4
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<PortfolioView> context = new XamlIlContext.Context<PortfolioView>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.Singleton
				}, "avares://Exodus/Views/PortfolioView.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (PortfolioView)obj;
					}
				}
				context.IntermediateRoot = new Panel();
				object intermediateRoot = context.IntermediateRoot;
				((ISupportInitialize)intermediateRoot).BeginInit();
				((ISupportInitialize)intermediateRoot).EndInit();
				return intermediateRoot;
			}
		}

		// Token: 0x02000028 RID: 40
		private class XamlClosure_79
		{
			// Token: 0x0600005A RID: 90 RVA: 0x0001C044 File Offset: 0x0001A244
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<PortfolioView> context = new XamlIlContext.Context<PortfolioView>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.Singleton
				}, "avares://Exodus/Views/PortfolioView.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (PortfolioView)obj;
					}
				}
				context.IntermediateRoot = new Path();
				object intermediateRoot = context.IntermediateRoot;
				((ISupportInitialize)intermediateRoot).BeginInit();
				Path path = intermediateRoot;
				context.PushParent(path);
				Path path2 = path;
				AvaloniaProperty dataProperty = Path.DataProperty;
				CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.PathData!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider = context;
				context.ProvideTargetProperty = Path.DataProperty;
				IBinding binding = compiledBindingExtension.ProvideValue(provider);
				context.ProvideTargetProperty = null;
				path2.Bind(dataProperty, binding, null);
				AvaloniaProperty strokeProperty = Shape.StrokeProperty;
				CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.DonutSegment,Exodus.Brush!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider2 = context;
				context.ProvideTargetProperty = Shape.StrokeProperty;
				IBinding binding2 = compiledBindingExtension2.ProvideValue(provider2);
				context.ProvideTargetProperty = null;
				path2.Bind(strokeProperty, binding2, null);
				path2.StrokeThickness = 9.0;
				path2.StrokeLineCap = PenLineCap.Round;
				path2.Fill = new ImmutableSolidColorBrush(16777215U);
				context.PopParent();
				((ISupportInitialize)intermediateRoot).EndInit();
				return intermediateRoot;
			}
		}

		// Token: 0x02000029 RID: 41
		private class DynamicSetters_80
		{
			// Token: 0x0600005B RID: 91 RVA: 0x0001C190 File Offset: 0x0001A390
			public static void DynamicSetter_1(TextBlock A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
					return;
				}
				if (A_1 is FontFamily)
				{
					A_0.FontFamily = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.FontFamily = A_1;
					return;
				}
				throw new InvalidCastException();
			}
		}

		// Token: 0x0200002A RID: 42
		private class XamlClosure_81
		{
			// Token: 0x0600005C RID: 92 RVA: 0x0001C1FC File Offset: 0x0001A3FC
			public static object Build(IServiceProvider A_0)
			{
				XamlIlContext.Context<PortfolioView> context = new XamlIlContext.Context<PortfolioView>(A_0, new object[]
				{
					(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Views/PortfolioView.axaml.Singleton
				}, "avares://Exodus/Views/PortfolioView.axaml");
				if (A_0 != null)
				{
					object obj = A_0.GetService(typeof(IRootObjectProvider));
					if (obj != null)
					{
						obj = ((IRootObjectProvider)obj).RootObject;
						context.RootObject = (PortfolioView)obj;
					}
				}
				context.IntermediateRoot = new Button();
				object intermediateRoot = context.IntermediateRoot;
				((ISupportInitialize)intermediateRoot).BeginInit();
				Button button = intermediateRoot;
				context.PushParent(button);
				Button button2 = button;
				button2.Classes.Add("assetRow");
				button2.HorizontalAlignment = HorizontalAlignment.Stretch;
				button2.HorizontalContentAlignment = HorizontalAlignment.Stretch;
				AvaloniaProperty commandProperty = Button.CommandProperty;
				CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(PortfolioView), 0).Property(StyledElement.DataContextProperty, new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor)).TypeCast<PortfolioViewModel>().Command("SelectCoin", new Action<object, object>(XamlIlTrampolines.Exodus:Exodus.ViewModels.PortfolioViewModel+SelectCoin_1!CommandExecuteTrampoline), null, null).Build());
				IServiceProvider provider = context;
				context.ProvideTargetProperty = Button.CommandProperty;
				IBinding binding = compiledBindingExtension.ProvideValue(provider);
				context.ProvideTargetProperty = null;
				button2.Bind(commandProperty, binding, null);
				CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension();
				IServiceProvider provider2 = context;
				context.ProvideTargetProperty = Button.CommandParameterProperty;
				CompiledBindingExtension compiledBindingExtension3 = compiledBindingExtension2.ProvideValue(provider2);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_1(button2, compiledBindingExtension3);
				Border border2;
				Border border = border2 = new Border();
				((ISupportInitialize)border).BeginInit();
				button2.Content = border;
				Border border3;
				ISupportInitialize supportInitialize = border3 = border2;
				context.PushParent(border3);
				Border border4 = border3;
				border4.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
				border4.Padding = new Thickness(10.0, 12.0, 10.0, 12.0);
				border4.Background = new ImmutableSolidColorBrush(16777215U);
				Grid grid2;
				Grid grid = grid2 = new Grid();
				((ISupportInitialize)grid).BeginInit();
				border4.Child = grid;
				Grid grid3;
				ISupportInitialize supportInitialize2 = grid3 = grid2;
				context.PushParent(grid3);
				Grid grid4 = grid3;
				ColumnDefinitions columnDefinitions = new ColumnDefinitions();
				columnDefinitions.Capacity = 10;
				columnDefinitions.Add(new ColumnDefinition(new GridLength(220.0, GridUnitType.Pixel)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(95.0, GridUnitType.Pixel)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(115.0, GridUnitType.Pixel)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(105.0, GridUnitType.Pixel)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(105.0, GridUnitType.Pixel)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(105.0, GridUnitType.Pixel)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(125.0, GridUnitType.Pixel)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(150.0, GridUnitType.Pixel)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(120.0, GridUnitType.Pixel)));
				columnDefinitions.Add(new ColumnDefinition(new GridLength(80.0, GridUnitType.Pixel)));
				grid4.ColumnDefinitions = columnDefinitions;
				grid4.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children = grid4.Children;
				StackPanel stackPanel2;
				StackPanel stackPanel = stackPanel2 = new StackPanel();
				((ISupportInitialize)stackPanel).BeginInit();
				children.Add(stackPanel);
				StackPanel stackPanel3;
				ISupportInitialize supportInitialize3 = stackPanel3 = stackPanel2;
				context.PushParent(stackPanel3);
				StackPanel stackPanel4 = stackPanel3;
				Grid.SetColumn(stackPanel4, 0);
				stackPanel4.Orientation = Orientation.Horizontal;
				stackPanel4.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children2 = stackPanel4.Children;
				Image image2;
				Image image = image2 = new Image();
				((ISupportInitialize)image).BeginInit();
				children2.Add(image);
				Image image3;
				ISupportInitialize supportInitialize4 = image3 = image2;
				context.PushParent(image3);
				Image image4 = image3;
				AvaloniaProperty sourceProperty = Image.SourceProperty;
				CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Icon!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider3 = context;
				context.ProvideTargetProperty = Image.SourceProperty;
				IBinding binding2 = compiledBindingExtension4.ProvideValue(provider3);
				context.ProvideTargetProperty = null;
				image4.Bind(sourceProperty, binding2, null);
				image4.Width = 30.0;
				image4.Height = 30.0;
				image4.Stretch = Stretch.Uniform;
				RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
				image4.Margin = new Thickness(0.0, 0.0, 12.0, 0.0);
				image4.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize4.EndInit();
				AvaloniaList<Control> children3 = stackPanel4.Children;
				StackPanel stackPanel6;
				StackPanel stackPanel5 = stackPanel6 = new StackPanel();
				((ISupportInitialize)stackPanel5).BeginInit();
				children3.Add(stackPanel5);
				ISupportInitialize supportInitialize5 = stackPanel3 = stackPanel6;
				context.PushParent(stackPanel3);
				StackPanel stackPanel7 = stackPanel3;
				stackPanel7.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children4 = stackPanel7.Children;
				StackPanel stackPanel9;
				StackPanel stackPanel8 = stackPanel9 = new StackPanel();
				((ISupportInitialize)stackPanel8).BeginInit();
				children4.Add(stackPanel8);
				ISupportInitialize supportInitialize6 = stackPanel3 = stackPanel9;
				context.PushParent(stackPanel3);
				StackPanel stackPanel10 = stackPanel3;
				stackPanel10.Orientation = Orientation.Horizontal;
				stackPanel10.Spacing = 4.0;
				AvaloniaList<Control> children5 = stackPanel10.Children;
				TextBlock textBlock2;
				TextBlock textBlock = textBlock2 = new TextBlock();
				((ISupportInitialize)textBlock).BeginInit();
				children5.Add(textBlock);
				TextBlock textBlock3;
				ISupportInitialize supportInitialize7 = textBlock3 = textBlock2;
				context.PushParent(textBlock3);
				TextBlock textBlock4 = textBlock3;
				AvaloniaProperty textProperty = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Name!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider4 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding3 = compiledBindingExtension5.ProvideValue(provider4);
				context.ProvideTargetProperty = null;
				textBlock4.Bind(textProperty, binding3, null);
				textBlock4.FontSize = 14.5;
				StaticResourceExtension staticResourceExtension = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj2 = staticResourceExtension.ProvideValue(serviceProvider);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_2(textBlock4, obj2);
				textBlock4.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock4.FontWeight = FontWeight.Normal;
				textBlock4.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize7.EndInit();
				AvaloniaList<Control> children6 = stackPanel10.Children;
				Image image6;
				Image image5 = image6 = new Image();
				((ISupportInitialize)image5).BeginInit();
				children6.Add(image5);
				ISupportInitialize supportInitialize8 = image3 = image6;
				context.PushParent(image3);
				Image image7 = image3;
				image7.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "/Assets/Resources/Icons/bsc_badge.png");
				image7.Width = 11.0;
				image7.Height = 11.0;
				image7.Stretch = Stretch.Uniform;
				AvaloniaProperty isVisibleProperty = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.IsBsc!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider5 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding4 = compiledBindingExtension6.ProvideValue(provider5);
				context.ProvideTargetProperty = null;
				image7.Bind(isVisibleProperty, binding4, null);
				image7.VerticalAlignment = VerticalAlignment.Center;
				image7.Margin = new Thickness(2.0, 0.0, 0.0, 0.0);
				context.PopParent();
				supportInitialize8.EndInit();
				AvaloniaList<Control> children7 = stackPanel10.Children;
				Viewbox viewbox2;
				Viewbox viewbox = viewbox2 = new Viewbox();
				((ISupportInitialize)viewbox).BeginInit();
				children7.Add(viewbox);
				Viewbox viewbox3;
				ISupportInitialize supportInitialize9 = viewbox3 = viewbox2;
				context.PushParent(viewbox3);
				Viewbox viewbox4 = viewbox3;
				viewbox4.Width = 7.0;
				viewbox4.Height = 7.0;
				AvaloniaProperty isVisibleProperty2 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasDropdown!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider6 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding5 = compiledBindingExtension7.ProvideValue(provider6);
				context.ProvideTargetProperty = null;
				viewbox4.Bind(isVisibleProperty2, binding5, null);
				viewbox4.VerticalAlignment = VerticalAlignment.Center;
				viewbox4.Margin = new Thickness(3.0, 2.0, 0.0, 0.0);
				Path path2;
				Path path = path2 = new Path();
				((ISupportInitialize)path).BeginInit();
				viewbox4.Child = path;
				Path path3;
				ISupportInitialize supportInitialize10 = path3 = path2;
				context.PushParent(path3);
				Path path4 = path3;
				StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("PointDownFullArrow");
				IServiceProvider serviceProvider2 = context;
				context.ProvideTargetProperty = Path.DataProperty;
				object obj3 = staticResourceExtension2.ProvideValue(serviceProvider2);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_3(path4, obj3);
				path4.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
				path4.Opacity = 0.4;
				path4.Stretch = Stretch.Uniform;
				context.PopParent();
				supportInitialize10.EndInit();
				context.PopParent();
				supportInitialize9.EndInit();
				context.PopParent();
				supportInitialize6.EndInit();
				AvaloniaList<Control> children8 = stackPanel7.Children;
				TextBlock textBlock6;
				TextBlock textBlock5 = textBlock6 = new TextBlock();
				((ISupportInitialize)textBlock5).BeginInit();
				children8.Add(textBlock5);
				ISupportInitialize supportInitialize11 = textBlock3 = textBlock6;
				context.PushParent(textBlock3);
				TextBlock textBlock7 = textBlock3;
				AvaloniaProperty textProperty2 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Symbol!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider7 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding6 = compiledBindingExtension8.ProvideValue(provider7);
				context.ProvideTargetProperty = null;
				textBlock7.Bind(textProperty2, binding6, null);
				textBlock7.FontSize = 12.0;
				StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider3 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj4 = staticResourceExtension3.ProvideValue(serviceProvider3);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_2(textBlock7, obj4);
				textBlock7.Foreground = new ImmutableSolidColorBrush(4285429378U);
				textBlock7.Margin = new Thickness(0.0, 2.0, 0.0, 0.0);
				context.PopParent();
				supportInitialize11.EndInit();
				context.PopParent();
				supportInitialize5.EndInit();
				context.PopParent();
				supportInitialize3.EndInit();
				AvaloniaList<Control> children9 = grid4.Children;
				Grid grid6;
				Grid grid5 = grid6 = new Grid();
				((ISupportInitialize)grid5).BeginInit();
				children9.Add(grid5);
				ISupportInitialize supportInitialize12 = grid3 = grid6;
				context.PushParent(grid3);
				Grid grid7 = grid3;
				Grid.SetColumn(grid7, 1);
				grid7.VerticalAlignment = VerticalAlignment.Center;
				AvaloniaList<Control> children10 = grid7.Children;
				Border border6;
				Border border5 = border6 = new Border();
				((ISupportInitialize)border5).BeginInit();
				children10.Add(border5);
				ISupportInitialize supportInitialize13 = border3 = border6;
				context.PushParent(border3);
				Border border7 = border3;
				border7.Background = new ImmutableSolidColorBrush(452984831U);
				border7.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
				border7.Padding = new Thickness(5.0, 2.0, 5.0, 2.0);
				border7.HorizontalAlignment = HorizontalAlignment.Left;
				AvaloniaProperty isVisibleProperty3 = Visual.IsVisibleProperty;
				CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.HasApy!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider8 = context;
				context.ProvideTargetProperty = Visual.IsVisibleProperty;
				IBinding binding7 = compiledBindingExtension9.ProvideValue(provider8);
				context.ProvideTargetProperty = null;
				border7.Bind(isVisibleProperty3, binding7, null);
				TextBlock textBlock9;
				TextBlock textBlock8 = textBlock9 = new TextBlock();
				((ISupportInitialize)textBlock8).BeginInit();
				border7.Child = textBlock8;
				ISupportInitialize supportInitialize14 = textBlock3 = textBlock9;
				context.PushParent(textBlock3);
				TextBlock textBlock10 = textBlock3;
				AvaloniaProperty textProperty3 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ApyText!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider9 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding8 = compiledBindingExtension10.ProvideValue(provider9);
				context.ProvideTargetProperty = null;
				textBlock10.Bind(textProperty3, binding8, null);
				textBlock10.FontSize = 11.0;
				StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider4 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj5 = staticResourceExtension4.ProvideValue(serviceProvider4);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_2(textBlock10, obj5);
				textBlock10.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock10.FontWeight = FontWeight.Medium;
				context.PopParent();
				supportInitialize14.EndInit();
				context.PopParent();
				supportInitialize13.EndInit();
				context.PopParent();
				supportInitialize12.EndInit();
				AvaloniaList<Control> children11 = grid4.Children;
				TextBlock textBlock12;
				TextBlock textBlock11 = textBlock12 = new TextBlock();
				((ISupportInitialize)textBlock11).BeginInit();
				children11.Add(textBlock11);
				ISupportInitialize supportInitialize15 = textBlock3 = textBlock12;
				context.PushParent(textBlock3);
				TextBlock textBlock13 = textBlock3;
				Grid.SetColumn(textBlock13, 2);
				AvaloniaProperty textProperty4 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PriceString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider10 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding9 = compiledBindingExtension11.ProvideValue(provider10);
				context.ProvideTargetProperty = null;
				textBlock13.Bind(textProperty4, binding9, null);
				textBlock13.FontSize = 13.5;
				StaticResourceExtension staticResourceExtension5 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider5 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj6 = staticResourceExtension5.ProvideValue(serviceProvider5);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_2(textBlock13, obj6);
				textBlock13.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock13.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize15.EndInit();
				AvaloniaList<Control> children12 = grid4.Children;
				TextBlock textBlock15;
				TextBlock textBlock14 = textBlock15 = new TextBlock();
				((ISupportInitialize)textBlock14).BeginInit();
				children12.Add(textBlock14);
				ISupportInitialize supportInitialize16 = textBlock3 = textBlock15;
				context.PushParent(textBlock3);
				TextBlock textBlock16 = textBlock3;
				Grid.SetColumn(textBlock16, 3);
				AvaloniaProperty textProperty5 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Change24HString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider11 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding10 = compiledBindingExtension12.ProvideValue(provider11);
				context.ProvideTargetProperty = null;
				textBlock16.Bind(textProperty5, binding10, null);
				textBlock16.FontSize = 13.5;
				StaticResourceExtension staticResourceExtension6 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider6 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj7 = staticResourceExtension6.ProvideValue(serviceProvider6);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_2(textBlock16, obj7);
				AvaloniaProperty foregroundProperty = TextBlock.ForegroundProperty;
				CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ChangeBrush!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider12 = context;
				context.ProvideTargetProperty = TextBlock.ForegroundProperty;
				IBinding binding11 = compiledBindingExtension13.ProvideValue(provider12);
				context.ProvideTargetProperty = null;
				textBlock16.Bind(foregroundProperty, binding11, null);
				textBlock16.FontWeight = FontWeight.Medium;
				textBlock16.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize16.EndInit();
				AvaloniaList<Control> children13 = grid4.Children;
				TextBlock textBlock18;
				TextBlock textBlock17 = textBlock18 = new TextBlock();
				((ISupportInitialize)textBlock17).BeginInit();
				children13.Add(textBlock17);
				ISupportInitialize supportInitialize17 = textBlock3 = textBlock18;
				context.PushParent(textBlock3);
				TextBlock textBlock19 = textBlock3;
				Grid.SetColumn(textBlock19, 4);
				AvaloniaProperty textProperty6 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.MarketCap!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider13 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding12 = compiledBindingExtension14.ProvideValue(provider13);
				context.ProvideTargetProperty = null;
				textBlock19.Bind(textProperty6, binding12, null);
				textBlock19.FontSize = 13.5;
				StaticResourceExtension staticResourceExtension7 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider7 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj8 = staticResourceExtension7.ProvideValue(serviceProvider7);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_2(textBlock19, obj8);
				textBlock19.Foreground = new ImmutableSolidColorBrush(4289113272U);
				textBlock19.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize17.EndInit();
				AvaloniaList<Control> children14 = grid4.Children;
				TextBlock textBlock21;
				TextBlock textBlock20 = textBlock21 = new TextBlock();
				((ISupportInitialize)textBlock20).BeginInit();
				children14.Add(textBlock20);
				ISupportInitialize supportInitialize18 = textBlock3 = textBlock21;
				context.PushParent(textBlock3);
				TextBlock textBlock22 = textBlock3;
				Grid.SetColumn(textBlock22, 5);
				AvaloniaProperty textProperty7 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.Volume24H!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider14 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding13 = compiledBindingExtension15.ProvideValue(provider14);
				context.ProvideTargetProperty = null;
				textBlock22.Bind(textProperty7, binding13, null);
				textBlock22.FontSize = 13.5;
				StaticResourceExtension staticResourceExtension8 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider8 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj9 = staticResourceExtension8.ProvideValue(serviceProvider8);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_2(textBlock22, obj9);
				textBlock22.Foreground = new ImmutableSolidColorBrush(4289113272U);
				textBlock22.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize18.EndInit();
				AvaloniaList<Control> children15 = grid4.Children;
				Viewbox viewbox6;
				Viewbox viewbox5 = viewbox6 = new Viewbox();
				((ISupportInitialize)viewbox5).BeginInit();
				children15.Add(viewbox5);
				ISupportInitialize supportInitialize19 = viewbox3 = viewbox6;
				context.PushParent(viewbox3);
				Viewbox viewbox7 = viewbox3;
				Grid.SetColumn(viewbox7, 6);
				viewbox7.Width = 115.0;
				viewbox7.Height = 26.0;
				viewbox7.VerticalAlignment = VerticalAlignment.Center;
				viewbox7.HorizontalAlignment = HorizontalAlignment.Left;
				Path path6;
				Path path5 = path6 = new Path();
				((ISupportInitialize)path5).BeginInit();
				viewbox7.Child = path5;
				ISupportInitialize supportInitialize20 = path3 = path6;
				context.PushParent(path3);
				Path path7 = path3;
				AvaloniaProperty dataProperty = Path.DataProperty;
				CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendPath!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider15 = context;
				context.ProvideTargetProperty = Path.DataProperty;
				IBinding binding14 = compiledBindingExtension16.ProvideValue(provider15);
				context.ProvideTargetProperty = null;
				path7.Bind(dataProperty, binding14, null);
				AvaloniaProperty strokeProperty = Shape.StrokeProperty;
				CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.TrendBrush!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider16 = context;
				context.ProvideTargetProperty = Shape.StrokeProperty;
				IBinding binding15 = compiledBindingExtension17.ProvideValue(provider16);
				context.ProvideTargetProperty = null;
				path7.Bind(strokeProperty, binding15, null);
				path7.StrokeThickness = 2.0;
				path7.StrokeLineCap = PenLineCap.Round;
				path7.Fill = new ImmutableSolidColorBrush(16777215U);
				context.PopParent();
				supportInitialize20.EndInit();
				context.PopParent();
				supportInitialize19.EndInit();
				AvaloniaList<Control> children16 = grid4.Children;
				TextBlock textBlock24;
				TextBlock textBlock23 = textBlock24 = new TextBlock();
				((ISupportInitialize)textBlock23).BeginInit();
				children16.Add(textBlock23);
				ISupportInitialize supportInitialize21 = textBlock3 = textBlock24;
				context.PushParent(textBlock3);
				TextBlock textBlock25 = textBlock3;
				Grid.SetColumn(textBlock25, 7);
				AvaloniaProperty textProperty8 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.BalanceString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider17 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding16 = compiledBindingExtension18.ProvideValue(provider17);
				context.ProvideTargetProperty = null;
				textBlock25.Bind(textProperty8, binding16, null);
				textBlock25.FontSize = 13.5;
				StaticResourceExtension staticResourceExtension9 = new StaticResourceExtension("RobotoCondensedRegular");
				IServiceProvider serviceProvider9 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj10 = staticResourceExtension9.ProvideValue(serviceProvider9);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_2(textBlock25, obj10);
				textBlock25.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock25.FontWeight = FontWeight.Normal;
				textBlock25.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize21.EndInit();
				AvaloniaList<Control> children17 = grid4.Children;
				TextBlock textBlock27;
				TextBlock textBlock26 = textBlock27 = new TextBlock();
				((ISupportInitialize)textBlock26).BeginInit();
				children17.Add(textBlock26);
				ISupportInitialize supportInitialize22 = textBlock3 = textBlock27;
				context.PushParent(textBlock3);
				TextBlock textBlock28 = textBlock3;
				Grid.SetColumn(textBlock28, 8);
				AvaloniaProperty textProperty9 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.ValueInUsdString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider18 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding17 = compiledBindingExtension19.ProvideValue(provider18);
				context.ProvideTargetProperty = null;
				textBlock28.Bind(textProperty9, binding17, null);
				textBlock28.FontSize = 13.5;
				StaticResourceExtension staticResourceExtension10 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider10 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj11 = staticResourceExtension10.ProvideValue(serviceProvider10);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_2(textBlock28, obj11);
				textBlock28.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
				textBlock28.FontWeight = FontWeight.Normal;
				textBlock28.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize22.EndInit();
				AvaloniaList<Control> children18 = grid4.Children;
				TextBlock textBlock30;
				TextBlock textBlock29 = textBlock30 = new TextBlock();
				((ISupportInitialize)textBlock29).BeginInit();
				children18.Add(textBlock29);
				ISupportInitialize supportInitialize23 = textBlock3 = textBlock30;
				context.PushParent(textBlock3);
				TextBlock textBlock31 = textBlock3;
				Grid.SetColumn(textBlock31, 9);
				AvaloniaProperty textProperty10 = TextBlock.TextProperty;
				CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Exodus.Models.PortfolioCoinItem,Exodus.PortfolioPercentageString!Property(), new Func<WeakReference<object>, IPropertyInfo, IPropertyAccessor>(PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)).Build());
				IServiceProvider provider19 = context;
				context.ProvideTargetProperty = TextBlock.TextProperty;
				IBinding binding18 = compiledBindingExtension20.ProvideValue(provider19);
				context.ProvideTargetProperty = null;
				textBlock31.Bind(textProperty10, binding18, null);
				textBlock31.FontSize = 13.5;
				StaticResourceExtension staticResourceExtension11 = new StaticResourceExtension("RobotoRegular");
				IServiceProvider serviceProvider11 = context;
				context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
				object obj12 = staticResourceExtension11.ProvideValue(serviceProvider11);
				context.ProvideTargetProperty = null;
				PortfolioView.XamlClosure_81.DynamicSetters_82.DynamicSetter_2(textBlock31, obj12);
				textBlock31.Foreground = new ImmutableSolidColorBrush(4287271584U);
				textBlock31.VerticalAlignment = VerticalAlignment.Center;
				context.PopParent();
				supportInitialize23.EndInit();
				context.PopParent();
				supportInitialize2.EndInit();
				context.PopParent();
				supportInitialize.EndInit();
				context.PopParent();
				((ISupportInitialize)intermediateRoot).EndInit();
				return intermediateRoot;
			}

			// Token: 0x0200002B RID: 43
			private class DynamicSetters_82
			{
				// Token: 0x0600005D RID: 93 RVA: 0x0001D480 File Offset: 0x0001B680
				public static void DynamicSetter_1(Button A_0, CompiledBindingExtension A_1)
				{
					if (A_1 != null)
					{
						A_0.Bind(Button.CommandParameterProperty, A_1, null);
						return;
					}
					A_0.CommandParameter = A_1;
				}

				// Token: 0x0600005E RID: 94 RVA: 0x0001D4AC File Offset: 0x0001B6AC
				public static void DynamicSetter_2(TextBlock A_0, object A_1)
				{
					if (A_1 is UnsetValueType)
					{
						A_0.SetValue(TextBlock.FontFamilyProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
						return;
					}
					if (A_1 is IBinding)
					{
						A_0.Bind(TextBlock.FontFamilyProperty, A_1, null);
						return;
					}
					if (A_1 is FontFamily)
					{
						A_0.FontFamily = A_1;
						return;
					}
					if (A_1 == null)
					{
						A_0.FontFamily = A_1;
						return;
					}
					throw new InvalidCastException();
				}

				// Token: 0x0600005F RID: 95 RVA: 0x0001D518 File Offset: 0x0001B718
				public static void DynamicSetter_3(Path A_0, object A_1)
				{
					if (A_1 is UnsetValueType)
					{
						A_0.SetValue(Path.DataProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
						return;
					}
					if (A_1 is IBinding)
					{
						A_0.Bind(Path.DataProperty, A_1, null);
						return;
					}
					if (A_1 is Geometry)
					{
						A_0.Data = A_1;
						return;
					}
					if (A_1 == null)
					{
						A_0.Data = A_1;
						return;
					}
					throw new InvalidCastException();
				}
			}
		}
	}
}
