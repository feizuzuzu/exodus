﻿using System;
using System.ComponentModel;
using System.Globalization;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Collections;
using Avalonia.Controls;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;

namespace Exodus.Controls
{
	// Token: 0x0200008F RID: 143
	public class ThreeDotAnimation : Border
	{
		// Token: 0x060003F4 RID: 1012 RVA: 0x00035CC3 File Offset: 0x00033EC3
		public ThreeDotAnimation()
		{
			this.InitializeComponent(true);
		}

		// Token: 0x060003F5 RID: 1013 RVA: 0x00035CD2 File Offset: 0x00033ED2
		public void InitializeComponent(bool loadXaml = true)
		{
			if (loadXaml)
			{
				ThreeDotAnimation.!XamlIlPopulateTrampoline(this);
			}
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x00035CE0 File Offset: 0x00033EE0
		static void !XamlIlPopulate(IServiceProvider A_0, ThreeDotAnimation A_1)
		{
			XamlIlContext.Context<ThreeDotAnimation> context = new XamlIlContext.Context<ThreeDotAnimation>(A_0, new object[]
			{
				(object)CompiledAvaloniaXaml.!AvaloniaResources.NamespaceInfo:/Controls/ThreeDotAnimation.axaml.Singleton
			}, "avares://Exodus/Controls/ThreeDotAnimation.axaml");
			context.RootObject = A_1;
			context.IntermediateRoot = A_1;
			((ISupportInitialize)A_1).BeginInit();
			context.PushParent(A_1);
			A_1.Width = 18.0;
			A_1.Background = new ImmutableSolidColorBrush(16777215U);
			Grid grid2;
			Grid grid = grid2 = new Grid();
			((ISupportInitialize)grid).BeginInit();
			A_1.Child = grid;
			Grid grid3;
			ISupportInitialize supportInitialize = grid3 = grid2;
			context.PushParent(grid3);
			Grid grid4 = grid3;
			grid4.HorizontalAlignment = HorizontalAlignment.Stretch;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 3;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid4.ColumnDefinitions = columnDefinitions;
			AvaloniaList<Control> children = grid4.Children;
			Viewbox viewbox2;
			Viewbox viewbox = viewbox2 = new Viewbox();
			((ISupportInitialize)viewbox).BeginInit();
			children.Add(viewbox);
			Viewbox viewbox3;
			ISupportInitialize supportInitialize2 = viewbox3 = viewbox2;
			context.PushParent(viewbox3);
			Viewbox viewbox4 = viewbox3;
			Grid.SetColumn(viewbox4, 0);
			viewbox4.Width = 3.25;
			viewbox4.HorizontalAlignment = HorizontalAlignment.Center;
			viewbox4.VerticalAlignment = VerticalAlignment.Center;
			viewbox4.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Viewbox)),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(20000000L),
						Delay = TimeSpan.FromTicks(10000000L),
						IterationCount = IterationCount.Parse("Infinite"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = Visual.OpacityProperty,
										Value = 0.85
									},
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 1.0
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 1.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("50%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = Visual.OpacityProperty,
										Value = 0.35
									},
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 0.935
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 0.935
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = Visual.OpacityProperty,
										Value = 0.85
									},
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 1.0
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 1.0
									}
								}
							}
						}
					}
				}
			});
			Path path2;
			Path path = path2 = new Path();
			((ISupportInitialize)path).BeginInit();
			viewbox4.Child = path;
			Path path3;
			ISupportInitialize supportInitialize3 = path3 = path2;
			context.PushParent(path3);
			Path path4 = path3;
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("CircleDot");
			IServiceProvider serviceProvider = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj = staticResourceExtension.ProvideValue(serviceProvider);
			context.ProvideTargetProperty = null;
			ThreeDotAnimation.DynamicSetters_23.DynamicSetter_1(path4, obj);
			path4.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			path4.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize3.EndInit();
			context.PopParent();
			supportInitialize2.EndInit();
			AvaloniaList<Control> children2 = grid4.Children;
			Viewbox viewbox6;
			Viewbox viewbox5 = viewbox6 = new Viewbox();
			((ISupportInitialize)viewbox5).BeginInit();
			children2.Add(viewbox5);
			ISupportInitialize supportInitialize4 = viewbox3 = viewbox6;
			context.PushParent(viewbox3);
			Viewbox viewbox7 = viewbox3;
			Grid.SetColumn(viewbox7, 1);
			viewbox7.Width = 3.25;
			viewbox7.HorizontalAlignment = HorizontalAlignment.Center;
			viewbox7.VerticalAlignment = VerticalAlignment.Center;
			viewbox7.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Viewbox)),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(20000000L),
						Delay = TimeSpan.FromTicks(15000000L),
						IterationCount = IterationCount.Parse("Infinite"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = Visual.OpacityProperty,
										Value = 0.85
									},
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 1.0
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 1.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("50%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = Visual.OpacityProperty,
										Value = 0.35
									},
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 0.935
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 0.935
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = Visual.OpacityProperty,
										Value = 0.85
									},
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 1.0
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 1.0
									}
								}
							}
						}
					}
				}
			});
			Path path6;
			Path path5 = path6 = new Path();
			((ISupportInitialize)path5).BeginInit();
			viewbox7.Child = path5;
			ISupportInitialize supportInitialize5 = path3 = path6;
			context.PushParent(path3);
			Path path7 = path3;
			StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("CircleDot");
			IServiceProvider serviceProvider2 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj2 = staticResourceExtension2.ProvideValue(serviceProvider2);
			context.ProvideTargetProperty = null;
			ThreeDotAnimation.DynamicSetters_23.DynamicSetter_1(path7, obj2);
			path7.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			path7.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize5.EndInit();
			context.PopParent();
			supportInitialize4.EndInit();
			AvaloniaList<Control> children3 = grid4.Children;
			Viewbox viewbox9;
			Viewbox viewbox8 = viewbox9 = new Viewbox();
			((ISupportInitialize)viewbox8).BeginInit();
			children3.Add(viewbox8);
			ISupportInitialize supportInitialize6 = viewbox3 = viewbox9;
			context.PushParent(viewbox3);
			Viewbox viewbox10 = viewbox3;
			Grid.SetColumn(viewbox10, 2);
			viewbox10.Width = 3.25;
			viewbox10.HorizontalAlignment = HorizontalAlignment.Center;
			viewbox10.VerticalAlignment = VerticalAlignment.Center;
			viewbox10.Styles.Add(new Style
			{
				Selector = Selectors.OfType((Selector)null, typeof(Viewbox)),
				Animations = 
				{
					new Animation
					{
						Duration = TimeSpan.FromTicks(20000000L),
						IterationCount = IterationCount.Parse("Infinite"),
						Children = 
						{
							new KeyFrame
							{
								Cue = Cue.Parse("0%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = Visual.OpacityProperty,
										Value = 0.85
									},
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 1.0
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 1.0
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("50%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = Visual.OpacityProperty,
										Value = 0.35
									},
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 0.935
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 0.935
									}
								}
							},
							new KeyFrame
							{
								Cue = Cue.Parse("100%", CultureInfo.InvariantCulture),
								Setters = 
								{
									new Setter
									{
										Property = Visual.OpacityProperty,
										Value = 0.85
									},
									new Setter
									{
										Property = ScaleTransform.ScaleXProperty,
										Value = 1.0
									},
									new Setter
									{
										Property = ScaleTransform.ScaleYProperty,
										Value = 1.0
									}
								}
							}
						}
					}
				}
			});
			Path path9;
			Path path8 = path9 = new Path();
			((ISupportInitialize)path8).BeginInit();
			viewbox10.Child = path8;
			ISupportInitialize supportInitialize7 = path3 = path9;
			context.PushParent(path3);
			Path path10 = path3;
			StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("CircleDot");
			IServiceProvider serviceProvider3 = context;
			context.ProvideTargetProperty = Path.DataProperty;
			object obj3 = staticResourceExtension3.ProvideValue(serviceProvider3);
			context.ProvideTargetProperty = null;
			ThreeDotAnimation.DynamicSetters_23.DynamicSetter_1(path10, obj3);
			path10.Fill = new ImmutableSolidColorBrush(uint.MaxValue);
			path10.Stretch = Stretch.Uniform;
			context.PopParent();
			supportInitialize7.EndInit();
			context.PopParent();
			supportInitialize6.EndInit();
			context.PopParent();
			supportInitialize.EndInit();
			context.PopParent();
			((ISupportInitialize)A_1).EndInit();
			StyledElement styled;
			if ((styled = (A_1 as StyledElement)) != null)
			{
				NameScope.SetNameScope(styled, context.AvaloniaNameScope);
			}
			context.AvaloniaNameScope.Complete();
		}

		// Token: 0x060003F7 RID: 1015 RVA: 0x000367D5 File Offset: 0x000349D5
		private static void !XamlIlPopulateTrampoline(ThreeDotAnimation A_0)
		{
			if (ThreeDotAnimation.!XamlIlPopulateOverride != null)
			{
				ThreeDotAnimation.!XamlIlPopulateOverride(A_0);
				return;
			}
			ThreeDotAnimation.!XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), A_0);
		}

		// Token: 0x04000227 RID: 551
		private static Action<object> !XamlIlPopulateOverride;

		// Token: 0x02000090 RID: 144
		private class DynamicSetters_23
		{
			// Token: 0x060003F8 RID: 1016 RVA: 0x000367FC File Offset: 0x000349FC
			public static void DynamicSetter_1(Path A_0, object A_1)
			{
				if (A_1 is UnsetValueType)
				{
					A_0.SetValue(Path.DataProperty, AvaloniaProperty.UnsetValue, BindingPriority.LocalValue);
					return;
				}
				if (A_1 is IBinding)
				{
					A_0.Bind(Path.DataProperty, A_1, null);
					return;
				}
				if (A_1 is Geometry)
				{
					A_0.Data = A_1;
					return;
				}
				if (A_1 == null)
				{
					A_0.Data = A_1;
					return;
				}
				throw new InvalidCastException();
			}
		}
	}
}
