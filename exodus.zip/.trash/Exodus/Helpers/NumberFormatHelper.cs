﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;

namespace Exodus.Helpers
{
	// Token: 0x0200008C RID: 140
	[NullableContext(1)]
	[Nullable(0)]
	public static class NumberFormatHelper
	{
		// Token: 0x060003EE RID: 1006 RVA: 0x00035A74 File Offset: 0x00033C74
		public static string FormatCrypto(double amount, int maxDecimals = 8)
		{
			if (amount == 0.0)
			{
				return "0";
			}
			string s = amount.ToString("0." + new string('#', maxDecimals), CultureInfo.InvariantCulture);
			long intPart2;
			if (s.Contains('.'))
			{
				string[] parts = s.Split('.', StringSplitOptions.None);
				long intPart;
				if (long.TryParse(parts[0], out intPart))
				{
					return intPart.ToString("N0", NumberFormatHelper.UsCulture) + "." + parts[1];
				}
			}
			else if (long.TryParse(s, out intPart2))
			{
				return intPart2.ToString("N0", NumberFormatHelper.UsCulture);
			}
			return s;
		}

		// Token: 0x04000226 RID: 550
		private static readonly CultureInfo UsCulture = new CultureInfo("en-US");
	}
}
