﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Exodus.Helpers
{
	// Token: 0x0200008D RID: 141
	public static class UrlUtils
	{
		// Token: 0x060003F0 RID: 1008 RVA: 0x00035B20 File Offset: 0x00033D20
		[NullableContext(1)]
		public static void OpenUrl(string url)
		{
			if (string.IsNullOrWhiteSpace(url))
			{
				return;
			}
			try
			{
				Process.Start(new ProcessStartInfo
				{
					FileName = url,
					UseShellExecute = true
				});
			}
			catch
			{
				try
				{
					if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
					{
						Process.Start(new ProcessStartInfo("cmd", "/c start \"\" \"" + url + "\"")
						{
							CreateNoWindow = true,
							UseShellExecute = false
						});
					}
					else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
					{
						Process.Start("xdg-open", url);
					}
					else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
					{
						Process.Start("open", url);
					}
				}
				catch
				{
				}
			}
		}
	}
}
