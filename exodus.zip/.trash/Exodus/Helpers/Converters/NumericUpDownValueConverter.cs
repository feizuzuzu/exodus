﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using Avalonia.Data.Converters;

namespace Exodus.Helpers.Converters
{
	// Token: 0x0200008E RID: 142
	public class NumericUpDownValueConverter : IValueConverter
	{
		// Token: 0x060003F1 RID: 1009 RVA: 0x00035BE4 File Offset: 0x00033DE4
		[NullableContext(1)]
		public object Convert([Nullable(2)] object value, Type targetType, [Nullable(2)] object parameter, CultureInfo culture)
		{
			if (value == null)
			{
				return 0;
			}
			return ((IConvertible)value).ToDecimal(culture);
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x00035C04 File Offset: 0x00033E04
		[NullableContext(1)]
		public object ConvertBack([Nullable(2)] object value, Type targetType, [Nullable(2)] object parameter, CultureInfo culture)
		{
			if (value == null)
			{
				if (targetType == typeof(int))
				{
					return 0;
				}
				if (targetType == typeof(double))
				{
					return 1E-08;
				}
				throw new ArgumentNullException("Unsupported type: " + targetType.FullName);
			}
			else
			{
				if (targetType == typeof(int))
				{
					return ((IConvertible)value).ToInt32(culture);
				}
				if (targetType == typeof(double))
				{
					return ((IConvertible)value).ToDouble(culture);
				}
				throw new ArgumentNullException("Unsupported type: " + targetType.FullName);
			}
		}
	}
}
